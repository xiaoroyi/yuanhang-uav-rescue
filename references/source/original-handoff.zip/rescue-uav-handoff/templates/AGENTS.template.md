# AGENTS.md | 援航：所有 Codex 的长期规范模板

> 仓库已有 AGENTS.md 时**合并**这些规则，不要盲目覆盖。

## 必读顺序

1. `docs/CODEX_MASTER_HANDOFF.md`（全量功能、设计和无日期任务）。
2. `docs/INTEGRATION_PACT.md`（三方字段与算法/HTTP 接口）。
3. `docs/DECISIONS.md`、`docs/IMPLEMENTATION_STATUS.md`、`docs/08-TASK-BOARD.md`。
4. `contracts/*.schema.json`，当前目录更具体的 `AGENTS.md`。

## 模块责任与权限

A 仅负责 `solver/`；B 仅负责 `frontend/`；C 仅负责 `backend/` 和部署集成。公共契约/docs/CI 经相关 owner 审核才修改，不擅自跨模块重写。三个 Codex 不可以各自定义一套 `Scenario`、`Plan`、`Event` 或 `SolveJob`。

## 单一数据真值

业务对象以已批准的 `contracts/*.schema.json` 为结构真值；FastAPI OpenAPI 是实现后的 HTTP 真值；前端 TS 类型自动生成。几何 EPSG:4326 [经度,纬度]，质量 kg、容积 L、能量 kWh、速度 m/s、相对时间秒、SOC/SOH 为 [0,1]，绝对时刻带时区。未知数用 null 和明确状态，不猜测。

## 诚信与安全边界

该项目是决策支持和模拟，不是飞控/实飞适航认证。Mock 不能显示已验证；历史数模结果不能冒充当前求解；未评估通信/地形不能冒充通过。求解器 UNKNOWN 不是 INFEASIBLE；有限模型 OPTIMAL 不是现实全局最优；任何新结果须有可追溯 Snapshot、Solver 实跑和独立验证。

## 代码与协作

- A 提供纯 Python `solver/public_api.py`，不访问 FastAPI/SQLite。C 只通过稳定接口调用算法。B 只消费后端 API，不在 JS 里计算电池安全或规划目标。
- 每次只领取 1 张小范围任务卡，先计划，再实现，再跑实际测试，再 PR。首次初始化只做规范与契约，不一次性生成全部系统。
- 共享字段变更必须 `RFC → 相关三方同意 → 同一 PR 更新 Schema、Pydantic、fixtures、TS、测试、文档`。
- 禁止 secret/身份信息/私人数据入库；比赛展示素材与源代码按匿名要求检查。

## 每次任务完成报告

TASK ID、修改文件、实现/未实现内容、接口变更、实际运行命令与 PASS/FAIL/未运行、可复现输入/输出、验证范围、后续依赖/阻塞。不得口头宣称测试通过而没有执行证据。
