# RFC-XXX｜公共契约变更申请

- 发起人 / Owner：
- 相关任务 ID：
- 当前生效合同版本与原字段：
- 变更动机（哪种真实使用场景不能表达）：
- 受影响对象：Scenario / Snapshot / Plan / Event / SolveJob / SolverOptions / HTTP API / UI
- 字段类型、必填性、默认值和单位：
- 新旧 JSON 样例及有效/无效示例：
- 是新增可选字段还是破坏性升级：
- 向后兼容和迁移（旧 Snapshot/Plan 如何回读）：
- 模型范围与真实性标记如何改变：
- 受影响代码路径（solver/backend/frontend/tests/fixtures/docs）：
- 测试清单：
- A 算法确认：待审/同意/需改
- B 前端确认：待审/同意/需改
- C 后端确认：待审/同意/需改
- 审批后的 schema 版本和实施 PR：
