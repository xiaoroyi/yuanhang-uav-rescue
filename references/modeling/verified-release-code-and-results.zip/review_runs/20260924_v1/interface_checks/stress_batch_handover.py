"""Exactly two fixed-margin checks for the conservative station-completion plan."""
from margin_stress import main,HERE,RUN

if __name__=='__main__':
    main([('batch_slack',RUN/'q3_performance/results/small_batch_slack_4')],HERE/'margin_stress_batch_slack')
