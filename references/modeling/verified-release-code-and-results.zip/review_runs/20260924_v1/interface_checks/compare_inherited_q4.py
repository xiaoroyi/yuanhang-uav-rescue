"""Keep three separately frozen Q3->Q4 chains comparable and traceable."""
from check_interfaces import *
from fractions import Fraction


def main():
    chains=[('old_baseline',PROJECT/'问题3/results',HERE/'q4_baseline_replay'),
            ('local_site_fast',HERE.parent/'q3_local_sites/refined/position_time_first',HERE/'q4_local_sites_refined'),
            ('joint_tradeoff',HERE.parent/'q3_performance/results/small_trade_4',HERE/'q4_small_trade_4'),
            ('energy_pruned_tight',HERE/'q3_energy_pruned_tight',HERE/'q4_small_energy_4'),
            ('station_complete_candidate',HERE.parent/'q3_performance/results/small_batch_slack_4',HERE/'q4_batch_slack_4')]
    output=[];lineage=[]
    for version,q3,q4dir in chains:
        manifest=json.loads((q4dir/'input_manifest.json').read_text(encoding='utf-8'))
        for path,expected in manifest.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,(version,path,'source changed')
        s=json.loads((q3/'solution_summary.json').read_text(encoding='utf-8'));r=json.loads((q4dir/'run_summary.json').read_text(encoding='utf-8'));comp=json.loads((q4dir/'components_q4.json').read_text(encoding='utf-8'))
        station_path=q3/'station_delivery_comparison.csv'
        station_rows=list(csv.DictReader(station_path.open(encoding='utf-8-sig',newline=''))) if station_path.exists() else []
        station_slack=min((float(z['hard_slack']) for z in station_rows if z.get('hard_slack') not in [None,'']),default=None)
        station_late=sum(float(z['soft_late']) for z in station_rows) if station_rows else None
        for k in (2,3):
            solution=json.loads((q4dir/f'solution_k{k}.json').read_text(encoding='utf-8'));p=solution['selected'];balanced=solution['balanced']
            output.append(dict(version=version,K=k,D=s['D'],C_joint_s=s['C_joint'],E_total_kwh=s['E_total'],N_transport=s['N_transport'],N_relay=s['N_relay'],
                               min_hard_slack_s=s['min_hard_slack'],reported_delivery_scope='sequential box completion',station_complete_min_hard_slack_s=station_slack,station_complete_total_soft_late_s=station_late,
                               atoms=len(comp['atoms']),partition=p['partition'],N=json.dumps(p['N']),gap=json.dumps(p['gap']),Jgap_exact=p['Jgap'],Jgap=float(Fraction(p['Jgap'])),
                               Jsize_exact=p['Jsize'],CV2=float(Fraction(p['CV2'])),max_deviation=float(Fraction(p['max_deviation'])),pooled_work_s=float(r['pooled_W']),
                               balanced_partition=balanced['partition'],balanced_CV2=float(Fraction(balanced['CV2'])),balanced_gap=json.dumps(balanced['gap']),
                               q3_path=str(q3),q4_path=str(q4dir),q3_sha256=r['source_task_hash'],all_inherited_source_hashes_current=True))
        lineage.append(dict(version=version,source_directory=str(q3),q4_directory=str(q4dir),source_hash=r['source_task_hash'],all_frozen_sources_unchanged=True,components=comp['atoms'],source_tie_invariance_tested=version=='old_baseline'))
    table('q3_q4_current_chains_comparison.csv',output);dump('q3_q4_current_chains_lineage.json',lineage)
    print(json.dumps(output,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
