"""Create a separate Q3 candidate deleting zero-actual-client relay sorties."""
from pathlib import Path
import sys,json,csv,copy,hashlib

HERE=Path(__file__).resolve().parent;RUN=HERE.parent
sys.path.insert(0,str(RUN/'q3/src'))
from setup_q3 import dump
from validate_q3 import run


def main():
    source=RUN/'q3_performance/results/small_energy_4';target=HERE/'q3_energy_pruned';target.mkdir(exist_ok=True)
    used=set()
    for filename in ['communication_intervals_q3.csv','communication_event_points_q3.csv']:
        for row in csv.DictReader((source/filename).open(encoding='utf-8-sig',newline='')):
            if row['source']!='G01':used.add(row['source'])
    original=json.loads((source/'solution_q3.json').read_text(encoding='utf-8'));new=copy.deepcopy(original);removed=[r for r in new['relay'] if r['sortie'] not in used];assert removed
    new['relay']=[r for r in new['relay'] if r['sortie'] in used];new['assignment']=[];new['grid_metrics']={};new['scope']='Original energy plan with no-client relay sorties removed; all other physical tasks, starts, positions, energy parameters, and original entity IDs frozen; independent full-time communication revalidation required.'
    dump(target/'solution_q3.json',new);report=run(target/'solution_q3.json');assert report['summary']['valid']
    dump(target/'pruning_evidence.json',dict(valid=True,original_solution=str(source/'solution_q3.json'),original_sha256=hashlib.sha256((source/'solution_q3.json').read_bytes()).hexdigest(),removed_sorties=removed,
                                          removed_total_energy_kwh=sum(r['energy'] for r in removed),transport_exactly_unchanged=original['transport']==new['transport'],new_summary=report['summary'],reason='No assigned customer in either original continuous interval records or event-point records. Deletion confirmed by complete independent Q3 validation, not just a table test.'))
    print(json.dumps(dict(removed=[r['sortie'] for r in removed],summary=report['summary']),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
