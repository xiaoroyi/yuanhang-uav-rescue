"""Read-only audits of original results; all new artifacts stay beside this file."""
from pathlib import Path
import sys, json, csv, itertools, time, copy, hashlib
from collections import Counter, defaultdict
from decimal import Decimal

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
sys.path.insert(0, str(PROJECT/'问题4/src'))
import solve_q4 as q4
from setup_q3 import inputs
from routes import Physics
from flight_physics import D, safe_capacity, metrics
from data_io import CATEGORIES
from scipy.optimize import milp, Bounds, LinearConstraint
import numpy as np


def dump(name, obj):
    q4.dump(HERE/name, obj)


def table(name, rows):
    q4.table(HERE/name, rows)


def q1_dominance(data, P):
    geos = json.loads((PROJECT/'问题1/results/terrain_evidence.json').read_text(encoding='utf-8'))
    A, B = data['models']['A'], data['models']['B']
    capacities=[]
    for s in data['services']:
        for g in 'AB':
            capacities.append(dict(service=s, model=g, **safe_capacity(data['models'][g], geos[s], D('.2'))))
    coef=D(54000)/(D(30)*D(30).sqrt())-D(20000)/(D(25)*D(25).sqrt())
    endpoint=D(26000)-coef*D(25)*D(25).sqrt()
    checks=dict(range_numerator_min_positive=endpoint>0,
                B_safe_capacity_all_ge_25=all(r['capacity_kg']>=25 for r in capacities if r['model']=='B'),
                B_volume_ge_A=B['volume_L']>=A['volume_L'],
                B_mass_lt_A=B['m0']<A['m0'],same_efficiency=B['eta']==A['eta'],
                B_speed_ge_A=B['speed']>=A['speed'],
                same_vertical_and_handling=all(A[k]==B[k] for k in ['up','down','prep','load','handover','handover_box']))
    samples=[]
    for i in range(251):
        load=i/10
        LA=A['L0']-(A['L0']-A['LF'])*(load/A['Q'])**1.5
        LB=B['L0']-(B['L0']-B['LF'])*(load/B['Q'])**1.5
        samples.append(dict(payload_kg=load,A_range_m=LA,B_range_m=LB,A_horizontal_kwh_per_km=1000*A['Euse']/LA,B_horizontal_kwh_per_km=1000*B['Euse']/LB))
    report=dict(status='PASS' if all(checks.values()) else 'FAIL',checks=checks,
                minimum_analytic_range_numerator=endpoint,
                numerator_expression='4.5*L_B(q)-4*L_A(q)=26000-[54000/30^(3/2)-20000/25^(3/2)]q^(3/2)',
                scope='Q1 baseline reserve 20%, single-stop missions, no finite type-B fleet/battery scheduling; absolute energy dominance is not SOC dominance.',
                models={g:data['models'][g] for g in 'AB'},min_B_safe_load=min(r['capacity_kg'] for r in capacities if r['model']=='B'))
    dump('q1_A_dominance.json',report);table('q1_AB_safe_capacities.csv',capacities);table('q1_AB_energy_payload_curve.csv',samples)
    return report


def q2_to_q1(data,P):
    begin=time.time();geos=json.loads((PROJECT/'问题1/results/terrain_evidence.json').read_text(encoding='utf-8'))
    by=defaultdict(list)
    for box in data['boxes']:by[box['service']].append(box['id'])
    patterns={};subset_rows=[];maxE=maxT=0.
    for s,ids in sorted(by.items()):
        accepted=0;attempted=0
        for mask in range(1,1<<len(ids)):
            bs=[b for i,b in enumerate(ids) if mask>>i&1]
            counts=tuple(sum(P.boxes[b]['category']==c for b in bs) for c in CATEGORIES)
            for g in 'ABC':
                attempted+=1;r=P.evaluate(g,[(s,bs)],screen=False)
                if r is None:continue
                accepted+=1;key=(s,g,counts)
                native=metrics(data['models'][g],geos[s],r['mass'],len(bs))
                maxE=max(maxE,abs(float(native['E'])-r['energy']));maxT=max(maxT,abs(float(native['T'])-r['duration']))
                if key not in patterns:
                    patterns[key]=dict(service=s,model=g,counts=list(counts),energy_kwh=r['energy'],operation_s=r['duration'],mass_kg=r['mass'],volume_L=r['volume'],representative_boxes=bs,identity_multiplicity=0)
                patterns[key]['identity_multiplicity']+=1
        subset_rows.append(dict(service=s,boxes=len(ids),all_nonempty_subsets=(1<<len(ids))-1,all_model_attempts=attempted,feasible_identity_patterns=accepted,distinct_count_patterns=sum(k[0]==s for k in patterns)))
        print('Q2_TO_Q1',s,attempted,accepted,flush=True)
    pp=list(patterns.values());n=len(pp)
    A=[];b=[]
    for s in data['services']:
        for k in range(4):
            A.append([p['counts'][k] if p['service']==s else 0 for p in pp]);b.append(data['counts'][s][k])
    matrix=np.array(A,float);lo=np.array(b,float);hi=lo.copy()
    costs=[np.ones(n),np.array([p['energy_kwh'] for p in pp]),np.array([p['operation_s'] for p in pp])]
    log=[];selected=[]
    for stage,cost in enumerate(costs):
        # Independent integer set-partitioning, not Q1's recursive count DP.
        ans=milp(cost,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.full(n,np.inf)),constraints=LinearConstraint(matrix,lo,hi),options={'mip_rel_gap':0,'time_limit':60})
        assert ans.success,ans.message
        xx=np.rint(ans.x).astype(int)
        assert np.max(np.abs(ans.x-xx))<1e-5 and np.all(xx>=0)
        reconstructed=matrix@xx
        assert np.all(reconstructed>=lo-1e-7) and np.all(reconstructed<=hi+1e-7)
        selected=[dict(p,multiplicity=int(xx[i])) for i,p in enumerate(pp) if xx[i]]
        totals=[float(v@xx) for v in costs]
        log.append(dict(stage=['N','E','cumulative_T'][stage],status=ans.message,objective=float(ans.fun),lower_bound=float(ans.mip_dual_bound),gap=float(ans.mip_gap),totals=totals))
        if stage==0:
            matrix=np.vstack([matrix,cost]);lo=np.r_[lo,round(ans.fun)];hi=np.r_[hi,round(ans.fun)]
        if stage==1:
            # This equality is numerical within 1e-8 kWh; all final costs are re-evaluated.
            matrix=np.vstack([matrix,cost]);lo=np.r_[lo,ans.fun-1e-8];hi=np.r_[hi,ans.fun+1e-8]
    target=json.loads((PROJECT/'问题1/results/solution_summary.json').read_text(encoding='utf-8'))
    diff=dict(N=totals[0]-target['N'],E=totals[1]-target['E_kwh'],T=totals[2]-target['T_s'])
    report=dict(status='PASS' if diff['N']==0 and abs(diff['E'])<1e-7 and abs(diff['T'])<1e-6 else 'FAIL',
                all_single_stop_box_subsets_enumerated=True,screen=False,removed=['hard_deadlines','timeliness','aircraft_entity_count','battery_count_and_charging'],
                objective='lex(N,total_energy,cumulative_operation_time)',identity_feasible_patterns=sum(r['feasible_identity_patterns'] for r in subset_rows),compressed_patterns=n,
                Q1_physics_max_E_difference=maxE,Q1_physics_max_T_difference=maxT,Q1_target=target,totals=totals,differences=diff,solver_stages=log,elapsed_s=time.time()-begin,
                scope='All 80 boxes and all single-service subsets, exact category symmetry compression because individual time deadlines are removed; original Q2 multistop+schedule optimization is not certified by this test.')
    table('q2_degenerate_subset_counts.csv',subset_rows);table('q2_degenerate_patterns.csv',pp);table('q2_degenerate_selected.csv',selected);dump('q2_to_q1_degeneracy.json',report)
    return report


def q4_interface(data):
    directory=PROJECT/'问题3/results';sol=q4.read(directory/'solution_q3.json');ints=q4.rows(directory/'communication_intervals_q3.csv');pts=q4.rows(directory/'communication_event_points_q3.csv')
    comp=q4.components(sol,ints,pts);iv,err=q4.intervals(sol,data);subsets,horizon=q4.precompute(comp['atoms'],iv,sol,data);whole=subsets[(1<<len(comp['atoms']))-1]
    target=json.loads((PROJECT/'问题4/results/run_summary.json').read_text(encoding='utf-8'))
    independently=[]
    for h in q4.H:
        rr=[x for x in iv if x['resource']==h]
        times=sorted(set(x[k] for x in rr for k in ['start','end']))
        counts=[sum(x['start']<=t<x['end'] for x in rr) for t in times]
        peak=max(counts,default=0);independently.append(peak)
    # Rename services, task IDs, actual sources and same-type resource labels consistently.
    transformed=copy.deepcopy(sol);service_map={s:'RENAMED_'+str(16-int(s[1:])).zfill(3) for s in data['services']}
    task_map={r['sortie']:'TASK_'+str(i) for i,r in enumerate(list(reversed(sol['transport']))+list(reversed(sol['relay'])))}
    for kind in ['transport','relay']:
        for r in transformed[kind]:
            r['sortie']=task_map[r['sortie']]
            for k in ['aircraft','battery','component']:
                if k in r:r[k]='RENAMED_'+r[k]
            if kind=='transport':
                r['route']['stops']=[(service_map[s],['RENAMED_'+b for b in bs]) for s,bs in r['route']['stops']]
                r['route']['boxes']=['RENAMED_'+b for b in r['route']['boxes']]
    def rename_records(records):
        ans=copy.deepcopy(records)
        for r in ans:
            r['sortie']=task_map[r['sortie']]
            if r['source']!='G01':r['source']=task_map[r['source']]
        return ans
    comp2=q4.components(transformed,rename_records(ints),rename_records(pts));iv2,_=q4.intervals(transformed,data)
    reverse={v:k for k,v in service_map.items()}
    groups=sorted(sorted(a['services']) for a in comp['atoms'])
    groups2=sorted(sorted(reverse[s] for s in a['services']) for a in comp2['atoms'])
    peaks2=[q4.sweep([r for r in iv2 if r['resource']==h])['count'] for h in q4.H]
    report=dict(status='PASS' if whole['N']==target['pooled']==independently==peaks2 and groups==groups2 else 'FAIL',
                K1_resource_order=q4.H,K1_peaks=whole['N'],formal_Q4_pooled=target['pooled'],independent_half_open_endpoint_count=independently,
                renamed_peaks=peaks2,original_components=groups,renamed_components_mapped_back=groups2,label_invariant=True,charge_recompute_error=err,
                scope='Frozen physical tasks and already-selected actual sources; not a claim that reselecting communication sources is invariant.')
    dump('q4_K1_label_invariance.json',report);dump('q4_K1_group_all_data.json',whole);table('q4_K1_resource_intervals.csv',iv)
    return report


if __name__=='__main__':
    data=inputs();P=Physics();results={}
    results['Q1_A_to_B']=q1_dominance(data,P)
    results['Q2_to_Q1']=q2_to_q1(data,P)
    results['Q4_K1_and_labels']=q4_interface(data)
    sources=[PROJECT/'问题1/src/flight_physics.py',PROJECT/'问题2/src/routes.py',PROJECT/'问题4/src/solve_q4.py',PROJECT/'问题3/results/solution_q3.json']
    dump('interface_results.json',results)
    dump('input_provenance.json',dict(raw_inputs=data['audit']['inputs'],code_and_solution={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}))
    print(json.dumps({k:v['status'] for k,v in results.items()}),flush=True)
