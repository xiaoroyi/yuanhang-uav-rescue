"""Reevaluate fixed Q3 physical plans at +1/+2 dB; never reschedule or publish."""
from pathlib import Path
import sys,json,time,hashlib
from collections import Counter

HERE=Path(__file__).resolve().parent;RUN=HERE.parent
sys.path.insert(0,str(RUN/'q3/src'))
from setup_q3 import dump,table
from validate_q3 import run


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main(scenarios=None,output=None):
    output=Path(output) if output is not None else HERE/'margin_stress';output.mkdir(exist_ok=True)
    if scenarios is None:
        scenarios=[('fast',RUN/'q3_local_sites/refined/position_time_first'),('tradeoff',RUN/'q3_performance/results/small_trade_4'),('energy',HERE/'q3_energy_pruned_tight')]
    rows=[];started=time.time()
    for name,folder in scenarios:
        path=folder/'solution_q3.json';before={f:sha(folder/f) for f in ['solution_q3.json','validation_q3.json','communication_intervals_q3.csv','communication_event_points_q3.csv']}
        base=json.loads((folder/'validation_q3.json').read_text(encoding='utf-8'))['summary']
        for margin in [9,10]:
            result=run(path,margin=margin,save=False);summary=result['summary'];codes=Counter(r['code'] for r in result['errors'])
            dump(output/f'{name}_margin_{margin}db.json',dict(scenario=name,required_margin_db=margin,fixed_solution_sha256=before['solution_q3.json'],scope='Fixed physical plan stress reevaluation, no reoptimization; source choices recomputed at changed link margin, therefore not inherited into Q4',**result))
            rows.append(dict(scenario=name,required_margin_db=margin,extra_margin_db=margin-8,status='PASS' if summary['valid'] else 'FAIL',valid=summary['valid'],communication_gap_customer_seconds=summary['gap_seconds'],
                             isolated_uncovered_event_records=codes['isolated_uncovered_point'],backhaul_invalid_sorties=codes['backhaul'],other_error_codes=json.dumps({k:v for k,v in codes.items() if k not in ['communication_gaps','isolated_uncovered_point','backhaul']},ensure_ascii=False),
                             hard_delivery_violations=summary['hard_violations'],D=summary['D'],C_joint_s=summary['C_joint'],E_total_kwh=summary['E_total'],min_hard_slack_s=summary['min_hard_slack'],
                             certified_open_intervals=summary['certified_open_intervals'],certified_event_records=summary['certified_event_points'],unknown_intervals=summary['unknown_intervals'],base_margin8_valid=base['valid'],source_sha256=before['solution_q3.json'],elapsed_s=summary['elapsed']))
        after={f:sha(folder/f) for f in before};assert before==after
        table(output/'fixed_plan_margin_stress.csv',rows)
    dump(output/'summary.json',dict(rows=rows,total_elapsed_s=time.time()-started,source_files_unchanged=True,Q4_inherited=False,interpretation='Failure shows this fixed schedule/sites are not feasible at the stricter margin; it does not prove the original problem or a reoptimized plan is infeasible. Gap seconds sum over customers and differ from wall-clock outage duration. Isolated event records include phase boundary duplicate records.'))
    print(json.dumps(rows,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
