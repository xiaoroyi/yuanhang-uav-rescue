"""Compare already saved Q1/Q2 pattern sets; no re-enumeration or solving."""
from pathlib import Path
import csv,json
from decimal import Decimal

HERE=Path(__file__).resolve().parent;PROJECT=HERE.parents[2]


def main():
    old=list(csv.DictReader((PROJECT/'问题1/results/all_patterns.csv').open(encoding='utf-8-sig',newline='')))
    new=list(csv.DictReader((HERE/'q2_degenerate_patterns.csv').open(encoding='utf-8-sig',newline='')))
    def key(r):return r['service'],r['model'],tuple(json.loads(r['counts']))
    aa={key(r):r for r in old};bb={key(r):r for r in new};old_energy={k:r for k,r in aa.items() if Decimal(r['SOC'])>=Decimal('.2')}
    differences=[]
    for k in sorted(set(aa)-set(bb)):
        r=aa[k];energy=Decimal(r['E']);soc=Decimal(r['SOC']);limit=Decimal({'A':'3.6','B':'3.2','C':'6.4'}[r['model']])
        differences.append(dict(service=r['service'],model=r['model'],counts=r['counts'],mass_kg=r['mass_kg'],volume_L=r['volume_L'],energy_kwh=str(energy),allowed_energy_kwh=str(limit),excess_energy_kwh=str(energy-limit),SOC=str(soc),reserve_requirement='0.2',reason='mass/volume feasible but energy reserve infeasible' if soc<Decimal('.2') else 'UNEXPLAINED'))
    assert set(old_energy)==set(bb)
    assert len(differences)==len(aa)-len(old_energy)==10
    assert all(r['reason']!='UNEXPLAINED' for r in differences)
    report=dict(status='PASS',old_Q1_all_patterns_mass_volume_feasible=len(aa),old_Q1_after_reserve_filter=len(old_energy),new_Q2_degenerate_energy_feasible=len(bb),
                identical_after_same_filter=True,excluded_energy_patterns=len(differences),Q1_only_after_same_filter=[],Q2_only_after_same_filter=[],
                explanation='742 counts mass-and-volume-feasible patterns before reserve filtering; 732 additionally enforces baseline SOC>=20%. The 10 omitted patterns all violate baseline energy reserve. No candidate omission or numeric mismatch.',
                formal_report_quote='合法质量体积模式742个；不永久按20%能耗删除，敏感性时重新过滤。',
                comparison_key=['service','model','counts_MED_WAT_FOD_HYG'])
    (HERE/'q1_q2_pattern_count_reconciliation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    with (HERE/'q1_patterns_excluded_by_20pct_reserve.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(differences[0]));w.writeheader();w.writerows(differences)
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
