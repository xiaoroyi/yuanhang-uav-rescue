"""Audit all eligible actual sources without changing the frozen Q3 assignment."""
from check_interfaces import *
from communication import Radio, phases
from validate_q3 import state


def main():
    started=time.time();data=inputs();P=Physics();radio=Radio(data)
    folder=PROJECT/'问题3/results';sol=json.loads((folder/'solution_q3.json').read_text(encoding='utf-8'))
    original_ints=q4.rows(folder/'communication_intervals_q3.csv');original_pts=q4.rows(folder/'communication_event_points_q3.csv')
    relays=sol['relay'];rids=[r['sortie'] for r in relays];records=[];plot_geometry=[]
    for row in sol['transport']:
        for p in phases(row['route'],P):
            start=row['start']+p['a'];end=row['start']+p['b'];dt=end-start
            direct=radio.profile(data['gateway'],p['p0'],p['p1'],'direct')
            links={'G01':direct};active={};cuts={0.,1.}
            for relay in relays:
                site=relay['site'];xyz=np.array([site['x'],site['y'],site['z']])
                back=radio.point(data['gateway'],xyz,'backhaul')
                if not back['valid'] or relay['service_end']<start or relay['link_complete']>end:continue
                rid=relay['sortie'];links[rid]=radio.profile(xyz,p['p0'],p['p1'],'access');active[rid]=(relay['link_complete'],relay['service_end'])
                for t in active[rid]:
                    if start<t<end:cuts.add((t-start)/dt)
            for prof in links.values():
                for a,b,_ in prof['pieces']:cuts.update((a,b))
                cuts.update(prof['events'])
            cuts=sorted(cuts)
            def eligible(u,event=False):
                t=start+dt*u
                all_relays=[rid for rid in active if active[rid][0]-1e-8<=t<=active[rid][1]+1e-8 and state(links[rid],u,event)]
                # A direct link makes relay selection prohibited by direct-first policy.
                direct_ok=state(direct,u,event)
                legal=['G01'] if direct_ok else all_relays
                return legal,all_relays,direct_ok
            for a,b in zip(cuts,cuts[1:]):
                opts,others,direct_ok=eligible((a+b)/2)
                records.append(dict(kind='interval',sortie=row['sortie'],phase=p['phase'],start=start+dt*a,end=start+dt*b,time='',source=opts[0] if opts else None,eligible_sources=opts,eligible_relays=others,direct_priority=direct_ok,choice_count=len(opts)))
            for u in cuts:
                opts,others,direct_ok=eligible(u,True)
                records.append(dict(kind='event',sortie=row['sortie'],phase=p['phase'],start='',end='',time=start+dt*u,source=opts[0] if opts else None,eligible_sources=opts,eligible_relays=others,direct_priority=direct_ok,choice_count=len(opts)))
            plot_geometry.append(dict(sortie=row['sortie'],phase=p['phase'],stage=p['type'],start=start,end=end,p0=p['p0'],p1=p['p1']))
    ints=[r for r in records if r['kind']=='interval'];pts=[r for r in records if r['kind']=='event']
    assert len(ints)==len(original_ints) and len(pts)==len(original_pts)
    mismatch=[]
    for kind,new,old in [('interval',ints,original_ints),('event',pts,original_pts)]:
        for i,(a,b) in enumerate(zip(new,old)):
            if (a['sortie'],str(a['phase']),a['source'])!=(b['sortie'],str(b['phase']),b['source']):mismatch.append(dict(kind=kind,index=i,ours=a,original=b))
    assert not mismatch,mismatch[:2]
    comp=q4.components(sol,ints,pts);actual=sorted(sorted(a['services']) for a in comp['atoms'])
    trials=[]
    for order in itertools.permutations(rids):
        rank={rid:i for i,rid in enumerate(order)};alt=copy.deepcopy(records)
        for r in alt:
            if r['source']!='G01':r['source']=min(r['eligible_sources'],key=rank.__getitem__)
        iv=[r for r in alt if r['kind']=='interval'];ev=[r for r in alt if r['kind']=='event'];cc=q4.components(sol,iv,ev)
        groups=sorted(sorted(a['services']) for a in cc['atoms'])
        trials.append(dict(relay_priority=list(order),changed_records=sum(a['source']!=b['source'] for a,b in zip(records,alt)),components=groups,same_as_frozen=groups==actual))
    dest={r['sortie']:sorted({s for s,_ in r['route']['stops']}) for r in sol['transport']}
    mandatory=defaultdict(set);possible=defaultdict(set);edge_details=defaultdict(lambda:dict(unique_interval_s=0.,choice_interval_s=0.,unique_event_records=0,choice_event_records=0))
    for r in records:
        if r['source']=='G01':continue
        unique=len(r['eligible_sources'])==1
        for rid in r['eligible_sources']:
            possible[rid].add(r['sortie'])
            if unique:mandatory[rid].add(r['sortie'])
            dd=edge_details[rid,r['sortie']]
            if r['kind']=='interval':dd['unique_interval_s' if unique else 'choice_interval_s']+=r['end']-r['start']
            else:dd['unique_event_records' if unique else 'choice_event_records']+=1
    def components_for_clients(clients):
        ds=q4.DSU(sorted({s for vv in dest.values() for s in vv}))
        for vv in dest.values():ds.merge(vv)
        for rid,tt in clients.items():ds.merge(sorted({s for t in tt for s in dest[t]}))
        return ds.groups()
    mandatory_components=components_for_clients(mandatory);possible_components=components_for_clients(possible)
    detail_rows=[dict(relay=rid,transport=t,services=dest[t],**dd) for (rid,t),dd in sorted(edge_details.items())]
    ties=[r for r in records if r['choice_count']>1];ties_intervals=[r for r in ties if r['kind']=='interval']
    report=dict(status='PASS',formal_actual_source_reproduced=True,intervals=len(ints),event_records=len(pts),unique_events=len({(r['sortie'],r['time']) for r in pts}),
                relay_priority_trials=trials,tie_interval_records=len(ties_intervals),tie_customer_seconds=sum(r['end']-r['start'] for r in ties_intervals),tie_event_records=sum(r['kind']=='event' for r in ties),
                direct_intervals_with_relay_alternative=sum(r['direct_priority'] and bool(r['eligible_relays']) for r in ints),
                actual_components=actual,mandatory_unique_source_components=mandatory_components,all_possible_source_components=possible_components,
                all_recordwise_source_choices_preserve_components=(actual==mandatory_components==possible_components),
                elapsed_s=time.time()-started,
                scope='All source eligibility intervals and boundary events for the frozen physical trajectories and given three relay sorties. Direct-first preserved. No upstream trajectory/relay retiming and no changes to official Q3/Q4.')
    table('q3_all_source_eligibility.csv',records);table('q3_source_choice_edges.csv',detail_rows);table('q3_phase_geometry_for_figures.csv',plot_geometry);dump('q3_actual_source_ties.json',report)
    print(json.dumps(report,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
