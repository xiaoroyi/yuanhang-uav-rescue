"""Tighten only unused leading/trailing relay hovering, then fully revalidate."""
from pathlib import Path
import sys,json,csv,copy,hashlib
from collections import defaultdict

HERE=Path(__file__).resolve().parent;RUN=HERE.parent
sys.path.insert(0,str(RUN/'q3/src'))
from setup_q3 import dump,inputs
from routes import charge
from validate_q3 import run


def main():
    source=HERE/'q3_energy_pruned';target=HERE/'q3_energy_pruned_tight';target.mkdir(exist_ok=True)
    data=inputs();obs=defaultdict(list)
    for filename in ['communication_intervals_q3.csv','communication_event_points_q3.csv']:
        for row in csv.DictReader((source/filename).open(encoding='utf-8-sig',newline='')):
            if row['source']=='G01':continue
            obs[row['source']].extend([float(row['start']),float(row['end'])] if 'start' in row else [float(row['time'])])
    old=json.loads((source/'solution_q3.json').read_text(encoding='utf-8'));new=copy.deepcopy(old);changes=[]
    for r in new['relay']:
        assert obs[r['sortie']];before=copy.deepcopy(r);first=min(obs[r['sortie']]);last=max(obs[r['sortie']])
        ready=max(r['link_complete'],first-1e-4);end=min(r['service_end'],last+1e-4);site=r['site'];start=ready-site['ready_offset'];ret=end+site['back']
        energy=site['fly_energy']+(data['relay']['hover']+data['relay']['radio'])*(end-start-site['arrival_offset'])/3600;soc=1-energy/data['relay']['Euse'];ch=charge(soc,data['relay']['Tfull'])
        r.update(start=start,arrival=start+site['arrival_offset'],link_complete=ready,grid_ready=ready,service_end=end,return_=ret,energy=energy,SOC=soc,charge=ch,component_ready=ret+ch,aircraft_ready=ret+data['relay']['turn']);r['return']=r.pop('return_')
        assert start>=before['start']-1e-8 and r['return']<=before['return']+1e-8
        changes.append(dict(sortie=r['sortie'],first_actual_requirement=first,last_actual_requirement=last,old_start=before['start'],new_start=start,old_service_end=before['service_end'],new_service_end=end,old_energy=before['energy'],new_energy=energy))
    new['assignment']=[];new['grid_metrics']={};new['scope']='Unused relay removed, remaining leading/trailing hover only tightened using freshly reconstructed actual sources; transport exactly frozen; independent full-time revalidation.'
    dump(target/'solution_q3.json',new);report=run(target/'solution_q3.json');assert report['summary']['valid']
    oldsummary=json.loads((source/'solution_summary.json').read_text(encoding='utf-8'))
    dump(target/'tightening_evidence.json',dict(valid=True,source=str(source/'solution_q3.json'),source_sha256=hashlib.sha256((source/'solution_q3.json').read_bytes()).hexdigest(),
                                              changes=changes,transport_exactly_unchanged=old['transport']==new['transport'],energy_saved_kwh=oldsummary['E_total']-report['summary']['E_total'],new_summary=report['summary']))
    print(json.dumps(dict(energy_saved=oldsummary['E_total']-report['summary']['E_total'],summary=report['summary']),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
