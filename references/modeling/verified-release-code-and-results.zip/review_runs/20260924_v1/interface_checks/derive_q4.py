"""Derive exact Q4 for any independently validated Q3 snapshot, without publishing."""
from check_interfaces import *
import argparse


def derive(q3_directory, out):
    q3_directory=Path(q3_directory).resolve();out=Path(out).resolve()
    assert out.is_relative_to(HERE.resolve()),'All new Q4 output must stay under interface_checks/'
    out.mkdir(parents=True,exist_ok=True)
    validation=json.loads((q3_directory/'validation_q3.json').read_text(encoding='utf-8'))
    assert validation['summary']['valid'],'Q3 independent validator must pass before inheritance'
    sol=q4.read(q3_directory/'solution_q3.json');ints=q4.rows(q3_directory/'communication_intervals_q3.csv');pts=q4.rows(q3_directory/'communication_event_points_q3.csv')
    data=inputs();comp=q4.components(sol,ints,pts);iv,err=q4.intervals(sol,data);atoms=comp['atoms'];subsets,horizon=q4.precompute(atoms,iv,sol,data)
    stock=[data['M'][g] for g in 'ABC']+[data['K'][g] for g in 'ABC']+[data['relay']['M'],data['relay']['K']]
    parts=q4.enumerate_all(subsets,len(atoms),stock);whole=subsets[(1<<len(atoms))-1]
    independent_K1=[]
    for h in q4.H:
        items=[r for r in iv if r['resource']==h];times=sorted(set(r[x] for r in items for x in ['start','end']))
        independent_K1.append(max((sum(r['start']<=t<r['end'] for r in items) for t in times),default=0))
    assert independent_K1==whole['N']
    q4.dump(out/'K1_verification.json',dict(valid=True,resource_order=q4.H,K1_minimum=whole['N'],independent_half_open_endpoint_peaks=independent_K1,within_original_inventory=all(a<=b for a,b in zip(whole['N'],stock))))
    q4.dump(out/'components_q4.json',comp);q4.dump(out/'group_subsets_q4.json',subsets);q4.table(out/'resource_intervals_q4.csv',iv);q4.table(out/'all_partitions_q4.csv',parts)
    assignments=[];coverage=[];work=[];decomp=[];selections={};validations=[]
    for k in (2,3):
        pp=[p for p in parts if p['K']==k]
        if not pp:
            selections[k]=dict(status='INFEASIBLE',reason=f'Only {len(atoms)} indivisible components, fewer than K={k}; adding resources cannot split frozen dependency components.')
            q4.dump(out/f'solution_k{k}.json',selections[k]);continue
        best=min(pp,key=q4.key);balanced=min(pp,key=lambda p:q4.key(p,'balance'));groups=[subsets[m] for m in best['masks']]
        for gno,g in enumerate(groups,1):
            work.append(dict(K=k,group=gno,**{x:g[x] for x in ['services','W','Wtransport','Wrelay','Wturn','boxes','mass','volume_L','energy','N','busy','utilization']}))
        for hno,h in enumerate(q4.H):
            allocated=0
            for gno,g in enumerate(groups,1):
                for r in g['assignment']:
                    if r['resource']!=h:continue
                    ident=allocated+r['color'];extra=ident>stock[hno]
                    assignments.append(dict(K=k,group=gno,**r,new_id=f'K{k}-{h}-{ident:02d}',needs_addition=extra))
                allocated+=g['N'][hno]
            decomp.append(dict(K=k,resource=h,stock=stock[hno],pooled=whole['N'][hno],partition_total=best['N'][hno],additional_vs_pool=best['N'][hno]-whole['N'][hno],deficit=best['gap'][hno],unallocated_stock=max(0,stock[hno]-best['N'][hno])))
        coverage.extend(dict(K=k,**r) for r in q4.ownership(groups,ints,pts))
        selections[k]=dict(selected=best,balanced=balanced,groups=[{x:v for x,v in g.items() if x not in ['witnesses','assignment']} for g in groups],status='exact conditional optimum; add explicitly listed deficit resources',Q3_task_hash=q4.sha(q3_directory/'solution_q3.json'))
        q4.dump(out/f'solution_k{k}.json',selections[k])
    q4.table(out/'group_resource_assignment.csv',assignments);q4.table(out/'coverage_ownership_q4.csv',coverage);q4.table(out/'deficit_decomposition.csv',decomp);q4.table(out/'group_workload.csv',work)
    # Separate generic verifier; avoid old regression tests that assume specific services/groups.
    import verify_q4
    verify_q4.OUT=out
    for k in (2,3):
        if 'groups' in selections[k]:
            good=verify_q4.validate_partition(sol,selections[k]['groups'],[r for r in assignments if r['K']==k],ints,pts,sol,ints,pts)
            validations.append(dict(K=k,all_physical_tasks_preserved=good,actual_sources_preserved=good,resource_entities_legal=good))
    for p in parts:q4.ownership([subsets[m] for m in p['masks']],ints,pts)
    milp=[]
    if len(atoms)>=3:milp=q4.milp_verify(subsets,len(atoms),stock,parts)
    report=dict(valid=True,atoms=len(atoms),partitions={k:sum(p['K']==k for p in parts) for k in (2,3)},stock=stock,pooled=whole['N'],pooled_W=whole['W'],horizon=horizon,
                strict_identity_components=len(comp['strict_original_identity_components']),max_charge_recompute_error=err,resource_order=q4.H,
                any_partition_within_inventory={k:any(not any(p['gap']) for p in parts if p['K']==k) for k in (2,3)},all_partition_ownership_checks=len(parts),selected_partition_verification=validations,milp=milp,
                K1_independent_peaks=independent_K1,source_task_hash=q4.sha(q3_directory/'solution_q3.json'),source_directory=str(q3_directory),scope='Q3 physical tasks and actual communication source frozen. No data-dependent Q3 reoptimization within Q4.')
    q4.dump(out/'run_summary.json',report)
    q4.dump(out/'input_manifest.json',{str(q3_directory/f):q4.sha(q3_directory/f) for f in ['solution_q3.json','validation_q3.json','communication_intervals_q3.csv','communication_event_points_q3.csv']})
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--q3-directory',required=True);parser.add_argument('--out',required=True);args=parser.parse_args()
    report=derive(args.q3_directory,args.out)
    print(json.dumps({k:report[k] for k in ['valid','atoms','partitions','pooled','any_partition_within_inventory']},ensure_ascii=False))
