from data import *
import numpy as np,inspect,shutil
from communication import Radio,phases
SRC=DIR['Q3_fast'];CACHE=BASE/'exposure_cache';CACHE.mkdir(exist_ok=True)
shutil.copy2(ROOT/'问题3/cache/pixel_corners.npz',CACHE/'pixel_corners.npz')
communication.CACHE=CACHE
read=js;write=dump
SOURCES=[SRC/'solution_q3.json',SRC/'communication_intervals_q3.csv',SRC/'communication_event_points_q3.csv']
def ident(p):return dict(path=str(p),sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest())
def prepare():
    saved=CACHE/'derived_exposure.json'
    signature={ident(p)['path']:ident(p)['sha256'] for p in SOURCES if p!=Path(__file__)}
    signature['analysis_prepare_function_sha256']=hashlib.sha256(inspect.getsource(prepare).encode('utf-8')).hexdigest()
    if saved.exists():
        data=read(saved)
        if data['source_signature']==signature:return data
    data=setup_q3.inputs();P=routes.Physics();eng=Radio(data)
    sol=read(SRC/'solution_q3.json');intervals=rows(SRC/'communication_intervals_q3.csv');events=rows(SRC/'communication_event_points_q3.csv')
    assert len(intervals)==377 and len(events)==558 and len(sol['transport'])==23
    trips={r['sortie']:r for r in sol['transport']}
    phase={(r['sortie'],p['phase']):dict(p,start=r['start']+p['a'],end=r['start']+p['b']) for r in sol['transport'] for p in phases(r['route'],P)}
    anchors={'G01':np.array(data['gateway'])};back={'G01':math.inf}
    for r in sol['relay']:
        anchors[r['sortie']]=np.array([r['site'][k] for k in ['x','y','z']])
        back[r['sortie']]=eng.point(anchors['G01'],anchors[r['sortie']],'backhaul')['margin']
    def position(p,t):return np.array(p['p0'])+(t-p['start'])/(p['end']-p['start'])*(np.array(p['p1'])-p['p0'])
    segments=[];conservative=[]
    for i,r in enumerate(intervals):
        p=phase[r['sortie'],int(r['phase'])];a,b=float(r['start']),float(r['end']);x0,x1=position(p,a),position(p,b)
        rid=r['source'];anchor=anchors[rid];kind='direct' if rid=='G01' else 'access'
        blocked=eng.blocked(anchor,x0,x1)
        # Even radius-certified intervals are split at their true terrain changes.
        cuts=sorted(set([0.,1.]+[0. if abs(float(v))<1e-10 else 1. if abs(float(v)-1)<1e-10 else float(v) for ab in blocked for v in ab]))
        for u,v in zip(cuts,cuts[1:]):
            if v-u<1e-14:continue
            mid=(u+v)/2;obs=any(lo-1e-12<=mid<=hi+1e-12 for lo,hi in blocked)
            left=x0+u*(x1-x0);right=x0+v*(x1-x0);delta=right-left;w=left-anchor
            constant=eng.limits[kind]-eng.base-eng.obstacle*obs
            coeff=[float(delta@delta),float(2*w@delta),float(w@w)]
            endpoint_min=constant-20*math.log10(max(np.linalg.norm(left-anchor),np.linalg.norm(right-anchor),1e-9))
            assert min(endpoint_min,back[rid])>=-1e-6,(i,r,min(endpoint_min,back[rid]))
            segments.append(dict(parent_interval=i,sortie=r['sortie'],phase=int(r['phase']),source=rid,
               start=a+u*(b-a),end=a+v*(b-a),duration=(v-u)*(b-a),blocked=obs,A=coeff[0],B=coeff[1],C=coeff[2],
               margin_constant_db=constant,backhaul_margin_db=back[rid] if math.isfinite(back[rid]) else None,
               actual_min_margin_db=min(endpoint_min,back[rid])))
        conservative.append(dict(duration=b-a,lower_bound=float(r['min_margin_bound_db'])))
        if i%60==0:print(f'EXPOSURE geometry {i+1}/377',flush=True)
    event_values=[]
    for r in events:
        p=phase[r['sortie'],int(r['phase'])];t=float(r['time']);rid=r['source'];kind='direct' if rid=='G01' else 'access'
        point=eng.point(anchors[rid],position(p,t),kind);margin=min(point['margin'],back[rid])
        assert margin>=-1e-6,(r,margin)
        event_values.append(dict(**r,actual_margin_db=margin,blocked=point['blocked']))
    total=sum(r['duration'] for r in segments)
    expected=sum(r['return']-r['start']-r['route']['prep'] for r in sol['transport'])
    assert abs(total-expected)<1e-7
    for rid,tr in trips.items():
        iv=sorted((float(r['start']),float(r['end'])) for r in intervals if r['sortie']==rid)
        assert abs(iv[0][0]-tr['start']-tr['route']['prep'])<1e-7 and abs(iv[-1][1]-tr['return'])<1e-7
        assert max(abs(x[1]-y[0]) for x,y in zip(iv,iv[1:]))<1e-7
    out=dict(source_signature=signature,segments=segments,conservative=conservative,events=event_values,
             total_customer_seconds=total,expected_customer_seconds=expected,nominal_valid=True,
             certified_intervals=len(intervals),terrain_constant_segments=len(segments),stage_event_records=len(event_values),
             unique_sortie_times=len({(r['sortie'],round(float(r['time']),8)) for r in event_values}),
             radio_limits=eng.limits,frequency_MHz=data['radio']['frequency'],base=eng.base,
             minimum_event_margin_db=min(r['actual_margin_db'] for r in event_values),
             original_external_input_hashes=data['audit']['inputs'])
    write(saved,out);return out

def low_duration(row,gamma,strict=False):
    back=row['backhaul_margin_db']
    if back is not None and (back<gamma if strict else back<=gamma):return row['duration']
    radius2=10**((row['margin_constant_db']-gamma)/10)
    A,B,C=row['A'],row['B'],row['C']-radius2
    if A<1e-16 and abs(B)<1e-12:
        margin=row['margin_constant_db']-10*math.log10(max(row['C'],1e-18))
        return row['duration']*int(margin<gamma if strict else margin<=gamma)
    cuts=[0.,1.]
    if A<1e-16:
        cuts.append(-C/B)
    else:
        disc=B*B-4*A*C
        if disc>=0:
            root=math.sqrt(disc);cuts += [(-B-root)/(2*A),(-B+root)/(2*A)]
    cuts=sorted(set(max(0.,min(1.,v)) for v in cuts))
    return row['duration']*sum(v-u for u,v in zip(cuts,cuts[1:]) if A*((u+v)/2)**2+B*((u+v)/2)+C>=0)


if __name__=='__main__':
 d=prepare();out=[]
 for g in [0,.25,.5,1,2,4,8]:
  actual=sum(low_duration(x,g) for x in d['segments']);failure=sum(low_duration(x,max(0,g-1e-8),True) for x in d['segments'])
  out.append(dict(threshold=g,actual_seconds=actual,bound_seconds=sum(x['duration'] for x in d['conservative'] if x['lower_bound']<=g),failure_seconds=failure,event_failures=sum(x['actual_margin_db']<g-1e-8 for x in d['events'])))
 table(BASE/'exposure_summary.csv',out);print(json.dumps(out),flush=True)
