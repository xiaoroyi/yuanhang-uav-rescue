from data import *
import zipfile,re,html,datetime,shutil
PAPER=ROOT/'论文LaTeX_20260926/论文';OUT=ROOT/'outputs/current_release_20260926_v4';FIG=ROOT/'paper/figures/20260926_release'
def entry(p):
 p=Path(p);return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)

# Source whitelist deliberately excludes server connection/deployment scripts.
files={}
def add(p,name=None):
 p=Path(p)
 if p.is_file():files[name or p.relative_to(ROOT).as_posix()]=p
for q in range(1,5):
 for p in (ROOT/f'问题{q}/src').glob('*.py'):add(p)
server=ROOT/'review_runs/20260925_server_search'
for folder in ['src','code','methods']:
 for p in (server/folder).rglob('*.py'):add(p)
for name in ['q2_search.py','q2_server.py','q2_master.py','q2_master_candidate.py','q2_portfolio_candidate.py','q3_search.py','q3_server.py','original_bounds.py']:
 add(server/name)
for name in ['q2_search.py','q2_decomposition_server.py','q3_focus.py']:
 add(ROOT/'review_runs/20260925_overnight'/name)
for p in (ROOT/'review_runs/20260924_v1/interface_checks').glob('*.py'):add(p)
for name in ['normalized_inputs.json','terrain_evidence_all.json']:add(server/'inputs'/name)
for p in BASE.glob('*.py'):add(p)
add(BASE/'selected_versions.json');add(BASE/'inheritance_validation.json');add(BASE/'q3_replay_validation.json')
for sid,d in DIR.items():
 for p in d.rglob('*'):
  if p.suffix in ['.csv','.json'] and p.stat().st_size<10_000_000:add(p)
for folder in ['q4_fast','q4_economy']:
 for p in (BASE/folder).glob('*'):
  if p.suffix in ['.json','.csv']:add(p)
for p in (ROOT/'问题1/results').glob('*'):
 if p.suffix in ['.csv','.json'] and p.stat().st_size<5_000_000:add(p)
for n,p in files.items():
 if p.suffix=='.py':
  content=p.read_text(encoding='utf-8-sig')
  assert not re.search(r'(?i)(?:password|passwd)\s*=\s*[\x22\x27][^\x22\x27]+[\x22\x27]',content),f'Credential-like assignment: {n}'
code_readme='''# 问题一至四详细代码与当前方案依据

本附件保存实际计算程序及所选完整解，不是伪代码。正文附录保留四问关键片段，详细程序在此。

- 问题1/src：地形闭像元、能耗、安全载荷、完整模式、动态规划和独立验证。
- 问题2/src：多站路线物理模型、共享电池与飞机调度、独立回放。
- 问题3/src：两跳链路、阶段几何、连续区间与事件认证、联合调度。
- 问题4/src：冻结任务关联、原子分组、资源峰值、区间分配及枚举。
- review_runs/20260925_server_search：服务器使用的移植代码、规范化输入、路线与联合搜索模块。
- review_runs/20260925_overnight：本轮分解搜索及定向联合搜索改动。
- review_runs/20260926_release：发布所用Q4继承、图表与论文更新脚本，及独立复核结果。

本包按项目相对目录保留。原始题目附件目录D题应与代码目录同级；部分历史程序还读取项目中已保存的航段缓存。没有将第三方依赖、全部历史候选池或原始DEM复制进本包，因此不宣称解压即可从零重现约10小时的搜索轨迹。审核当前数值可以直接读取保存的完整解、逐箱交付、连续通信和Q4独立分配证据。

主要环境：Python 3.11、NumPy、SciPy、pandas、OR-Tools、Shapely、pyproj、openpyxl、Matplotlib。实际依赖导入以源文件为准。服务器随机种子和求解阶段记录见各所选方案的solver_evidence、run_contract等证据。

所选主方案：Q2_fast、Q3_fast；第四问严格继承Q3_fast。Q2/Q3没有原题全局最优证书；有限候选与整数网格中的阶段状态不能外推。Q4的精确结论只针对该冻结方案。
'''
codezip=OUT/'问题1至4_详细代码与结果依据_20260926.zip'
with zipfile.ZipFile(codezip,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('使用说明.md',code_readme)
 manifest=[]
 for n,p in sorted(files.items()):z.write(p,n);manifest.append(dict(file=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
 z.writestr('文件清单.json',json.dumps(manifest,ensure_ascii=False,indent=2))
dump(BASE/'code_attachment_manifest.json',dict(archive=entry(codezip),file_count=len(files),secrets='connection and deployment files excluded; source assignment scan passed'))

tex=(PAPER/'全文.tex').read_text(encoding='utf-8');aliases=re.findall(r'\\includegraphics(?:\[[^]]*\])?\{figures/([^}]+)\}',tex)
figs=[]
for alias in dict.fromkeys(aliases):
 p=PAPER/'figures'/(alias+'.pdf');assert p.exists(),alias
 changed=(FIG/alias/'figure.pdf').exists()
 figs.append(dict(alias=alias,**entry(p),redrawn=changed,numeric_release='20260926_v4_excel1',scope='current solution' if changed else 'unchanged Q1, input physics or result-free method'))
dump(PAPER/'figure_manifest.json',dict(version='20260926_v4_excel1',figures=figs))
dump(FIG/'figure_manifest.json',dict(version='20260926_v4_excel1',figures=figs))
for m in FIG.glob('*/metadata.json'):
 v=js(m);v['qa']='rendered and visually reviewed';dump(m,v)
cards=[]
for f in figs:
 a=f['alias'];p=PAPER/'figures'/(a+'.png')
 rel=os.path.relpath(p,FIG).replace('\\','/')
 cards.append(f'<article><h3>{html.escape(a)}</h3><a href="{os.path.relpath(ROOT/f["path"],FIG).replace(chr(92),"/")}"><img loading="lazy" src="{html.escape(rel)}"></a><p>{"本轮更新" if f["redrawn"] else "沿用：输入、Q1或方法结构"}</p></article>')
(FIG/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>20260926 当前论文图表</title><style>body{font-family:system-ui;margin:30px;background:#f2f5f6}main{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px}article{background:white;padding:16px}img{width:100%}h3{font-size:16px}</style><h1>20260926 当前论文图表</h1><p>数值版20260926_v4_excel1；点击图片打开单图PDF。旧图册保留，不代表全部旧图均已更新。</p><main>'+''.join(cards)+'</main>',encoding='utf-8')
metrics=[dict(scenario=v['id'],**v['metrics']) for v in SEL['solutions']]
allkeys=list(dict.fromkeys(k for m in metrics for k in m));table(BASE/'accepted_metrics.csv',[{k:m.get(k,'') for k in allkeys} for m in metrics])

report='''# 20260926 新结果发布与论文更新说明

## 采用结论

正式提交采用Q2_fast与Q3_fast，优先保证全部按期交付并缩短应急任务完成时间。省电备选保持独立，不把不同方案的时间与能耗拼接。第一问不变。

| 方案 | 全部返航/min | 能耗/kWh | 运输＋中继架次 |
|---|---:|---:|---:|
| Q2 主方案 | 94.887 | 66.215 | 23＋0 |
| Q2 较短时域省电备选 | 99.484 | 64.734 | 22＋0 |
| Q3 主方案 | 96.387 | 68.682 | 23＋3 |
| Q3 省电备选 | 98.995 | 67.715 | 23＋3 |

四个完整方案均完成80箱、758 kg、2011 L物资的整站按期交付，31箱硬截止全部满足。Q3两个方案连续通信无缺口。较宽时域仍有更低能耗的历史方案，因此新“省电备选”不等于无时间限制的全局最低能耗。

## 与原主方案及截图的比较

Q2主方案相对原折中基准，返航由5969.043 s降至5693.243 s，能耗由66.472 kWh降至66.215 kWh，架次由24降至23。Q3主方案由6204.224 s、69.361 kWh、24＋3架次，改善为5783.227 s、68.682 kWh、23＋3架次。

截图中的Q2时间、能耗被打码，最多能确认我们落在相同数量级，不能认定完整方案相同。Q3主方案96.387分钟优于截图98.xx分钟，中继架次3小于其4；主方案68.682 kWh与被遮挡的68.xx kWh不能严格排序。另一个完整Q3备选67.715 kWh低于截图68.xx kWh，但其98.995分钟与截图98.xx不能严格排序。没有据此声称“全网唯一最优”或把两个备选合为一个方案。

## Q4 必须随新 Q3 继承的变化

新实际任务关系形成3个不可分单元：C1=S001；C2=其余13区（含S011）；C3=S006。合法分区为3种二分、1种三分。不能沿用旧四原子、十三分区。

资源顺序为A/B/C飞机、A/B/C电池、中继机、能源组件。集中共享需求为(4,2,2,6,4,4,2,3)。

- 二分K2-01：S006独立，其余14区为一组；需求(4,2,3,6,4,5,2,3)，共9架运输机、15组运输电池，增配C机和C电池各1。
- 三分K3-01：S001、其余13区、S006三组；需求(5,2,4,7,4,6,2,3)，共11架运输机、17组运输电池，增配A机/电池各1、C机/电池各2。
- 两种分法均需2架中继机和3组能源组件。总任务工时52572.543 s，C2占88.841%。

完整枚举、独立MILP、实体分配与资源峰值复核一致。最优性仅针对新Q3冻结任务及实际来源。

## 方法与正文改动

物理模型、题目参数、闭像元地形、能耗与通信预算不变。Q2补充本轮实际使用的有限路线选择与资源排程分解、候选共享和扩大搜索；目标明确为整站零延期条件下时间优先。Q3更新最终一轮32条运输候选、124个悬停点、4651覆盖块、4个中继槽及求解状态；时间阶段只对当前候选网格最优，能耗阶段为FEASIBLE。

全量更换Q2/Q3路线、实体、货箱停靠、时刻、能耗、硬余量、资源及通信表。Q4全部分区相关结果重建。摘要、模型说明、结论及跨章接口同步。相同门限下的通信暴露表与失效压力表合为一表，保留全部原数据，避免小结单独占页。原种子、资源、扰动实验保留基准身份，不伪称是新主方案的重复实验。

附录保留四问关键代码，开头写“详细代码见附件。”；实际详细代码与所选证据已打包。封面信息、模板、目录样式及用户指定AI声明保持。

## 图表与表格

当前论文42幅插图。受解变化影响的Q2/Q3/Q4图依据新方案重绘；Q1、原始输入、无结果方法图保留。包括飞机/电池时序、真实多站状态、地面站与中继范围、连续通信来源、三链路原生DEM剖面、低裕量压力、原子关联、所有分区与资源共享。

地图曲线只作展示，真实航段仍为直线。范围圆是理想无遮挡距离上限，不是越过地形的真实服务边界。实际静态可用图按接收端离地30 m、地形遮挡及双跳预算计算，不能替代连续轨迹认证。

正式Excel沿用原6张工作表和原格式，仅填入新数据。Q3运输及逐箱明细放配套CSV，不新增模板工作表。原Q1单元格数值不变。

## 验证依据

- `inheritance_validation.json`：两套Q2独立物理回放、两套Q3分别继承Q4。
- `q3_replay_validation.json`：两套Q3完整连续认证重新运行。主方案377开区间、558阶段事件、63独立射线检查；与服务器来源一致，最大浮点差小于1e-7。
- `q4_fast/run_summary.json`：源任务哈希、4分区、MILP与分配。
- 输出目录`original_template_validation.json`：6364填值单元格精确读回，3214原样式单元格检查；表头、列宽、样式和非工作表ZIP内容保留。
- LaTeX最终日志与`delivery_audit.json`：图片、引用、标签及跨媒体数据检查。

## 新增参考文献及支持范围

1. Hooker J N, Ottosson G. Logic-based Benders decomposition. Mathematical Programming, 2003, 96:33–60. DOI:10.1007/s10107-003-0375-9。作者公开全文：https://johnhooker.tepper.cmu.edu/benders.pdf 。支持分解思想，不声称我们的启发式排除规则等同于具有全局收敛证明的完整Benders算法。
2. Ropke S, Pisinger D. An Adaptive Large Neighborhood Search Heuristic for the Pickup and Delivery Problem with Time Windows. Transportation Science, 2006,40:455–472. DOI:10.1287/trsc.1050.0135。作者所在大学记录：https://orbit.dtu.dk/en/publications/an-adaptive-large-neighborhood-search-heuristic-for-the-pickup-an/ 。支持邻域设计，不冒称实现了原论文全部自适应机制。

## 文件入口与版本边界

- 新论文：`论文LaTeX_20260926/论文/全文.tex`；PDF在同目录`build/全文_20260926更新.pdf`。
- Excel与代码附件：`outputs/current_release_20260926_v4/`。
- 新图入口：`paper/figures/20260926_release/index.html`；全部论文单图在新LaTeX工程`figures/`。
- 完整方案选择与哈希：本目录`selected_versions.json`。精确数值以CSV/JSON为准，正文一般显示三位小数，坐标保留必要定位精度。
- Q1与原始物理模型的详细历史推导仍见`review_runs/20260924_v3/最终建模与绘图完整对接.md`；其中Q2/Q3/Q4主结果已被本说明和新正文替代。
- 旧论文、旧Excel、旧图册不覆盖。读取当前版本应从根目录CURRENT_RELEASE.json和CURRENT_FIGURES.json开始。
'''
(BASE/'新结果发布与论文更新说明.md').write_text(report,encoding='utf-8')
(ROOT/'论文LaTeX_20260926/使用说明.md').write_text('''# 当前论文与编译

主文件：`论文/全文.tex`。图片在`论文/figures/`，文献在`论文/references.bib`。

在项目根PowerShell运行：
```powershell
& './论文LaTeX_20260926/论文/编译.ps1' -Offline
```
默认输出`论文/build/全文_20260926更新.pdf`，重复编译会覆盖这个PDF；不会覆盖20260925旧工程。若需另存输出，可追加`-JobName '全文_个人修改'`。编辑前建议另存源码；若PDF被WPS锁定，先关闭PDF再编译。

本工程已同步20260926新Q2、Q3和严格继承的Q4。请直接编辑此处源码，不要继续改临时ZIP目录中的旧源码。发布脚本update_paper.py用于从旧稿重建，不应在手工修改此稿后随意重跑；必要时还须依次运行finalize_text.py、layout_finish.py并重新编译。
''',encoding='utf-8')
print(json.dumps(dict(code_files=len(files),code_zip=entry(codezip),figures=len(figs),redrawn=sum(f['redrawn'] for f in figs)),ensure_ascii=False))
