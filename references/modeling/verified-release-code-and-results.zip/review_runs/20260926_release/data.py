from pathlib import Path
import sys,json,csv,hashlib,os,math
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'问题3/src'),str(ROOT/'问题4/src'),str(ROOT/'selection_review/deps')]
import setup_q3,routes,communication
routes.OUT=ROOT/'review_runs/20260924_v1/q2/results'
DATA=setup_q3.inputs();P=routes.Physics()
SEL=json.loads((BASE/'selected_versions.json').read_text(encoding='utf-8'));DIR={v['id']:ROOT/v['directory'] for v in SEL['solutions']}
def js(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def rows(p):return list(csv.DictReader(Path(p).open(encoding='utf-8-sig',newline='')))
def dump(p,o):Path(p).parent.mkdir(parents=True,exist_ok=True);Path(p).write_text(json.dumps(o,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
def table(p,r):
 r=list(r)
 if not r:return
 with Path(p).open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
def station(d):
 ends={(x['sortie'],x['visit']):float(x['departure']) for x in rows(d/'stop_events.csv')};rs=[]
 for x in rows(d/'deliveries.csv'):
  t=ends[x['sortie'],x['visit_index']];due=float(x['hard_due']) if x['hard_due'] else None
  rs.append(dict(**x,station_complete=t,station_lateness=max(0,t-float(x['expected_s'])),station_hard_slack=None if due is None else due-t))
 assert len(rs)==len({x['box'] for x in rs})==80
 assert sum(x['station_hard_slack'] is not None for x in rs)==31
 assert all(x['station_lateness']<=1e-7 and (x['station_hard_slack'] is None or x['station_hard_slack']>=-1e-7) for x in rs)
 return rs
if __name__=='__main__':
 for sid,d in DIR.items():
  q3=sid.startswith('Q3');v=d/'transport_validation' if q3 else d;out=BASE/sid;out.mkdir(exist_ok=True)
  rr=station(v);table(out/'station_deliveries.csv',rr)
  sol=js(d/('solution_q3.json' if q3 else 'solution.json'));tr=sol['transport'] if q3 else sol
  phase=[]
  for r in tr:
   for p in communication.phases(r['route'],P):
    phase.append(dict(sortie=r['sortie'],phase=p['phase'],stage=p['type'],start=r['start']+p['a'],end=r['start']+p['b'],**{f'{k}{i}':float(p[f'p{i}'][j]) for i in (0,1) for j,k in enumerate('xyz')}))
  table(out/'phases.csv',phase)
  summ=js(d/('validation_q3.json' if q3 else 'validation.json'))['summary']
  summ.update(min_station_hard_slack=min(x['station_hard_slack'] for x in rr if x['station_hard_slack'] is not None),station_D=0)
  dump(out/'metrics.json',summ)
 print('derived station deliveries and phases')
