from data import *
import re
p=ROOT/'论文LaTeX_20260926/论文/全文.tex'
s=p.read_text(encoding='utf-8')
s=s.replace('沿用20260924_v3_excel1结果和visual_v7图形','采用20260926_v4_excel1结果；Q1保持原计算版本')
s=s.replace('本轮只作成文、符号、精度与表头修订；未重跑优化或通信认证。','本轮同步新Q2/Q3、独立重放认证及继承Q4，原稿保存在20260925目录。')
s=s.replace(r'用CP-SAT按本轮目标顺序求解；主路线选择采用 $E\to N\to C_{\max}$','先用有限路线主问题选择箱组，再用CP-SAT核验与优化资源排程')
s=s.replace('主方案优先保持零期望延期，在较紧的时间上限内节能；时间优先、零延期节能和允许软延期节能方案分别展示其他偏好。','主方案在整站零期望延期条件下优先缩短全部返航时间；较短时域节能、较宽时域节能和允许软延期方案分别展示其他偏好。')
s=s.replace('一般地，在给定$\\overline C$时，可以求解','对主方案，在给定$\\overline C$时求解')
s=s.replace(r'\min_{\rm lex}(E,N,C_{\max})',r'\min_{\rm lex}(C_{\max},E,N)')
s=s.replace(r'D=0,\quad C_{\max}\le\overline C',r'D_{\rm station}=0,\quad C_{\max}\le\overline C')
s=s.replace('这里$D$采用对应求解阶段的交付定义，主方案采用整站口径，分解搜索设置在下节给出。','主方案采用整站口径。节能备选在其完成时间上限内先减小能耗；允许软延期的对照另行报告延期量。分解搜索设置在下节给出。')
s=s.replace('选择与调度模型采用CP-SAT求解\\citep{perron2023cpsat}。上述方法以邻域操作扩充候选，再在当前候选池内联合求解路线选择与资源时序。','调度子问题采用CP-SAT求解\\citep{perron2023cpsat}。邻域操作扩充候选，有限路线主问题选择箱组，调度子问题安排精确资源时序。')
s=re.sub(r'图\\ref\{fig:q2-reuse\}以主方案中的U01说明这种差别。[^\n]+',lambda m:r'图\ref{fig:q2-reuse}以主方案中的U01说明这种差别。Q2-003使用A-BAT-01，在$1968.604\,\mathrm s$返航；U01随即换用A-BAT-06，开始Q2-014的准备。原电池独立补电，无须与飞机同时释放。此后U01又使用A-BAT-05执行Q2-022，体现机体与同型电池的分离周转。',s)
s=re.sub(r'\\begin\{figure\}\[!htbp\]\\centering\s*\\includegraphics\[width=\\linewidth\]\{figures/Q2_03_battery_decoupling\}.*?\\end\{figure\}', '',s,flags=re.S)
s=s.replace('完整方案的返航时间、能耗与架次取舍；不同交付条件分别标注。','主方案、较短时域节能方案与原折中基准的返航、能耗和架次比较。')
a=s.index(r'\PaperDetail{距离与高度的共同影响}');b=s.index(r'\subsubsection{中继任务与资源周转}',a)
s=s[:a]+r'''\PaperDetail{距离与高度的共同影响}
以主方案中$2898.916\,\mathrm s$时刻的Q3T-017为接收端，固定中继Q3R-002的水平位置，在离地30至300 m范围内每5 m计算一次接入与回传裕量。提高中继高度可能解除遮挡，也会改变三维距离；两条链路均满足零裕量边界时，该高度才具有通信可行性。这是固定位置的机理分析，未重新优化任务。
\begin{figure}[!htbp]\centering
\includegraphics[width=\linewidth]{figures/Q3_02_height_margin}
\caption{固定水平位置下，中继高度对接入和回传裕量的影响。}\label{fig:q3-height}
\end{figure}
折线连接5 m高度采样值，局部跳变来自地形遮挡状态改变；实际任务的连续通信另按阶段与边界事件认证。

'''+s[b:]
s=s.replace('建立 54 条固定资源区间','建立 52 条固定资源区间')
s=s.replace('主方案的时限、能量与通信余量较紧。','主方案的返航电量和部分通信链路余量较紧。')
s=s.replace(r'\includegraphics[width=\linewidth]{figures/Q3_12_margin_exposure}',r'\includegraphics[width=\linewidth]{figures/Q3_12_margin_exposure}')
# Keep body font size, tighten only long-table row padding to avoid a single final row.
s=s.replace(r'\begingroup\setlength{\tabcolsep}{4pt}'+'\n'+r'\begin{longtable}',r'\begingroup\setlength{\tabcolsep}{4pt}\renewcommand{\arraystretch}{1.0}'+'\n'+r'\begin{longtable}')
s=s.replace(r'\subsection{联合执行结果与通信保障}',r'\Needspace{14\baselineskip}\subsection{联合执行结果与通信保障}')
start=s.index(r'\section{问题三');end=s.index(r'\section{问题四',start)
part=s[start:end].replace(r'\subsection{本问小结}',r'\FloatBarrier\subsection{本问小结}')
s=s[:start]+part+s[end:]
p.write_text(s,encoding='utf-8')
print('Final text and pagination corrections applied')
