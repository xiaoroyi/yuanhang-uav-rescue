from data import *
import re
p=ROOT/'论文LaTeX_20260926/论文/全文.tex';s=p.read_text(encoding='utf-8')
tables=re.findall(r'\\begin\{table\}.*?\\end\{table\}',s,re.S)
found=[t for t in tables if '{tab:q3-exposure}' in t or '{tab:q3-pressure}' in t]
if len(found)==2:
 m=js(BASE/'Q3_fast/metrics.json');total=m['direct_customer_seconds']+m['relay_customer_seconds']
 out=r'''\begin{table}[!htbp]\centering
\caption{低裕量暴露与固定来源的附加门限压力}\label{tab:q3-exposure}\label{tab:q3-pressure}
\begingroup\setlength{\tabcolsep}{3pt}
\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}rrrrrr@{}}\toprule
门限/dB & 暴露时长/s & 占比/\% & 时长上界/s & 失效时长/s & 失效事件\\\midrule
'''
 for row in rows(BASE/'exposure_summary.csv'):
  g=float(row['threshold'])
  if g<=4:
   nums=[g,float(row['actual_seconds']),100*float(row['actual_seconds'])/total,float(row['bound_seconds']),float(row['failure_seconds'])]
   out+=' & '.join(f'{v:.3f}' for v in nums)+' & '+row['event_failures']+r'\\'+'\n'
 out+=r'\bottomrule\end{tabular*}\endgroup\end{table}'+'\n'
 s=s.replace(found[0],out).replace(found[1],'')
 p.write_text(s,encoding='utf-8')
 print('Combined two tables with identical thresholds; all original data preserved')
