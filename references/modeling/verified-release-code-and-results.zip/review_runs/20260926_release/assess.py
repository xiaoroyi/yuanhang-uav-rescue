from pathlib import Path
import sys,json,os,hashlib,time
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
os.environ['NUMBA_CACHE_DIR']=str(HERE/'numba_cache')
sys.path.insert(0,str(ROOT/'review_runs/20260924_v1/interface_checks'))
import derive_q4
from validate import check
base=ROOT/'review_runs/20260925_overnight/reviews/morning_20260926'
entries=json.loads((base/'selected_entries.json').read_text(encoding='utf-8'))
data=derive_q4.inputs();reports=[]
for i,e in enumerate(entries):
 src=base/e['path'];q=3 if 'q3_' in e['path'] else 2
 fn='solution_q3.json' if q==3 else 'solution.json'
 assert hashlib.sha256((src/fn).read_bytes()).hexdigest()==e['solution_sha256']
 if q==2:
  out=HERE/('replay_q2_fast' if i==0 else 'replay_q2_economy');out.mkdir(exist_ok=True)
  v=check(json.loads((src/fn).read_text(encoding='utf-8')),save=out,data=data)
  assert v['summary']['valid'];print('Q2 REPLAY',v['summary'],flush=True)
 else:
  out=HERE/('q4_fast' if i==1 else 'q4_economy');derive_q4.HERE=HERE;derive_q4.q4.OUT=out
  v=derive_q4.derive(src,out)
  print('Q4',out.name,json.dumps(v,ensure_ascii=False,default=str),flush=True)
 reports.append(dict(source=e['path'],question=q,result=v))
(HERE/'inheritance_validation.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
