from data import *
from fractions import Fraction
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch,Circle,FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap
from scipy.spatial import cKDTree
from collections import defaultdict
FIG=ROOT/'paper/figures/20260926_release';FIG.mkdir(parents=True,exist_ok=True)
DEST=ROOT/'论文LaTeX_20260926/论文/figures'
plt.rcParams.update({'font.family':['SimSun','DejaVu Serif'],'font.size':11,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.labelsize':11,'xtick.labelsize':10,'ytick.labelsize':10,'legend.fontsize':10,'legend.frameon':False,'pdf.fonttype':42,'svg.fonttype':'none','mathtext.fontset':'stix','grid.color':'#DCE4E7','grid.linewidth':.6,'grid.linestyle':'-'})
C={'A':'#507CA5','B':'#C48C48','C':'#4D9477'};SC={'G01':'#527CA5','Q3R-001':'#9770AC','Q3R-002':'#C59842','Q3R-003':'#499D7D'}
SL={'G01':'地面站','Q3R-001':'中继1','Q3R-002':'中继2','Q3R-003':'中继3'}
STAGE={'准备':'#D2D8DE','爬升':'#BC7B3F','巡航':'#5F95BA','下降':'#65A582','交接':'#A987BB'}
origin=np.array(DATA['nodes']['O01']['xy']);nodes={s:np.array(v['xy']) for s,v in DATA['nodes'].items()}
sol2=js(DIR['Q2_fast']/'solution.json');sol3=js(DIR['Q3_fast']/'solution_q3.json');Q4=BASE/'q4_fast'
terrain=np.load(ROOT/'paper/figures/20260924_pro_v4/B00/FIG-G02/r02/native_crop.npz');tx,ty,tz=terrain['east_km'],terrain['north_km'],terrain['elevation_m']
if tx.ndim==1:tx,ty=np.meshgrid(tx,ty)
TC=LinearSegmentedColormap.from_list('terrain',['#F1F3E8','#CFDCC1','#A5C197','#67866C'])
def save(f,alias,values=None):
    import shutil,warnings
    d=FIG/alias;d.mkdir(exist_ok=True);f.canvas.draw()
    for ext in ['pdf','png','svg']:
        f.savefig(d/('figure.'+ext),dpi=220,facecolor='white');shutil.copy2(d/('figure.'+ext),DEST/(alias+'.'+ext))
    if values is not None:
        if isinstance(values,pd.DataFrame):values.to_csv(d/'values.csv',index=False,encoding='utf-8-sig')
        else:dump(d/'values.json',values)
    dump(d/'metadata.json',dict(numeric_release='20260926_v4_excel1',width_mm=f.get_figwidth()*25.4,height_mm=f.get_figheight()*25.4,source_selection=SEL,script=__file__,qa='rendered; pending visual review'))
    plt.close(f);print('SAVED',alias,flush=True)
def new(h=100):return plt.figure(figsize=(165/25.4,h/25.4),layout='constrained')
def back(ax):
    ax.pcolormesh(tx,ty,tz,cmap=TC,vmin=100,vmax=750,shading='auto',rasterized=True,alpha=.75)
    for s,v in nodes.items():
        p=(v-origin)/1000;ax.scatter(*p,s=35 if s=='O01' else 15,color='#314B50',marker='s' if s=='O01' else 'o',zorder=6);ax.annotate(s,p,xytext=(3,3),textcoords='offset points',fontsize=8,zorder=7)
    ax.set(xlabel='东向距离/km',ylabel='北向距离/km',aspect='equal')
def route(ax,rr,alpha=.55):
    for r in rr:
        visits=['O01']+[s for s,b in r['route']['stops']]+['O01']
        for a,b in zip(visits,visits[1:]):
            pa,pb=(nodes[a]-origin)/1000,(nodes[b]-origin)/1000
            ax.add_patch(FancyArrowPatch(pa,pb,connectionstyle='arc3,rad=0.035',arrowstyle='-|>',mutation_scale=7,lw=.8,color=C[r['route']['model']],alpha=alpha,zorder=4))
def modellegend(f):f.legend(handles=[Patch(color=C[g],label=g+'型') for g in 'ABC'],loc='outside upper center',ncol=3)
def gantt(ax,rr,key,ends=None):
    names=sorted({r[key] for r in rr});index={x:i for i,x in enumerate(names)}
    for r in rr:
        i=index[r[key]];a=r['start']/60;b=r['return']/60
        ax.broken_barh([(a,b-a)],(i-.32,.64),facecolors=C[r['route']['model']],edgecolors='white',linewidth=.7)
        if b-a>6:ax.text((a+b)/2,i,r['sortie'].split('-')[-1],ha='center',va='center',fontsize=8,color='white')
        if ends:
            e=ends[r['sortie']]/60;ax.broken_barh([(b,e-b)],(i-.32,.64),facecolors='#CFD8DF')
    ax.set(yticks=range(len(names)),yticklabels=names,xlabel='任务启动后的时间/min',ylim=(len(names)-.4,-.6));ax.grid(axis='x',alpha=.65);ax.set_axisbelow(True)
def phases_df(sid):return pd.read_csv(BASE/sid/'phases.csv')
def phase_energy(tr,ph):
    boxes={b['id']:b for b in DATA['boxes']};out=[]
    for r in tr:
        model=DATA['models'][r['route']['model']];load=r['route']['mass'];e=0;stop=0
        for p in ph[ph.sortie==r['sortie']].sort_values('start').to_dict('records'):
            de=0.
            if p['stage']=='爬升':de=(model['m0']+load)*9.81*(p['z1']-p['z0'])/(model['eta']*3600000)
            if p['stage']=='巡航':de=model['Euse']*np.hypot(p['x1']-p['x0'],p['y1']-p['y0'])/(model['L0']-(model['L0']-model['LF'])*(load/model['Q'])**1.5)
            after=load
            if p['stage']=='交接':after-=sum(boxes[b]['weight'] for b in r['route']['stops'][stop][1]);stop+=1
            out.append(dict(**p,load0=load,load1=after,soc0=100*(1-e/model['Euse']),soc1=100*(1-(e+de)/model['Euse'])));e+=de;load=after
        assert abs(e-r['route']['energy'])<1e-7
    return pd.DataFrame(out)
def plotstate(sid,tr,alias,communication=False):
    ph=phase_energy(tr,phases_df(sid));counts=defaultdict(int)
    if communication:
        for x in rows(DIR[sid]/'communication_intervals_q3.csv'):
            if x['source']!='G01':counts[x['sortie']]+=1
        chosen=max(counts,key=counts.get)
    else:chosen=max(tr,key=lambda x:len(x['route']['stops']))['sortie']
    pp=ph[ph.sortie==chosen];f=new(125);axs=f.subplots(4 if communication else 3,1,sharex=True,gridspec_kw={'height_ratios':[1,1,1,.55] if communication else [1,1,1]})
    for p in pp.itertuples():
        t=np.array([p.start,p.end])/60
        axs[0].plot(t,[p.z0,p.z1],color=STAGE[p.stage],lw=2.5)
        axs[1].plot(t,[p.load0,p.load0],color='#527CA5',lw=2);axs[1].plot([t[1],t[1]],[p.load0,p.load1],color='#527CA5')
        axs[2].plot(t,[p.soc0,p.soc1],color='#548E70',lw=2)
    axs[0].set(ylabel='海拔/m',title=chosen+'：实际阶段变化',ylim=(0,max(pp.z1)*1.15));axs[1].set(ylabel='载荷/kg');axs[2].set(ylabel='电量/%',ylim=(0,105));axs[2].axhline(20,color='#BD794B',lw=1);axs[2].text(pp.start.min()/60,23,'20%储备',ha='left',fontsize=9)
    if communication:
        ci=[x for x in rows(DIR[sid]/'communication_intervals_q3.csv') if x['sortie']==chosen]
        for x in ci:axs[3].broken_barh([(float(x['start'])/60,(float(x['end'])-float(x['start']))/60)],(0,.7),facecolors=SC[x['source']])
        axs[3].set(yticks=[],ylabel='来源');f.legend(handles=[Patch(color=SC[x],label=SL[x]) for x in sorted({x['source'] for x in ci})],loc='outside lower center',ncol=3)
    axs[-1].set_xlabel('任务启动后的时间/min');f.legend(handles=[Patch(color=STAGE[x],label=x) for x in ['爬升','巡航','下降','交接']],loc='outside upper center',ncol=4)
    for ax in axs[:3]:ax.grid(alpha=.5)
    save(f,alias,pp);dump(BASE/('example_'+sid+'.json'),dict(sortie=chosen))
def q2plots():
    f=new(142);ax=f.subplots(2,1,gridspec_kw={'height_ratios':[1.4,1]});back(ax[0]);route(ax[0],sol2);modellegend(f)
    stops=pd.read_csv(DIR['Q2_fast']/'stop_events.csv');servicecol='service' if 'service' in stops else 'destination'
    for p in stops.itertuples():ax[1].scatter(p.departure/60,int(getattr(p,servicecol)[1:]),s=35,color=C[next(x['route']['model'] for x in sol2 if x['sortie']==p.sortie)])
    ax[1].set(xlabel='整站交付时间/min',ylabel='服务区',yticks=range(1,16),yticklabels=[f'{i:02d}' for i in range(1,16)]);ax[1].grid(alpha=.5);save(f,'Q2_04_spacetime_routes',stops)
    bats=pd.read_csv(DIR['Q2_fast']/'battery_timeline.csv');ends={r.sortie:float(r.charging_end) for r in bats.itertuples()}
    for alias,key,h in [('Q2_06_aircraft_schedule','aircraft',105),('Q2_07_battery_schedule','battery',140)]:
        f=new(h);ax=f.subplots();gantt(ax,sol2,key,ends if key=='battery' else None)
        f.legend(handles=[Patch(color=C[g],label=g+'型') for g in 'ABC']+([Patch(color='#CFD8DF',label='返航后补电')] if key=='battery' else []),loc='outside upper center',ncol=4)
        save(f,alias,sol2)
    f=new(86);axs=f.subplots(2,1,sharex=True);chosen=[r for r in sol2 if r['aircraft']=='U01'];gantt(axs[0],chosen,'aircraft');gantt(axs[1],chosen,'battery',ends);axs[0].set_title('同一飞机换电执行，电池各自补电');save(f,'Q2_03_battery_decoupling',chosen)
    plotstate('Q2_fast',sol2,'Q2_05_multistop_state')
    f=new(113);axs=f.subplots(3,1,sharex=True)
    for g,ax in zip('ABC',axs):
        rr=[x for x in sol2 if x['route']['model']==g];cuts=sorted({0}|{t for r in rr for t in [r['start'],r['return'],ends[r['sortie']]]})
        for what,col,stock in [('aircraft',C[g],DATA['M'][g]),('battery','#929BA8',DATA['K'][g])]:
            count=[sum(r['start']<=t<(r['return'] if what=='aircraft' else ends[r['sortie']]) for r in rr) for t in cuts];ax.step(np.array(cuts)/60,count,where='post',color=col,label='飞机' if what=='aircraft' else '电池');ax.axhline(stock,color=col,lw=.7,alpha=.6)
        ax.set(ylabel=g+'型数量');ax.set_ylim(0,DATA['K'][g]+1);ax.legend(ncol=2,loc='upper right');ax.grid(alpha=.4)
    axs[-1].set_xlabel('任务启动后的时间/min');save(f,'Q2_08_ready_inventory')
    dd=pd.read_csv(BASE/'Q2_fast/station_deliveries.csv');f=new(112);axs=f.subplots(2,1)
    services=sorted(dd.service.unique())
    for i,s in enumerate(services):
        d=dd[dd.service==s];axs[0].plot([d.station_complete.min()/60,d.station_complete.max()/60],[i,i],lw=5,color='#76A4C4');axs[0].scatter(d.station_complete/60,[i]*len(d),s=12,color='#375E83')
    axs[0].set(yticks=range(15),yticklabels=services,xlabel='整站交付时间/min');hard=dd.dropna(subset=['station_hard_slack']).sort_values('station_hard_slack');axs[1].plot(np.arange(1,len(hard)+1),hard.station_hard_slack/60,color='#4D9477',marker='o',ms=3);axs[1].set(xlabel='31个硬截止货箱（按余量排序）',ylabel='硬截止余量/min');axs[1].grid(alpha=.5);save(f,'Q2_10_delivery_dashboard',dd)
    strategies('Q2_09_strategy_profiles',2)
def strategies(alias,q):
    selected=[f'Q{q}_fast',f'Q{q}_economy'];mm=[js(BASE/s/'metrics.json') for s in selected];names=['时间优先','节能备选'];old=js(ROOT/'review_runs/20260924_v3/selected_versions.json');oid='Q2_balanced' if q==2 else 'Q3_conservative';od=ROOT/next(x['directory'] for x in old['solutions'] if x['id']==oid);mm.append(js(od/('validation.json' if q==2 else 'validation_q3.json'))['summary']);names.append('原主方案')
    f=new(85);axs=f.subplots(1,3)
    for ax,key,title in zip(axs,['Cmax' if q==2 else 'C_joint','E' if q==2 else 'E_total','N' if q==2 else 'N_transport'],['全部返航/min','总能耗/kWh','运输架次']):
        vals=[m[key]/60 if key.startswith('C') else m[key] for m in mm];ax.barh(range(3),vals,color=['#5685AD','#70A489','#C5CCD1']);ax.set(yticks=range(3),yticklabels=names if ax==axs[0] else [],xlabel=title,ylim=(2.7,-.7));ax.set_xlim(0,max(vals)*1.24)
        for i,v in enumerate(vals):ax.text(v+max(vals)*.02,i,f'{v:.3f}' if key[0]!='N' else str(v),va='center',fontsize=9)
    save(f,alias,mm)
def occupancy(intervals):
    cuts=sorted({0.}|{float(r[k]) for r in intervals for k in ['start','end']});return np.array(cuts),[sum(float(r['start'])<=t<float(r['end']) for r in intervals) for t in cuts]
def q3resources():
    f=new(154);axs=f.subplots(3,1,sharex=True,gridspec_kw={'height_ratios':[2.4,1,1.2]});gantt(axs[0],sol3['transport'],'aircraft');axs[0].set_xlabel('');axs[0].set_title('运输机')
    iv=rows(DIR['Q3_fast']/'relay_resource_timeline.csv')
    for ax,typ in zip(axs[1:],['relay','component']):
        items=[r for r in iv if r['resource']==typ];ids=sorted({r['id'] for r in items});idx={x:i for i,x in enumerate(ids)}
        for r in items:
            sr=next(x for x in sol3['relay'] if x['sortie']==r['sortie']);y=idx[r['id']];a,b=float(r['start'])/60,float(r['end'])/60;ax.broken_barh([(a,b-a)],(y-.25,.5),facecolors='#D5DCE1');ax.broken_barh([(a,(sr['return']-sr['start'])/60)],(y-.25,.5),facecolors=SC[sr['sortie']]);ax.text(a,y+.38,f'{a:.2f}',fontsize=8,ha='left');ax.text((sr['link_complete']+sr['service_end'])/120,y,sr['sortie'].replace('Q3R-','R'),ha='center',va='center',color='white',fontsize=9)
        ax.set(yticks=range(len(ids)),yticklabels=ids,ylim=(len(ids)-.4,-.6),title='中继机体（灰色为周转）' if typ=='relay' else '能源组件（灰色为补电）');ax.grid(axis='x',alpha=.4)
    axs[-1].set_xlabel('任务启动后的时间/min');save(f,'Q3_05_joint_resources',iv)
def q3sources():
    ci=pd.read_csv(DIR['Q3_fast']/'communication_intervals_q3.csv');f=new(147);axs=f.subplots(2,1,sharex=True,gridspec_kw={'height_ratios':[3,1]});ids=[r['sortie'] for r in sol3['transport']]
    for x in ci.itertuples():axs[0].broken_barh([(x.start/60,(x.end-x.start)/60)],(ids.index(x.sortie)-.35,.7),facecolors=SC[x.source])
    axs[0].set(yticks=range(len(ids)),yticklabels=[x.replace('Q3T-','T') for x in ids],ylim=(len(ids)-.4,-.6));axs[0].tick_params(axis='y',labelsize=8);f.legend(handles=[Patch(color=SC[x],label=SL[x]) for x in SC],loc='outside upper center',ncol=4)
    for rid in list(SC)[1:]:
        x,y=occupancy(ci[ci.source==rid].to_dict('records'));axs[1].step(x/60,y,where='post',label=SL[rid],color=SC[rid])
    axs[1].set(xlabel='任务启动后的时间/min',ylabel='同时服务/架');axs[1].grid(alpha=.5);save(f,'Q3_07_sources_concurrency',ci)
    m={r['sortie']:r['route']['model'] for r in sol3['transport']};mat=np.zeros((4,3))
    for x in ci.itertuples():mat[list(SC).index(x.source),'ABC'.index(m[x.sortie])]+=(x.end-x.start)/60
    f=new(90);ax=f.subplots();left=np.zeros(4)
    for i,g in enumerate('ABC'):
        ax.barh(range(4),mat[:,i],left=left,color=C[g],label=g+'型')
        for j,v in enumerate(mat[:,i]):
            if v>22:ax.text(left[j]+v/2,j,f'{v:.1f}',ha='center',va='center',color='white',fontsize=10)
        left+=mat[:,i]
    ax.set(yticks=range(4),yticklabels=list(SL.values()),xlabel='逐机累计保障时间/min',ylim=(3.6,-.6));ax.legend(ncol=3);save(f,'Q3_08_service_sankey',mat.tolist())
def radio():
    cache=BASE/'exposure_cache';communication.CACHE=cache;return communication.Radio(DATA)
def q3map():
    eng=radio();f=new(150);axs=f.subplots(2,1,gridspec_kw={'height_ratios':[1,1]});back(axs[0]);route(axs[0],sol3['transport'])
    for r in sol3['relay']:
        p=(np.array([r['site']['x'],r['site']['y']])-origin)/1000;axs[0].scatter(*p,marker='^',s=70,color=SC[r['sortie']],zorder=9);axs[0].annotate(SL[r['sortie']],p,xytext=(5,-10),textcoords='offset points',fontsize=10,color=SC[r['sortie']])
    axs[0].set_title('(a) 真实航线与中继部署');modellegend(f);back(axs[1])
    for label in axs[1].texts:label.set_visible(False)
    anchors=[('G01',np.array(DATA['gateway']))]+[(r['sortie'],np.array([r['site'][k] for k in ['x','y','z']])) for r in sol3['relay']]
    bounds=[]
    for rid,p in anchors:
        kind='direct' if rid=='G01' else 'access';radius=10**((eng.limits[kind]-eng.base)/20)/1000;xy=(p[:2]-origin)/1000
        axs[1].add_patch(Circle(xy,radius,fc=SC[rid],ec='none',alpha=.035));axs[1].add_patch(Circle(xy,radius,fill=False,ec=SC[rid],lw=1.3));axs[1].scatter(*xy,marker='s' if rid=='G01' else '^',s=35,color=SC[rid]);bounds.extend([xy-radius,xy+radius])
    bounds=np.array(bounds);axs[1].set_title('(b) 无遮挡距离上限；非实际覆盖边界');axs[1].set_xlim(bounds[:,0].min()-.4,bounds[:,0].max()+.4);axs[1].set_ylim(bounds[:,1].min()-.4,bounds[:,1].max()+.4)
    axs[1].legend(handles=[Patch(color=SC[rid],label=SL[rid]) for rid,p in anchors],loc='upper left',fontsize=8,ncol=2);save(f,'Q3_04_terrain_relay_scene',sol3['relay'])
def q3coverage():
    eng=radio();f=new(156);axs=f.subplots(3,2,gridspec_kw={'width_ratios':[1.25,1]});tree=cKDTree(np.column_stack([tx.ravel(),ty.ravel()]));gx,gy=np.meshgrid(np.linspace(tx.min(),tx.max(),26),np.linspace(ty.min(),ty.max(),26));zz=tz.ravel()[tree.query(np.column_stack([gx.ravel(),gy.ravel()]))[1]].reshape(gx.shape)
    values=[]
    for i,r in enumerate(sol3['relay']):
        anchor=np.array([r['site'][k] for k in ['x','y','z']]);backmargin=eng.point(DATA['gateway'],anchor,'backhaul')['margin'];m=[]
        for x,y,z in zip(gx.ravel(),gy.ravel(),zz.ravel()):m.append(min(backmargin,eng.point(anchor,[origin[0]+1000*x,origin[1]+1000*y,z+30],'access')['margin']))
        mm=np.array(m).reshape(gx.shape);ax=axs[i,0];ax.pcolormesh(gx,gy,mm>=0,cmap=LinearSegmentedColormap.from_list('cover',['#EEF0EA',SC[r['sortie']]]),shading='nearest',alpha=.55);ax.scatter((anchor[0]-origin[0])/1000,(anchor[1]-origin[1])/1000,marker='^',s=40,color=SC[r['sortie']]);radius=10**((eng.limits['access']-eng.base)/20)/1000;ax.add_patch(Circle((anchor[:2]-origin)/1000,radius,fill=False,color=SC[r['sortie']],lw=1));ax.set(aspect='equal',xlim=(tx.min(),tx.max()),ylim=(ty.min(),ty.max()),title=SL[r['sortie']],xlabel='东向/km',ylabel='北向/km');ax.tick_params(labelsize=8)
        ax=axs[i,1];start=r['link_complete']/60;end=r['service_end']/60;ax.barh([0],[end-start],left=start,height=.36,color=SC[r['sortie']]);ax.text(start,.24,f'{start:.3f} min',fontsize=9);ax.text(end,-.28,f'{end:.3f} min',ha='right',fontsize=9);ax.set(yticks=[],xlabel='实际服务时段/min',xlim=(0,100),ylim=(-.65,.7));ax.grid(axis='x',alpha=.5)
        values.append(dict(relay=r['sortie'],points=676,feasible=int((mm>=0).sum()),start=start,end=end));print('coverage',i,flush=True)
    save(f,'Q3_06_relay_coverage',values)
def raycase():
    eng=radio();ci=rows(DIR['Q3_fast']/'communication_intervals_q3.csv');ph=pd.read_csv(BASE/'Q3_fast/phases.csv');rr=max((x for x in ci if x['source']!='G01'),key=lambda x:float(x['end'])-float(x['start']));t=(float(rr['start'])+float(rr['end']))/2;p=ph[(ph.sortie==rr['sortie'])&(ph.phase==int(rr['phase']))].iloc[0];u=(t-p.start)/(p.end-p.start);xyz=np.array([p[f'{k}0']+u*(p[f'{k}1']-p[f'{k}0']) for k in 'xyz']);relay=next(r for r in sol3['relay'] if r['sortie']==rr['source']);rp=np.array([relay['site'][k] for k in 'xyz']);gate=np.array(DATA['gateway']);case=dict(time=t,sortie=rr['sortie'],relay=rr['source'],transport=xyz.tolist());dump(BASE/'ray_example.json',case)
    return eng,[(gate,xyz,'direct','地面站→运输机'),(rp,xyz,'access','中继→运输机'),(gate,rp,'backhaul','地面站→中继')]
def rays():
    import shapely
    eng,pairs=raycase();f=new(134);axs=f.subplots(3,1);out=[]
    for ax,(a,b,kind,title) in zip(axs,pairs):
        lowa=np.array([a[0],a[1],-1e6]);lowb=np.array([b[0],b[1],-1e6]);vs,hs=eng.cells(lowa,lowb,lowb);line=shapely.LineString([a[:2],b[:2]]);polys=shapely.polygons(vs);ids=np.flatnonzero(shapely.intersects(polys,line));vec=b[:2]-a[:2];length=np.linalg.norm(vec);cells=[]
        for j in ids:
            xy=shapely.get_coordinates(shapely.intersection(polys[j],line))
            if len(xy):v=(xy-a[:2])@vec/(length**2);cells.append((max(0,v.min())*length,min(1,v.max())*length,float(hs[j])))
        for lo,hi,z in sorted(cells):ax.fill_between([lo/1000,hi/1000],[z,z],color='#B0C39E');ax.plot([lo/1000,hi/1000],[z,z],color='#718663',lw=.6)
        val=eng.point(a,b,kind);ax.plot([0,length/1000],[a[2],b[2]],color='#A86647' if not val['valid'] else '#4A8C72',lw=2);ax.set(xlabel='各链路沿线距离/km',ylabel='海拔/m',ylim=(0,800),title=f'{title}：'+('可用' if val['valid'] else '不可用')+f"，余量{val['margin']:.3f} dB");out.append(dict(kind=kind,**val))
    save(f,'Q3_10_three_link_profiles',out)
    # Height response uses the same representative horizontal relay location and actual receiver.
    f=new(100);axs=f.subplots(1,2);a,b,_,_=pairs[1];ground=next(r['site']['ground'] if 'ground' in r['site'] else r['site']['z']-r['site'].get('agl',300) for r in sol3['relay'] if np.linalg.norm(np.array([r['site'][k] for k in 'xy'])-a[:2])<.01);height=np.arange(30,301,5);access=[];back=[]
    for h in height:
        p=np.array([a[0],a[1],ground+h]);access.append(eng.point(p,b,'access')['margin']);back.append(eng.point(DATA['gateway'],p,'backhaul')['margin'])
    for ax,values,title in zip(axs,[access,back],['接入链路','回传链路']):ax.plot(height,values,color='#557FA6');ax.axhline(0,color='#BD8B4E',lw=1);ax.set(xlabel='中继离地高度/m',ylabel='剩余通信裕量/dB',title=title);ax.grid(alpha=.4)
    save(f,'Q3_02_height_margin',dict(heights=height.tolist(),access=access,backhaul=back))
def exposureplot():
    from exposure import low_duration
    data=js(BASE/'exposure_cache/derived_exposure.json');g=np.linspace(0,8,161);actual=[sum(low_duration(s,x) for s in data['segments'])/60 for x in g];bound=[sum(s['duration'] for s in data['conservative'] if s['lower_bound']<=x)/60 for x in g];stress=pd.read_csv(BASE/'exposure_summary.csv');f=new(65);axs=f.subplots(1,2,gridspec_kw={'width_ratios':[1.2,1]})
    axs[0].fill_between(g,actual,bound,color='#DCE7EC');axs[0].plot(g,actual,color='#4F88A8',label='实际累计');axs[0].step(g,bound,where='post',color='#9C8C72',label='区间下界给出的上界');axs[0].set(xlabel='剩余通信裕量门限/dB',ylabel='逐机累计时间/min');axs[0].legend(fontsize=8,loc='upper left')
    d=stress[stress.threshold.isin([0,.5,1,2,4])];axs[1].bar(d.threshold.astype(str),d.failure_seconds/60,color='#B2876B');axs[1].set(xlabel='附加通信要求/dB',ylabel='固定来源失效时间/min');axs[1].grid(axis='y',alpha=.4);save(f,'Q3_12_margin_exposure',stress)
def q4plots():
    comp=js(Q4/'components_q4.json');sub=js(Q4/'group_subsets_q4.json');summ=js(Q4/'run_summary.json');ss={k:js(Q4/f'solution_k{k}.json') for k in [2,3]};edges=[e for e in comp['edges'] if len(e['services'])>1];services=[s for a in comp['atoms'] for s in a['services']];mat=np.array([[int(s in e['services']) for e in edges] for s in services]);f=new(123);ax=f.subplots();ax.imshow(mat,cmap=LinearSegmentedColormap.from_list('assoc',['#EFF2F3','#5F95AF']),aspect='auto');ax.set(yticks=range(15),yticklabels=services,xticks=range(len(edges)),xticklabels=[e['id'].replace('Q3T-','运输').replace('Q3R-','中继') for e in edges]);ax.tick_params(axis='x',rotation=35);ax.set_title('着色：该服务区参与此任务');ax.axhline(.5,color='white',lw=3);ax.axhline(13.5,color='white',lw=3);save(f,'Q4_02_task_hypergraph',comp)
    aa=[sub[str(1<<i)] for i in range(3)];f=new(85);ax=f.subplots();w=np.array([float(Fraction(a['Wtransport']))/3600 for a in aa]);r=np.array([float(Fraction(a['Wrelay']))/3600 for a in aa]);ax.barh(range(3),w,color='#648FB3',label='运输');ax.barh(range(3),r,left=w,color='#AB91B7',label='中继');ax.set(yticks=range(3),yticklabels=['C1：S001','C2：其余13区','C3：S006'],xlabel='累计任务工时/h',ylim=(2.6,-.6));ax.legend(ncol=2)
    for i,v in enumerate(w+r):ax.text(v+.15,i,f'{v:.3f}',va='center');ax.set_xlim(0,14.5)
    save(f,'Q4_03_workload_treemap',aa)
    parts=rows(Q4/'all_partitions_q4.csv');f=new(103);axs=f.subplots(2,1,sharex=True);x=np.arange(4);axs[0].bar(x-.18,[float(Fraction(p['Jgap'])) for p in parts],.36,label='库存缺口',color='#B38B63');axs[0].bar(x+.18,[float(Fraction(p['Jsize'])) for p in parts],.36,label='总配置',color='#6896AE');axs[0].legend(ncol=2);axs[0].set_ylabel('库存归一化指标');axs[1].bar(x,[float(Fraction(p['CV2'])) for p in parts],color='#74A18C');axs[1].set(xticks=x,xticklabels=[p['id'] for p in parts],ylabel='工作量变异系数平方');save(f,'Q4_04_partition_profiles',parts)
    for k in [2,3]:
        f=new(114);ax=f.subplots();back(ax)
        for i,g in enumerate(ss[k]['groups']):
            xy=np.array([(nodes[s]-origin)/1000 for s in g['services']]);ax.scatter(xy[:,0],xy[:,1],s=130,color=['#6D9CBE','#BA9863','#7DA689'][i],edgecolor='white',linewidth=1,label=f'第{i+1}组（{len(g["services"])}区）',zorder=5)
        ax.legend(loc='upper right');save(f,'Q4_05_partition_map_k2' if k==2 else 'Q4_06_partition_map_k3',ss[k])
    f=new(118);axs=f.subplots(2,1,sharex=True);labels=['A机','B机','C机','A电池','B电池','C电池','中继机','组件'];x=np.arange(8)
    for k,ax in zip([2,3],axs):ax.bar(x-.18,summ['stock'],.36,color='#CCD4DA',label='原库存');ax.bar(x+.18,ss[k]['selected']['N'],.36,color='#6290AC',label='独立需求');ax.set(title=f'{k}组配置',ylabel='架/组',xticks=x,xticklabels=labels);ax.legend(ncol=2);ax.grid(axis='y',alpha=.4)
    save(f,'Q4_07_resource_radar',summ)
    iv=rows(Q4/'resource_intervals_q4.csv');f=new(121);axs=f.subplots(2,1,sharex=True)
    for resource,ax in zip(['U_C','BAT_C'],axs):
        allrows=[r for r in iv if r['resource']==resource];xx,yy=occupancy(allrows);ax.step(xx/60,yy,where='post',color='#354F65',lw=2,label='集中共享并发')
        peak=0
        for i,g in enumerate(ss[2]['groups']):
            tasks=set(g['transport']+g['relay']);subset=[r for r in allrows if r['task'] in tasks];x,y=occupancy(subset);ax.step(x/60,y,where='post',color=['#6F9BB9','#BF9662'][i],label=f'第{i+1}组');peak+=max(y,default=0)
        ax.axhline(peak,color='#A67594',lw=1.3,label='各组峰值之和');ax.set(ylabel='同时占用数量',title='C型飞机' if resource=='U_C' else 'C型电池');ax.grid(alpha=.4)
    axs[0].legend(ncol=2,fontsize=9);axs[-1].set_xlabel('任务启动后的时间/min');save(f,'Q4_08_sharing_loss',iv)
if __name__=='__main__':
    q2plots();q3resources();q3sources();q3map();q3coverage();plotstate('Q3_fast',sol3['transport'],'Q3_09_integrated_state',True);rays();strategies('Q3_11_strategy_dashboard',3);exposureplot();q4plots()
