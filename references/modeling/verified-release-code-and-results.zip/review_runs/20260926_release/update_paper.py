from data import *
from fractions import Fraction
import re,collections
PAPER=ROOT/'论文LaTeX_20260926/论文'
original=(ROOT/'论文LaTeX_20260925/论文/全文.tex').read_text(encoding='utf-8')
def num(x):return f'{float(Fraction(str(x))):.3f}'
def esc(x):return str(x).replace('_',r'\_').replace('%',r'\%')
def tabletex(label,title,heads,rr,widths=None,long=False):
    n=len(heads);widths=widths or [1/n]*n
    spec='@{}'+''.join(r'>{\centering\arraybackslash}p{\dimexpr '+f'{w:.5f}'+r'\linewidth-'+f'{8*(n-1)*w:.3f}'+r'pt\relax}' for w in widths)+'@{}'
    top=r'\toprule'+'\n'+' & '.join(heads)+r'\\'+'\n'+r'\midrule'+'\n'
    body='\n'.join(' & '.join(str(v) for v in r)+r'\\' for r in rr)+'\n'
    pre=r'\begingroup\setlength{\tabcolsep}{4pt}'+'\n'
    if long:
        return pre+r'\begin{longtable}{'+spec+'}\n'+r'\caption{'+title+r'}\label{tab:'+label+r'}\\'+'\n'+top+r'\endfirsthead'+'\n'+top+r'\endhead\bottomrule\endfoot'+'\n'+body+r'\end{longtable}\endgroup'+'\n'
    return '\n'+r'\begin{table}[!htbp]\centering'+'\n'+r'\caption{'+title+r'}\label{tab:'+label+'}\n'+pre+r'\begin{tabular}{'+spec+'}\n'+top+body+r'\bottomrule\end{tabular}\endgroup\end{table}'+'\n'
def fig(alias,label,caption,width=r'\linewidth'):
    return '\n'+r'\begin{figure}[!htbp]\centering'+'\n'+r'\includegraphics[width='+width+r']{figures/'+alias+'}\n'+r'\caption{'+caption+r'}\label{fig:'+label+r'}\end{figure}'+'\n'
def replace_table(s,label,t):
    # Existing table and longtable environments have no nested environments of these types.
    pat=r'\\begin\{(table|longtable)\}.*?\\end\{\1\}'
    found=False
    def sub(m):
        nonlocal found
        if '{tab:'+label+'}' in m[0]:found=True;return t
        return m[0]
    s=re.sub(pat,sub,s,flags=re.S);assert found,label;return s
def extract(s,a,b):return s[s.index(a):s.index(b,s.index(a)+len(a))]
def eq(s,label):
    return next(e for e in re.findall(r'\\begin\{equation\}.*?\\end\{equation\}',s,re.S) if '{eq:'+label+'}' in e)+'\n'
q2old=(BASE/'old_q2.tex').read_text(encoding='utf-8');q3old=(BASE/'old_q3.tex').read_text(encoding='utf-8');q4old=(BASE/'old_q4.tex').read_text(encoding='utf-8')
q2=js(DIR['Q2_fast']/'solution.json');q3=js(DIR['Q3_fast']/'solution_q3.json');M2=js(BASE/'Q2_fast/metrics.json');M3=js(BASE/'Q3_fast/metrics.json')
Q4=BASE/'q4_fast';S4={k:js(Q4/f'solution_k{k}.json') for k in (2,3)};subsets=js(Q4/'group_subsets_q4.json');summary4=js(Q4/'run_summary.json');atoms=js(Q4/'components_q4.json')['atoms']
def triptables(sid,prefix,labels):
    d=DIR[sid];tr=js(d/('solution.json' if sid.startswith('Q2') else 'solution_q3.json'));tr=tr if isinstance(tr,list) else tr['transport'];vd=d if sid.startswith('Q2') else d/'transport_validation'
    sorties={x['sortie']:x for x in rows(vd/'sorties.csv')};st=rows(vd/'stop_events.csv');deliver=rows(BASE/sid/'station_deliveries.csv')
    a=[];b=[]
    for r in tr:
        rt=r['route'];ss=sorties[r['sortie']]
        a.append([r['sortie'],r['aircraft']+'/'+rt['model'],r['battery'],'$\\to$'.join(v[0] for v in rt['stops']),len(rt['boxes']),int(rt['mass']),int(float(ss['volume_L']))])
        b.append([r['sortie'],num(r['start']),num(r['start']+rt['prep']),num(r['return']),num(rt['energy']),num(100*rt['soc'])])
    out=tabletex(labels[0],prefix+'运输安排与装载规模',['架次','飞机/型','电池','访问顺序','箱数','质量/kg','体积/L'],a,[.12,.12,.15,.25,.08,.14,.14],True)
    out+=tabletex(labels[1],prefix+'运输时刻、能耗与返航电量',['架次','准备开始/s','起飞/s','返航/s','能耗/kWh','返航电量/\\%'],b,[.14,.18,.18,.18,.16,.16],True)
    dd=[]
    for x in st:
        boxes=json.loads(x['boxes']);dd.append([x['sortie'],x['service'] if 'service' in x else x['destination'],', '.join(z.replace(x.get('service','')+'-','') for z in boxes),num(x['departure'])])
    out+=tabletex(labels[2],prefix+'全部停靠的整站交付',['架次','服务区','本站货箱编号','交付/s'],dd,[.14,.12,.56,.18],True)
    hard=sorted((x for x in deliver if x['station_hard_slack']),key=lambda x:float(x['station_hard_slack']))[:8]
    out+=tabletex(labels[3],prefix+'整站硬截止最紧的八箱',['货箱','架次','交付/s','硬截止/s','余量/s'],[[x['box'],x['sortie'],num(x['station_complete']),num(x['hard_due']),num(x['station_hard_slack'])] for x in hard],[.27,.16,.19,.19,.19])
    return out

# Q2: preserve physical model and baseline experiments; replace current solution and search identity.
q2head=q2old[:q2old.index(r'\subsection{运输方案与执行安排}')]
a=q2head.index(r'\PaperDetail{主方案') if r'\PaperDetail{主方案' in q2head else -1
if a>=0:q2head=q2head[:a]
else:
    # Last former solver subsection starts after the unchanged precision/rebuild equations.
    pos=q2head.find(r'\caption{主方案各阶段的求解记录}')
    if pos>=0:
        a=q2head.rfind(r'\PaperDetail',0,pos);q2head=q2head[:a]
q2head=q2head.replace('逐箱方式用于第一阶段路线选择和基准对照','逐箱方式用于基准对照').replace('两阶段主方案的形成与资源校验流程','候选扩充、路线选择与资源排程流程')
q2head=q2head.replace('用CP-SAT按本轮目标顺序求解；主路线选择采用 $E\to N\to C_{\max}$','以有限路线主问题选择箱组，再用CP-SAT核验与优化资源排程')
q2head=q2head.replace('按主方案的两步设置完成路线选择与整站时序重排','在整站零延期条件下比较完整方案，时间优先选取主方案')
q2head=re.sub(r'主方案先.*?作为主方案。','主方案采用整站零延期条件下的时间优先偏好，另保留节能方案说明取舍。',q2head,flags=re.S) if '主方案先' in q2head[:1500] else q2head
q2head+=r'''
\PaperDetail{有限路线主问题与资源排程分解}
为扩大可比较的路线集合，将路线选择与精确资源排程分开处理。主问题保留逐箱唯一覆盖和必要资源条件，以线性松弛筛选有潜力的列，再在候选子集上求整数路线组合。选定路线交由CP-SAT安排飞机、电池及开始时刻；不可执行的组合反馈给后续搜索。该结构借鉴主问题与调度子问题分解的思想\citep{hooker2003}，搜索中使用的临时排除条件与经过证明的不可行条件分开记录。

候选扩充包含移箱、换箱、拆并、换型与访问顺序调整，其邻域设计可参考车辆路径大邻域搜索\citep{ropke2006}；本文不将这些操作等同于该文的完整自适应算法。整夜搜索并行运行路线扩充、分解排程和运输--中继联合搜索，共运行约10小时。各Q2路线池约33万列，池间共享候选，不能相加为独立路线总数。

主方案按$D_{\rm station}=0$筛选完整方案，优先比较$C_{\max}$，相同完成时间下比较能耗。分解主问题的松弛下界仅对应当时的有限路线集合；搜索排除条件也不构成原问题不可行证明。本文保留最终完整方案和独立物理回放记录，\textbf{不宣称问题二的全局最优性}。
'''
q2head+=tabletex('q2-main-solver','扩展搜索与最终方案的验证范围',['环节','范围或结果'],[['候选扩充','多起点路线邻域与候选共享'],['主问题','有限路线的覆盖选择与必要资源条件'],['调度子问题','0.1 s网格上的飞机、电池约束'],['最终回放','80箱唯一覆盖；31箱硬截止；全部整站按期'],['最优性范围','完整可行方案；无原问题全局最优证书']],[.23,.77])
q2body=r'\subsection{运输方案与执行安排}\subsubsection{路线安排与货箱交付}'+'\n'
q2body+=f"主方案采用23个运输架次，其中A、B、C型分别为11、6、6次，运送80箱、758 kg和2011 L物资。最后返航为${num(M2['Cmax'])}\\,\\mathrm s$（${num(M2['Cmax']/60)}$分钟），总能耗为${num(M2['E'])}\\,\\mathrm{{kWh}}$。全部货箱按整站交接结束计均按期送达，31箱硬截止全部满足；最小整站硬截止余量为${num(M2['min_station_hard_slack'])}\\,\\mathrm s$，最低返航电量为${num(M2['min_SOC']*100)}\\%$。四个架次访问多个服务区，最多连续访问三站。\n"
q2body+=triptables('Q2_fast','主方案',['q2-sorties','q2-times','q2-delivery-groups','q2-tight-boxes'])
q2body+=fig('Q2_04_spacetime_routes','q2-spacetime','全机队的路线与服务时序；航线微曲仅用于区分往返，计算仍采用原直线航段。')
q2body+=fig('Q2_05_multistop_state','q2-multistop','代表多站架次的载荷与剩余电量变化。')
q2body+=r'\subsubsection{飞机与电池执行安排}'+'\n飞机返航即可更换同型满电电池再次执行任务，原电池独立补电。图中分别列示实体飞机与电池占用，避免把飞行任务结束误认为电池释放。\n'
fleet=[]
for g in 'ABC':
    rr=[x for x in q2 if x['route']['model']==g];fleet.append([g,len(rr),num(sum(x['route']['mass'] for x in rr)),num(sum(x['route']['energy'] for x in rr)),M2['aircraft_peak'][g],M2['battery_peak'][g]])
q2body+=tabletex('q2-fleet-role','三型机的运输分工与资源峰值',['机型','架次','质量/kg','能耗/kWh','飞机峰值','电池峰值'],fleet)
for alias,label,caption in [('Q2_03_battery_decoupling','q2-decoupling','飞机与电池分离周转的实际任务片段。'),('Q2_06_aircraft_schedule','q2-aircraft','八架运输机的实际执行时间。'),('Q2_07_battery_schedule','q2-battery','十四组电池的任务占用与补电时间。'),('Q2_08_ready_inventory','q2-inventory','实际资源同时占用量与库存上限。'),('Q2_10_delivery_dashboard','q2-delivery-dashboard','各区整站交付时间与货箱硬截止余量。')]:q2body+=fig(alias,label,caption)
q2body+=r'\subsection{方案比较与结果检验}\subsubsection{不同目标偏好的比较}'+'\n'
altern=[]
for sid,title in [('Q2_fast','时间优先主方案'),('Q2_economy','较短时域节能方案')]:
 m=js(BASE/sid/'metrics.json');altern.append([title,m['N'],num(m['Cmax']),num(m['E']),num(m['min_station_hard_slack']),0])
oldsel=js(ROOT/'review_runs/20260924_v3/selected_versions.json');oldidx={x['id']:ROOT/x['directory'] for x in oldsel['solutions']}
for sid,title in [('Q2_balanced','原折中基准'),('Q2_energy','较宽时域节能对照'),('Q2_soft_energy','允许软延期对照')]:
 v=js(oldidx[sid]/'validation.json')['summary'];st=js(oldidx[sid]/'station_delivery_validation.json') if (oldidx[sid]/'station_delivery_validation.json').exists() else js(ROOT/'review_runs/20260924_v3/derived_delivery'/sid/'station_delivery_summary.json');altern.append([title,v['N'],num(v['Cmax']),num(v['E']),num(st['min_hard_slack']),st['late_boxes']])
q2body+=tabletex('q2-alternatives','不同时间与能耗偏好的完整方案',['方案','架次','返航/s','能耗/kWh','硬余量/s','延期箱'],altern,[.27,.09,.17,.17,.18,.12])
q2body+='新节能方案比快方案少1架次、省电1.481 kWh，但晚返航275.801 s。与原折中基准相比，它在相同返航时间下省电1.738 kWh、减少2架次。较宽时域下仍存在能耗更低的19架次方案，因此“节能方案”需同时给出允许完成时域，不能理解为所有时域内的最低能耗。提交结果采用时间优先主方案，备选指标不与主方案拼接。\n'
q2body+=fig('Q2_09_strategy_profiles','q2-strategies','完整方案的返航时间、能耗与架次取舍；不同交付条件分别标注。')
baseline=q2old[q2old.index(r'\subsubsection{可行性检验、基准对照与敏感性分析}'):q2old.index(r'\subsection{本问小结}')]
# Historical experiments are preserved with explicit identities; remove former-current replay summary.
first=baseline.index(r'\PaperDetail{')
second=baseline.find(r'\PaperDetail{',first+1)
if second>0:baseline=baseline[:first]+r'\PaperDetail{主方案核验与基准试验范围}'+'\n新主方案按原始航段、载荷能耗、整站交付及实体资源顺序独立重放通过。下述固定批次、逐箱交付、种子、资源及扰动试验保留其原基准身份，用于说明机制，不作为新主方案的重复实验。\n'+baseline[second:]
q2body+=baseline+r'\subsection{本问小结}'+'\n问题二通过扩充路线池并分解路线选择与资源排程，得到23架次的时间优先可行方案。相比单点组批，实体资源与时限使机型分工及访问顺序重新调整。第三问可继续联合调整运输和中继安排，并单独检查全过程通信。\n'
q2new=q2head+q2body

# Q3 current search contract and evidence, with physical and continuous-certification equations retained.
q3head=q3old[:q3old.index(r'\subsection{联合执行结果与通信保障}')]
a=q3head.index('本次联合求解使用88条');b=q3head.index('采用 CP-SAT',a)
q3head=q3head[:a]+'最终主方案所在轮使用32条运输候选、124个悬停点、4651个覆盖块及4个可选中继架次槽。该规模仅表示这一轮的联合模型，不是整夜搜索的累计候选数。不同轮次改变候选组合与时间、能耗上界，并以已验证方案提供初始解；输出统一通过完整连续通信认证。\n\n'+q3head[b:]
a=q3head.index(r'\PaperDetail{求解阶段与停止状态}');b=q3head.index(r'\begin{algorithm}',a)
evidence=js(DIR['Q3_fast']/'solver_evidence.json')
solver=r'\PaperDetail{求解阶段与停止状态}'+'\n主方案最终一轮在整站零延期、联合完成上限5940 s与能耗上限72 kWh内，先优化联合完成时间，再减少能耗。使用8线程，随机种子2026120628。时间阶段在本轮有限候选和整数网格上证明最优；能耗阶段返回可行解。两者均不能推出原题完整决策空间的全局最优。\n'
solver+=tabletex('q3-solver','最终联合求解的阶段记录',['阶段','目标刻度','下界','用时/s','状态'],[[x['stage'],int(x['objective']),int(x['bound']),num(x['seconds']),x['status']] for x in evidence],[.1,.23,.22,.2,.25])
solver+='时间目标以0.1 s为一刻度，能耗目标以微kWh为单位。后文最终指标均依据完整方案按原始物理时长与能耗回算。\n'
q3head=q3head[:a]+solver+q3head[b:]
q3body=r'\subsection{联合执行结果与通信保障}\subsubsection{运输安排与货箱交付}'+'\n'
q3body+=f"主方案包含23个运输架次和3个中继架次。全部返航时间为${num(M3['C_joint'])}\\,\\mathrm s$（${num(M3['C_joint']/60)}$分钟），运输能耗${num(M3['E_transport'])}\\,\\mathrm{{kWh}}$，中继能耗${num(M3['E_relay'])}\\,\\mathrm{{kWh}}$，合计${num(M3['E_total'])}\\,\\mathrm{{kWh}}$。80箱全部整站按期交付，最小硬截止余量${num(M3['min_station_hard_slack'])}\\,\\mathrm s$。\n"
q3body+=triptables('Q3_fast','联合主方案',['q3-transport','q3-transport-times','q3-deliveries','q3-tight'])
q3body+=r'\subsubsection{中继部署与资源配置}'+'\n三次中继任务由两架中继机和三组能源组件完成。同一中继实体可在机体周转结束后再执行下一架次；能源组件独立补电，不必等待原机体。\n'
rr=q3['relay']
q3body+=tabletex('q3-relay-sites','三个中继点的位置与高度',['架次','经度/度','纬度/度','海拔/m','离地高度/m'],[[x['sortie'],f"{x['site']['lon']:.9f}",f"{x['site']['lat']:.9f}",num(x['site']['z']),num(x['site'].get('agl',x['site'].get('height',300)))] for x in rr],[.15,.24,.24,.18,.19])
relaycsv=rows(DIR['Q3_fast']/'relay_trips_q3.csv')
q3body+=tabletex('q3-relay-times','中继准备、建链及服务时段',['架次','准备/s','到达/s','建链完成/s','服务结束/s','返航/s'],[[x['sortie'],num(x['start']),num(x['link_complete']-30),num(x['link_complete']),num(x['service_end']),num(x['return'])] for x in rr],[.14,.17,.17,.18,.18,.16])
iv4=rows(Q4/'resource_intervals_q4.csv')
q3body+=tabletex('q3-relay-release','中继实体与能源组件释放',['架次','机体/组件','机体可用/s','组件可用/s','能耗/kWh','剩余电量/\\%'],[[x['sortie'],x['aircraft']+'/'+x['component'].replace('R-COMP-',''),num(next(v['end'] for v in iv4 if v['task']==x['sortie'] and v['resource']=='U_R')),num(next(v['end'] for v in iv4 if v['task']==x['sortie'] and v['resource']=='COMP_R')),num(x['energy']),num(100*(1-x['energy']/DATA['relay']['Euse']))] for x in rr],[.14,.18,.18,.18,.16,.16])
q3body+=tabletex('q3-resource-peaks','联合方案资源库存与同时占用峰值',['资源','库存','峰值'],[[esc(h),stock,peak] for h,stock,peak in zip(summary4['resource_order'],summary4['stock'],summary4['pooled'])],[.5,.25,.25])
q3body+=fig('Q3_04_terrain_relay_scene','q3-scene','运输路线、中继点与地形；微曲航线仅为显示，圆形表示给定高度的理想无遮挡范围。')
q3body+=fig('Q3_05_joint_resources','q3-joint-gantt','运输机、中继机与能源组件的联合时序。')+r'\label{fig:q3-components}'+'\n'
q3body+=fig('Q3_06_relay_coverage','q3-range-r3','三个中继点在接收端离地30 m时的可用范围与实际服务窗口；圆形仅表示无遮挡距离上限。')
q3body+=r'\subsubsection{实际通信来源与连续核验}'+'\n'
ci=rows(DIR['Q3_fast']/'communication_intervals_q3.csv');ev=rows(DIR['Q3_fast']/'communication_event_points_q3.csv');sourcework=[]
for rid in ['G01']+[x['sortie'] for x in rr]:
    ii=[x for x in ci if x['source']==rid];tasks=sorted({x['sortie'] for x in ii}|{x['sortie'] for x in ev if x['source']==rid});sourcework.append([rid,len(tasks),num(sum(float(x['end'])-float(x['start']) for x in ii))])
q3body+=tabletex('q3-source-work','各来源的客户数与逐机累计保障时长',['通信来源','客户架次数','累计保障/s'],sourcework,[.4,.25,.35])
q3body+=eq(q3old,'q3-customer-time')
q3body+=f"逐机累计保障总时长为${num(M3['direct_customer_seconds']+M3['relay_customer_seconds'])}\\,\\mathrm s$；其中直连${num(M3['direct_customer_seconds'])}\\,\\mathrm s$，中继${num(M3['relay_customer_seconds'])}\\,\\mathrm s$。该指标按运输机分别累加，不能当作中继驻留时间代入能源公式。\n"
for alias,label,caption in [('Q3_07_sources_concurrency','q3-sources','运输架次的实际通信来源及中继同时服务数量。'),('Q3_08_service_sankey','q3-service-flow','通信来源与运输机型之间的累计保障时间。'),('Q3_09_integrated_state','q3-state','代表架次的飞行、载荷、电量与通信来源变化。'),('Q3_10_three_link_profiles','q3-ray-panels','同一时刻的直连、接入和回传地形剖面；三条距离轴各自独立。')]:q3body+=fig(alias,label,caption)
q3body+=r'\label{fig:q3-concurrency}\label{fig:q3-switch}'+'\n'
q3body+=tabletex('q3-validation','联合方案的独立核验摘要',['核验项目','结果'],[['唯一货箱/总质量/体积','80箱 / 758 kg / 2011 L'],['硬截止/整站按期','31箱满足 / 80箱满足'],['运输/中继最低返航电量',num(100*M3['min_transport_SOC'])+r'\% / '+num(100*M3['min_relay_SOC'])+r'\%'],['认证开区间/阶段事件','377 / 558'],['通信缺口/未认证区间','0 s / 0'],['独立射线交叉检查','63项一致'],['本机重新回放','通过；来源相同，数值差异小于$10^{-7}$']],[.46,.54])
q3body+=r'\subsection{方案比较与通信裕量分析}\subsubsection{联合方案的目标取舍}'+'\n'
q3alts=[]
for sid,title in [('Q3_fast','时间优先主方案'),('Q3_economy','99分钟内节能方案')]:
    m=js(BASE/sid/'metrics.json');q3alts.append([title,m['N_transport'],m['N_relay'],num(m['C_joint']),num(m['E_total']),num(m['min_station_hard_slack'])])
oldm=js(oldidx['Q3_conservative']/'validation_q3.json')['summary'];q3alts.append(['原联合基准',oldm['N_transport'],oldm['N_relay'],num(oldm['C_joint']),num(oldm['E_total']),'14.411'])
q3body+=tabletex('q3-alternatives','统一整站零延期口径的完整联合方案',['方案','运输','中继','返航/s','能耗/kWh','硬余量/s'],q3alts,[.27,.08,.08,.19,.19,.19])
q3body+='节能方案比时间优先方案晚返航156.477 s，减少能耗0.967 kWh，两者均使用23个运输和3个中继架次。相对原联合基准，时间优先主方案提前420.997 s、减少能耗0.679 kWh，并少用1个运输架次。上述比较基于完整方案，不将不同方案的最低时间与最低能耗拼成一个结果。\n'
q3body+=fig('Q3_11_strategy_dashboard','q3-tradeoffs','完整联合方案的时间、能耗与架次对照。')
q3body+=r'\subsubsection{通信裕量与附加门限压力}'+'\n保持主方案的轨迹、点位和实际通信来源不变，对额外通信裕量门限进行确定性分析。设$m(t)$为已经扣除题设8 dB要求的剩余裕量，则低裕量暴露及由区间下界构成的保守上界定义如下。\n'+eq(q3old,'q3-exposure')+eq(q3old,'q3-exposure-bound')
exp=rows(BASE/'exposure_summary.csv');total=M3['direct_customer_seconds']+M3['relay_customer_seconds']
q3body+=tabletex('q3-exposure','实际来源的低裕量暴露与保守上界',['门限/dB','实际累计/s','占比/\\%','保守上界/s'],[[num(x['threshold']),num(x['actual_seconds']),num(float(x['actual_seconds'])/total*100),num(x['bound_seconds'])] for x in exp if float(x['threshold']) in [.25,.5,1,2,4]],[.18,.28,.22,.32])
q3body+=tabletex('q3-pressure','固定来源下的附加门限压力',['附加门限/dB','不满足时长/s','失败事件记录'],[[num(x['threshold']),num(x['failure_seconds']),x['event_failures']] for x in exp if float(x['threshold']) in [0,.5,1,2,4]],[.3,.35,.35])
q3body+='增加0.5 dB门限时，逐机累计有1086.268 s不再满足固定来源要求。这是确定性余量压力，不是失联概率；允许重选来源或重新优化运输与中继后，需要重新计算。边界事件单独判定、时间权重为零，不能与区间时长相加。\n'
q3body+=fig('Q3_12_margin_exposure','q3-exposure','低裕量累计时长及固定来源的附加门限压力。')
q3body+=r'\subsection{本问小结}'+'\n运输与中继联合优化获得23运输加3中继的可行方案，80箱全部按期交付，连续通信无缺口。第四问固定本方案的物理任务、时刻和实际通信来源，研究其分组后所需资源；该冻结边界不回溯到第一、二问。\n'
q3new=q3head+q3body

# Q4: preserve mathematical identities; regenerate every partition-dependent table and explanation.
def qe(label):return eq(q4old,label).replace(r'\ldots,4',r'\ldots,3').replace(r'\ell=1}^{4}',r'\ell=1}^{3}')
q4new=r'''\section{问题四的模型建立与求解}\label{sec:q4}
\subsection{问题分析与总体思路}
固定第三问时间优先方案的23个运输架次、3个中继架次、全部执行时刻及实际通信来源。货箱不重新组批，运输访问顺序和中继服务对象不改变；仅在执行开始前重新分配同型飞机、电池与能源组件。由于分组后不能跨组共享资源，原来错峰复用的资源可能需要增配。
'''+fig('Q4_01_partition_pipeline','q4-framework','固定任务关联、合法分区与独立资源配置的求解流程。','111mm')
q4new+=r'\subsection{任务分区与独立资源模型}\subsubsection{任务关联与不可分原子}'+'\n每个服务区作为超图顶点。多站运输把同一架次访问的服务区关联；中继超边覆盖其实际保障过的运输架次所涉及的服务区。边界事件也参与关联，不能只统计正时长区间。\n'+qe('q4-hypergraph')
q4new+='同一超边涉及的服务区必须归入一组，因此超图连通分量形成不可分单元。这里按实际任务关系关联，不按原飞机编号把所有任务强行绑为一组。新方案得到三个单元：C1仅含S001，C3仅含S006，其余13区形成C2。S011已通过实际任务关系并入C2，不能再单独划组。\n'
edges=[x for x in js(Q4/'components_q4.json')['edges'] if len(x['services'])>1]
q4new+=tabletex('q4-hyperedges','跨区运输及实际中继关联',['类型','任务','关联服务区'],[[x['kind']=='transport' and '运输' or '中继',x['id'],', '.join(x['services'])] for x in edges],[.1,.18,.72])
aa=[subsets[str(1<<i)] for i in range(3)]
q4new+=tabletex('q4-atoms','三个不可分单元的任务规模',['单元','服务区','运输架次','中继架次','货箱'],[[a['id'],', '.join(a['services']),len(a['transport']),len(a['relay']),aa[i]['boxes']] for i,a in enumerate(atoms)],[.1,.59,.11,.1,.1])
q4new+=fig('Q4_02_task_hypergraph','q4-atoms','实际运输和中继关联形成三个不可分单元。')
q4new+=r'\subsubsection{固定任务的最少资源}'+'\n八类资源及原库存按统一顺序表示为\n'+qe('q4-stock')
q4new+=tabletex('q4-intervals','固定任务对应的资源占用区间',['资源','开始','结束'],[['运输飞机','$s_r$','$R_r$'],['同型电池','$s_r$','$R_r+\\chi_g(\\sigma_r)$'],['中继机体','$Y_j$','$R_j^R+300$'],['中继能源组件','$Y_j$','$R_j^R+\\chi_R(\\sigma_j)$']],[.35,.22,.43])
q4new+='各任务保留独立身份，使用左闭右开区间。组内某类资源的最少数量等于最大同时占用数：\n'+qe('q4-peak')
q4new+='峰值时刻给出必要数量下界；按开始时刻依次把任务分配给已释放实体，可构造达到该下界的区间着色\citep{gilmore1964interval}。同一时刻先释放再占用，允许无缝接续。集中共享时的需求为\n'+qe('q4-pooled')
q4new+=r'\subsubsection{分区指标与优化目标}'+'\n以二元变量表示不可分单元归属，要求每个单元唯一归组、每组非空：\n'+qe('q4-assignment')
q4new+='任务工作量按准备至返航的完整时长累加，中继任务只记一次；不包含返航后补电与机体周转。\n'+qe('q4-workload')
W=float(Fraction(summary4['pooled_W']));alpha=float(Fraction(aa[1]['W']))/W
q4new+=tabletex('q4-workload','不可分单元的任务工作量',['单元','运输工时/s','中继工时/s','合计/s','占比/\\%'],[[f'C{i+1}',num(a['Wtransport']),num(a['Wrelay']),num(a['W']),num(float(Fraction(a['W']))/W*100)] for i,a in enumerate(aa)])
q4new+=fig('Q4_03_workload_treemap','q4-workload','运输与中继工时构成；C2包含13个服务区。')
q4new+=f'总任务工时为${num(W)}\\,\\mathrm s$，分区不改变该总量。用工作量变异系数平方评价相对不均衡：\n'+qe('q4-cv')
q4new+='分组后，同类资源配置为各组需求之和。定义库存缺口、未配置库存及相对集中共享的配置损失：\n'+qe('q4-deficit')
q4new+='由于各组峰值可能错开，峰值之和通常大于合并后的峰值。按原库存归一化后，以减少增配、减少总配置、改善均衡的顺序比较：\n'+qe('q4-objective')
q4new+=r'\subsection{完整枚举求解与分区结果}'+'\n以限制增长序列消除组号置换重复；三个单元的所有二分和三分均可完整枚举。\n'
q4new+=r'\begin{equation}\left\{\begin{matrix}3\\2\end{matrix}\right\}=3,\qquad\left\{\begin{matrix}3\\3\end{matrix}\right\}=1.\label{eq:q4-partition-count}\end{equation}'+'\n'
alg=next(x for x in re.findall(r'\\begin\{algorithm\}.*?\\end\{algorithm\}',q4old,re.S));alg=alg.replace('四个','三个').replace('13','4').replace('15个非空','7个非空').replace('15 个非空','7 个非空');q4new+=alg+'\n'
pp=rows(Q4/'all_partitions_q4.csv')
q4new+=tabletex('q4-all-objectives','全部合法分区及目标值',['编号','分区','缺口指标','配置指标','$CV^2$'],[[x['id'],x['partition'],num(x['Jgap']),num(x['Jsize']),num(x['CV2'])] for x in pp],[.14,.29,.19,.19,.19])
q4new+=tabletex('q4-all-resources','全部合法分区的八类资源配置',['分区','$U_A$','$U_B$','$U_C$','$B_A$','$B_B$','$B_C$','$U_R$','$K_R$'],[[x['id']]+json.loads(x['N']) for x in pp],[.2]+[.1]*8)
q4new+=fig('Q4_04_partition_profiles','q4-tradeoffs','全部合法分区的资源需求和均衡取舍。')
q4new+='资源优先二分为K2-01，即S006独立、其余14区一组。三分只有K3-01，即S001、其余13区、S006分别成组；不存在其他保持冻结任务关系的三分方案。\n'
q4new+=r'\begin{equation}\begin{aligned}K=2:&\quad\mathcal S_1=\mathcal S\setminus\{S006\},\quad\mathcal S_2=\{S006\};\\K=3:&\quad\mathcal S_1=\{S001\},\quad\mathcal S_2=\mathcal S\setminus\{S001,S006\},\quad\mathcal S_3=\{S006\}.\end{aligned}\label{eq:q4-selected-partitions}\end{equation}'+'\n'
q4new+=fig('Q4_05_partition_map_k2','q4-maps','资源优先二分的离散任务归属。')+fig('Q4_06_partition_map_k3','q4-map-k3','三分的离散任务归属；颜色不表示连续行政边界。')
q4new+=r'\subsection{独立执行配置与共享损失}\subsubsection{两组与三组的资源配置}'+'\n'
gg=[(k,i,g) for k in (2,3) for i,g in enumerate(S4[k]['groups'],1)]
q4new+=tabletex('q4-groups','所选分区各组的物资与任务规模',['组','运输','中继','货箱','质量/kg','体积/L'],[[f'K{k}-G{i}',len(g['transport']),len(g['relay']),g['boxes'],num(g['mass']),num(g['volume_L'])] for k,i,g in gg],[.2,.12,.12,.12,.22,.22])
q4new+=tabletex('q4-group-work','所选分区各组工作量与能耗',['组','运输工时/s','中继工时/s','总工时/s','能耗/kWh'],[[f'K{k}-G{i}',num(g['Wtransport']),num(g['Wrelay']),num(g['W']),num(g['energy'])] for k,i,g in gg],[.16,.21,.21,.21,.21])
q4new+=tabletex('q4-group-resources','各组独立执行的最少配置',['组','$U_A$','$U_B$','$U_C$','$B_A$','$B_B$','$B_C$','$U_R$','$K_R$'],[[f'K{k}-G{i}']+g['N'] for k,i,g in gg],[.2]+[.1]*8)
q4new+=tabletex('q4-inventory','库存、集中共享与分组配置',['资源','库存','集中需求','二分需求','二分缺口','三分需求','三分缺口'],[[esc(h),summary4['stock'][j],summary4['pooled'][j],S4[2]['selected']['N'][j],S4[2]['selected']['gap'][j],S4[3]['selected']['N'][j],S4[3]['selected']['gap'][j]] for j,h in enumerate(summary4['resource_order'])],[.22]+[.13]*6)
q4new+='二分总计需要9架运输机、15组运输电池；三分需要11架运输机、17组运输电池。两种分法都需要2架中继机和3组能源组件。相对原库存，二分增C型飞机与电池各1；三分增A型各1、C型各2。能源组件库存仍有结余，但不同类型资源不可替代，不能用中继组件抵消运输电池缺口。\n'
q4new+=r'\subsubsection{共享损失与配置见证}'+'\n下表以二分主组的峰值时刻给出资源下界证据，任务区间内均为实际同时占用。\n'
wit=subsets['3']['witnesses'];q4new+=tabletex('q4-witness','二分主组的资源峰值见证',['资源','数量','时刻/s','同时占用任务'],[[esc(h),x['count'],num(x['time']),', '.join(v.replace('Q3T-','T').replace('Q3R-','R') for v in x['tasks'])] for h,x in wit.items()],[.17,.08,.17,.58])
assignment=rows(Q4/'group_resource_assignment.csv');groups=collections.defaultdict(list)
for x in assignment:
    if x['K']=='2' and x['resource'] in ['U_C','BAT_C']:groups[(x['group'],x['new_id'],x['needs_addition'])].append(x)
q4new+=tabletex('q4-entity-example','二分方案C型资源的执行前分配',['组','资源编号','按时间排列的任务','来源'],[[g,esc(ident),', '.join(x['task'].replace('Q3T-','T') for x in sorted(v,key=lambda x:float(x['start']))),'增配' if extra=='True' else '原库存'] for (g,ident,extra),v in groups.items()],[.07,.3,.46,.17])
q4new+=fig('Q4_08_sharing_loss','q4-sharing','C型机体和电池的组内需求、合并并发与独立配置。')+fig('Q4_07_resource_radar','q4-resource','二分、三分需求与各类库存的直接比较。')
q4new+='“各组峰值之和”是独立配置需求，不是某时刻的实际并发；电池统计保留返航后的完整补电尾部，避免低估独立配置。\n'
q4new+=r'\subsection{均衡取舍与结果检验}\subsubsection{工作量均衡与资源代价}'+'\n'
pr=[]
for k in (2,3):
 for role in ['selected','balanced']:
  x=S4[k][role];pr.append([k,'资源优先' if role=='selected' else '均衡优先',x['id'],num(x['Jgap']),num(x['Jsize']),num(x['CV2'])])
q4new+=tabletex('q4-priority','资源优先与均衡优先的配置比较',['组数','偏好','分区','缺口指标','配置指标','$CV^2$'],pr,[.08,.2,.16,.19,.19,.18])
q4new+=f'大单元C2承担总工时的${num(alpha*100)}\\%$，其不可拆分性限制了均衡效果。令\n'+r'\begin{equation}\alpha=\frac{W_{\mathrm{C2}}}{W}\approx'+num(alpha)+r'.\label{eq:q4-alpha}\end{equation}'+'\n'
q4new+='当其余工时在剩余组间均分时得到理想均衡下界；实际离散分区一般不能达到该下界。\n'+qe('q4-balance-bound')
q4new+='二分的均衡优先解把S001与S006合并，与C2分开，但需要更多资源；三分仅有一个合法结果，改变偏好不会改变该分区。\n'
q4new+=r'\subsubsection{独立核验与最优性范围}'+'\n独立检查每个任务恰好归属一组、全部实际通信来源与客户同组、物理时刻与源方案相同、实体资源不重叠。全部4种分区通过归属核验，所选二分和三分均完成实体分配验证。另以全部7个非空原子子集为列建立集合划分整数规划：\n'+qe('q4-milp')
q4new+='依次固定缺口、配置规模并优化均衡，结果与完整枚举一致。集中共享峰值还使用半开端点逐项计数独立复核。精确最优性仅针对本次冻结的运输、中继、来源关系和目标优先级，不能推及任意重新优化的Q3方案。\n'
q4new+=tabletex('q4-milp','独立整数规划与枚举的一致性',['组数','阶段','状态','枚举一致'],[[x.get('K',''),x.get('stage',''),x.get('status',''), '是' if x.get('exact_enumeration_agrees') else '待核'] for x in summary4['milp']],[.12,.3,.35,.23])
q4new+=r'\subsection{本问小结}'+'\n固定新联合方案后，实际任务形成三个不可分单元。完整枚举得到三种二分和一种三分，资源峰值下界与实体分配共同保证最少配置。运输调度改善并不必然使每类分区资源都减少，分区结论必须与其继承的Q3任务保持一致。\n'

# Assemble without changing Q1, official cover or user-specified AI disclosure.
start=re.search(r'^\\section\{问题二',original,re.M).start();end=re.search(r'^\\section\{模型评价与改进',original,re.M).start()
text=original[:start]+q2new+'\n'+q3new+'\n'+q4new+'\n'+original[end:]
# Abstract and final conclusions: replace entire solution paragraphs, retaining the surrounding structure.
replacements={'5969.043':'5693.243','66.472':'66.215','6204.224':'5783.227','69.361':'68.682','53712.055':'52572.543','82.671':'88.841','82.67':'88.84','14.609':'420.514','14.411':'202.000','20.948':'20.096','1129.732':'1086.268'}
front_end=text.index(r'\section{问题重述与分析}');tail_start=text.index(r'\section{模型评价与改进}')
front=text[:front_end];tail=text[tail_start:]
for old,new in replacements.items():front=front.replace(old,new);tail=tail.replace(old,new)
for name,s in [('front',front),('tail',tail)]:
 s=s.replace('完整枚举7种二分和6种三分','完整枚举3种二分和1种三分').replace('三分再将S011独立','三分将S001、S006与其余13区分别成组')
 s=s.replace('24个架次','23个架次').replace('24个运输架次','23个运输架次').replace('24架次','23架次').replace('370个','377个').replace('550条','558条').replace('4个不可分','3个不可分').replace('13种','4种').replace('四原子','三原子').replace('B、C型运输机各1架及对应电池各1组','A型运输机及电池各1、C型运输机及电池各2').replace('B、C型运输机各1架','A型1架、C型2架运输机').replace('对应电池各1组','对应A型1组、C型2组电池').replace('B/C型','A/C型').replace('折中方案','时间优先方案').replace('四个原子','三个原子').replace('4 原子','3 原子')
 if name=='front':front=s
 else:tail=s
tail=tail.replace('以下列出四问的关键计算与约束实现，','详细代码见附件。以下列出四问的关键计算与约束实现，')
text=front+text[front_end:tail_start]+tail
# Ensure no obsolete explanation of the old current main in opening Q2 paragraphs.
text=text.replace('兼顾完成时间与能耗的方案作为主方案','优先缩短完成时间的方案作为主方案')
text=text.replace('先确定逐箱零延期路线，再将相同路线按整站交付重排','以整站零延期约束选择路线并安排资源时序')
text=text.replace('正式24架次整站','正式23架次整站')
text=text.replace('主方案的两阶段设置在下节给出','主方案采用整站口径，分解搜索设置在下节给出')
text=text.replace('另在活跃位置附近尝试东西南北 $120\\,\\mathrm m$ 位移和高度 $\\pm30\\,\\mathrm m$，\n筛选后最多保留 6 个新增点。','在活跃点周边轮换70、120、350、700、1600及2500 m搜索半径，并尝试150、200、250、280、300 m离地高度；全部候选仍须通过原物理筛选。')
text=text.replace('Optimization terminated successfully. (HiGHS Status 7: Optimal)','OPTIMAL')
(PAPER/'全文.tex').write_text(text,encoding='utf-8')
(BASE/'paper_generation_summary.json').write_text(json.dumps(dict(q2_sorties=len(q2),q3_transport=len(q3['transport']),q4_atoms=len(atoms),q4_partitions=len(pp),alpha=alpha),ensure_ascii=False,indent=2),encoding='utf-8')
print('updated manuscript')
