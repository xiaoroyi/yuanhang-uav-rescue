from data import *
import re,datetime,zipfile,shutil
PAPER=ROOT/'论文LaTeX_20260926/论文';OUT=ROOT/'outputs/current_release_20260926_v4';FIG=ROOT/'paper/figures/20260926_release'
def entry(p):
 p=Path(p);return dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)
sys.path.insert(0,str(ROOT/'问题1/论文工作/deps'));import fitz
pdf=PAPER/'build/全文_20260926更新.pdf';doc=fitz.open(pdf)
s=(PAPER/'全文.tex').read_text(encoding='utf-8');old=(ROOT/'论文LaTeX_20260925/论文/全文.tex').read_text(encoding='utf-8')
labels=re.findall(r'\\label\{([^}]+)\}',s);refs=re.findall(r'\\(?:ref|eqref|pageref)\{([^}]+)\}',s)
assert len(labels)==len(set(labels));assert not set(refs)-set(labels),set(refs)-set(labels)
def part(t,a,b):return t[t.index(a):t.index(b,t.index(a)+len(a))]
assert part(s,r'\section{问题一',r'\section{问题二')==part(old,r'\section{问题一',r'\section{问题二')
assert part(s,'本项目在开展过程中',r'\section*{附录')==part(old,'本项目在开展过程中',r'\section*{附录')
assert (PAPER/'gmcmthesis.cls').read_bytes()==(ROOT/'论文LaTeX_20260925/论文/gmcmthesis.cls').read_bytes()
log=(PAPER/'build/全文_20260926更新.log').read_text(encoding='utf-8',errors='replace')
bad=re.findall(r'^.*(?:Overfull|undefined|multiply defined|Missing character|Rerun to get).*$',log,re.M);assert not bad,bad
fmanifest=js(PAPER/'figure_manifest.json');assert len(fmanifest['figures'])==42
for f in fmanifest['figures']:assert entry(ROOT/f['path'])['sha256']==f['sha256']
assert js(OUT/'original_template_validation.json')['status']=='PASS'
assert all(x['valid'] for x in js(BASE/'q3_replay_validation.json'))
q4=js(BASE/'q4_fast/run_summary.json');assert all(x['exact_enumeration_agrees'] for x in q4['milp'])
assert q4['source_task_hash']==next(x['sha256'] for x in SEL['solutions'] if x['id']=='Q3_fast')
from openpyxl import load_workbook
w=load_workbook(OUT/'结果提交_原版模板_20260926_v4.xlsx',data_only=True)
q2=list(w['Q2_运输架次'].values)[1:];q2=[r for r in q2 if r[0]]
assert len(q2)==23
assert abs(sum(r[7] for r in q2)-next(x['metrics']['E'] for x in SEL['solutions'] if x['id']=='Q2_fast'))<1e-7
assert abs(max(r[6] for r in q2)-next(x['metrics']['C'] for x in SEL['solutions'] if x['id']=='Q2_fast'))<1e-7
ow=load_workbook(ROOT/'outputs/current_release_20260924_v3/结果提交_原版模板_20260924_v3.xlsx',data_only=True)
assert list(w['Q1_单点组批'].values)==list(ow['Q1_单点组批'].values);w.close();ow.close()
citekeys=set(k for group in re.findall(r'\\cite[a-z]*\{([^}]+)\}',s) for k in group.split(','));bib=(PAPER/'references.bib').read_text(encoding='utf-8');assert all(re.search(r'@\w+\{\s*'+re.escape(k)+r'\s*,',bib) for k in citekeys)
audit=dict(status='PASS',release_id='20260926_v4_excel1',paper_pdf=entry(pdf),physical_pages=len(doc),figures=42,redrawn_figures=26,references=len(citekeys),unique_labels=len(labels),all_references_resolved=True,latex_final_overflow_or_missing_glyph=False,Q1_text_and_Excel_unchanged=True,template_cls_unchanged=True,user_AI_statement_unchanged=True,Q2_Excel_energy_and_return_match=True,Q3_independent_replay=True,Q4_source_hash_matches=True,Q4_enumeration_and_MILP_agree=True,original_Excel_template_preserved=True,proof_scope='No original-problem global optimum claimed for Q2/Q3; Q4 exact only for frozen new Q3')
dump(BASE/'delivery_audit.json',audit)

previous=js(BASE/'previous_CURRENT_RELEASE.json')
release=dict(schema_version=4,release_id='20260926_v4_excel1',model_version='20260926_v4',status='verified',published_local=datetime.datetime.now().astimezone().isoformat(),user_authorization='用户要求自主选择快/省电方案并更新提交Excel、论文、图表、继承Q4和最终编译。',previous_release_id=previous['release_id'],workbook=entry(OUT/'结果提交_原版模板_20260926_v4.xlsx'),workbook_validation=entry(OUT/'original_template_validation.json'),workbook_sources=entry(OUT/'excel_source_manifest.json'),complete_handoff=entry(BASE/'新结果发布与论文更新说明.md'),selected_versions=entry(BASE/'selected_versions.json'),accepted_metrics=entry(BASE/'accepted_metrics.csv'),primary_q1='问题1/results',primary_q2='Q2_fast',primary_q3='Q3_fast',primary_q4_directory='review_runs/20260926_release/q4_fast',paper_source=entry(PAPER/'全文.tex'),paper_pdf=entry(pdf),code_attachment=js(BASE/'code_attachment_manifest.json')['archive'],delivery_definition='整站交接结束；80箱按期、31箱硬截止全部满足。',objective_preference='整站零延期条件下优先缩短完成时间；省电方案为独立备选，不混用指标。',proof_scope=audit['proof_scope'],data_overrides=previous.get('data_overrides',[]),validation=entry(BASE/'delivery_audit.json'),previous_release_manifest=entry(BASE/'previous_CURRENT_RELEASE.json'))
dump(ROOT/'CURRENT_RELEASE.json',release)
dump(ROOT/'CURRENT_FIGURES.json',dict(status='verified',artifact_status='self_reviewed_with_user_authorization',visual_version='20260926_paper_update',numerical_release_id=release['release_id'],numerical_release_sha256=entry(ROOT/'CURRENT_RELEASE.json')['sha256'],directory='paper/figures/20260926_release',gallery='paper/figures/20260926_release/index.html',figure_count=42,component_count=42,new_exports=26,reused_exports=16,manifest='paper/figures/20260926_release/figure_manifest.json',paper_pdf=entry(pdf),scope='当前论文42图；历史91组件图册不冒充已更新。',historical_gallery='paper/figures/20260924_pro_v4/index.html'))
guide='''# 当前版本与目录说明（20260926）

当前正式发布：**20260926_v4_excel1**，状态verified。入口以CURRENT_RELEASE.json和CURRENT_FIGURES.json为准。

- 论文PDF：论文LaTeX_20260926/论文/build/全文_20260926更新.pdf
- 源码：论文LaTeX_20260926/论文/全文.tex；编译及覆盖说明见论文LaTeX_20260926/使用说明.md。
- 正式提交Excel：outputs/current_release_20260926_v4/结果提交_原版模板_20260926_v4.xlsx
- 代码附件及Q3配套CSV：outputs/current_release_20260926_v4/
- 更新说明与全部源路径：review_runs/20260926_release/新结果发布与论文更新说明.md
- 当前42幅论文图：paper/figures/20260926_release/index.html

Q1保持；Q2主角色为Q2_fast；Q3主角色为Q3_fast；Q4必须继承review_runs/20260926_release/q4_fast。不能继续用Q2_balanced、Q3_conservative及q4_local_sites作为当前主结果。

Q2：23架次、5693.242512959364 s、66.21486599521012 kWh。
Q3：23运输＋3中继、5783.226919003505 s、68.68177239672228 kWh。连续认证377开区间、558阶段事件。
Q4：3不可分单元、3种二分＋1种三分；总工时52572.54251277223669 s。二分9架运输机/15组电池；三分11架/17组。二者均2中继机/3能源组件。

旧结果、旧论文与旧图集均保留；上一版目录说明备份在review_runs/20260926_release/previous_当前版本与目录说明.md。
'''
(ROOT/'当前版本与目录说明.md').write_text(guide,encoding='utf-8')
agents=ROOT/'AGENTS.md';a=agents.read_text(encoding='utf-8')
notice='''## 最新正式发布覆盖说明（2026-09-26）

- 当前已发布20260926_v4_excel1；以下20260924段落仅为历史背景，冲突时以CURRENT_RELEASE.json为准。
- Q2主方案Q2_fast：23架次、5693.242512959364 s、66.21486599521012 kWh。Q3主方案Q3_fast：23运输＋3中继、5783.226919003505 s、68.68177239672228 kWh。
- Q4严格继承review_runs/20260926_release/q4_fast：3原子、3种二分＋1种三分；不能复用旧4原子/13分区。独立枚举、MILP与实体分配通过。
- 正式原格式Excel在outputs/current_release_20260926_v4/；当前论文在论文LaTeX_20260926/论文/全文.tex，PDF在build/全文_20260926更新.pdf。
- 当前论文42图（26重绘、16复用），入口paper/figures/20260926_release/index.html。旧v4图册为历史。
- 完整更新与来源说明：review_runs/20260926_release/新结果发布与论文更新说明.md。代码附件在同版输出目录。Q2/Q3仍无原题全局最优证书。

'''
if '## 最新正式发布覆盖说明（2026-09-26）' not in a:a=a.replace('## 当前交付与论文版本',notice+'## 当前交付与论文版本',1);agents.write_text(a,encoding='utf-8')
archive=ROOT/'论文LaTeX_20260926/论文完整工程_20260926.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in PAPER.rglob('*'):
  if p.is_file() and (p.suffix in ['.tex','.cls','.bib','.bst','.pdf','.py','.ps1','.cmd','.json'] or 'template-assets' in p.parts) and ('build' not in p.parts or p==pdf):z.write(p,p.relative_to(PAPER.parent).as_posix())
 z.write(ROOT/'论文LaTeX_20260926/使用说明.md','使用说明.md')
print(json.dumps(dict(status='published',pages=len(doc),paper=entry(pdf),archive=entry(archive)),ensure_ascii=False))
