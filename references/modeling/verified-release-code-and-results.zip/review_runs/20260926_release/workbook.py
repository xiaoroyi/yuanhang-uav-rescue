from data import *
import shutil
OUT=ROOT/'outputs/current_release_20260926_v4';OUT.mkdir(exist_ok=True)
old=js(ROOT/'outputs/current_release_20260924_v3/template_payload.json');q2=js(DIR['Q2_fast']/'solution.json');q3=js(DIR['Q3_fast']/'solution_q3.json');q4={k:js(BASE/'q4_fast'/f'solution_k{k}.json') for k in (2,3)}
def tr(rr):return [[r['sortie'],r['aircraft'],r['route']['model'],r['battery'],r['start'],'→'.join(s for s,b in r['route']['stops']),r['return'],r['route']['energy']] for r in rr]
def dl(sid):return [[r['box'],r['sortie'],r['service'],float(r['station_complete'])] for r in sorted(rows(BASE/sid/'station_deliveries.csv'),key=lambda x:x['box'])]
ci=rows(DIR['Q3_fast']/'communication_intervals_q3.csv');ev=rows(DIR['Q3_fast']/'communication_event_points_q3.csv');stage={(r['sortie'],r['phase']):r['stage'] for r in ci}
comm=[[r['sortie'],r['stage'],float(r['start']),float(r['end']),'直连' if r['source']=='G01' else '中继',None if r['source']=='G01' else r['source']] for r in ci]
comm += [[r['sortie'],stage[r['sortie'],r['phase']],float(r['time']),float(r['time']),'直连' if r['source']=='G01' else '中继',None if r['source']=='G01' else r['source']] for r in ev]
comm.sort(key=lambda x:(x[0],x[2],x[3]));assert len(comm)==935
vals={'Q2_运输架次':tr(q2),'Q2_逐箱交付':dl('Q2_fast'),'Q3_中继架次':[[r['sortie'],r['aircraft'],r['component'],r['start'],r['site']['lon'],r['site']['lat'],r['site']['z'],r['link_complete'],r['service_end'],r['return'],r['energy']] for r in q3['relay']],'Q3_通信保障':comm,'Q4_分区配置':[[k,f'K{k}-G{i}',', '.join(g['services'])]+g['N'] for k in (2,3) for i,g in enumerate(q4[k]['groups'],1)]}
for t in old['sheets']:
 if t['name'] in vals:t['rows']=vals[t['name']]
old['release_id']='20260926_v4_excel1';dump(OUT/'template_payload.json',old)
for name,rr,header in [('Q3_运输架次',tr(q3['transport']),['架次编号','无人机编号','机型','电池编号','准备开始/s','航线','返航/s','能耗/kWh']),('Q3_逐箱交付',dl('Q3_fast'),['货箱编号','架次编号','服务区','整站交付/s'])]:
 with (OUT/(name+'_配套明细.csv')).open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(header);w.writerows(rr)
oldout=ROOT/'outputs/current_release_20260924_v3'
s=(oldout/'preserve_template.py').read_text(encoding='utf-8').replace('20260924_v3','20260926_v4').replace('communication_intervals=370,zero_duration_events=550','communication_intervals=377,zero_duration_events=558')
(OUT/'preserve_template.py').write_text(s,encoding='utf-8')
s=(oldout/'fill_original_template.mjs').read_text(encoding='utf-8').replace('20260924_v3','20260926_v4');(OUT/'fill_original_template.mjs').write_text(s,encoding='utf-8')
dump(OUT/'excel_source_manifest.json',dict(release='20260926_v4_excel1',sources=SEL,template='review_runs/20260924_v1/data_archive/raw_tables/结果提交模板.xlsx',Q4='review_runs/20260926_release/q4_fast',policy='时间优先主方案；交付统一取整站交接结束；保持原六表格式'))
print(OUT)
