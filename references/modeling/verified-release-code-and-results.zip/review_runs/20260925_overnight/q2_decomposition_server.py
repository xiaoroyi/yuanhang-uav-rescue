"""Finite-pool route-selection/CP scheduling decomposition, isolated from live workers.

LP: all loaded continuous-physics columns, exact box cover and necessary resource
conditions. Its checked dual bound is ONLY for this finite route inventory.
MILP: a priced subset, plus separately labelled search cuts. CP: selected routes
only, original conservative 0.1 s grid; independent continuous replay is required.
"""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import itertools
import json
import math
import os
import sys
import threading
import time
import traceback
import warnings

for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
sys.dont_write_bytecode = True
from q2_server import ServerPortfolio, sha_file, atomic_text
from q2_search import HERE, read, dump, now


def finite(value):
    return float(value) if value is not None and math.isfinite(float(value)) else None


def exact_two_aircraft(tasks, tolerance=1e-5):
    """Exact AIRCRAFT-ONLY relaxation: release=0, processing p, due=L+p.

Enumerate all two-way partitions; EDD is exact on each single aircraft because
all jobs are released at zero. Batteries are ignored, never assumed feasible.
The tolerance only enlarges the set deemed feasible. Failure is a necessary-
condition certificate for these exact tasks, not for other route patterns.
"""
    tasks = sorted(tasks, key=lambda t: (t['d'], t['id']))
    n = len(tasks)
    if n > 14:
        return dict(proved_infeasible=False, checked=False, reason='task_count_above_14', tasks=n)
    size = 1 << n
    load = [0.] * size
    okay = bytearray(size); okay[0] = 1
    for mask in range(1, size):
        k = mask.bit_length() - 1
        before = mask ^ (1 << k)
        load[mask] = load[before] + tasks[k]['p']
        okay[mask] = bool(okay[before] and load[mask] <= tasks[k]['d'] + tolerance)
    full = size - 1
    witness = next((m for m in range(size) if okay[m] and okay[full ^ m]), None)
    return dict(checked=True, proved_infeasible=witness is None, tasks=tasks,
                subsets_checked=size, unordered_partitions_covered=1 if not n else 1 << (n-1),
                release_times=0, batteries='ignored necessary-condition relaxation',
                float_tolerance_s=tolerance,
                feasible_partition=None if witness is None else [
                    [t['id'] for j,t in enumerate(tasks) if witness & (1 << j)],
                    [t['id'] for j,t in enumerate(tasks) if not witness & (1 << j)]])


class Decomposition(ServerPortfolio):
    def __init__(self, args):
        requested_control_seconds = args.control_seconds
        super().__init__(args)
        # ServerPortfolio disables its old control; retain this independent control budget.
        args.control_seconds = requested_control_seconds
        import numpy as np
        import scipy
        from scipy import sparse
        from scipy.optimize import Bounds, LinearConstraint, linprog, milp
        self.np, self.sparse = np, sparse
        self.Bounds, self.LinearConstraint = Bounds, LinearConstraint
        self.linprog, self.milp = linprog, milp
        self.scipy_version = scipy.__version__
        self.proof_cuts = []
        self.grid_cuts = []
        self.temporary_cuts = []
        self.last_selected = []
        self.last_lp = None
        self.events = []
        self.inventory_ids = set()
        self.inventory_shards = []
        self.forward_done = threading.Event()
        self.forwarder = threading.Thread(target=self.forward_stop, daemon=True)

    def forward_stop(self):
        while not self.forward_done.wait(.25):
            if self.stop.exists() or time.perf_counter() >= self.deadline:
                atomic_text(self.out / 'STOP', 'Global STOP or monotonic budget reached.\n')
                return

    def seconds_left(self, wanted, reserve=3):
        if self.expired(reserve): return 0.
        return max(.05, min(float(wanted), self.deadline-time.perf_counter()-reserve))

    def inventory_checkpoint(self):
        """Immutable base plus immutable new-column shards; never delete old columns."""
        added={rid:r for rid,r in self.pool.items() if rid not in self.inventory_ids}
        if added:
            stem='base' if not self.inventory_shards else f'new_{len(self.inventory_shards):05d}'
            path=self.out/'inventory'/(stem+'.jsonl')
            self.save_pool(added,path)
            packed=path.with_name(path.name+'.gz')
            meta=read(packed.with_name(packed.name+'.meta.json'))
            self.inventory_shards.append(dict(path=packed.relative_to(HERE).as_posix(),
                sha256=meta['sha256'],uncompressed_sha256=meta['uncompressed_sha256'],routes=len(added)))
            self.inventory_ids.update(added)
            dump(self.out/'inventory/index.json',dict(input_signature=self.input_signature,
                immutable_shards=self.inventory_shards,total_routes=len(self.inventory_ids),updated_at=now()))

    def lp_inventory_evidence(self,data,folder):
        self.inventory_checkpoint()
        path=self.own_path(folder/'lp_eligible_ids.txt.gz')
        temp=path.with_name(path.name+f'.{os.getpid()}.tmp')
        ids_digest=hashlib.sha256();physical_digest=hashlib.sha256()
        with gzip.open(temp,'wb',compresslevel=3) as stream:
            for r in data['routes']:
                line=(r['id']+'\n').encode('utf-8');stream.write(line);ids_digest.update(line)
                physical_digest.update((json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode('utf-8'))
        check=hashlib.sha256()
        with gzip.open(temp,'rb') as stream:
            for chunk in iter(lambda:stream.read(1024*1024),b''):check.update(chunk)
        if check.digest()!=ids_digest.digest():raise IOError('LP inventory ID gzip failed verification')
        os.replace(temp,path)
        return dict(eligible_ids_file=path.relative_to(HERE).as_posix(),eligible_ids_gzip_sha256=sha_file(path),
            ordered_ids_sha256=ids_digest.hexdigest(),ordered_canonical_route_contents_sha256=physical_digest.hexdigest(),
            ordered_routes=len(data['routes']),inventory_shards=list(self.inventory_shards),
            reconstruction='Read immutable shards; select routes in UTF-8 LF-delimited eligible ID order; JSON each route with ensure_ascii=False,sort_keys=True,separators=(comma,colon), then LF; concatenate and SHA256.',
            physical_input_signature=self.input_signature)

    def initialize_baselines(self):
        super().initialize_baselines()
        c = read(self.out / 'input_contract.json')
        c.update(algorithm='finite-pool LP-priced route selection MILP / exact B,C aircraft check / small CP scheduling',
                 adapter_sha256=sha_file(Path(__file__)), scipy=self.scipy_version,
                 highs_threads=self.args.master_threads, cp_threads=self.args.workers,
                 finite_pool_only=True, bound_scope='finite loaded route inventory, continuous necessary-condition LP only',
                 original_problem_global_gap=None,
                 zero_station_lateness=True,delivery_definition='whole-stop handover completion',
                 proof_cut_scope='continuous p/latest-start, zero release, exhaustive B/C two-aircraft EDD partitions',
                 grid_cut_scope='original conservative 0.1 second CP model only; excluded from continuous LP',
                 temporary_cut_scope='search diversification only; excluded from proof bounds',
                 generated_columns='LP-dual guided local physical packings; no complete route-pricing oracle',
                 initial_loaded_routes=len(self.pool))
        dump(self.out / 'input_contract.json', c)

    def matrices(self, routes, H, Ncap, continuous_cuts=True):
        """Sparse outer relaxation. No route start or interval variable here."""
        np = self.np
        routes = [r for r in routes if min(H-r['duration'], self.latest(r)) >= -1e-7]
        ids = [r['id'] for r in routes]; lookup = {rid:i for i,rid in enumerate(ids)}
        boxes = sorted(self.P.boxes); bindex = {b:i for i,b in enumerate(boxes)}
        times = sorted({H*f for f in (.25,.5,.75,1.)} |
                       {float(b['expected_s']) for b in self.P.boxes.values() if 0 < b['expected_s'] < H} |
                       {float(b['hard_due']) for b in self.P.boxes.values() if b['hard_due'] and 0 < b['hard_due'] < H})
        # A modest common prefix grid is enough for a safe necessary relaxation.
        if len(times) > 12:
            times = sorted({times[round(i*(len(times)-1)/11)] for i in range(12)})
        metadata = [('N', None, None)]
        rhs = [float(Ncap)]
        for g in self.P.models:
            metadata.append(('load', g, H)); rhs.append(float(self.P.data['M'][g]))
            for t in times:
                metadata.append(('air_prefix', g, t)); rhs.append(self.P.data['M'][g]*t/H)
                metadata.append(('battery_prefix', g, t)); rhs.append(self.P.data['K'][g]*t/H)
        cut_rows = []
        if continuous_cuts:
            for cut in self.proof_cuts:
                if H <= cut['H'] + 1e-7:
                    metadata.append(('proof_cut', None, cut['ids']))
                    rhs.append(float(len(cut['ids'])-1)); cut_rows.append(cut)
        eqrow=[];eqcol=[];eqvalue=[];ur=[];uc=[];uv=[]
        for j,r in enumerate(routes):
            for box in r['boxes']:
                eqrow.append(bindex[box]); eqcol.append(j); eqvalue.append(1.)
            latest = max(0., min(H-r['duration'], self.latest(r)))
            for i,(kind,g,t) in enumerate(metadata):
                if kind == 'N': value = 1.
                elif kind == 'proof_cut': value = float(r['id'] in t)
                elif g != r['model']: continue
                elif kind == 'load': value = r['duration']/H
                else:
                    duration = r['duration'] + (r['charge'] if kind == 'battery_prefix' else 0.)
                    value = min(duration, max(0., t-latest))/H
                if value:
                    ur.append(i); uc.append(j); uv.append(value)
        Aeq = self.sparse.csc_matrix((eqvalue,(eqrow,eqcol)), shape=(80,len(routes)))
        Aub = self.sparse.csc_matrix((uv,(ur,uc)), shape=(len(metadata),len(routes)))
        return dict(routes=routes, ids=ids, lookup=lookup, boxes=boxes, Aeq=Aeq, Aub=Aub,
                    beq=np.ones(80), bub=np.asarray(rhs), c=np.asarray([r['energy'] for r in routes]),
                    metadata=metadata, H=H, Ncap=Ncap, proof_cut_count=len(cut_rows), prefix_times=times)

    def lp_price(self, data, folder, seconds=None):
        self.last_lp=None
        duration = self.seconds_left(self.args.lp_seconds if seconds is None else seconds)
        if duration <= 0 or not data['routes']: return None
        inventory=self.lp_inventory_evidence(data,folder)
        duration=self.seconds_left(duration)
        if duration<=0:return None
        self.pulse('decomposition_lp', all_inventory_columns=len(data['routes']), H=data['H'])
        began=time.perf_counter()
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore', message='Unrecognized options detected.*')
            result = self.linprog(data['c'], A_ub=data['Aub'], b_ub=data['bub'],
                                  A_eq=data['Aeq'], b_eq=data['beq'], bounds=(0,None), method='highs',
                                  options=dict(time_limit=duration, threads=self.args.master_threads,
                                               presolve=True, primal_feasibility_tolerance=1e-8,
                                               dual_feasibility_tolerance=1e-8))
        evidence=dict(status=int(result.status), message=str(result.message), elapsed_s=time.perf_counter()-began,
            columns=len(data['routes']), rows=data['Aeq'].shape[0]+data['Aub'].shape[0],
            finite_pool_only=True, bound_scope='loaded finite pool continuous necessary-condition LP; not original global gap',
            zero_station_lateness=True,delivery_definition='whole-stop handover completion',
            primal_energy_kwh=finite(result.fun), dual_energy_bound_kwh=None,
            proof_cuts=data['proof_cut_count'], grid_cuts_in_lp=0, heuristic_cuts_in_lp=0,
            target_return_cap_s=data['H'], target_sortie_cap=data['Ncap'], prefix_times=data['prefix_times'],
            column_inventory=inventory,box_order=data['boxes'],equality_rhs=list(map(float,data['beq'])),
            inequality_row_metadata=data['metadata'],inequality_rhs=list(map(float,data['bub'])),
            matrix_definition='q2_decomposition_server.Decomposition.matrices',code_sha256=sha_file(Path(__file__)))
        priced=None
        if result.status == 0 and result.x is not None:
            y=self.np.asarray(result.eqlin.marginals).copy()
            z=self.np.minimum(self.np.asarray(result.ineqlin.marginals),0.)
            rc=data['c']-data['Aeq'].T@y-data['Aub'].T@z
            # Every column covers at least one box. Lowering all equality duals
            # by delta repairs floating-point reduced-cost deficits conservatively.
            correction=max(0., -float(rc.min())) + 1e-8
            y-=correction
            rc=data['c']-data['Aeq'].T@y-data['Aub'].T@z
            bound=float(data['beq']@y + data['bub']@z)
            valid=bool(float(rc.min()) >= -1e-10 and float(z.max(initial=-math.inf)) <= 0.
                       and bound <= float(result.fun)+1e-6)
            evidence.update(dual_certificate_numerically_checked=valid,
                minimum_reduced_cost=float(rc.min()), dual_repair_per_box=correction,
                dual_energy_bound_kwh=bound if valid else None,
                bound_note='Numerical certificate on floating physical coefficients, checked across every loaded eligible column; missing physical routes remain unpriced.',
                box_duals={b:float(v) for b,v in zip(data['boxes'],y)},
                inequality_duals=list(map(float,z)),
                positive_lp_columns=int((result.x>1e-7).sum()))
            priced=dict(y=y,z=z,rc=rc,x=result.x,evidence=evidence)
        dump(folder/'lp_pricing.json',evidence)
        self.last_lp=evidence
        return priced

    def active_indices(self, data, priced):
        limit=self.args.active_pool
        mandatory={v['route']['id'] for e in self.elites for v in e['rows']}
        mandatory.update(self.last_selected)
        keep={data['lookup'][rid] for rid in mandatory if rid in data['lookup']}
        if priced is not None:
            keep.update(int(i) for i in self.np.flatnonzero(priced['x']>1e-7))
            order=list(map(int,self.np.argsort(priced['rc'],kind='stable')))
        else:
            order=sorted(range(len(data['routes'])),key=lambda i:data['routes'][i]['energy']/len(data['routes'][i]['boxes']))
        # Preserve at least several low-price alternatives per box and model.
        counts=collections.Counter()
        for i in order:
            r=data['routes'][i]
            keys=[(b,r['model']) for b in r['boxes']]
            if any(counts[k]<3 for k in keys):
                keep.add(i)
                for k in keys: counts[k]+=1
        target=max(len(keep),int(limit*.85))
        for i in order:
            if len(keep)>=target:break
            keep.add(i)
        unused=[i for i in order if i not in keep]
        self.rng.shuffle(unused)
        keep.update(unused[:max(0,limit-len(keep))])
        return sorted(keep)

    def integer_master(self, data, indices, H, Ecap, Ncap, folder, seconds=None):
        np=self.np
        duration=self.seconds_left(self.args.master_seconds if seconds is None else seconds)
        if duration <= 0 or not indices:return None,dict(status='NOT_RUN')
        routes=[data['routes'][i] for i in indices]
        lookup={r['id']:i for i,r in enumerate(routes)}
        rows=[data['Aeq'][:,indices], data['Aub'][:,indices],
              self.sparse.csc_matrix(data['c'][indices].reshape(1,-1))]
        lower=[np.ones(80), np.full(len(data['bub']),-np.inf), np.asarray([-np.inf])]
        upper=[np.ones(80),data['bub'],np.asarray([Ecap])]
        search_cuts=[]
        for cut in self.grid_cuts:
            if abs(cut['H']-H)<1e-7 and abs(cut['Ecap']-Ecap)<1e-8 and cut['Ncap']==Ncap:search_cuts.append(cut)
        self.temporary_cuts=[c for c in self.temporary_cuts if c['expires_round']>=self.round]
        search_cuts += [c for c in self.temporary_cuts if abs(c['H']-H)<1e-7 and abs(c['Ecap']-Ecap)<1e-8 and c['Ncap']==Ncap]
        for cut in search_cuts:
            cols=[lookup[rid] for rid in cut['ids'] if rid in lookup]
            rows.append(self.sparse.csc_matrix((np.ones(len(cols)),(np.zeros(len(cols),dtype=int),cols)),shape=(1,len(routes))))
            lower.append(np.asarray([-np.inf])); upper.append(np.asarray([len(cut['ids'])-1.]))
        matrix=self.sparse.vstack(rows,format='csc')
        # SciPy/HiGHS sparse wrappers expect signed 32-bit index arrays.
        matrix.indices=matrix.indices.astype(np.int32);matrix.indptr=matrix.indptr.astype(np.int32)
        constraint=self.LinearConstraint(matrix,np.concatenate(lower),np.concatenate(upper))
        self.pulse('decomposition_milp', active_columns=len(routes), H=H, Ecap=Ecap, Ncap=Ncap)
        began=time.perf_counter()
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore',message='Unrecognized options detected.*')
            result=self.milp(data['c'][indices],integrality=np.ones(len(routes),dtype=np.uint8),
                bounds=self.Bounds(np.zeros(len(routes)),np.ones(len(routes))), constraints=constraint,
                options=dict(time_limit=duration,threads=self.args.master_threads,presolve=True,
                             mip_rel_gap=0.,random_seed=(self.args.seed+self.round)%2147483647))
        evidence=dict(status=int(result.status),message=str(result.message),elapsed_s=time.perf_counter()-began,
            columns=len(routes),all_loaded_eligible_columns=len(data['routes']),rows=matrix.shape[0],
            objective_energy_kwh=finite(result.fun),mip_dual_bound=finite(getattr(result,'mip_dual_bound',None)),
            mip_gap=finite(getattr(result,'mip_gap',None)),mip_nodes=int(getattr(result,'mip_node_count',0) or 0),
            bound_scope='active restricted MILP with grid/temporary search cuts; NOT a continuous or original-problem lower bound',
            finite_pool_only=True,proof_cuts=data['proof_cut_count'],search_cuts=len(search_cuts),
            H=H,Ecap=Ecap,Ncap=Ncap)
        selected=None
        if result.x is not None and max(abs(result.x-np.round(result.x)),default=0.)<=1e-5:
            chosen=[r for r,x in zip(routes,result.x) if x>.5]
            counts=collections.Counter(b for r in chosen for b in r['boxes'])
            if (set(counts)==set(self.P.boxes) and all(v==1 for v in counts.values()) and len(chosen)<=Ncap
                and sum(r['energy'] for r in chosen)<=Ecap+1e-8):
                selected=chosen
                evidence.update(selected_count=len(chosen),selected_energy_kwh=sum(r['energy'] for r in chosen),
                                selected_route_ids=sorted(r['id'] for r in chosen),partition_is_schedule=False)
        dump(folder/'master_evidence.json',evidence)
        self.save_pool({r['id']:r for r in routes},folder/'candidate_pool.jsonl')
        if selected:dump(folder/'selected_routes.json',selected)
        return selected,evidence

    def packing_filter(self, selected, H, folder):
        reports=[];newcuts=[]
        for typ in ('B','C'):
            tasks=[]
            for r in selected:
                if r['model']!=typ:continue
                L=min(H-r['duration'],self.latest(r))
                tasks.append(dict(id=r['id'],model=typ,p=float(r['duration']),L=float(L),d=float(L+r['duration'])))
            check=exact_two_aircraft(tasks)
            check['model']=typ
            if check['proved_infeasible']:
                core=list(tasks)
                for task in list(core):
                    test=[t for t in core if t is not task]
                    reduced=exact_two_aircraft(test)
                    if reduced['checked'] and reduced['proved_infeasible']:core=test
                proof=exact_two_aircraft(core)
                cut=dict(kind='continuous_aircraft_necessary_infeasibility',ids=sorted(t['id'] for t in core),
                    H=H,model=typ,input_signature=self.input_signature,proof=proof,created_round=self.round,
                    zero_station_lateness=True,delivery_definition='whole-stop handover completion',
                    scope='exact listed tasks; zero-release continuous aircraft-only relaxation; no battery assumptions')
                token=(H,tuple(cut['ids']))
                if not any((c['H'],tuple(c['ids']))==token for c in self.proof_cuts):
                    self.proof_cuts.append(cut);newcuts.append(cut)
                check['minimal_by_greedy_deletion_core']=cut
            reports.append(check)
        dump(folder/'packing_check.json',dict(H=H,reports=reports,new_proof_cuts=newcuts,
            full_schedule_proved_feasible=False,passes_necessary_filter=not any(r['proved_infeasible'] for r in reports)))
        return not any(r['proved_infeasible'] for r in reports)

    def fixed_schedule(self, selected, H, Ecap, Ncap, folder, seconds=None, warm=None):
        duration=self.seconds_left(self.args.schedule_seconds if seconds is None else seconds)
        if duration<=0:return None,dict(status='NOT_RUN')
        self.pulse('decomposition_fixed_cp', selected_routes=len(selected), H=H)
        pool={r['id']:r for r in selected}
        result=self.engine_solve(self.P,pool,seconds=duration,seed=(self.args.seed+self.round)%2147483647,q=.1,
            warm=warm,objectives=('C',),fixed_D=0,max_C=H,max_E=Ecap,max_N=Ncap,workers=self.args.workers,
            required_route_ids=list(pool),delivery_mode='batch',edd_order=True,
            stage_seconds={'C':duration},evidence_path=folder/'solver_stage_checkpoint.json',
            deadline_monotonic=self.deadline-3,stop_file=self.out/'STOP')
        dump(folder/'fixed_schedule_evidence.json',{k:v for k,v in result.items() if k!='selected'})
        record=None
        if result['selected']:
            self.effective_caps={'C':H,'E':Ecap,'N':Ncap}
            record=self.validate(self.decode(self.P,result),folder,'decomposition: selected routes independently scheduled and replayed',
                                 solver=result,caps=self.effective_caps)
            if record:self.update_elites(record)
        status=result['evidence'][-1]['status'] if result['evidence'] else 'NOT_RUN'
        ids=sorted(pool)
        if status=='INFEASIBLE':
            self.grid_cuts.append(dict(kind='conservative_grid_only',ids=ids,H=H,Ecap=Ecap,Ncap=Ncap,q=.1,
                input_signature=self.input_signature,created_round=self.round,
                scope='restricted conservative grid; excluded from continuous LP proof bound'))
        elif record is None and status not in ('NOT_RUN','MODEL_INVALID'):
            self.temporary_cuts.append(dict(kind='temporary_search_skip_not_proof',ids=ids,H=H,Ecap=Ecap,Ncap=Ncap,
                 expires_round=self.round+4,reason=status,created_round=self.round))
        elif record is not None:
            # Avoid repeatedly selecting the same feasible cover; purely heuristic.
            self.temporary_cuts.append(dict(kind='temporary_search_skip_not_proof',ids=ids,H=H,Ecap=Ecap,Ncap=Ncap,
                 expires_round=self.round+3,reason='already independently validated',created_round=self.round))
        return record,dict(status=status,independently_validated=record is not None,evidence=result['evidence'])

    def reduced_cost(self,r,data,priced):
        y,z=priced['y'],priced['z']; boxindex={b:i for i,b in enumerate(data['boxes'])}
        value=r['energy']-sum(y[boxindex[b]] for b in r['boxes'])
        H=data['H'];L=min(H-r['duration'],self.latest(r))
        if L < -1e-7:return math.inf
        L=max(0.,L)
        for dual,(kind,g,t) in zip(z,data['metadata']):
            if kind=='N':coef=1.
            elif kind=='proof_cut':coef=float(r['id'] in t)
            elif g!=r['model']:continue
            elif kind=='load':coef=r['duration']/H
            else:coef=min(r['duration']+(r['charge'] if kind=='battery_prefix' else 0),max(0,t-L))/H
            value-=dual*coef
        return float(value)

    def generate_priced(self, selected, data, priced, folder):
        if priced is None or self.expired(5):return
        began=time.perf_counter();deadline=min(self.deadline-4,began+self.args.pricing_seconds)
        base=selected or [v['route'] for v in self.best['rows']]
        boxdual={b:float(v) for b,v in zip(data['boxes'],priced['y'])}
        pairs=list(itertools.combinations(base,2));self.rng.shuffle(pairs)
        pairs.sort(key=lambda pair: -sum(max(0.,boxdual[b]) for r in pair for b in r['boxes']))
        tried=0;generated={};negative=0;best_rc=None
        def emit(boxes):
            nonlocal tried,negative,best_rc
            if time.perf_counter()>=deadline or tried>=500:return
            tried+=1
            for r in self.options(boxes):
                if r['id'] in self.pool or r['id'] in generated:continue
                rc=self.reduced_cost(r,data,priced)
                if not math.isfinite(rc):continue
                # Keep all valid targeted columns; reduced cost ranks adoption.
                generated[r['id']]=(rc,r)
                if rc < -1e-7:negative+=1
                best_rc=rc if best_rc is None else min(best_rc,rc)
        for a,b in pairs:
            if time.perf_counter()>=deadline or tried>=500:break
            aa=set(a['boxes']);bb=set(b['boxes'])
            emit(aa|bb)
            for donor,receiver in ((aa,bb),(bb,aa)):
                ranked=sorted(donor,key=lambda x:-boxdual[x])
                for n in (1,2,3):
                    if len(ranked)>=n:
                        transfer=set(ranked[:n]);emit(donor-transfer);emit(receiver|transfer)
            for x in sorted(aa,key=lambda v:-boxdual[v])[:3]:
                for y in sorted(bb,key=lambda v:-boxdual[v])[:3]:
                    emit((aa-{x})|{y});emit((bb-{y})|{x})
        ranked=sorted(generated.values(),key=lambda item:item[0])
        for rc,r in ranked[:self.args.new_columns]:self.pool[r['id']]=r
        report=dict(mechanism='LP-dual guided merge / 1-3 box relocation / swaps, full physical evaluation',
            attempted_box_sets=tried,new_physical_columns=len(generated),added_columns=min(len(ranked),self.args.new_columns),
            negative_reduced_cost_columns=negative,best_reduced_cost=best_rc,elapsed_s=time.perf_counter()-began,
            pricing_complete=False,finite_pool_only=True,
            warning='Failure to find a negative-price route is not an all-routes optimality certificate')
        dump(folder/'generated_pricing.json',report)

    def control(self):
        """Real known feasible route cover -> MILP -> CP -> independent replay."""
        folder=self.out/'control';folder.mkdir(parents=True,exist_ok=True)
        rows=self.baselines['Q2_fast']['rows'];routes=[v['route'] for v in rows]
        data=self.matrices(routes,6600.,len(routes),continuous_cuts=False)
        selected,master=self.integer_master(data,list(range(len(routes))),6600.,70.,len(routes),folder,
                                             seconds=min(5.,self.args.master_seconds))
        if selected is None:raise RuntimeError('Known feasible cover failed selection control')
        if not self.packing_filter(selected,6600.,folder):raise RuntimeError('Known feasible cover failed exact aircraft relaxation control')
        record,schedule=self.fixed_schedule(selected,6600.,70.,len(routes),folder,
                                            seconds=self.args.control_seconds,warm=rows)
        report=dict(valid=record is not None,known_feasible_sorties=len(routes),actual_selected_sorties=len(selected),
                    master=master,schedule=schedule,metrics=None if record is None else record['metrics'])
        dump(folder/'control_review.json',report)
        if record is None:raise RuntimeError('Known feasible route control not independently validated')

    def decomposition_round(self):
        self.round+=1
        strict=self.round%2==1
        H=self.args.strict_c if strict else self.args.bridge_c
        Ecap=self.args.strict_e if strict else self.args.bridge_e
        mode='strict' if strict else 'bridge23'
        folder=self.out/'rounds'/f'r{self.round:04d}_{mode}';folder.mkdir(parents=True,exist_ok=True)
        self.sync_all()
        data=self.matrices(list(self.pool.values()),H,self.args.target_n)
        priced=self.lp_price(data,folder)
        indices=self.active_indices(data,priced)
        dump(folder/'parameters.json',dict(mode=mode,H=H,Ecap=Ecap,Ncap=self.args.target_n,
            loaded_pool=len(self.pool),eligible_columns=len(data['routes']),active_columns=len(indices),
            LP_scope='all loaded eligible physical columns; continuous necessary constraints',
            MILP_scope='priced subset; optional grid and temporary cuts; not a global certificate',
            highs_threads=self.args.master_threads,CP_threads=self.args.workers,
            code_sha256=sha_file(Path(__file__))))
        selected,master=self.integer_master(data,indices,H,Ecap,self.args.target_n,folder)
        record=None;schedule=None;packing=None
        if selected:
            self.last_selected=[r['id'] for r in selected]
            packing=self.packing_filter(selected,H,folder)
            if packing:
                record,schedule=self.fixed_schedule(selected,H,Ecap,self.args.target_n,folder)
        self.generate_priced(selected,data,priced,folder)
        self.inventory_checkpoint()
        self.compress_large_evidence(folder)
        event=dict(round=self.round,mode=mode,H=H,Ecap=Ecap,Ncap=self.args.target_n,
            selected_count=None if selected is None else len(selected),packing_necessary_pass=packing,
            master=master,LP=self.last_lp,schedule=schedule,
            independently_validated=record is not None,candidate_id=None if record is None else record['id'],
            metrics=None if record is None else record['metrics'],best=self.best['metrics'],
            proof_cuts=len(self.proof_cuts),grid_only_cuts=len(self.grid_cuts),temporary_skips=len(self.temporary_cuts),
            loaded_pool=len(self.pool),finite_pool_only=True,original_problem_global_gap=None,
            elapsed_s=time.perf_counter()-self.started)
        self.events.append(event)
        with (self.out/'progress.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(event,ensure_ascii=False)+'\n')
        dump(self.out/'cuts.json',dict(continuous_proofs=self.proof_cuts,grid_only=self.grid_cuts,
                                     temporary_search_only=self.temporary_cuts))
        if self.round%2==0:self.save_pool(self.pool,self.out/'cumulative_pool.jsonl')
        self.pulse('decomposition_round_completed',mode=mode,selected_count=event['selected_count'],
                   independently_validated=record is not None,proof_cuts=len(self.proof_cuts))

    def run(self):
        state='running';error=None
        self.heartbeat.start();self.forwarder.start()
        try:
            self.initialize_baselines()
            self.control()
            while not self.expired(5):
                self.decomposition_round()
                if self.args.smoke and self.round>=self.args.smoke_rounds:break
            state='smoke_complete' if self.args.smoke else 'stopped_by_file' if self.expired() and (self.stop.exists() or (self.out/'STOP').exists()) else 'budget_complete'
        except BaseException:
            state='error';error=traceback.format_exc();raise
        finally:
            self.phase=state
            self.forward_done.set();self.forwarder.join(timeout=1)
            self.done.set();self.heartbeat.join(timeout=2)
            if self.pool:self.save_pool(self.pool,self.out/'cumulative_pool.jsonl')
            summary=dict(state=state,updated_at=now(),elapsed_s=time.perf_counter()-self.started,
                runtime_budget_s=self.args.seconds,rounds=self.round,workers=self.args.workers,
                highs_threads=self.args.master_threads,seed=self.args.seed,pool_size=len(self.pool),
                validation_count=self.validation_count,best=None if self.best is None else self.best['metrics'],
                newly_scheduled_valid_candidates=sum(e['independently_validated'] for e in self.events),
                proof_cuts=len(self.proof_cuts),grid_only_cuts=len(self.grid_cuts),
                finite_pool_only=True,bound_scope='saved LP records apply only to their loaded finite route snapshot',
                original_problem_global_gap=None,automatic_promotion=False,error=error)
            dump(self.out/'run_summary.json',summary);dump(self.out/'status.json',summary)
            atomic_text(self.out/'实时进展.md','# Q2 分解搜索\n\n'+json.dumps(summary,ensure_ascii=False,indent=2)+'\n\n有限路线池实验；未声明原题全局最优或全局gap。\n')
            print(json.dumps(summary,ensure_ascii=False),flush=True)
        return summary


def parse_args():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--seconds',type=float,default=7200.)
    p.add_argument('--workers',type=int,default=2)
    p.add_argument('--master-threads',type=int,default=2)
    p.add_argument('--seed',type=int,default=2026092601)
    p.add_argument('--output',default='runs/q2_decomp_a')
    p.add_argument('--active-pool',type=int,default=10000)
    p.add_argument('--lp-seconds',type=float,default=30.)
    p.add_argument('--master-seconds',type=float,default=45.)
    p.add_argument('--schedule-seconds',type=float,default=45.)
    p.add_argument('--control-seconds',type=float,default=20.)
    p.add_argument('--pricing-seconds',type=float,default=6.)
    p.add_argument('--new-columns',type=int,default=1200)
    p.add_argument('--strict-c',type=float,default=5699.9)
    p.add_argument('--strict-e',type=float,default=66.99999)
    p.add_argument('--bridge-c',type=float,default=6600.)
    p.add_argument('--bridge-e',type=float,default=70.)
    p.add_argument('--target-n',type=int,default=23)
    p.add_argument('--share-seconds',type=float,default=180.)
    p.add_argument('--resume',action='append',default=None)
    p.add_argument('--share-peers',action=argparse.BooleanOptionalAction,default=True)
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--smoke-rounds',type=int,default=2)
    a=p.parse_args()
    if a.seconds<=0 or not 1<=a.workers<=4 or not 1<=a.master_threads<=2:p.error('Invalid runtime/threads')
    if a.smoke and a.seconds>120:p.error('Smoke budget must not exceed 120 seconds')
    for k in ('active_pool','lp_seconds','master_seconds','schedule_seconds','control_seconds','pricing_seconds','new_columns','strict_c','strict_e','bridge_c','bridge_e','target_n','smoke_rounds'):
        if getattr(a,k)<=0:p.error(k+' must be positive')
    a.resume=a.resume if a.resume is not None else ['seeds/q2','seeds/q2_phase2']
    # Fields expected by the reviewed server adapter; its old round loop is not used.
    a.worker_id=Path(a.output).name;a.skip_resume_pools=False
    a.local_pool=a.large_pool=a.global_pool=a.active_pool
    a.generation_seconds=a.pricing_seconds
    a.stage_seconds=a.global_seconds=a.polish_seconds=a.target_seconds=a.schedule_seconds
    a.target_c=a.strict_c;a.target_e=a.strict_e;a.config=None
    return a


if __name__=='__main__':
    Decomposition(parse_args()).run()
