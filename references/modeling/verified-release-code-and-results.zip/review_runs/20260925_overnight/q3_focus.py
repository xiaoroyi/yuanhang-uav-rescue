"""Q3 epsilon-constraint search; original physics and validation are unchanged."""
import argparse
import sys
import time
import q3_server as base
from q3_search import HERE, read, write

PROBE = False

def focus_policy(index, feasible_metrics, probe=False):
    if probe:
        m = feasible_metrics[0]
        return dict(mode='known_feasible_pipeline_probe', C=m['C']+1., E=m['E']+.1,
                    N=m['N_transport'], slots=max(4,m['N_relay']), objectives=('C','E'))
    mode=index%4
    if mode in (0,3):
        c,e=5939.9,68.9999
        hits=[m for m in feasible_metrics if m['C']<5940 and m['E']<69
              and m['N_transport']<=23 and m['N_relay']<=4]
        if hits and mode==3:
            if (index//4)%2:c=min(m['C'] for m in hits)-5.
            else:e=min(m['E'] for m in hits)-.01
        return dict(mode='joint_target',C=c,E=e,N=23,slots=4,objectives=('E','C'))
    if mode==1:
        return dict(mode='energy_bridge',C=6059.9,E=68.9999,N=23,slots=4,objectives=('C','E'))
    return dict(mode='time_bridge',C=5939.9,E=69.6,N=23,slots=4,objectives=('E','C'))

class FocusedSearch(base.ServerSearch):
    def __init__(self,args):
        super().__init__(args)
        self.focus_step=0
        original=self.joint.solve
        def solve(name,**kwargs):
            metrics=[r['metrics'] for r in self.archive]
            policy=focus_policy(self.focus_step+(0 if PROBE else args.seed%4),metrics,PROBE)
            self.focus_step+=1
            kwargs.update(max_C=policy['C'],max_E=policy['E'],max_transport=policy['N'],
                          slots=policy['slots'],objectives=policy['objectives'])
            warm=kwargs.get('warm')
            if warm and len(warm['relay'])>policy['slots']:
                kwargs.update(warm=None,complete_warm=False)
            folder=self.cases/name
            contract=read(folder/'input_contract.json')
            contract.update(max_C=policy['C'],max_E=policy['E'],max_transport=policy['N'],
                            slots=policy['slots'],objectives=policy['objectives'],focus_policy=policy,
                            original_constraints_unchanged=True)
            write(folder/'input_contract.json',contract)
            result=original(name,**kwargs)
            return result
        self.joint.solve=solve

    def import_q2(self):
        super().import_q2()
        self.q2={k:v for k,v in self.q2.items() if v['N']<=23}

    def warm_solution(self,number):
        if PROBE:return super().warm_solution(number)
        def distance(item):
            m=item['metrics']
            return max(0,m['C']-5939.9)/60+2*max(0,m['E']-68.9999)+3*max(0,m['N_transport']-23)+max(0,m['N_relay']-4)
        ranked=sorted(self.archive,key=lambda x:(distance(x),x['metrics']['E'],x['metrics']['C']))
        if number%4 in (0,3):item=ranked[0]
        elif number%4==1:item=min(ranked,key=lambda x:(max(0,x['metrics']['E']-68.9999),x['metrics']['C']))
        else:item=self.rng.choice(ranked[:min(8,len(ranked))])
        sol=read(HERE/item['path']/'solution_q3.json')
        for j,row in enumerate(sorted(sol['relay'],key=lambda r:r['start'])):row['slot']=j
        return sol,item

    def run_server(self):
        if not PROBE:return super().run_server()
        options=self.resume_options()
        assert options,'Need an actual certified overnight seed'
        self.replay_seed(options[0],'probe_seed')
        result=self.run_round(0)
        assert result['status']=='accepted',result
        report=read(HERE/result['path']/'candidate_review.json')
        assert report['validation']['valid'] and report['metrics']['gap_seconds']==0
        assert report['station']['boxes']==report['station']['unique_boxes']==80
        assert report['station']['hard_boxes']==31 and report['station']['late_boxes']==0
        write(self.out/'focus_probe.json',dict(status='PASS',elapsed_s=time.monotonic()-self.started,
              result=result,physical_validation=report['validation'],station_validation=report['station'],
              scope='Real inherited solver plus focused wrapper, feasible control; target feasibility is not presumed'))
        return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--focus-probe',action='store_true')
    own,rest=parser.parse_known_args();PROBE=own.focus_probe
    sys.argv=[sys.argv[0]]+rest
    base.ServerSearch=FocusedSearch
    base.main()
