"""Complete incumbent hints and Q2-informed joint route/location expansion."""
from setup_q3 import *
from joint import solve
from validate_q3 import run
from atoms import build_route
from communication import Radio
from routes import Physics
import time,argparse

def main():
    warm=json.loads((OUT/'warm_original.json').read_text(encoding='utf-8'))
    pool={r['id']:r for r in json.loads((OUT/'routes_review.json').read_text(encoding='utf-8'))}
    sources=[]
    q2root=ROOT.parent/'q2/results'
    for p in sorted(q2root.glob('ABC*/solution.json')):
        rows=json.loads(p.read_text(encoding='utf-8'));sources.append(str(p))
        for row in rows:pool[row['route']['id']]=row['route']
    sites=json.loads((OUT/'relay_sites.json').read_text(encoding='utf-8'));ids=[s['id'] for s in sites]
    atoms=json.loads((OUT/'coverage_atoms_review.json').read_text(encoding='utf-8'));P=Physics();radio=Radio(inputs())
    for rid,r in pool.items():
        if rid not in atoms:atoms[rid],_=build_route(r,P,radio,sites,max_block=30)
    dump(OUT/'joint_augmented_routes.json',list(pool.values()));dump(OUT/'joint_augmented_atoms.json',atoms)
    dump(OUT/'joint_augmented_sources.json',sources)
    records=[]
    cases=[('joint_hinted_3',3,6027.,('C','E')),('joint_hinted_4',4,6027.,('C','E')),('joint_hinted_6',6,6027.,('C',)),('joint_energy_trade',4,6327.,('E','C','N'))]
    for name,slots,limit,obj in cases:
        t=time.time();directory=OUT/name;directory.mkdir(exist_ok=True)
        contract=dict(routes=len(pool),sites=ids,slots=slots,resources=[2,6],objectives=obj,zero_late=True,max_C=limit,seconds_per_stage=90,workers=2,seed=0,complete_warm=True,source_solutions=sources)
        dump(directory/'experiment_contract.json',contract)
        res=solve(name,seconds=90,slots=slots,site_ids=ids,pool=list(pool.values()),atoms=atoms,zero_late=True,max_C=limit,objectives=obj,warm=warm,workers=2,complete_warm=True)
        rec=dict(name=name,contract=contract,wall_seconds=time.time()-t,evidence=json.loads((directory/'solver_evidence.json').read_text(encoding='utf-8')))
        if res:
            report=run(directory/'solution_q3.json');rec['validation']=report['summary']
            if report['summary']['valid']:
                if obj[0]=='C' and (report['summary']['C_joint'],report['summary']['E_total'])< (max(r['return'] for r in warm['transport']+warm['relay']),sum(r['route']['energy'] for r in warm['transport'])+sum(r['energy'] for r in warm['relay'])):warm=res
        else:rec['validation']=None
        records.append(rec);dump(OUT/'targeted_joint_summary.json',records)
        print('JOINT_COMPLETED',name,flush=True)

if __name__=='__main__':main()
