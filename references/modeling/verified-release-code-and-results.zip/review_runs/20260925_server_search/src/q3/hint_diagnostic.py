from setup_q3 import *
from joint import solve
from validate_q3 import run
if __name__=='__main__':
    pool=json.loads((OUT/'joint_augmented_routes.json').read_text(encoding='utf-8'));atoms=json.loads((OUT/'joint_augmented_atoms.json').read_text(encoding='utf-8'));warm=json.loads((OUT/'warm_original.json').read_text(encoding='utf-8'))
    s=solve('joint_no_presolve_diagnostic',seconds=40,slots=3,pool=pool,atoms=atoms,zero_late=True,max_C=6027.,objectives=('C',),warm=warm,workers=2,complete_warm=True,presolve=False)
    if s:run(OUT/'joint_no_presolve_diagnostic/solution_q3.json')
