"""Nested route/site evidence; generate sites from airborne blind spots, not endpoints alone."""
from setup_q3 import *
from routes import Physics
from communication import Radio, phases
from sites import relay_metrics
from atoms import build_route
import time, math, shutil

def main():
    started=time.time();P=Physics();d=inputs();radio=Radio(d)
    old=PROJECT/'问题3/results'
    warm=json.loads((old/'solution_q3.json').read_text(encoding='utf-8'))
    sites=json.loads((old/'relay_sites.json').read_text(encoding='utf-8'))
    refined=json.loads((old/'site_refinement.json').read_text(encoding='utf-8'))
    ids=['P001','P009','P010']+refined['activated']
    base=[s for s in sites if s['id'] in ids]
    routes=json.loads((old/'expanded_routes.json').read_text(encoding='utf-8'))
    pool={r['id']:r for r in routes}
    for r in warm['transport']:pool[r['route']['id']]=r['route']
    # Target samples are used ONLY to propose locations. Acceptance is continuous.
    targets={}
    for row in warm['transport']:
        for p in phases(row['route'],P):
            if p['type']=='交接':continue
            pr=radio.profile(d['gateway'],p['p0'],p['p1'],'direct')
            for a,b,ok in pr['pieces']:
                if ok or b-a<1e-8:continue
                for frac in (.2,.5,.8):
                    u=a+(b-a)*frac;xyz=np.array(p['p0'])+u*(np.array(p['p1'])-p['p0'])
                    key=tuple(round(float(x),3) for x in xyz)
                    targets[key]=dict(x=float(xyz[0]),y=float(xyz[1]),z=float(xyz[2]),phase=p['type'],weight=(b-a)*(p['b']-p['a']))
    targets=list(targets.values());table(OUT/'airborne_blind_targets.csv',targets)
    # Stratified top-duration targets keep scouting bounded; save their identities.
    targets=sorted(targets,key=lambda v:-v['weight'])[:48]
    points=set()
    for t in targets:
        for dx,dy in [(0,0),(300,0),(-300,0),(0,300),(0,-300)]:
            for agl in (150,250,300):points.add((round(t['x']+dx,2),round(t['y']+dy,2),agl))
    for s in (r['site'] for r in warm['relay']):
        for dx,dy in [(150,0),(-150,0),(0,150),(0,-150),(300,0),(-300,0),(0,300),(0,-300)]:
            for agl in (200,250,300):points.add((round(s['x']+dx,2),round(s['y']+dy,2),agl))
    proposed=[];rejected=0
    for k,(x,y,agl) in enumerate(sorted(points)):
        lon,lat=INVERSE.transform(x,y)
        row=int(math.floor((d['lat'][0]-lat)/radio.dy+.5));col=int(math.floor((lon-d['lon'][0])/radio.dx+.5))
        if not(0<=row<d['dem'].shape[0] and 0<=col<d['dem'].shape[1]):continue
        xyz=np.array([x,y,float(d['dem'][row,col])+agl]);back=radio.point(d['gateway'],xyz,'backhaul')
        if not back['valid']:rejected+=1;continue
        covered=[]
        for j,t in enumerate(targets):
            p=np.array([t['x'],t['y'],t['z']])
            prof=radio.profile(xyz,p,p,'access')
            if prof['pieces'][0][2] and not prof['events']:covered.append(j)
        if not covered:continue
        endpoint=[]
        for name,n in d['nodes'].items():
            if name=='O01':continue
            p=n['xy']+[n['z']+30];prof=radio.profile(xyz,p,p,'access')
            if prof['pieces'][0][2] and not prof['events']:endpoint.append(name)
        proposed.append(dict(lon=lon,lat=lat,x=x,y=y,agl=agl,cover=endpoint,airborne_targets=covered,score=sum(targets[j]['weight'] for j in covered),backhaul_margin=back['margin'],distance=float(np.linalg.norm(xyz-d['gateway']))))
        if k%100==0:print('SCOUT',k,len(points),len(proposed),round(time.time()-started,1),flush=True)
    dump(OUT/'airborne_site_scout_all.json',dict(targets=targets,candidates=proposed,backhaul_rejected=rejected))
    selected=[];used=set()
    def take(c):
        key=(c['lon'],c['lat'],c['agl'])
        if key not in used:used.add(key);selected.append(c)
    # Cover diverse transit target subsets, including endpoint-free sites if present.
    for c in sorted((c for c in proposed if not c['cover']),key=lambda v:(-v['score'],v['distance']))[:4]:take(c)
    patterns=set()
    for c in sorted(proposed,key=lambda v:(-v['score']/(v['distance']+1000),-v['backhaul_margin'])):
        pattern=tuple(c['airborne_targets'])
        if pattern in patterns:continue
        patterns.add(pattern);take(c)
        if len(selected)>=16:break
    for i,c in enumerate(selected,1):
        m=relay_metrics(d,c['lon'],c['lat'],c['agl'])
        if m is not None and m['max_service']>0:m.update(id=f'T{i:03d}',cover=c['cover'],origin='airborne_blind_spot',backhaul_margin=c['backhaul_margin']);base.append(m)
    dump(OUT/'relay_sites.json',base);table(OUT/'relay_sites.csv',base)
    dump(OUT/'routes_review.json',list(pool.values()));dump(OUT/'warm_original.json',warm)
    atoms={}
    for i,r in enumerate(pool.values(),1):
        atoms[r['id']],_=build_route(r,P,radio,base,max_block=30)
        if i%25==0:print('ATOMS',i,len(pool),round(time.time()-started,1),flush=True)
    dump(OUT/'coverage_atoms_review.json',atoms)
    dump(OUT/'preparation_summary.json',dict(routes=len(pool),old_site_ids=ids,new_site_ids=[s['id'] for s in base if s['id'].startswith('T')],sites=len(base),blind_targets=len(targets),proposed_sites=len(proposed),transit_only_proposals=sum(not c['cover'] for c in proposed),atoms=sum(len(v) for v in atoms.values()),uncovered_routes=sum(any(not a['sites'] for a in aa) for aa in atoms.values()),elapsed=time.time()-started,scouting_is_heuristic=True,acceptance='continuous interval+event validation'))
    print('PREPARED',time.time()-started,flush=True)

if __name__=='__main__':main()
