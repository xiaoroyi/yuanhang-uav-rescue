from setup_q3 import *
from joint import solve
from validate_q3 import run
import time,copy,argparse,platform,hashlib

def main(mode):
    warm=json.loads((OUT/'warm_original.json').read_text(encoding='utf-8'))
    full=json.loads((OUT/'routes_review.json').read_text(encoding='utf-8'))
    narrow=[r['route'] for r in warm['transport']]
    prep=json.loads((OUT/'preparation_summary.json').read_text(encoding='utf-8'))
    old=prep['old_site_ids'];new=old+prep['new_site_ids'];fixed=[r['site']['id'] for r in warm['relay']]
    atoms=json.loads((OUT/'coverage_atoms_review.json').read_text(encoding='utf-8'))
    if mode=='compare':
        cases=[('baseline_25_19_3',narrow,old,3),('routes_only_311_19_3',full,old,3),('sites_only_25_expanded_3',narrow,new,3),('joint_311_expanded_3',full,new,3)]
        seconds=60;objectives=('C','E')
    elif mode=='slots':
        cases=[('joint_slots4',full,new,4),('joint_slots6',full,new,6)];seconds=90;objectives=('C','E')
    else:raise ValueError(mode)
    records=[]
    for name,pool,ids,slots in cases:
        directory=OUT/name;directory.mkdir(exist_ok=True)
        contract=dict(name=name,routes=len(pool),route_ids=[r['id'] for r in pool],sites=ids,slots=slots,resources=[2,6],seconds_per_stage=seconds,workers=2,seed=0,max_C=6027.,zero_late=True,objectives=objectives,warm='old frozen Q3',atom_partition='shared full-site breakpoint partition, filtered per case',optimality_scope='restricted candidates, 0.1s grid, finite coverage handover blocks')
        dump(directory/'experiment_contract.json',contract);beg=time.time()
        res=solve(name,seconds=seconds,slots=slots,site_ids=ids,pool=pool,atoms=atoms,zero_late=True,max_C=6027.,objectives=objectives,warm=warm,workers=2)
        rec=dict(name=name,wall_seconds=time.time()-beg,contract=contract,solver_evidence=json.loads((directory/'solver_evidence.json').read_text(encoding='utf-8')))
        if res:
            report=run(directory/'solution_q3.json');rec['validation']=report['summary']
        else:rec['validation']=None
        # Solver timeout cannot invalidate the previously validated incumbent.
        rec['known_incumbent_retained']=res is None or not rec['validation']['valid']
        records.append(rec);dump(OUT/f'{mode}_summary.json',records)
        print('COMPLETED_CASE',name,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['compare','slots']);args=p.parse_args();main(args.mode)
