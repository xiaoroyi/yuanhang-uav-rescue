"""Meaningful optional-activation and no-communication reduction tests."""
from setup_q3 import *
from joint import solve
from validate import check
from master import ceil_tick
import copy,itertools

def main():
    original=json.loads((PROJECT/'问题2/results/solution.json').read_text(encoding='utf-8'))
    # Rebuild the known Q2 aircraft/battery order on Q3's common envelopes.
    warm=dict(transport=copy.deepcopy(original),relay=[]);ready_u={};ready_b={}
    for row in sorted(warm['transport'],key=lambda r:r['start']):
        st=max(ready_u.get(row['aircraft'],0),ready_b.get(row['battery'],0))
        row['start']=st*.1;ready_u[row['aircraft']]=st+ceil_tick(row['route']['duration'],.1);ready_b[row['battery']]=st+ceil_tick(row['route']['duration']+row['route']['charge'],.1)
    routes=[r['route'] for r in warm['transport']]
    empty={r['id']:[] for r in routes}
    dummy=copy.deepcopy(routes[0]);dummy.update(id='FORBIDDEN_LONG_ROUTE',duration=100000.,charge=100000.,energy=1000.)
    extra=routes+[dummy];empty[dummy['id']]=[]
    badsite=copy.deepcopy(json.loads((OUT/'warm_original.json').read_text(encoding='utf-8'))['relay'][0]['site']);badsite.update(id='FORBIDDEN_FAR_SITE',ready_offset=100000.,arrival_offset=99970.,back=100000.,fly_energy=1000.)
    cases=[('control_no_communication',routes,0,(),(),[]),('control_disabled_candidates',extra,4,(dummy['id'],),tuple(range(4)),[badsite])]
    records=[]
    for name,pool,n,fr,fs,sites in cases:
        res=solve(name+'_v2',seconds=25,slots=n,pool=pool,atoms=empty,objectives=('C',),zero_late=True,warm=warm,workers=1,forbidden_routes=fr,forbidden_slots=fs,sites_override=sites,max_C=max(ready_u.values())*.1,complete_warm=True)
        name=name+'_v2'
        evidence=json.loads((OUT/name/'solver_evidence.json').read_text(encoding='utf-8'))
        rec=dict(name=name,evidence=evidence)
        if res:
            validation=check(res['transport'],save=OUT/name/'transport_validation');rec['transport_validation']=validation['summary'];rec['grid']=res['grid_metrics']
            act=json.loads((OUT/name/'activation_evidence.json').read_text(encoding='utf-8'))
            rec['inactive_zero']=all(not r['enabled'] and all(r[k]==0 for k in ['start','link','finish','return_tick','energy_micro_kwh','charge_ticks']) for r in act['relay_slots'])
            rec['forbidden_route_zero']=all(not r['selected'] and r['start']==0 and r['end']==0 for r in act['routes'] if r['id'] in fr)
        records.append(rec)
    # An independent exact two-machine partition relaxation attains the feasible
    # CP schedule, certifying fixed-route C on this common whole-route 0.1s grid.
    ct=[ceil_tick(r['duration'],.1) for r in routes if r['model']=='C']
    lower=min(max(sum(v for j,v in enumerate(ct) if mask>>j&1),sum(v for j,v in enumerate(ct) if not(mask>>j&1))) for mask in range(1<<len(ct)))
    result=dict(scope='Fixed original routes, same whole-route conservative 0.1s envelopes; communication disabled. This is not full-route-space equivalence or a global bound.',cases=records,fixed_C_partition_lower_s=lower*.1)
    result['passed']=all(r.get('transport_validation',{}).get('valid') and r.get('inactive_zero') and r.get('forbidden_route_zero') and abs(r['grid']['C']-lower*.1)<1e-7 for r in records)
    dump(OUT/'activation_and_reduction_checks.json',result);print('CONTROLS',result['passed'],lower*.1,flush=True)

if __name__=='__main__':main()
