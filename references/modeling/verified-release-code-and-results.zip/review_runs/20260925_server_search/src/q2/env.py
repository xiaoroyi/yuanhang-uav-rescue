from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
PROJECT=ROOT.parents[1]
sys.path.insert(0,str(PROJECT/'问题1/src'))
import bootstrap
sys.path.insert(0,str(PROJECT/'问题2/deps311'))
OUT=ROOT/'inputs'
OUT.mkdir(exist_ok=True,parents=True)
