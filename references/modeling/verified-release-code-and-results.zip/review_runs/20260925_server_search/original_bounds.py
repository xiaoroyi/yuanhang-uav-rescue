"""Route-pool-independent lower bounds for the original Q2/Q3 physical model.

Only exact rational arithmetic, optimistic complete-node graph closures and
enumeration of three aggregate sortie counts are used. No schedule is solved,
no candidate route pool is read, and no running worker is changed.
"""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import argparse
import hashlib
import json
import math
import os
import sys
import time
import zipfile
from xml.etree import ElementTree as ET

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
TIME_SCALE = 10**6
ENERGY_SCALE = 10**9
DISTANCE_SCALE = 10**6
PINNED = {
    'inputs/normalized_inputs.json': '7f8035e098d08de3a12986700c964df6a5d0348e1dd880841b7f0c5caa611b9a',
    'inputs/terrain_evidence_all.json': '8d8e5477493680c8db5d35698cf1c3b898c114c3556b3b5fbbdd6040fe93ebb4',
    'src/q2/routes.py': '940cf521ef218bf257a950eebbd48d3c617e213e1b1d95b927561e0675cba06e',
    'src/q2/validate.py': '5642caa076a4a7e559c749cdc4aa7b3a50f3d77adc6a08ce4bddc2a79dee0109',
}
PINNED_Q3 = {
    'src/q3/sites.py': '4ab40f245616e3cdbc4dd8b9c7e9551cdda145cf5a62c79582fccf24c57767b4',
    'src/q3/validate_q3.py': '3b7629fc71d69c964bf5f83aea045d48405df5577dca79439871c5b92606d9ee',
}
DOCX_SHA = '0a4f507b91a02a0ea4264973dd432cdcb5b8916c61c24214719665f326d57685'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def frac(value):
    return F(str(value))


def floor_scaled(value, scale):
    value = frac(value) * scale
    return value.numerator // value.denominator


def ceil_ratio(a, b):
    value = frac(a) / frac(b)
    return -(-value.numerator // value.denominator)


def lower_value(units, scale):
    # The rational certificate is authoritative. Round the JSON float outward.
    return math.nextafter(float(F(units, scale)), -math.inf) if units else 0.0


def dump(path, value):
    path = Path(path).resolve()
    if not path.is_relative_to(HERE) or path.name != 'original_bounds.json':
        raise ValueError('Only an isolated original_bounds.json beneath HERE may be written.')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    os.replace(temporary, path)


def closure(matrix):
    result = [row[:] for row in matrix]
    for k in range(len(result)):
        for i in range(len(result)):
            for j in range(len(result)):
                result[i][j] = min(result[i][j], result[i][k] + result[k][j])
    return result


def mst(matrix):
    # Every union of depot-returning routes serving every node is connected.
    # A spanning tree costs no more than that connected multigraph.
    visited = {0}; total = 0; edges = []
    while len(visited) < len(matrix):
        cost, a, b = min((matrix[a][b], a, b) for a in visited
                         for b in range(len(matrix)) if b not in visited)
        visited.add(b); total += cost; edges.append((a, b, cost))
    return total, edges


def original_text_evidence():
    name = '山区洪涝灾害下无人机运输与通信协同优化.docx'
    paths = list((PROJECT.parent/'D题').glob(name))
    if len(paths) != 1:
        raise RuntimeError('The packaged original problem DOCX is required for scope checks.')
    path = paths[0]
    assert sha(path) == DOCX_SHA, 'Original problem text changed.'
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read('word/document.xml'))
    paragraphs = [''.join(p.itertext()) for p in root.findall('.//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p')]
    text = '\n'.join(paragraphs)
    for phrase in ('每个运输架次可访问一个或多个服务区', '返回 O01',
                   '每次投送后均从30米作业高度重新爬升', '80个不可拆货箱'):
        assert phrase in text, phrase
    selected = [p for p in paragraphs if any(s in p for s in (
        '每个运输架次可访问一个或多个服务区', '任意两个任务节点之间',
        '联合任务完成时间取', '航段运输能耗按'))]
    return {'sha256': DOCX_SHA, 'path': path.relative_to(PROJECT.parent).as_posix(),
            'scope_paragraphs': selected, 'source_formula': 'src/q2/routes.py Physics.evaluate and independent src/q2/validate.py; unchanged common Appendix-2 physical model'}


def derive():
    started = time.perf_counter()
    source_hashes = {name: sha(HERE/name) for name in PINNED}
    assert source_hashes == PINNED, 'Frozen input or reviewed physical formula changed.'
    q3_hashes = {name: sha(HERE/name) for name in PINNED_Q3}
    assert q3_hashes == PINNED_Q3, 'Reviewed Q3 physical/validation source changed.'
    signature = hashlib.sha256(json.dumps(source_hashes, sort_keys=True).encode()).hexdigest()
    original = original_text_evidence()
    data = read(HERE/'inputs/normalized_inputs.json')
    terrain = read(HERE/'inputs/terrain_evidence_all.json')
    boxes = data['boxes']; models = data['models']; names = sorted(data['nodes'])
    assert names[0] == 'O01' and set(models) == {'A','B','C'}
    assert data['M'] == {'A':4,'B':2,'C':2} and data['K'] == {'A':6,'B':4,'C':4}
    assert len(boxes) == len({b['id'] for b in boxes}) == 80
    assert all(b['weight'] > 0 and b['volume_L'] > 0 for b in boxes)
    assert all(isinstance(b['weight'],int) and isinstance(b['volume_L'],int) for b in boxes)
    assert all(isinstance(m['Q'],int) and isinstance(m['volume_L'],int) for m in models.values())
    assert all(m['L0'] >= m['LF'] > 0 and m['eta'] > 0 and m['down_eff'] == 0 for m in models.values())
    mass = sum(b['weight'] for b in boxes); volume = sum(b['volume_L'] for b in boxes)
    assert (mass, volume) == (758, 2011)
    services = sorted({b['service'] for b in boxes})
    assert services == names[1:]
    index = {s:i for i,s in enumerate(names)}; size = len(names)
    geometry = {tuple(sorted((r['start'],r['end']))):r for r in terrain['legs']}
    assert len(geometry) == size*(size-1)//2
    time_graph = {}; empty_graph = {}; vertical_graph = {}
    distances = [[0]*size for _ in names]
    for typ,m in models.items():
        tm = [[0]*size for _ in names]; em = [[0]*size for _ in names]; vm = [[0]*size for _ in names]
        for i,a in enumerate(names):
            for j,b in enumerate(names):
                if i == j: continue
                g = geometry[tuple(sorted((a,b)))]; distance = frac(g['distance_m'])
                za = frac(data['nodes'][a]['z']) + (0 if a == 'O01' else 30)
                zb = frac(data['nodes'][b]['z']) + (0 if b == 'O01' else 30)
                up = frac(g['cruise_m'])-za; down = frac(g['cruise_m'])-zb
                assert min(distance,up,down) >= 0
                flight = up/frac(m['up']) + distance/frac(m['speed']) + down/frac(m['down'])
                vertical = frac(m['m0'])*F(981,100)*up/(frac(m['eta'])*3600000)
                empty = frac(m['Euse'])*distance/frac(m['L0']) + vertical
                tm[i][j] = floor_scaled(flight,TIME_SCALE)
                em[i][j] = floor_scaled(empty,ENERGY_SCALE)
                vm[i][j] = floor_scaled(vertical,ENERGY_SCALE)
                distances[i][j] = floor_scaled(distance,DISTANCE_SCALE)
        time_graph[typ] = tm; empty_graph[typ] = em; vertical_graph[typ] = vm
    shortest_t = {g:closure(m) for g,m in time_graph.items()}
    shortest_e = {g:closure(m) for g,m in empty_graph.items()}
    shortest_v = {g:closure(m) for g,m in vertical_graph.items()}
    shortest_d = closure(distances)
    cycle_t = {g:min(m[0][s]+m[s][0] for s in range(1,size)) for g,m in shortest_t.items()}
    cycle_e = {g:min(m[0][s]+m[s][0] for s in range(1,size)) for g,m in shortest_e.items()}
    cycle_v = {g:min(m[0][s]+m[s][0] for s in range(1,size)) for g,m in shortest_v.items()}
    qmax = max(m['Q'] for m in models.values()); vmax = max(m['volume_L'] for m in models.values())
    visits = sum(max(1,ceil_ratio(sum(b['weight'] for b in boxes if b['service']==s),qmax),
                     ceil_ratio(sum(b['volume_L'] for b in boxes if b['service']==s),vmax)) for s in services)
    boxmax = {g:min(80,int(m['Q']//min(b['weight'] for b in boxes)),
                     int(m['volume_L']//min(b['volume_L'] for b in boxes))) for g,m in models.items()}
    handling = min(floor_scaled(frac(m['load'])+frac(m['handover_box']),TIME_SCALE) for m in models.values())
    handover = min(floor_scaled(m['handover'],TIME_SCALE) for m in models.values())
    base_t = {g:cycle_t[g]+floor_scaled(frac(m['prep'])+frac(m['handover']),TIME_SCALE) for g,m in models.items()}
    one_box_t = {g:floor_scaled(frac(m['load'])+frac(m['handover_box']),TIME_SCALE) for g,m in models.items()}
    # Exhaustively enumerate ALL aggregate (n_A,n_B,n_C) with nonempty sorties.
    # Constraints below are necessary, never sufficient. Minima are lower bounds.
    count = 0; minima = {'N':None,'C_eight_microseconds':None,'empty_nano_kwh':None,'vertical_nano_kwh':None}; witnesses = {}
    for a in range(81):
        for b in range(81-a):
            for c in range(81-a-b):
                n = {'A':a,'B':b,'C':c}; total = a+b+c
                if sum(n[g]*models[g]['Q'] for g in n) < mass: continue
                if sum(n[g]*models[g]['volume_L'] for g in n) < volume: continue
                if sum(n[g]*boxmax[g] for g in n) < len(boxes): continue
                count += 1
                # Each sortie pays one preparation/base handover; extra visits
                # pay additional base handovers; each box load/handling paid ONCE.
                aggregate = sum(n[g]*base_t[g] for g in n)+len(boxes)*handling+max(0,visits-total)*handover
                resource = [n[g]*(base_t[g]+one_box_t[g])*(8//data['M'][g]) for g in n]
                values = {'N':total,'C_eight_microseconds':max([aggregate]+resource),
                          'empty_nano_kwh':sum(n[g]*cycle_e[g] for g in n),
                          'vertical_nano_kwh':sum(n[g]*cycle_v[g] for g in n)}
                for key,value in values.items():
                    if minima[key] is None or value < minima[key]:
                        minima[key] = value; witnesses[key] = n.copy()
    assert count and all(v is not None for v in minima.values())
    # A necessary single-box route lower bound, with arbitrary intermediate
    # nodes allowed and every other box/handover removed.
    box_times = []
    for box in boxes:
        s = index[box['service']]
        allowed = [g for g,m in models.items() if box['weight'] <= m['Q'] and box['volume_L'] <= m['volume_L']]
        assert allowed
        value = min(shortest_t[g][0][s]+shortest_t[g][s][0]+
                    floor_scaled(frac(models[g]['prep'])+frac(models[g]['handover'])+
                                 frac(models[g]['load'])+frac(models[g]['handover_box']),TIME_SCALE) for g in allowed)
        box_times.append((value,box['id']))
    critical_t,critical_box = max(box_times)
    c_units = max(minima['C_eight_microseconds']//8,critical_t)
    mixed_empty = [[min(min(empty_graph[g][i][j],empty_graph[g][j][i]) for g in models) for j in range(size)] for i in range(size)]
    mixed_vertical = [[min(min(vertical_graph[g][i][j],vertical_graph[g][j][i]) for g in models) for j in range(size)] for i in range(size)]
    mst_empty,tree_empty = mst(mixed_empty); mst_vertical,tree_vertical = mst(mixed_vertical)
    empty_lb = max(mst_empty,minima['empty_nano_kwh'])
    vertical_lb = max(mst_vertical,minima['vertical_nano_kwh'])
    # Since q<=Q and L(q)<=L0, Euse/L(q)>=q*Euse/(Q*L0).
    # Sum(q*d) counts each box's own carried path ONCE and is at least its
    # depot-to-destination shortest distance times its mass. Empty return adds 0.
    flow_coef = min(frac(m['Euse'])/(frac(m['Q'])*frac(m['L0'])) for m in models.values())
    mass_distance = sum(frac(b['weight'])*F(shortest_d[0][index[b['service']]],DISTANCE_SCALE) for b in boxes)
    horizontal_flow = floor_scaled(flow_coef*mass_distance,ENERGY_SCALE)
    eta_max = max(frac(m['eta']) for m in models.values())
    payload_height = sum(frac(b['weight'])*max(F(0),frac(data['nodes'][b['service']]['z'])+30-frac(data['nodes']['O01']['z'])) for b in boxes)
    payload_lift = floor_scaled(F(981,100)*payload_height/(eta_max*3600000),ENERGY_SCALE)
    # Both terms inside max bound the SAME empty/horizontal components. Do not
    # add them. Payload lift is a disjoint term of the original energy formula.
    energy_units = max(empty_lb,horizontal_flow+vertical_lb)+payload_lift
    values = {'C_seconds':lower_value(c_units,TIME_SCALE),
              'E_kwh':lower_value(energy_units,ENERGY_SCALE),'N_transport':minima['N']}
    derivation = {
        'all_bounds': 'Original common physical model on frozen original straight-leg geometry; all routes and continuous schedules remain admissible. No route-pool, time-grid, deadline, battery, SOC, communication or site restriction is used to remove feasible solutions. Ignoring these constraints can only decrease minimization optima.',
        'count': 'Each box is delivered once, each nonempty transport sortie leaves O01 and returns. 0<=n_A+n_B+n_C<=80; total payload/volume/optimistic box capacity must cover 758kg/2011L/80 boxes. Exhaustive aggregate-count enumeration is a superset of original feasible schedules. N>=minimum count.',
        'time': 'Every route through service s costs at least shortest_t[O,s]+shortest_t[s,O]. Per-type route time >= prep+minimum such cycle+one base handover. Total occupied aircraft time additionally includes exactly 80 minimum(load+box_handover) terms and only the additional required visit bases. Sum occupied time<=8*C; each type also satisfies occupied time<=M_g*C. Minimize the maximum necessary workload bounds over all aggregate counts. Separately C must cover the cheapest allowed-type cycle for each individual box. Take max, never add overlapping workload bounds.',
        'energy': 'E = horizontal + empty-aircraft lift + payload lift. Horizontal >= empty horizontal and also >= min_g(Euse/(Q*L0))*sum_b(weight_b*shortest_horizontal_distance(O,s_b)). Union of routes is connected, so minimum spanning trees with the smallest empty or vertical-only edge cost across types/directions are lower bounds; independent count/cycle bounds strengthen these via max. Payload cumulative climb before delivery >= max(z_service+30-z_O,0), hence its separate m*g*h/eta lower bound. Final E_LB=max(empty_total_LB,horizontal_flow_LB+empty_vertical_LB)+payload_lift_LB. The box-flow and empty-horizontal bounds overlap and are NOT added.',
        'q3': 'Deleting all communication, relay positioning and relay resource constraints leaves a Q2 transport schedule. Joint C>=transport C; total E>=transport E because relay energy is nonnegative; Q3 transport sortie count equals that transport schedule count. Thus the same three numbers are valid Q3 lower bounds. This is not a claim that the best available feasible Q2 value is a Q3 lower bound.',
        'arithmetic': 'Fraction arithmetic treats serialized decimal geometry/parameters as the frozen model values. Every edge is rounded DOWN to integer microseconds/nano-kWh/micrometers before shortest-path/MST/count calculations; shortest paths permit arbitrary intermediate nodes and hence are optimistic. Aggregate bounds are rounded down; published floats use nextafter toward minus infinity. No conservative scheduling-grid bound is repurposed.',
    }
    components = {'aggregate_counts_checked':count,'witnesses':witnesses,'required_visits_lower_bound':visits,
                  'optimistic_boxes_per_sortie':boxmax,'minimum_flight_cycle_microseconds':cycle_t,
                  'minimum_empty_cycle_nano_kwh':cycle_e,'minimum_vertical_cycle_nano_kwh':cycle_v,
                  'aggregate_C_eight_microseconds':minima['C_eight_microseconds'],
                  'single_box_C_microseconds':critical_t,'critical_box':critical_box,
                  'empty_mst_nano_kwh':mst_empty,'empty_count_nano_kwh':minima['empty_nano_kwh'],
                  'vertical_mst_nano_kwh':mst_vertical,'vertical_count_nano_kwh':minima['vertical_nano_kwh'],
                  'horizontal_flow_nano_kwh':horizontal_flow,'payload_lift_nano_kwh':payload_lift,
                  'mass_distance_kg_m':str(mass_distance),'payload_height_kg_m':str(payload_height),
                  'flow_coefficient_kwh_per_kg_m':str(flow_coef),
                  'empty_spanning_tree':[(names[a],names[b],v) for a,b,v in tree_empty],
                  'vertical_spanning_tree':[(names[a],names[b],v) for a,b,v in tree_vertical]}
    checks = smoke(data,values,time_graph,empty_graph)
    assert {name:sha(HERE/name) for name in PINNED} == source_hashes
    assert {name:sha(HERE/name) for name in PINNED_Q3} == q3_hashes
    bounds = []
    for question in ('Q2','Q3'):
        for objective in ('C_seconds','E_kwh','N_transport'):
            key = {'C_seconds':'time','E_kwh':'energy','N_transport':'count'}[objective]
            bounds.append({'id':question+'_'+objective+'_original_relaxation','question':question,'objective':objective,
                           'unit':{'C_seconds':'s','E_kwh':'kWh','N_transport':'sorties'}[objective],
                           'sense':'min','value':values[objective],'scope':'original_problem','validity':'verified','caps':{},
                           'input_signature':signature,'derivation':derivation[key]+(' '+derivation['q3'] if question=='Q3' else ''),
                           'domain':'All original admissible transport routes and continuous schedules; frozen common geometry/formulas; Q3 ignores communication and relay nonnegative costs.'})
    return {'schema_version':1,'status':'PASS_VALID_ORIGINAL_RELAXATION',
            'created_utc':datetime.now(timezone.utc).isoformat(),'input_signature':signature,'source_hashes':source_hashes,
            'additional_source_hashes':q3_hashes,
            'rational_certificate':{'C_seconds':{'numerator':c_units,'denominator':TIME_SCALE},
                                    'E_kwh':{'numerator':energy_units,'denominator':ENERGY_SCALE},
                                    'N_transport':{'numerator':minima['N'],'denominator':1}},
            'script_sha256':sha(Path(__file__)),'python':sys.version,'elapsed_s':time.perf_counter()-started,
            'bounds':bounds,'derivation':derivation,'components':components,'original_problem_evidence':original,
            'selfcheck':checks,'inputs_unchanged':True,'optimization_started':False,'candidate_pool_read':False,
            'target_problem_only':{'Q2':{'D_station':0,'N_transport_max':23,'E_kwh_max':66.99999,'C_seconds_target_below':5700},
                                   'note':'Targets label a separate epsilon-constrained search. None is used to inflate the unconditional bounds above; they do not assert target feasibility.'},
            'limitations':['These deliberately relaxed bounds may leave large gaps; no near-optimality claim follows.',
                           'Validity is for the frozen original common physical model/geometry, not unknown alternate interpretations or an independently exact earth geometry.',
                           'No positive relay-only lower bound or full multiobjective Pareto certificate is claimed.']}


def smoke(data, values, time_graph, empty_graph):
    sys.path.insert(0,str(HERE/'src/q2'))
    from routes import Physics
    physics = Physics()
    assert physics.rho == .2 and physics.es == physics.fs == physics.hs == 1
    tested = 0; names = sorted(data['nodes'])
    for g in physics.models:
        for i,a in enumerate(names):
            for j,b in enumerate(names):
                if i==j: continue
                flight,distance,up = physics.legs[g,a,b]; m=physics.models[g]
                empty = m['Euse']*distance/m['L0']+m['m0']*9.81*up/(m['eta']*3600000)
                assert time_graph[g][i][j]/TIME_SCALE <= flight+1e-9
                assert empty_graph[g][i][j]/ENERGY_SCALE <= empty+1e-12
                tested += 1
    schedules = []
    for path in sorted((HERE/'seeds').glob('q2*/elites/*/solution.json')):
        rows=read(path); c=max(r['return'] for r in rows); e=sum(r['route']['energy'] for r in rows); n=len(rows)
        assert values['C_seconds'] <= c+1e-6 and values['E_kwh'] <= e+1e-9 and values['N_transport'] <= n
        ids=[b for r in rows for _,bs in r['route']['stops'] for b in bs]
        assert len(ids)==len(set(ids))==80
        schedules.append({'path':path.relative_to(HERE).as_posix(),'sha256':sha(path),'C':c,'E':e,'N':n})
    assert schedules, 'At least one frozen complete Q2 schedule is required for the contradiction smoke.'
    return {'status':'PASS','physics_edges_checked':tested,'frozen_schedule_checks':schedules,
            'proof_note':'Smoke detects contradictions and implementation mistakes. Validity derives from the relaxation arguments, not from testing finitely many feasible schedules.',
            'new_physical_optimization':False}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',default='original_bounds.json')
    args=parser.parse_args()
    output=(HERE/args.output).resolve()
    result=derive(); dump(output,result)
    print(json.dumps({'status':result['status'],'elapsed_s':result['elapsed_s'],
                      'bounds':[(r['question'],r['objective'],r['value']) for r in result['bounds']],
                      'output':str(output)},ensure_ascii=False))


if __name__=='__main__':
    main()
