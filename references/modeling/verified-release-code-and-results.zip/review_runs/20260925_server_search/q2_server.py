"""Portable, isolated Q2 portfolio worker; no publication writes or fixed date.

The copied Portfolio/Physics/independent validator remain authoritative. This
adapter adds configurable budgets, immutable-seed and peer replay, atomic gzip
route snapshots, and compact evidence copies. Decomposition is not imported.
"""
from pathlib import Path
import argparse
import collections
import gzip
import hashlib
import json
import os
import re
import shutil
import sys
import threading
import time
import traceback

sys.dont_write_bytecode = True
from q2_search import HERE, PROJECT, Search, dump, read, now, objective
from q2_portfolio_candidate import Portfolio


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()


def atomic_text(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + f'.{os.getpid()}.{threading.get_ident()}.tmp')
    temp.write_text(value, encoding='utf-8')
    os.replace(temp, path)


class ServerPortfolio(Portfolio):
    def __init__(self, args):
        target = (HERE / args.output).resolve()
        if not target.is_relative_to((HERE / 'runs').resolve()) or target == (HERE / 'runs').resolve():
            raise ValueError('Worker output must be a child of HERE/runs')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.mkdir(exist_ok=False)  # Exclusive ownership; resume uses a NEW output.
        args.resume_root = None
        args.deadline_local = None
        args.control_seconds = 0.
        super().__init__(args)
        self.signature_sources = ['inputs/normalized_inputs.json', 'inputs/terrain_evidence_all.json',
                                  'src/q2/routes.py', 'src/q2/validate.py']
        self.source_hashes = {p: sha_file(HERE / p) for p in self.signature_sources}
        self.input_signature = hashlib.sha256(json.dumps(self.source_hashes, sort_keys=True).encode()).hexdigest()
        self.engine_solve = self.solve
        self.solve = self.configured_solve
        self.save_pool = self.compact_pool_save
        self.seen_solutions = set()
        self.seen_pools = {}
        self.sync_records = []
        self.last_sync = 0.
        self.phase = 'created'
        self.effective_caps = None
        self.done = threading.Event()
        self.worker_id = target.name
        self.shared_roots = [(HERE / p).resolve() for p in args.resume]
        for p in self.shared_roots:
            if not p.is_relative_to(HERE.resolve()) or p == self.out:
                raise ValueError('Resume sources must be separate directories inside HERE')
        self.heartbeat = threading.Thread(target=self.heartbeat_loop, daemon=True)

    def aspiration(self, m):
        a = self.args
        return max(0., m['C'] - a.target_c) / 60 + max(0., m['E'] - a.target_e) * 2 + max(0, m['N'] - a.target_n) * 1.5 + m['C'] / 60000

    def expired(self, reserve=0):
        return super().expired(reserve) or (self.out / 'STOP').exists()

    def own_path(self, path):
        path = Path(path).resolve()
        if not path.is_relative_to(self.out) or path == self.out:
            raise ValueError('Refusing to mutate a path outside this worker output')
        return path

    def compact_pool_save(self, pool, path):
        """One atomically replaced, verified gzip; no repeated cumulative copies."""
        path = self.own_path(path)
        target = path if path.suffix == '.gz' else path.with_name(path.name + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(target.name + f'.{os.getpid()}.tmp')
        raw_hash = hashlib.sha256()
        with gzip.open(temp, 'wb', compresslevel=3) as stream:
            for route in pool.values():
                line = (json.dumps(route, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
                stream.write(line); raw_hash.update(line)
        check_hash = hashlib.sha256()
        with gzip.open(temp, 'rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''): check_hash.update(chunk)
        if check_hash.digest() != raw_hash.digest(): raise IOError('gzip route snapshot verification failed')
        os.replace(temp, target)
        dump(target.with_name(target.name + '.meta.json'), dict(schema=1, kind='q2_route_pool',
             input_signature=self.input_signature, worker=self.worker_id, routes=len(pool),
             sha256=sha_file(target), uncompressed_sha256=raw_hash.hexdigest(), updated_at=now()))
        if path != target and path.exists(): path.unlink()  # own_path checked above; verified replacement exists.

    def compress_large_evidence(self, folder):
        """Keep accepted solutions/reviews/metrics in plain JSON for consumers."""
        folder = self.own_path(folder)
        if not folder.exists(): return
        protected = {'solution.json', 'candidate_review.json', 'solution_summary.json',
                     'metrics.json', 'parameters.json', 'station_delivery_validation.json'}
        for path in folder.rglob('*.json'):
            if path.name in protected or path.name.endswith('.meta.json') or path.stat().st_size < 128 * 1024: continue
            path = self.own_path(path)
            dest = path.with_name(path.name + '.gz')
            temp = dest.with_name(dest.name + f'.{os.getpid()}.tmp')
            digest = sha_file(path)
            with path.open('rb') as source, gzip.open(temp, 'wb', compresslevel=3) as sink:
                shutil.copyfileobj(source, sink)
            h = hashlib.sha256()
            with gzip.open(temp, 'rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''): h.update(chunk)
            if h.hexdigest() != digest: raise IOError('gzip evidence verification failed')
            os.replace(temp, dest)
            path.unlink()

    def copy_record(self, record, target):
        target = self.own_path(target)
        target.mkdir(parents=True, exist_ok=True)
        # Heavy route pools and checkpoints remain once in their round archive.
        for path in Path(record['directory']).iterdir():
            if not path.is_file() or path.name.startswith(('candidate_pool.', 'solver_stage_checkpoint.')): continue
            if path.suffix == '.tmp': continue
            shutil.copy2(path, target / path.name)
        dump(target / 'archive_source.json', dict(path=Path(record['directory']).relative_to(HERE).as_posix(),
             id=record['id'], input_signature=self.input_signature, verified_copy=True))

    def update_elites(self, record, baseline=False):
        if record is None: return False
        improved = self.best is None or objective(record['metrics']) < objective(self.best['metrics'])
        if improved: self.best = record; self.since_improvement = 0
        else: self.since_improvement += 1
        self.archive.setdefault(record['id'], record)
        representatives = {}
        for candidate in self.archive.values():
            key = self.structure(candidate['rows'])
            if key not in representatives or objective(candidate['metrics']) < objective(representatives[key]['metrics']):
                representatives[key] = candidate
        records = list(representatives.values())
        self.best = representatives[self.structure(self.best['rows'])]
        front = [r for r in records if not any(
            all(b['metrics'][k] <= r['metrics'][k] + (1e-7 if k != 'N' else 0) for k in ('C', 'E', 'N')) and
            any(b['metrics'][k] < r['metrics'][k] - (1e-7 if k != 'N' else 0) for k in ('C', 'E', 'N'))
            for b in records if b is not r)]
        ordered = sorted(front, key=lambda r: self.aspiration(r['metrics']))
        ordered += sorted(records, key=lambda r: objective(r['metrics']))[:3]
        ordered += sorted(records, key=lambda r: (r['metrics']['E'], r['metrics']['C']))[:2]
        chosen = []; seen = set()
        for r in ordered:
            key = self.structure(r['rows'])
            if key in seen: continue
            seen.add(key); chosen.append(r)
            if len(chosen) >= 12: break
        if self.best not in chosen: chosen.insert(0, self.best)
        self.elites = chosen
        index = []
        for r in chosen:
            target = self.out / 'elites' / r['id']
            if not (target / 'candidate_review.json').exists(): self.copy_record(r, target)
            index.append(dict(id=r['id'], path=target.relative_to(HERE).as_posix(), metrics=r['metrics'],
                structure_signature=hashlib.sha256(repr(self.structure(r['rows'])).encode()).hexdigest()[:16],
                structure_signature_kind='physical_profile_with_deadline_and_priority',
                route_ids=sorted(v['route']['id'] for v in r['rows'])))
        assert len({r['structure_signature'] for r in index}) == len(index)
        dump(self.out / 'elites/index.json', dict(schema=1, input_signature=self.input_signature,
             worker=self.worker_id, updated_at=now(), elites=index, best_id=self.best['id'],
             automatic_promotion=False, full_verified_archive_records=len(self.archive),
             distinct_physical_archive_structures=len(representatives)))
        if improved or baseline:
            # Best is a pointer plus lean copy; never a second complete route pool.
            self.copy_record(self.best, self.out / 'best')
            dump(self.out / 'best.json', dict(id=self.best['id'], metrics=self.best['metrics'],
                 path=(self.out / 'best').relative_to(HERE).as_posix(), updated_at=now()))
        for value in record['rows']: self.pool[value['route']['id']] = value['route']
        return improved

    def resolve_elite(self, root, entry):
        # Frozen indices retain old q2/... paths; prefer their local copied elite.
        candidates = [root / 'elites' / entry['id'], HERE / entry.get('path', '')]
        for p in candidates:
            p = p.resolve()
            if p.is_relative_to(HERE.resolve()) and (p / 'solution.json').exists(): return p
        return None

    def stable_pool_read(self, path, require_signature=False):
        path = Path(path)
        try:
            stat = path.stat(); stamp = (stat.st_size, stat.st_mtime_ns)
            if self.seen_pools.get(str(path)) == stamp: return 0
            meta_path = path.with_name(path.name + '.meta.json')
            meta = read(meta_path) if meta_path.exists() else {}
            if require_signature and meta.get('input_signature') != self.input_signature: return 0
            digest = sha_file(path)
            if meta.get('sha256') and meta['sha256'] != digest: return 0
            reader = gzip.open if path.suffix == '.gz' else open
            with reader(path, 'rt', encoding='utf-8-sig') as stream:
                values = [json.loads(line) for line in stream if line.strip()]
            stat2 = path.stat()
            if (stat2.st_size, stat2.st_mtime_ns) != stamp: return 0
            count = 0
            for r in values:
                if r['id'] in self.pool: continue
                # Cached physics never becomes authoritative across machines.
                rebuilt = self.P.evaluate(r['model'], r['stops'])
                if rebuilt is not None and rebuilt['id'] == r['id'] and self.latest(rebuilt) >= -1e-7:
                    self.pool[rebuilt['id']] = rebuilt; count += 1
            self.seen_pools[str(path)] = stamp
            self.sync_records.append(dict(kind='pool', path=path.relative_to(HERE).as_posix(),
                 sha256=digest, supplied_routes=len(values), added_routes=count, at=now()))
            return count
        except (OSError, ValueError, KeyError, EOFError): return 0

    def sync_root(self, root, peer=False):
        if root == self.out or not root.exists(): return
        index_path = root / 'elites/index.json'
        try:
            index = read(index_path)
            if peer and index.get('input_signature') != self.input_signature: return
            for entry in index['elites']:
                if self.expired(3): break
                folder = self.resolve_elite(root, entry)
                if folder is None: continue
                review = read(folder / 'candidate_review.json')
                if not review.get('accepted'): continue
                solution = folder / 'solution.json'; content = solution.read_bytes()
                digest = hashlib.sha256(content).hexdigest()
                expected_digest = review.get('solution_sha256')
                # New peer outputs must bind validation to the exact payload.
                # Historical seeds are also checked whenever a hash is present.
                if (peer and not expected_digest) or (expected_digest and expected_digest != digest): continue
                if digest in self.seen_solutions: continue
                rows = json.loads(content.decode('utf-8-sig'))
                # Stable index publication occurs only after complete evidence.
                if sha_file(solution) != digest: continue
                for v in rows:
                    r = self.P.evaluate(v['route']['model'], v['route']['stops'])
                    if r is None: raise ValueError('Shared route failed physical replay')
                    v['route'] = r
                result = self.validate(rows, self.out / 'imports' / digest[:20],
                                       'independently replayed ' + solution.relative_to(HERE).as_posix())
                self.seen_solutions.add(digest)
                if result: self.update_elites(result)
                self.sync_records.append(dict(kind='elite', path=solution.relative_to(HERE).as_posix(),
                     sha256=digest, accepted=result is not None, at=now()))
        except (OSError, ValueError, KeyError) as exc:
            self.sync_records.append(dict(kind='index_unavailable', path=root.relative_to(HERE).as_posix(), detail=str(exc), at=now()))
        if not self.args.skip_resume_pools:
            paths = [root / 'cumulative_pool.jsonl.gz', root / 'cumulative_pool.jsonl']
            for path in paths:
                if path.exists(): self.stable_pool_read(path, require_signature=peer); break

    def sync_all(self, initial=False):
        if not initial and time.monotonic() - self.last_sync < self.args.share_seconds: return
        for root in self.shared_roots: self.sync_root(root)
        if self.args.share_peers:
            for root in sorted((HERE / 'runs').glob('q2_*')):
                if not self.expired(3): self.sync_root(root, peer=True)
        if initial and not self.args.skip_resume_pools:
            # Optional parent-produced merged immutable snapshot in seeds/.
            for path in sorted((HERE / 'seeds').glob('*.jsonl*')):
                if path.name.endswith(('.jsonl', '.jsonl.gz')): self.stable_pool_read(path)
        self.last_sync = time.monotonic()
        dump(self.out / 'sharing_log.json', dict(input_signature=self.input_signature, records=self.sync_records))

    def initialize_baselines(self):
        # Deliberately bypass Portfolio's single legacy resume and absolute date.
        Search.initialize_baselines(self)
        self.sync_all(initial=True)
        self.current = self.best
        contract = read(self.out / 'input_contract.json')
        contract.update(algorithm='verified Portfolio adapter; no decomposition', worker=self.worker_id,
            input_signature=self.input_signature, physical_source_hashes=self.source_hashes,
            server_config=vars(self.args), relative_layout=True, absolute_calendar_deadline=None,
            resume_sources=[p.relative_to(HERE).as_posix() for p in self.shared_roots],
            adapter_sources={p: sha_file(HERE / p) for p in ('q2_server.py', 'q2_portfolio_candidate.py', 'q2_master_candidate.py')},
            compact_storage='atomic cumulative_pool.jsonl.gz; no duplicated elite route pools',
            sharing='read-only peer snapshots; independent physics and station-end replay before adoption')
        dump(self.out / 'input_contract.json', contract)
        self.since_improvement = max(4, self.since_improvement)
        self.pulse('resume_verified', imported_solutions=len(self.seen_solutions))

    def generate(self, group, seconds):
        return super().generate(group, self.args.generation_seconds)

    def trim(self, candidates, mandatory, limit, fresh=None):
        limits = {6500: self.args.global_pool, 2200: self.args.large_pool,
                  1600: self.args.local_pool, 900: self.args.local_pool}
        return super().trim(candidates, mandatory, limits.get(limit, limit), fresh)

    def configured_solve(self, *positional, **kwargs):
        folder = Path(kwargs['evidence_path']).parent
        mode = folder.name.split('_', 1)[1]
        full = mode in ('global', 'target')
        seconds = self.args.target_seconds if mode == 'target' else self.args.global_seconds if full else self.args.stage_seconds
        kwargs['seconds'] = seconds
        kwargs['stage_seconds'] = {s: self.args.polish_seconds if s == 'E' and full else seconds for s in kwargs['objectives']}
        if mode == 'target':
            kwargs.update(max_C=self.args.target_c, max_E=self.args.target_e, max_N=self.args.target_n)
        self.effective_caps = {'C': kwargs['max_C'], 'E': kwargs['max_E'], 'N': kwargs['max_N']}
        params = read(folder / 'parameters.json')
        params.update(stage_seconds=kwargs['stage_seconds'], max_C=kwargs['max_C'], max_E=kwargs['max_E'],
                      max_N=kwargs['max_N'], pool_file='candidate_pool.jsonl.gz', adapter='q2_server.py')
        dump(folder / 'parameters.json', params)
        return self.engine_solve(*positional, **kwargs)

    def validate(self, rows, folder, source, solver=None, caps=None):
        if solver is not None and self.effective_caps is not None: caps = self.effective_caps
        result = super().validate(rows, folder, source, solver, caps)
        folder = self.own_path(folder)
        review = read(folder / 'candidate_review.json')
        review['solution_sha256'] = sha_file(folder / 'solution.json')
        dump(folder / 'candidate_review.json', review)
        return result

    def round_search(self):
        self.sync_all()
        super().round_search()
        folder = self.out / 'rounds' / f'r{self.round:04d}_{self.history[-1]["mode"]}'
        self.compress_large_evidence(folder)
        # Lean copied evidence is small; accepted payloads are never compressed.
        self.compress_large_evidence(self.out / 'best')
        self.compress_large_evidence(self.out / 'elites')

    def pulse(self, phase, **other):
        self.phase = phase
        super().pulse(phase, **other)

    def heartbeat_loop(self):
        while not self.done.is_set():
            m = None if self.best is None else dict(self.best['metrics'])
            snapshot = dict(updated_at=now(), pid=os.getpid(), worker=self.worker_id, phase=self.phase,
                 elapsed_s=time.perf_counter()-self.started, remaining_s=max(0,self.deadline-time.perf_counter()),
                 round=self.round, pool_size=len(self.pool), verified_candidates=self.validation_count, best=m)
            atomic_text(self.out / 'heartbeat.json', json.dumps(snapshot, ensure_ascii=False, indent=2))
            metrics = '尚未完成基线重放。' if m is None else f'已独立验证最佳 C={m["C"]:.6f} s（{m["C"]/60:.6f} min），E={m["E"]:.9f} kWh，N={m["N"]}；整站延期 D={m["D_station"]:.6g}。'
            atomic_text(self.out / '实时进展.md', f'# Q2 {self.worker_id}\n\n更新时间：{snapshot["updated_at"]}\n\n状态：{self.phase}；轮次：{self.round}；路线数：{len(self.pool)}。\n\n{metrics}\n\n真实物理约束、80 箱与31 个硬截止均由原校验器和整站完成校验重放；有限邻域搜索，无全局最优证明。正式论文与发布结果未修改。\n')
            self.done.wait(10)

    def run(self):
        self.heartbeat.start()
        try: return super().run()
        finally:
            self.phase = 'finished'
            self.done.set(); self.heartbeat.join(timeout=2)
            if (self.out / 'run_summary.json').exists():
                summary = read(self.out / 'run_summary.json')
                atomic_text(self.out / '实时进展.md', '# Q2 搜索结束\n\n' + json.dumps(summary, ensure_ascii=False, indent=2) + '\n\n无全局最优证明；正式发布未改变。\n')


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', help='Optional JSON keys matching CLI destinations')
    p.add_argument('--worker-id', default='00')
    p.add_argument('--output', help='Fresh output below HERE/runs; default runs/q2_<worker-id>')
    p.add_argument('--seconds', type=float, default=14400.)
    p.add_argument('--workers', type=int, default=8)
    p.add_argument('--seed', type=int, default=2026092500)
    p.add_argument('--resume', action='append', default=None, help='Repeat for read-only source directories relative to HERE')
    p.add_argument('--local-pool', type=int, default=1800)
    p.add_argument('--large-pool', type=int, default=2800)
    p.add_argument('--global-pool', type=int, default=9000)
    p.add_argument('--generation-seconds', type=float, default=10.)
    p.add_argument('--stage-seconds', type=float, default=80.)
    p.add_argument('--global-seconds', type=float, default=180.)
    p.add_argument('--polish-seconds', type=float, default=180.)
    p.add_argument('--target-seconds', type=float, default=240.)
    p.add_argument('--target-c', type=float, default=5699.9)
    p.add_argument('--target-e', type=float, default=66.99999)
    p.add_argument('--target-n', type=int, default=23)
    p.add_argument('--share-seconds', type=float, default=180.)
    p.add_argument('--share-peers', action=argparse.BooleanOptionalAction, default=True)
    p.add_argument('--skip-resume-pools', action='store_true', help='Startup test only; restores verified elites but not large route snapshots')
    p.add_argument('--smoke', action='store_true')
    known, _ = p.parse_known_args()
    if known.config:
        config = read(Path(known.config))
        allowed = {a.dest for a in p._actions}
        if set(config) - allowed: p.error('Unknown configuration keys: ' + ', '.join(sorted(set(config)-allowed)))
        p.set_defaults(**config)
    args = p.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9_-]+', args.worker_id): p.error('worker-id must be portable ASCII')
    args.output = args.output or ('runs/q2_' + args.worker_id)
    args.resume = args.resume if args.resume is not None else ['seeds/q2', 'seeds/q2_phase2']
    if args.seconds <= 0 or not 1 <= args.workers <= 128: p.error('Invalid runtime/worker count')
    for key in ('generation_seconds', 'stage_seconds', 'global_seconds', 'polish_seconds', 'target_seconds', 'share_seconds', 'local_pool', 'large_pool', 'global_pool', 'target_c', 'target_e', 'target_n'):
        if getattr(args, key) <= 0: p.error(key + ' must be positive')
    return args


if __name__ == '__main__':
    ServerPortfolio(parse_args()).run()
