"""Portable bounded Q3 worker using the frozen physics and continuous verifier.

One process owns one output directory/seed. A server controller can run several
seeds and Q2 workers in parallel. There is no historical calendar deadline here;
each invocation still has an explicit seconds budget and observes HERE/STOP.
"""
from pathlib import Path
import argparse,copy,gzip,hashlib,json,math,os,random,shutil,threading,time,traceback

from q3_search import HERE,PROJECT,BASE,Search,read,write,sha,route_key


def normalized_path(value):
    return Path(str(value).replace('\\','/'))


def resolve_entry(root,item):
    """Resolve both copied historical indexes and new HERE-relative indexes."""
    raw=normalized_path(item.get('path',''))
    options=[HERE/raw,root.parent/raw,root/raw]
    if item.get('id'):options.insert(0,root/'elites'/str(item['id']))
    for path in options:
        path=path.resolve()
        if path.is_relative_to(root.resolve()) and path.is_dir():return path
    return None


class ServerSearch(Search):
    def __init__(self,args):
        self._status_lock=threading.RLock();self._last_phase='initializing';self._last_extra={}
        self._heartbeat_done=threading.Event();self._seen_q2={}
        self.q2_patterns=args.q2_glob or ['seeds/q2*','runs/q2*']
        self.resume_patterns=args.resume_glob or ['seeds/q3*','runs/q3*']
        self.original_stage_seconds=args.stage_seconds
        out=(HERE/normalized_path(args.output)).resolve()
        if not out.is_relative_to((HERE/'runs').resolve()) or out==(HERE/'runs').resolve():
            raise ValueError('Each server Q3 output must be a separate HERE/runs/<worker> directory.')
        if (out/'run_contract.json').exists():
            raise ValueError('Use a fresh output directory; old certified archives are read-only resume inputs.')
        super().__init__(args)
        self.stop_path=HERE/'STOP'
        original=self.joint.solve
        def configured_solve(*positional,**kwargs):
            stages=len(kwargs.get('objectives',('C','E')))
            remaining=self.deadline-time.monotonic()-18
            kwargs['seconds']=min(args.stage_seconds,max(.1,remaining/max(1,stages)))
            kwargs['workers']=args.workers
            kwargs['deadline']=self.deadline-18
            kwargs['stop_path']=self.stop_path
            name=positional[0] if positional else kwargs['name']
            write(self.cases/name/'effective_solver_config.json',dict(
                workers=args.workers,stage_seconds=kwargs['seconds'],seed=kwargs.get('seed'),
                slots=kwargs.get('slots'),seconds_budget=args.seconds,calendar_deadline=None,
                original_physics_preserved=True))
            self.pulse('joint_solver',candidate=name,per_stage_seconds=kwargs['seconds'],workers=args.workers)
            return original(*positional,**kwargs)
        self.joint.solve=configured_solve

    def roots(self,patterns):
        found={}
        for pattern in patterns:
            if Path(pattern).is_absolute() or '..' in normalized_path(pattern).parts:
                raise ValueError('Input globs must remain relative to the server search directory.')
            for root in HERE.glob(pattern.replace('\\','/')):
                if root.is_dir() and root.resolve()!=self.out.resolve():found[str(root.resolve())]=root.resolve()
        return sorted(found.values())

    def import_q2(self):
        roots=self.roots(self.q2_patterns)
        for root in roots:
            folders=set()
            index=root/'elites/index.json'
            if index.exists():
                try:
                    for item in read(index).get('elites',[]):
                        folder=resolve_entry(root,item)
                        if folder is not None:folders.add(folder)
                except (OSError,ValueError,KeyError):pass
            if self.args.include_rounds:
                folders.update(p.parent.resolve() for p in (root/'rounds').glob('*/candidate_review.json'))
            for folder in sorted(folders):
                try:
                    report=read(folder/'candidate_review.json');physical=report.get('validation',{})
                    station=report.get('station_validation',{})
                    if not(report.get('accepted') and physical.get('valid') and
                           physical.get('boxes')==physical.get('unique_boxes')==80 and
                           physical.get('hard_boxes')==31 and physical.get('hard_violations')==0 and
                           station.get('valid') and station.get('hard_boxes')==31 and
                           station.get('hard_violations')==station.get('late_boxes')==0 and
                           abs(station.get('D_station',float('inf')))<1e-6):continue
                    path=folder/'solution.json';payload=path.read_bytes();digest=hashlib.sha256(payload).hexdigest()
                    if self._seen_q2.get(str(path))==digest:continue
                    rows=json.loads(payload.decode('utf-8-sig'))
                    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:continue
                    c=max(r['return'] for r in rows);energy=sum(r['route']['energy'] for r in rows)
                    if c>self.args.q2_horizon or energy>self.args.q2_energy_limit:continue
                    metrics=report['metrics']
                    if abs(c-metrics['C'])>1e-6 or abs(energy-metrics['E'])>1e-8 or len(rows)!=metrics['N']:continue
                    checked=[self.P.evaluate(r['route']['model'],r['route']['stops']) for r in rows]
                    if any(r is None or r['id']!=row['route']['id'] for r,row in zip(checked,rows)):continue
                    boxes=[b for r in checked for b in r['boxes']]
                    if len(boxes)!=80 or set(boxes)!=set(self.P.boxes):continue
                    self._seen_q2[str(path)]=digest;key=route_key(rows)
                    previous=self.q2.get(key)
                    if previous is not None and previous['C']<=c+1e-7:continue
                    self.q2[key]=dict(key=key,rows=rows,C=c,E=energy,N=len(rows),
                                     source=path.relative_to(PROJECT).as_posix(),sha256=digest,
                                     validation='independent_Q2_physical_and_station_certificates',
                                     candidate_review_sha256=sha(folder/'candidate_review.json'))
                    self.route_bank.update({r['id']:r for r in checked})
                except (OSError,ValueError,KeyError,TypeError):continue
        write(self.out/'q2_sources.json',[{k:v for k,v in r.items() if k!='rows'} for r in self.q2.values()])

    def pulse(self,phase,**extra):
        with self._status_lock:
            if not extra.pop('_heartbeat',False):
                self._last_phase=phase;self._last_extra=copy.deepcopy(extra)
            super().pulse(phase,**extra)
            ranked=sorted(list(self.archive),key=lambda r:(r['metrics']['C'],r['metrics']['E']))
            text=['# Q3 服务器搜索实时记录','',f'- 更新时间：{time.strftime("%Y-%m-%d %H:%M:%S %z")}',
                  f'- 阶段：{phase}',f'- 种子：{self.args.seed}；线程：{self.args.workers}',
                  f'- 本批已用：{time.monotonic()-self.started:.1f} 秒；预算：{self.args.seconds:.1f} 秒',
                  f'- 已独立认证候选：{len(self.archive)}；可用 Q2 结构：{len(self.q2)}；中继候选点：{len(self.sites)}',
                  '- 指标仅列独立物理、整站交付与连续通信复放通过的候选；未写入正式发布。','',
                  '| 候选 | 联合返航 / s | 总能耗 / kWh | 运输＋中继 |',
                  '|---|---:|---:|---:|']
            for item in ranked[:8]:
                m=item['metrics'];text.append(f"| {item['id']} | {m['C']:.6f} | {m['E']:.9f} | {m['N_transport']}＋{m['N_relay']} |")
            text+=['','所有候选保持 80 箱整站零延期、31 个硬截止及原有物理/资源约束。',
                   '截图阈值仅作搜索目标；不声称全局最优。']
            tmp=self.out/'progress.md.tmp';tmp.write_text('\n'.join(text)+'\n',encoding='utf-8');os.replace(tmp,self.out/'progress.md')

    def heartbeat(self):
        while not self._heartbeat_done.wait(30):
            try:self.pulse(self._last_phase,_heartbeat=True,**copy.deepcopy(self._last_extra))
            except Exception as exc:
                write(self.out/'heartbeat_error.json',dict(error=str(exc),time=time.time()))

    def new_sites(self,warm,round_number):
        if self.args.new_sites<=0 or len(self.sites)>=self.args.site_limit:return
        from setup_q3 import INVERSE
        from sites import relay_metrics
        anchors=[r['site'] for r in warm['relay']]+self.rng.sample(self.base_sites,min(3,len(self.base_sites)))
        self.rng.shuffle(anchors);radius=self.args.site_radii[round_number%len(self.args.site_radii)];added=0
        for anchor in anchors:
            angle=self.rng.randrange(8)*math.pi/4
            for height in [anchor['agl'],self.rng.choice([150.,200.,250.,280.,300.])]:
                if self.stopped(35) or added>=self.args.new_sites or len(self.sites)>=self.args.site_limit:break
                lon,lat=INVERSE.transform(anchor['x']+radius*math.cos(angle),anchor['y']+radius*math.sin(angle))
                token=(round(lon,10),round(lat,10),round(height,4))
                if token in self.site_seen:continue
                self.site_seen.add(token);m=relay_metrics(self.data,lon,lat,height)
                record=dict(parent=anchor['id'],radius=radius,lon=lon,lat=lat,agl=height,accepted=False)
                if m is None or m['max_service']<=0:record['reason']='outside_DEM_or_energy'
                else:
                    back=self.radio.point(self.data['gateway'],[m['x'],m['y'],m['z']],'backhaul')
                    if back['valid']:
                        sid='SV_'+hashlib.sha256(json.dumps(token).encode()).hexdigest()[:12]
                        m.update(id=sid,cover=[],parent_site=anchor['id']);self.sites.append(m);self.site_ids.add(sid);added+=1
                        record.update(accepted=True,id=sid,backhaul_margin=back['margin'])
                    else:record.update(reason='backhaul',backhaul_margin=back['margin'])
                self.geometry_attempts.append(record)
            if added>=self.args.new_sites or len(self.sites)>=self.args.site_limit:break
        write(self.out/'site_search.json',dict(attempts=self.geometry_attempts,sites=self.sites))

    def ensure_atoms(self,pool,prep_seconds=80):
        return super().ensure_atoms(pool,prep_seconds=self.args.geometry_seconds)

    def resume_options(self):
        found={}
        for root in self.roots(self.resume_patterns):
            index=root/'elites/index.json'
            if not index.exists():continue
            try:
                for item in read(index).get('elites',[]):
                    folder=resolve_entry(root,item)
                    if folder is None:continue
                    report=read(folder/'candidate_review.json')
                    if not report.get('accepted'):continue
                    digest=sha(folder/'solution_q3.json')
                    if report.get('solution_sha256')!=digest:continue
                    found[digest]=dict(path=folder,sha256=digest,metrics=report['metrics'])
            except (OSError,ValueError,KeyError):continue
        values=sorted(found.values(),key=lambda r:(r['metrics']['C'],r['metrics']['E']))
        # Keep different transport structures plus both time and energy endpoints.
        seeds=[];seen=set()
        if values:
            values=[values[0],min(values,key=lambda r:(r['metrics']['E'],r['metrics']['C']))]+values
        for item in values:
            if item['sha256'] in seen:continue
            seen.add(item['sha256']);seeds.append(item)
            if len(seeds)>=self.args.resume_limit:break
        return seeds

    def replay_seed(self,item,label):
        saved=read(item['path']/'solution_q3.json')
        for row in saved['relay']:
            site=row['site']
            if site['id'] not in self.site_ids:
                self.sites.append(site);self.site_ids.add(site['id'])
                self.site_seen.add((round(site['lon'],10),round(site['lat'],10),round(site['agl'],4)))
        folder=self.cases/label;folder.mkdir(parents=True,exist_ok=True)
        write(folder/'solution_q3.json',saved)
        report=self.accept(folder,dict(type='server_independent_resume_replay',
                                      path=item['path'].relative_to(PROJECT).as_posix(),sha256=item['sha256']))
        if not report['accepted']:raise RuntimeError('Historical seed failed independent server replay: '+str(item['path']))
        return report

    def compact_own_geometry(self):
        """Compress reproducibility details after use; executable solutions stay plain."""
        if not self.args.compress_geometry:return
        names=('candidate_pool.json','coverage_atoms.json','activation_evidence.json')
        for parent in (self.out/'cases',self.out/'elites'):
            for folder in parent.iterdir() if parent.exists() else []:
                if not folder.is_dir():continue
                manifest=folder/'compressed_geometry.json'
                previous=read(manifest) if manifest.exists() else []
                for name in names:
                    source=folder/name
                    if not source.exists() or source.stat().st_size<131072:continue
                    assert source.resolve().is_relative_to(self.out.resolve())
                    digest=sha(source);before=source.stat().st_size
                    destination=source.with_suffix(source.suffix+'.gz')
                    temporary=destination.with_suffix(destination.suffix+'.tmp')
                    with source.open('rb') as inp,gzip.open(temporary,'wb',compresslevel=5) as out:
                        shutil.copyfileobj(inp,out)
                    check=hashlib.sha256()
                    with gzip.open(temporary,'rb') as inp:
                        for chunk in iter(lambda:inp.read(1024*1024),b''):check.update(chunk)
                    if check.hexdigest()!=digest:raise RuntimeError('Geometry gzip checksum mismatch')
                    os.replace(temporary,destination);source.unlink()
                    previous.append(dict(original_name=name,gzip_name=destination.name,sha256_uncompressed=digest,
                                         original_bytes=before,gzip_bytes=destination.stat().st_size))
                if previous:write(manifest,previous)

    def run_server(self):
        source_files=[Path(__file__),HERE/'q3_search.py']+list((HERE/'src/q3').glob('*.py'))
        write(self.out/'run_contract.json',dict(started_at=time.time(),seconds=self.args.seconds,workers=self.args.workers,
              seed=self.args.seed,stage_seconds=self.args.stage_seconds,geometry_seconds=self.args.geometry_seconds,
              site_limit=self.args.site_limit,new_sites_per_expansion=self.args.new_sites,site_radii_m=self.args.site_radii,
              q2_globs=self.q2_patterns,resume_globs=self.resume_patterns,calendar_deadline=None,
              stop_file=str(self.stop_path),source_sha256={p.relative_to(HERE).as_posix():sha(p) for p in source_files},
              inputs_sha256={p.name:sha(p) for p in (HERE/'inputs').glob('*.json')},resources=[2,6],
              delivery='whole-stop handover completion',zero_station_lateness=True,
              original_physics_and_independent_continuous_certification=True,promotion_allowed=False,smoke=self.args.smoke))
        heartbeat=threading.Thread(target=self.heartbeat,daemon=True);heartbeat.start()
        try:
            options=self.resume_options()
            if self.args.smoke:
                item=options[0] if options else dict(path=BASE,sha256=sha(BASE/'solution_q3.json'))
                report=self.replay_seed(item,'resume_smoke')
                result=dict(status='PASS_SERVER_PORTABLE_REPLAY',elapsed_s=time.monotonic()-self.started,
                            metrics=report['metrics'],certified_open_intervals=report['validation']['certified_open_intervals'],
                            certified_event_points=report['validation']['certified_event_points'],
                            q2_structures=len(self.q2),new_optimization=False)
                write(self.out/'smoke_review.json',result);self.pulse('smoke_completed',smoke=result);return result
            self.replay_seed(dict(path=BASE,sha256=sha(BASE/'solution_q3.json')),'baseline')
            for item in options:
                if self.stopped(35):break
                if any(a['solution_sha256']==item['sha256'] for a in self.archive):continue
                self.replay_seed(item,'resume_'+item['sha256'][:16])
            iteration=0
            while not self.stopped(28):
                try:record=self.run_round(iteration)
                except Exception as exc:record=dict(iteration=iteration,status='error',error=str(exc),traceback=traceback.format_exc())
                self.compact_own_geometry()
                self.records.append(record);write(self.out/'iterations.json',self.records)
                self.pulse('iteration_complete',last=record);iteration+=1
                if len(self.records)>=3 and all(r['status']=='error' for r in self.records[-3:]):
                    raise RuntimeError('Three consecutive implementation failures; see iterations.json.')
            summary=dict(status='STOPPED_BY_REQUEST' if self.stop_path.exists() else 'BATCH_BUDGET_COMPLETED',
                         elapsed_s=time.monotonic()-self.started,budget_seconds=self.args.seconds,
                         iterations=len(self.records),accepted=len(self.archive),calendar_deadline=None,
                         best=min(self.archive,key=lambda r:(r['metrics']['C'],r['metrics']['E'])) if self.archive else None,
                         promotion_allowed=False)
            write(self.out/'run_summary.json',summary);self.pulse(summary['status'],summary=summary);return summary
        except Exception as exc:
            write(self.out/'fatal_error.json',dict(error=str(exc),traceback=traceback.format_exc()));self.pulse('failed',error=str(exc));raise
        finally:self._heartbeat_done.set();heartbeat.join(timeout=2)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seconds',type=float,default=10800)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--seed',type=int,default=20260925)
    parser.add_argument('--output',default='runs/q3_20260925')
    parser.add_argument('--stage-seconds',type=float,default=300)
    parser.add_argument('--geometry-seconds',type=float,default=180)
    parser.add_argument('--site-limit',type=int,default=128)
    parser.add_argument('--new-sites',type=int,default=6)
    parser.add_argument('--site-radii',type=lambda s:[float(v) for v in s.split(',')],default=[70.,120.,350.,700.,1600.,2500.])
    parser.add_argument('--q2-glob',action='append')
    parser.add_argument('--resume-glob',action='append')
    parser.add_argument('--resume-limit',type=int,default=6)
    parser.add_argument('--q2-horizon',type=float,default=6900.)
    parser.add_argument('--q2-energy-limit',type=float,default=72.)
    parser.add_argument('--include-rounds',action=argparse.BooleanOptionalAction,default=True)
    parser.add_argument('--compress-geometry',action=argparse.BooleanOptionalAction,default=True)
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    if min(args.seconds,args.stage_seconds,args.geometry_seconds)<=0 or args.workers<1 or args.resume_limit<1:
        parser.error('positive time budgets, workers and resume limit are required')
    if args.site_limit<41 or args.new_sites<0 or not args.site_radii or any(r<0 for r in args.site_radii):
        parser.error('invalid lawful site-expansion configuration')
    if args.smoke and args.seconds>30:parser.error('portable recovery smoke budget must be <=30 seconds')
    ServerSearch(args).run_server()


if __name__=='__main__':main()
