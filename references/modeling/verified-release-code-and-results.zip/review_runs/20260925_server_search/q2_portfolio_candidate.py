"""Unlaunched alternative Q2 worker with forced structural diversification.

Uses separate output and master files. It can resume the live worker's validated
archive and route columns without writing to the live worker's directory.
"""
from pathlib import Path
import argparse, collections, datetime, hashlib, json, math, sys, time
from q2_search import HERE, PROJECT, Search, dump, read, now, objective, aspiration_score


class Portfolio(Search):
    def __init__(self,args):
        super().__init__(args)
        from q2_master_candidate import solve
        self.solve=solve
        self.resume=(HERE/args.resume_root).resolve() if args.resume_root else None
        if self.resume:
            assert self.resume.is_relative_to(HERE.resolve()) and self.resume!=self.out
        if args.deadline_local:
            absolute=datetime.datetime.fromisoformat(args.deadline_local)
            if absolute.tzinfo is None:absolute=absolute.astimezone()
            self.deadline=min(self.deadline,time.perf_counter()+max(0,absolute.timestamp()-time.time()))
        self.tabu=[]
        self.followup_rounds=0
        self.changed_structure_count=0
        self.last_pool_sync=0
        self.resume_manifests=[]
        self.shake_no_solution=0
        self.bundles=read(HERE/'planning/q2_structural_diagnosis.json')['proposed_targeted_bundles']

    def fixed_pool_control(self):
        # The original worker already owns this controlled experiment.
        return

    def profile(self,r):
        # Labels of physically equivalent boxes do not define a new structure.
        return (r['model'],tuple((s,tuple(sorted((self.P.boxes[b]['weight'],self.P.boxes[b]['volume_L'],
                   self.P.boxes[b]['expected_s'],self.P.boxes[b]['hard_due'] or -1,
                   self.P.boxes[b]['priority']) for b in bs))) for s,bs in r['stops']))

    def structure(self,rows):
        return tuple(sorted(self.profile(v['route']) for v in rows))

    def update_elites(self,record,baseline=False):
        """Archive every verified record, but give each physical plan one seat."""
        if record is None:return False
        import shutil
        improved=self.best is None or objective(record['metrics'])<objective(self.best['metrics'])
        if improved:self.best=record;self.since_improvement=0
        else:self.since_improvement+=1
        self.archive.setdefault(record['id'],record)
        representatives={}
        for r in self.archive.values():
            key=self.structure(r['rows'])
            old=representatives.get(key)
            if old is None or objective(r['metrics'])<objective(old['metrics']):representatives[key]=r
        records=list(representatives.values())
        self.best=representatives[self.structure(self.best['rows'])]
        front=[r for r in records if not any(
            all(b['metrics'][k]<=r['metrics'][k]+(1e-7 if k!='N' else 0) for k in ('C','E','N'))
            and any(b['metrics'][k]<r['metrics'][k]-(1e-7 if k!='N' else 0) for k in ('C','E','N'))
            for b in records if b is not r)]
        ordered=sorted(front,key=lambda r:aspiration_score(r['metrics']))
        ordered+=sorted(records,key=lambda r:objective(r['metrics']))[:3]
        ordered+=sorted(records,key=lambda r:(r['metrics']['E'],r['metrics']['C']))[:2]
        selected=[];seen=set()
        for r in ordered:
            key=self.structure(r['rows'])
            if key in seen:continue
            seen.add(key);selected.append(r)
            if len(selected)>=12:break
        if self.best not in selected:selected.insert(0,self.best)
        self.elites=selected
        index=[]
        for r in selected:
            target=self.out/'elites'/r['id']
            if not (target/'candidate_review.json').exists():shutil.copytree(r['directory'],target,dirs_exist_ok=True)
            index.append(dict(id=r['id'],path=target.relative_to(HERE).as_posix(),metrics=r['metrics'],
                structure_signature=hashlib.sha256(repr(self.structure(r['rows'])).encode()).hexdigest()[:16],
                structure_signature_kind='physical_profile_with_deadline_and_priority',
                route_ids=sorted(v['route']['id'] for v in r['rows'])))
        assert len({v['structure_signature'] for v in index})==len(index)
        dump(self.out/'elites/index.json',dict(updated_at=now(),elites=index,best_id=self.best['id'],
            automatic_promotion=False,full_verified_archive_records=len(self.archive),
            distinct_physical_archive_structures=len(representatives)))
        if improved or baseline:
            target=self.out/'best';shutil.copytree(self.best['directory'],target,dirs_exist_ok=True)
            dump(self.out/'best.json',dict(id=self.best['id'],metrics=self.best['metrics'],
                 path=target.relative_to(HERE).as_posix(),updated_at=now()))
        for v in record['rows']:self.pool[v['route']['id']]=v['route']
        return improved

    def stable_pool_read(self,path):
        try:
            content=path.read_bytes();sha=hashlib.sha256(content).hexdigest()
            values=[json.loads(line) for line in content.decode('utf-8-sig').splitlines() if line.strip()]
            # A file which changed during the copy is retried next sync.
            if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:return 0
            for r in values:
                if self.latest(r)>=-1e-7:self.pool[r['id']]=r
            self.resume_manifests.append(dict(path=str(path.relative_to(HERE)),sha256=sha,routes=len(values)))
            return len(values)
        except (OSError,ValueError,KeyError):return 0

    def initialize_baselines(self):
        super().initialize_baselines()
        if self.resume and self.resume.exists():
            candidates=[]
            index=self.resume/'elites/index.json'
            if index.exists():
                candidates += [HERE/v['path'] for v in read(index)['elites']]
            candidates += [p.parent for p in sorted((self.resume/'rounds').glob('*/candidate_review.json'))]
            # Complete validated archive, including dominated but different
            # structures which can be useful as a search state after a shake.
            seen=set()
            for folder in candidates:
                if self.expired(12):break
                review=read(folder/'candidate_review.json')
                if not review.get('accepted'):continue
                path=folder/'solution.json';sha=hashlib.sha256(path.read_bytes()).hexdigest()
                if sha in seen:continue
                seen.add(sha)
                result=self.validate(read(path),self.out/'resume'/sha[:16],
                                     'resume independently replayed '+str(path.relative_to(HERE)))
                if result:self.update_elites(result)
            self.stable_pool_read(self.resume/'cumulative_pool.jsonl')
            # The cumulative snapshot may lag by eight rounds, so recover every
            # complete round pool as well; stable reads avoid partial live files.
            for path in sorted((self.resume/'rounds').glob('*/candidate_pool.jsonl')):
                self.stable_pool_read(path)
            self.current=self.best
        contract=read(self.out/'input_contract.json')
        contract.update(variant='forced physical-structure shake, exact diagnosed bundles, 8-10 route ruin, rolling tabu',
                        parent_worker='q2_search.py',resume_root=None if self.resume is None else str(self.resume.relative_to(HERE)),
                        resume_pool_sources=self.resume_manifests,
                        effective_deadline_local=(datetime.datetime.now().astimezone()+datetime.timedelta(seconds=max(0,self.deadline-time.perf_counter()))).isoformat(),
                        added_sources=[dict(path=str(p.relative_to(PROJECT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                                       for p in (Path(__file__),HERE/'q2_master_candidate.py')])
        dump(self.out/'input_contract.json',contract)
        self.since_improvement=max(4,self.since_improvement)
        self.pulse('resume_verified',archive_records=len(self.archive),resume_pool_files=len(self.resume_manifests))

    def bundle_group(self,source,index):
        bundle=self.bundles[index%len(self.bundles)];wanted=set(bundle['route_ids'])
        group=[v for v in source['rows'] if v['route']['id'] in wanted]
        exact=len(group)==len(wanted)
        if not exact:
            # These diagnostic bundles are defined on the frozen original fast
            # plan. Keep that exact six-route experiment alongside new elites.
            source=self.baselines['Q2_fast']
            group=[v for v in source['rows'] if v['route']['id'] in wanted]
            assert len(group)==len(wanted)
        return source,group,bundle['name'],exact

    def cuts(self,active,profiles,max_count,label):
        profiles=set(profiles)
        ids=[r['id'] for r in active.values() if self.profile(r) in profiles]
        return dict(route_ids=ids,max_selected=max_count,label=label)

    def round_search(self):
        self.round+=1
        cycle=('shake_bundle','recover','wide','energy','shake_wide','recover','N','global','target')
        mode=cycle[(self.round-1)%len(cycle)]
        if self.args.smoke:mode='shake_bundle' if self.round==1 else 'recover'
        source=self.current if self.followup_rounds else self.choose_source()
        forced=mode.startswith('shake') or (self.since_improvement>=5 and mode in ('wide','global'))
        full=mode in ('global','target')
        if mode=='shake_bundle':
            source,group,mechanism,was_exact=self.bundle_group(source,(self.round//len(cycle)+2)%3)
        elif full:
            group=source['rows'];mechanism='full_archive_recombination';was_exact=False
        else:
            size=self.rng.randint(8,10) if mode in ('wide','shake_wide') or self.since_improvement>=6 else 6
            mechanism='random' if mode=='shake_wide' else 'cross_model' if mode=='wide' else 'critical_tail'
            group=self.destroy(source['rows'],mechanism,min(size,len(source['rows'])));was_exact=False
        rows=source['rows']
        if full:
            active=self.trim(self.pool,[v['route'] for e in self.elites for v in e['rows']],6500)
            required=[];stats=dict(global_recombination=True,boxes=80);gen_s=0.
        else:
            ids,new,stats,gen_s=self.generate(group,2. if self.args.smoke else 8.)
            outside=[v for v in rows if v not in group]
            required=[v['route']['id'] for v in outside]
            active={k:r for k,r in self.pool.items() if set(r['boxes'])<=ids}
            for v in outside:active[v['route']['id']]=v['route']
            active=self.trim(active,[v['route'] for v in rows],900 if self.args.smoke else 2200 if len(group)>6 else 1600,new)
        cuts=[]
        # The current incumbent's physical route profiles are excluded, not
        # merely one arbitrary box-label realization of those profiles.
        if forced:
            destroyed_profiles={self.profile(v['route']) for v in group}
            original_count=sum(self.profile(v['route']) in destroyed_profiles for v in rows)
            cuts.append(self.cuts(active,destroyed_profiles,original_count-1,'must_change_destroyed_physical_pattern'))
        self.tabu=[t for t in self.tabu if t['expires_round']>=self.round]
        for i,tabu in enumerate(self.tabu):
            cuts.append(self.cuts(active,tabu['profiles'],tabu['N']-1,'rolling_tabu_'+str(i)))
        maxC=6800. if forced else min(6600,max(6200,source['metrics']['C']+60))
        maxE=72. if forced else 70.;maxN=29 if forced else 27
        objectives=('C',);seconds=60. if not full else 150.
        if mode=='energy':objectives=('E',);maxC=min(6400,max(self.best['metrics']['C']+150,source['metrics']['C']));seconds=80.
        if mode=='N':objectives=('N','C');maxC=6600.;seconds=60.
        if mode=='global':objectives=('C','E');maxC=min(6200,self.best['metrics']['C']+80);seconds=150.
        if mode=='target':maxC=5699.9;maxE=66.99999;maxN=23;seconds=180.
        if self.args.smoke:seconds=min(18.,max(.1,self.deadline-time.perf_counter()-4));objectives=('C',)
        folder=self.out/'rounds'/f'r{self.round:04d}_{mode}';folder.mkdir(parents=True,exist_ok=True)
        solve_seed=(self.args.seed+self.round)%2147483647
        self.save_pool(active,folder/'candidate_pool.jsonl')
        dump(folder/'parameters.json',dict(round=self.round,mode=mode,source=source['id'],seed=solve_seed,
            mechanism=mechanism,exact_bundle_available_in_source=was_exact,removed_route_ids=[v['route']['id'] for v in group],
            required_route_ids=required,structural_cuts=cuts,forced_structure_change=forced,
            max_C=maxC,max_E=maxE,max_N=maxN,objectives=objectives,stage_seconds=seconds,workers=self.args.workers,
            generation=stats,generation_seconds=gen_s,pool_size=len(active)))
        self.pulse('solver',mode=mode,active_routes=len(active),destroyed_routes=len(group),forced_change=forced)
        result=self.solve(self.P,active,seconds=seconds,seed=solve_seed,q=.1,warm=rows,
            objectives=objectives,fixed_D=0,max_C=maxC,max_E=maxE,max_N=maxN,workers=self.args.workers,
            required_route_ids=required,delivery_mode='batch',edd_order=True,structural_cuts=cuts,
            # E polishing receives enough presolve budget; the old 30s global
            # stage repeatedly expired before any search branches in early runs.
            stage_seconds={s:(100 if s=='E' and full else seconds) for s in objectives},
            evidence_path=folder/'solver_stage_checkpoint.json',deadline_monotonic=self.deadline-2,stop_file=self.stop)
        dump(folder/'solver_evidence.json',{k:v for k,v in result.items() if k!='selected'})
        record=None;improved=False;move=False;changed=False
        if result['selected']:
            record=self.validate(self.decode(self.P,result),folder,'portfolio_candidate_'+mode,result,
                                 caps={'C':maxC,'E':maxE,'N':maxN})
            if record:
                changed=self.structure(record['rows'])!=self.structure(rows)
                if forced:assert changed,'structural cut admitted unchanged physical structure'
                for cut in cuts:
                    selected=sum(v['route']['id'] in set(cut['route_ids']) for v in record['rows'])
                    assert selected<=cut['max_selected']
                improved=self.update_elites(record)
                delta=(record['metrics']['C']-self.current['metrics']['C']+
                       35*(record['metrics']['E']-self.current['metrics']['E'])+
                       25*(record['metrics']['N']-self.current['metrics']['N']))
                move=forced or improved or delta<=0 or self.rng.random()<math.exp(-min(700,max(0,delta)/120))
                if move:self.current=record
                if forced:
                    self.changed_structure_count+=1
                    self.followup_rounds=3
                    self.tabu.append(dict(profiles=[self.profile(v['route']) for v in rows],N=len(rows),expires_round=self.round+5))
                    self.tabu=self.tabu[-3:]
                elif self.followup_rounds:self.followup_rounds-=1
        if record is None:
            self.since_improvement+=1
            if forced:self.shake_no_solution+=1
        history=dict(round=self.round,mode=mode,mechanism=mechanism,source=source['id'],candidate_id=None if record is None else record['id'],
            metrics=None if record is None else record['metrics'],improved_fast=improved,accepted_search_state=move,
            changed_physical_structure=changed,forced_structure_change=forced,stagnation_rounds=self.since_improvement,
            successful_forced_changes=self.changed_structure_count,failed_forced_solves=self.shake_no_solution,
            best=self.best['metrics'],solver=result['evidence'],generation=stats,pool_size=len(self.pool),
            elapsed_s=time.perf_counter()-self.started)
        self.history.append(history)
        with (self.out/'progress.jsonl').open('a',encoding='utf-8') as stream:stream.write(json.dumps(history,ensure_ascii=False)+'\n')
        if self.round%4==0:self.save_pool(self.pool,self.out/'cumulative_pool.jsonl')
        self.pulse('round_completed',mode=mode,improved=improved,moved=move,changed_physical_structure=changed)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--seconds',type=float,default=1800.)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--seed',type=int,default=2026092517)
    parser.add_argument('--output',default='q2_portfolio_candidate')
    parser.add_argument('--resume-root',default='q2')
    parser.add_argument('--deadline-local',default='2026-09-25T20:16:15+08:00')
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args();args.control_seconds=0.
    if args.seconds<=0 or not 1<=args.workers<=8:parser.error('invalid budget or workers')
    Portfolio(args).run()
