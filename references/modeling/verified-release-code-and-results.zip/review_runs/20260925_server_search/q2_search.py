"""Isolated Q2 multi-elite, variable-neighborhood route/schedule search.

The physical model, fleet and station-end delivery contract are frozen. Routes
are generated afresh at every iteration; only independently replayed solutions
enter the shared elite index. No publication or manuscript path is writable.

CLI: python -B q2_search.py --seconds 10800 --workers 4 --seed 20260925
     --output q2_smoke --smoke --seconds 60  # short real-data startup probe
"""
from pathlib import Path
import argparse, collections, csv, datetime, hashlib, itertools, json, math
import os, random, sys, time, traceback, types

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def dump(path, obj):
    path = Path(path)
    assert path.resolve().is_relative_to(HERE.resolve()), str(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    temp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(temp, path)


def initialize(workers):
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "1"
    os.environ["NUMBA_CACHE_DIR"] = str(HERE / "cache/numba_q2")
    env = types.ModuleType("env")
    env.ROOT, env.PROJECT, env.OUT = HERE, PROJECT, HERE / "inputs"
    sys.modules["env"] = env
    sys.path[:0] = [str(HERE), str(HERE / "src/q2"), str(PROJECT / "问题1/src"), str(PROJECT / "问题2/deps311")]
    import bootstrap
    from routes import Physics, read_pool, save_pool
    from validate import check
    from q2_master import solve, decode
    return Physics, read_pool, save_pool, check, solve, decode


def station_validation(folder):
    """Use the independent checker's event tables, never route cached arrivals."""
    with (folder / "stop_events.csv").open(encoding="utf-8-sig") as stream:
        stops = {(v["sortie"], v["visit"]): float(v["departure"]) for v in csv.DictReader(stream)}
    rows = []
    with (folder / "deliveries.csv").open(encoding="utf-8-sig") as stream:
        for v in csv.DictReader(stream):
            end = stops[v["sortie"], v["visit_index"]]
            hard = float(v["hard_due"]) if v["hard_due"] else None
            late = max(0., end - float(v["expected_s"]))
            rows.append(dict(box=v["box"], station_complete=end, station_lateness=late,
                             weighted_lateness=late*float(v["priority"]), hard_due=hard,
                             hard_slack=None if hard is None else hard-end))
    hard_rows = [v for v in rows if v["hard_due"] is not None]
    report = dict(valid=len(rows)==80 and len({v["box"] for v in rows})==80
                  and len(hard_rows)==31 and all(v["hard_slack"]>=-1e-6 for v in hard_rows),
                  D_station=sum(v["weighted_lateness"] for v in rows),
                  late_boxes=sum(v["station_lateness"]>1e-6 for v in rows),
                  hard_boxes=len(hard_rows), hard_violations=sum(v["hard_slack"] < -1e-6 for v in hard_rows),
                  min_hard_slack=min((v["hard_slack"] for v in hard_rows), default=None), rows=rows)
    dump(folder / "station_delivery_validation.json", report)
    return report


def objective(metrics):
    return metrics["C"], metrics["E"], metrics["N"]


def aspiration_score(metrics):
    # Screenshot only specifies truncated ranges. 95 min, 67 kWh are upper
    # edges, and are labelled aspirational targets, not verified lower bounds.
    return (max(0., metrics["C"]-5700)/60 + max(0., metrics["E"]-67)*2
            + max(0, metrics["N"]-23)*1.5 + metrics["C"]/60000)


class Search:
    def __init__(self, args):
        self.args = args
        self.out = (HERE / args.output).resolve()
        assert self.out.is_relative_to(HERE.resolve()) and self.out != HERE.resolve()
        self.out.mkdir(parents=True, exist_ok=True)
        if (self.out / "run_summary.json").exists():
            raise RuntimeError("Output already contains a completed run; use another --output directory")
        self.started = time.perf_counter()
        self.deadline = self.started + args.seconds
        self.rng = random.Random(args.seed)
        Physics, self.read_pool, self.save_pool, self.check, self.solve, self.decode = initialize(args.workers)
        self.P = Physics()
        assert self.P.data["M"] == {"A":4,"B":2,"C":2}
        assert self.P.data["K"] == {"A":6,"B":4,"C":4}
        self.pool, self.elites, self.history = {}, [], []
        self.cache = {}
        self.stop = HERE / "STOP"
        self.archive = {}
        self.since_improvement = 0
        self.generated = collections.Counter()
        self.best = None
        self.current = None
        self.round = 0
        self.validation_count = 0
        self.baselines = {}

    def expired(self, reserve=0):
        return self.stop.exists() or time.perf_counter() >= self.deadline-reserve

    def pulse(self, phase, **other):
        value = dict(state="running", phase=phase, pid=os.getpid(), round=self.round,
                     updated_at=now(), elapsed_s=time.perf_counter()-self.started,
                     remaining_s=max(0,self.deadline-time.perf_counter()), pool_size=len(self.pool),
                     verified_candidates=self.validation_count,
                     stagnation_rounds=self.since_improvement,
                     best=None if self.best is None else self.best["metrics"], **other)
        dump(self.out / "status.json", value)
        print(json.dumps(value, ensure_ascii=False), flush=True)

    def validate(self, rows, folder, source, solver=None, caps=None):
        folder.mkdir(parents=True, exist_ok=True)
        report = self.check(rows, folder, data=self.P.data)
        station = station_validation(folder)
        s = report["summary"]
        accepted = bool(s["valid"] and station["valid"] and s["D"]<=1e-6
                        and station["D_station"]<=1e-6 and station["late_boxes"]==0)
        m = dict(C=s["Cmax"], E=s["E"], N=s["N"], D=s["D"], D_station=station["D_station"],
                 late_boxes=station["late_boxes"], hard_slack=station["min_hard_slack"],
                 min_SOC=s["min_SOC"], by_model=s["by_model"])
        cap_checks={k:m[k]<=limit+(1e-6 if k=="C" else 1e-8 if k=="E" else 0)
                    for k,limit in (caps or {}).items()}
        accepted=accepted and all(cap_checks.values())
        review = dict(accepted=accepted, question="Q2", metrics=m, source=source,
                      validation=s, station_validation={k:v for k,v in station.items() if k!="rows"},
                      promotion_allowed=False, source_release="20260924_v3_excel1",
                      delivery_definition="whole-stop handover completion", checked_at=now(),
                      scope="feasible candidate, not a global optimum or global gap certificate")
        review["requested_caps"]=caps or {}
        review["actual_cap_checks"]=cap_checks
        if solver is not None:
            review["solver"] = solver["evidence"]
            dump(folder / "solver_evidence.json", {k:v for k,v in solver.items() if k!="selected"})
        dump(folder / "candidate_review.json", review)
        dump(folder / "solution_summary.json", {**s, **m})
        self.validation_count += 1
        if not accepted:
            return None
        signature = hashlib.sha256(json.dumps([(v["route"]["id"],round(v["start"],6),v["aircraft"],v["battery"])
                                              for v in sorted(rows,key=lambda z:z["route"]["id"])],
                                             separators=(",",":")).encode()).hexdigest()[:16]
        return dict(id=signature, rows=rows, metrics=m, directory=folder)

    def update_elites(self, record, baseline=False):
        if record is None:
            return False
        m = record["metrics"]
        improved = self.best is None or objective(m) < objective(self.best["metrics"])
        if improved:
            self.best = record
            self.since_improvement = 0
        else:
            self.since_improvement += 1
        prior = self.archive.get(record["id"])
        if prior is None:
            self.archive[record["id"]] = record
        records = list(self.archive.values())
        front = [r for r in records if not any(
            all(b["metrics"][k]<=r["metrics"][k]+(1e-7 if k!="N" else 0) for k in ("C","E","N"))
            and any(b["metrics"][k]<r["metrics"][k]-(1e-7 if k!="N" else 0) for k in ("C","E","N"))
            for b in records if b is not r)]
        # Retain several objective endpoints and structurally different near
        # incumbents. The active elite set is bounded; immutable evidence stays.
        ordered = sorted(front, key=lambda r:aspiration_score(r["metrics"]))
        ordered += sorted(records, key=lambda r:objective(r["metrics"]))[:3]
        ordered += sorted(records, key=lambda r:(r["metrics"]["E"],r["metrics"]["C"]))[:2]
        chosen, structures = [], set()
        for r in ordered:
            structure = tuple(sorted(v["route"]["id"] for v in r["rows"]))
            if structure in structures:continue
            structures.add(structure);chosen.append(r)
            if len(chosen)>=12:break
        if self.best not in chosen:chosen.insert(0,self.best)
        self.elites = chosen
        index = []
        import shutil
        for r in chosen:
            target = self.out / "elites" / r["id"]
            if not (target / "candidate_review.json").exists():
                shutil.copytree(r["directory"], target, dirs_exist_ok=True)
            structure=sorted(v["route"]["id"] for v in r["rows"])
            index.append(dict(id=r["id"], path=target.relative_to(HERE).as_posix(), metrics=r["metrics"],
                              structure_signature=hashlib.sha256("|".join(structure).encode()).hexdigest()[:16],
                              route_ids=structure))
        dump(self.out / "elites/index.json", dict(updated_at=now(), elites=index,
                                                best_id=self.best["id"], automatic_promotion=False))
        if improved or baseline:
            target = self.out / "best"
            shutil.copytree(self.best["directory"], target, dirs_exist_ok=True)
            dump(self.out / "best.json", dict(id=self.best["id"],metrics=self.best["metrics"],
                                             path=target.relative_to(HERE).as_posix(), updated_at=now()))
        # All evaluated columns survive across basins; long-term pool pruning is
        # applied only to individual CP-SAT solves, not to stored candidates.
        for v in record["rows"]:self.pool[v["route"]["id"]] = v["route"]
        return improved

    def initialize_baselines(self):
        selected = read(PROJECT / "review_runs/20260924_v3/selected_versions.json")
        paths = [(v["id"], PROJECT/v["directory"]/"solution.json") for v in selected["solutions"]
                 if v["id"] in ("Q2_fast","Q2_balanced")]
        for label, path in paths:
            rows = read(path)
            for v in rows:
                r = self.P.evaluate(v["route"]["model"], v["route"]["stops"])
                assert r is not None
                v["route"] = r
                self.pool[r["id"]] = r
            record = self.validate(rows, self.out/"baseline"/label, str(path.relative_to(PROJECT)))
            assert record is not None, label
            self.baselines[label]=record
            self.update_elites(record, baseline=True)
        self.current = self.best
        sources = [PROJECT/"review_runs/20260924_background_v3/cache/q2_cumulative_pool.jsonl",
                   PROJECT/"review_runs/20260924_v2/q2_soft_energy/candidate_pool.jsonl"]
        pool_source=None
        for path in sources:
            if path.exists():
                pool_source=dict(path=str(path.relative_to(PROJECT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                raw = self.read_pool(path)
                for r in raw.values():
                    if self.latest(r)>=-1e-7:self.pool[r["id"]] = r
                break
        dump(self.out/"input_contract.json", dict(source_release="20260924_v3_excel1",
              sources=[dict(path=str(p.relative_to(PROJECT)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                       for p in [HERE/"inputs/normalized_inputs.json",HERE/"inputs/terrain_evidence_all.json",
                                 Path(__file__),HERE/"q2_master.py",HERE/"src/q2/routes.py",HERE/"src/q2/validate.py"]],
              seed=self.args.seed, workers=self.args.workers, runtime_budget_s=self.args.seconds,
              initial_route_pool=pool_source,python=sys.version,executable=sys.executable,
              resources=dict(M=self.P.data["M"],K=self.P.data["K"]), reserve=.2,
              physical_scaling=dict(energy=1.,flight=1.,horizontal=1.), grid_s=.1,
              delivery_definition="whole-stop completion; zero expected and hard deadline violations",
              target=dict(C_lt_s=5700,E_lt_kwh=67,N_le=23,source="user screenshot; unverified comparator"),
              method="adaptive 3-6-route ruin/recreate with exact restricted set partition/scheduling, multistart and annealed objective changes",
              baseline="v3 fast and balanced, independently replayed", automatic_promotion=False))
        self.pulse("baseline_verified")

    def fixed_pool_control(self):
        """Same 4501 routes, seed and two threads as v3; longer C stage only.

        This measures the value of extra scheduling time before any new columns
        enter the solve. Bounds remain pool-specific. Energy polishing is logged
        separately and is not represented as the same-budget energy experiment.
        """
        if self.args.smoke or self.args.control_seconds<=0 or self.expired(600):return
        source=self.baselines["Q2_fast"]
        old_folder=PROJECT/"review_runs/20260924_background_v3/cases/q2_fast_critical_three_routes"
        path=old_folder/"candidate_pool.jsonl"
        pool=self.read_pool(path)
        old_contract=read(old_folder/"input_contract.json")
        warm_path=Path(old_contract["warm_source"])
        if not warm_path.is_absolute():warm_path=PROJECT/warm_path
        assert warm_path.resolve().is_relative_to(PROJECT.resolve())
        warm_rows=read(warm_path)
        # Match the old worker's exact hint preparation, including effective-
        # deadline order. The released final fast plan is only the comparator.
        for v in warm_rows:
            r=self.P.evaluate(v["route"]["model"],v["route"]["stops"])
            assert r is not None and r["id"] in pool
            v["route"]=r
            v["orders"]=[sorted(bs,key=lambda b:(min(self.P.boxes[b]["expected_s"],
                                    self.P.boxes[b]["hard_due"] or math.inf),b)) for _,bs in r["stops"]]
        folder=self.out/"fixed_pool_control"
        folder.mkdir(parents=True,exist_ok=True)
        seconds=min(self.args.control_seconds,self.deadline-time.perf_counter()-240)
        dump(folder/"parameters.json",dict(control="unchanged route pool, same seed/two workers; C search time increased",
             source=str(path.relative_to(PROJECT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
             warm_source=str(warm_path.relative_to(PROJECT)),warm_sha256=hashlib.sha256(warm_path.read_bytes()).hexdigest(),
             warm_metrics=old_contract["warm_metrics"],warm_preparation="same physical reevaluation and effective-deadline box order as original worker",
             pool_size=len(pool),seed=202609252,workers=2,q=.1,max_C=6500,
             old_C_stage_seconds=180,new_C_stage_seconds=seconds,
             old_pool_bound_s=5523.4,old_actual_C_s=5903.043477110843,
             energy_polish_seconds=60,interpretation="C stage comparison isolates added solver time; later E polishing is separate"))
        self.pulse("fixed_pool_control",active_routes=len(pool),stage_seconds=seconds)
        result=self.solve(self.P,pool,seconds=seconds,seed=202609252,q=.1,warm=warm_rows,
                          objectives=("C","E"),fixed_D=0,max_C=6500,workers=2,
                          delivery_mode="batch",edd_order=True,stage_seconds={"C":seconds,"E":60},
                          evidence_path=folder/"solver_stage_checkpoint.json",deadline_monotonic=self.deadline-2,
                          stop_file=self.stop)
        dump(folder/"solver_evidence.json",{k:v for k,v in result.items() if k!="selected"})
        record=None
        if result["selected"]:
            record=self.validate(self.decode(self.P,result),folder,"fixed_pool_control",result)
            if record:
                self.update_elites(record);self.current=self.best
        dump(folder/"comparison.json",dict(baseline=source["metrics"],
             candidate=None if record is None else record["metrics"],
             objective_preference="zero-late C first; same finite route pool",
             no_global_gap_claim=True))
        self.pulse("fixed_pool_control_completed")

    def latest(self, route):
        m = self.P.models[route["model"]]
        return min(min(self.P.boxes[b]["expected_s"], self.P.boxes[b]["hard_due"] or math.inf)
                   - route["arrivals"][j]-m["handover"]-m["handover_box"]*len(bs)
                   for j,(_,bs) in enumerate(route["stops"]) for b in bs)

    def options(self, ids):
        ids = tuple(sorted(ids))
        if not ids:return []
        if ids in self.cache:return self.cache[ids]
        nodes = sorted({self.P.boxes[b]["service"] for b in ids})
        if len(nodes)>5:return []
        # Full visit orders through four sites; five-site probes are diversified.
        if len(nodes)<=4:orders=list(itertools.permutations(nodes))
        else:
            orders=[tuple(nodes),tuple(reversed(nodes))]
            orders += [tuple(self.rng.sample(nodes,len(nodes))) for _ in range(12)]
        mass=sum(self.P.boxes[b]["weight"] for b in ids)
        volume=sum(self.P.boxes[b]["volume_L"] for b in ids)
        found={}
        for typ,m in self.P.models.items():
            if mass>m["Q"] or volume>m["volume_L"]:continue
            for order in orders:
                stops=[(s,[b for b in ids if self.P.boxes[b]["service"]==s]) for s in order]
                route=self.P.evaluate(typ,stops)
                self.generated["physical_evaluations"]+=1
                if route is not None and self.latest(route)>=-1e-7:
                    found[route["id"]]=route
        answer=list(found.values())
        if len(self.cache)>60000:self.cache.clear()
        self.cache[ids]=answer
        return answer

    def destroy(self, rows, mechanism, size):
        rng=self.rng
        anchor=rng.choice(sorted(rows,key=lambda v:-v["return"])[:max(2,len(rows)//3)])
        others=[v for v in rows if v is not anchor]
        if mechanism=="random":return rng.sample(rows,min(size,len(rows)))
        if mechanism=="critical_tail":
            tail=sorted(rows,key=lambda v:-v["return"])
            # Release both late C chains and contemporaneous A/B work so the
            # master can exchange boxes across the actual makespan bottlenecks.
            return tail[:size]
        if mechanism=="resource_chain":
            same=[v for v in others if v["aircraft"]==anchor["aircraft"] or v["battery"]==anchor["battery"]]
            rest=[v for v in others if v not in same]
            rng.shuffle(rest);rng.shuffle(same)
            return [anchor]+(same+rest)[:size-1]
        def distance(v):
            return min(0 if a==b else self.P.geo[a,b][0]
                       for a,_ in anchor["route"]["stops"] for b,_ in v["route"]["stops"])
        near=sorted(others,key=lambda v:(distance(v),rng.random()))
        if mechanism=="geography":return [anchor]+rng.sample(near[:min(len(near),size+2)],size-1)
        # Workload transfer must include both overloaded and underused models.
        cross=[v for v in near if v["route"]["model"]!=anchor["route"]["model"]]
        selected=[anchor]+cross[:min(2,size-1)]
        rest=[v for v in near if v not in selected]
        selected += rng.sample(rest[:min(len(rest),size+2)],size-len(selected))
        return selected

    def generate(self, group, seconds):
        began=time.perf_counter();end=min(self.deadline-3,began+seconds)
        bins=[set(v["route"]["boxes"]) for v in group]
        ids=set().union(*bins);new={};stats=collections.Counter()
        def emit(bs,mechanism):
            if time.perf_counter()>=end:return
            for r in self.options(bs):new[r["id"]]=r
            stats[mechanism]+=1
        for bs in bins:emit(bs,"model_order")
        # Systematic merge, relocation and swap open route-count reductions and
        # machine workload transfers before randomized larger perturbations.
        pairs=list(itertools.combinations(range(len(bins)),2));self.rng.shuffle(pairs)
        for i,j in pairs:
            emit(bins[i]|bins[j],"merge")
            moves=[(i,j,b) for b in bins[i]]+[(j,i,b) for b in bins[j]]
            self.rng.shuffle(moves)
            for a,b,x in moves:
                emit(bins[a]-{x},"relocate");emit(bins[b]|{x},"relocate")
            swaps=list(itertools.product(sorted(bins[i]),sorted(bins[j])));self.rng.shuffle(swaps)
            for a,b in swaps[:24]:
                emit((bins[i]-{a})|{b},"swap");emit((bins[j]-{b})|{a},"swap")
            if time.perf_counter()>=end:break
        for bs in bins:
            values=sorted(bs)
            masks=list(range(1,1<<max(0,len(values)-1)))
            self.rng.shuffle(masks)
            for mask in masks[:50]:
                a={b for j,b in enumerate(values) if mask>>j&1}
                emit(a,"split");emit(bs-a,"split")
        attempts=0
        # Complete random multi-route repartitions: all original boxes retained;
        # route feasibility is checked separately and set partition enforces it.
        while time.perf_counter()<end and attempts<600:
            attempts+=1
            n=max(2,len(bins)+self.rng.choice((-2,-1,-1,0,1)))
            candidate=[set() for _ in range(n)]
            models=[self.rng.choice("AABC") for _ in range(n)]
            order=sorted(ids,key=lambda b:(-self.P.boxes[b]["volume_L"],self.rng.random()))
            if attempts%3==0:self.rng.shuffle(order)
            feasible=True
            for b in order:
                box=self.P.boxes[b];choices=[]
                for k,bb in enumerate(candidate):
                    model=self.P.models[models[k]]
                    mass=sum(self.P.boxes[x]["weight"] for x in bb)+box["weight"]
                    vol=sum(self.P.boxes[x]["volume_L"] for x in bb)+box["volume_L"]
                    if mass>model["Q"] or vol>model["volume_L"]:continue
                    nodes={self.P.boxes[x]["service"] for x in bb}
                    geo=0 if not nodes else min(0 if s==box["service"] else self.P.geo[s,box["service"]][0]/6000 for s in nodes)
                    deadline=0 if not bb else abs(min(self.P.boxes[x]["expected_s"] for x in bb)-box["expected_s"])/5000
                    score=geo*(.1+self.rng.random())+deadline*.2+self.rng.random()*.7
                    choices.append((score,k))
                if not choices:feasible=False;break
                candidate[min(choices)[1]].add(b)
            if feasible:
                for bb in candidate:emit(bb,"repartition")
            # Arbitrary union subsets inject routes unreachable in a single
            # relocate step. Complements are emitted on the same iteration.
            if attempts%3==0:
                subset=set(self.rng.sample(sorted(ids),self.rng.randint(1,min(8,len(ids)))))
                emit(subset,"union_subset");emit(ids-subset,"union_complement")
        before=len(self.pool);self.pool.update(new)
        stats.update(new_routes=len(self.pool)-before,candidate_routes=len(new),
                     repartition_attempts=attempts,removed_routes=len(group),boxes=len(ids))
        return ids,new,dict(stats),time.perf_counter()-began

    def trim(self, candidates, mandatory, limit, fresh=None):
        if len(candidates)<=limit:return candidates
        retained={r["id"]:r for r in mandatory}
        by=collections.defaultdict(list)
        for r in candidates.values():
            for b in r["boxes"]:by[b,r["model"]].append(r)
        # Preserve different pricing objectives rather than selecting solely by
        # energy per box; short routes can be essential to machine balance.
        per=max(2,min(8,limit//max(1,len(by))//2))
        for values in by.values():
            for key in (lambda r:r["energy"]/len(r["boxes"]),
                        lambda r:r["duration"]/len(r["boxes"]),
                        lambda r:-self.latest(r)):
                for r in sorted(values,key=key)[:per]:retained[r["id"]]=r
        novel=[r for k,r in (fresh or {}).items() if k not in retained]
        self.rng.shuffle(novel)
        for r in novel[:max(0,(limit-len(retained))//2)]:retained[r["id"]]=r
        unused=[r for k,r in candidates.items() if k not in retained];self.rng.shuffle(unused)
        for r in unused[:max(0,limit-len(retained))]:retained[r["id"]]=r
        return retained

    def choose_source(self):
        if self.round%7==0:return self.best
        if self.round%3==0:return self.rng.choice(self.elites)
        return self.current

    def round_search(self):
        self.round+=1;source=self.choose_source();rows=source["rows"]
        mode=("C","C","E","C","N","target","E","global")[(self.round-1)%8]
        if self.args.smoke:mode="C"
        full=mode=="global" or (mode=="target" and self.round%24==22)
        if full:
            mandatory=[v["route"] for e in self.elites for v in e["rows"]]
            active=self.trim(self.pool,mandatory,4800)
            group=rows;required=[];stats=dict(global_recombination=True,boxes=80);gen_s=0
            mechanism="global_recombination"
        else:
            mechanism=("geography","resource_chain","cross_model","random","critical_tail")[self.round%5]
            size=self.rng.randint(3,6) if self.since_improvement<8 else 6
            group=self.destroy(rows,mechanism,size)
            ids,new,stats,gen_s=self.generate(group,1.5 if self.args.smoke else 5.)
            outside=[v for v in rows if v not in group]
            required=[v["route"]["id"] for v in outside]
            active={k:r for k,r in self.pool.items() if set(r["boxes"])<=ids}
            for v in outside:active[v["route"]["id"]]=v["route"]
            active=self.trim(active,[v["route"] for v in rows],1300,new)
        metrics=source["metrics"]
        maxC=min(6400,max(6100,metrics["C"]+180));maxE=70.;maxN=27
        seconds=90. if full else 35.
        objectives=("C",)
        if mode=="E":
            objectives=("E",);maxC=min(6300,max(self.best["metrics"]["C"]+120,metrics["C"]+80));maxN=min(25,metrics["N"])
        elif mode=="N":
            objectives=("N","C");maxC=min(6300,metrics["C"]+180)
        elif mode=="target":
            objectives=("C",);maxN=min(23,metrics["N"]);maxE=66.99999;maxC=5699.9
        if full and mode!="target":
            objectives=("C","E");maxC=min(6100,self.best["metrics"]["C"]+1);maxE=69.
        if self.args.smoke:
            seconds=min(8,max(1,self.deadline-time.perf_counter()-4));objectives=("C",)
        folder=self.out/"rounds"/f"r{self.round:04d}_{mode}"
        folder.mkdir(parents=True,exist_ok=True)
        # Reproducible local input list; full growing pool checkpointed below.
        self.save_pool(active,folder/"candidate_pool.jsonl")
        params=dict(round=self.round,mode=mode,seed=self.args.seed+self.round,mechanism=mechanism,
                    removed_route_ids=[v["route"]["id"] for v in group],source=source["id"],
                    required_route_ids=required,max_C=maxC,max_E=maxE,max_N=maxN,
                    objectives=objectives,stage_seconds=seconds,workers=self.args.workers,
                    pool_size=len(active),generation=stats,generation_seconds=gen_s)
        dump(folder/"parameters.json",params)
        self.pulse("solver",mode=mode,active_routes=len(active),destroyed_routes=len(group))
        result=self.solve(self.P,active,seconds=seconds,seed=self.args.seed+self.round,q=.1,
                   warm=rows,objectives=objectives,fixed_D=0,max_C=maxC,max_E=maxE,max_N=maxN,
                   workers=self.args.workers,required_route_ids=required,delivery_mode="batch",edd_order=True,
                   stage_seconds={s:seconds if s!="E" or not full else 30 for s in objectives},
                   evidence_path=folder/"solver_stage_checkpoint.json",deadline_monotonic=self.deadline-2,
                   stop_file=self.stop)
        dump(folder/"solver_evidence.json",{k:v for k,v in result.items() if k!="selected"})
        record=None;improved=False;move=False
        if result["selected"]:
            candidate=self.decode(self.P,result)
            record=self.validate(candidate,folder,"generated_route_neighborhood",result,
                                 caps={"C":maxC,"E":maxE,"N":maxN})
            if record:
                # Validate actual metrics against requested caps as well as the
                # independent physical checks; grid rounding cannot relax caps.
                assert record["metrics"]["C"]<=maxC+1e-6
                assert record["metrics"]["E"]<=maxE+1e-8
                assert record["metrics"]["N"]<=maxN
                improved=self.update_elites(record)
                delta=(record["metrics"]["C"]-self.current["metrics"]["C"]
                       +30*(record["metrics"]["E"]-self.current["metrics"]["E"])
                       +20*(record["metrics"]["N"]-self.current["metrics"]["N"]))
                # Cooling resets every 20 iterations. Keeping a bounded worse
                # state is intentional; best validated candidates are immutable.
                temperature=90*(1-(self.round%20)/20)+10
                move=improved or delta<=0 or self.rng.random()<math.exp(-min(700,max(0,delta)/temperature))
                if move:self.current=record
        if record is None:self.since_improvement+=1
        if self.since_improvement>=12:
            self.current=self.rng.choice(self.elites);self.since_improvement=4
        history=dict(round=self.round,mode=mode,mechanism=mechanism,source=source["id"],
                     candidate_id=None if record is None else record["id"],
                     metrics=None if record is None else record["metrics"],improved_fast=improved,
                     accepted_search_state=move,best=self.best["metrics"],solver=result["evidence"],
                     stagnation_rounds=self.since_improvement,
                     structure_signature=None if record is None else hashlib.sha256("|".join(sorted(v["route"]["id"] for v in record["rows"])).encode()).hexdigest()[:16],
                     generation=stats,pool_size=len(self.pool),elapsed_s=time.perf_counter()-self.started)
        self.history.append(history)
        with (self.out/"progress.jsonl").open("a",encoding="utf-8") as stream:
            stream.write(json.dumps(history,ensure_ascii=False)+"\n")
        if self.round%8==0:self.save_pool(self.pool,self.out/"cumulative_pool.jsonl")
        self.pulse("round_completed",mode=mode,improved=improved,moved=move)

    def run(self):
        state="running";error=None
        try:
            self.initialize_baselines()
            self.fixed_pool_control()
            while not self.expired(4):
                self.round_search()
                if self.args.smoke and self.round>=2:break
            state="smoke_complete" if self.args.smoke else "stopped_by_file" if self.stop.exists() else "budget_complete"
        except BaseException:
            state="error";error=traceback.format_exc();raise
        finally:
            if self.pool:self.save_pool(self.pool,self.out/"cumulative_pool.jsonl")
            summary=dict(state=state,started_at=datetime.datetime.fromtimestamp(time.time()-(time.perf_counter()-self.started)).astimezone().isoformat(),
                         completed_at=now(),elapsed_s=time.perf_counter()-self.started,budget_s=self.args.seconds,
                         seed=self.args.seed,workers=self.args.workers,rounds=self.round,
                         verified_candidates=self.validation_count,pool_size=len(self.pool),
                         new_candidate_evaluations=dict(self.generated),
                         best=None if self.best is None else self.best["metrics"],
                         elites=[dict(id=r["id"],metrics=r["metrics"]) for r in self.elites],
                         error=error,promotion_allowed=False,target_is_global_bound=False,
                         scope="Finite sampled route neighborhoods; no original-problem global optimality certificate")
            dump(self.out/"run_summary.json",summary);dump(self.out/"status.json",summary)
            print(json.dumps(summary,ensure_ascii=False),flush=True)
        return summary


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--seconds",type=float,default=10800.)
    parser.add_argument("--workers",type=int,default=4)
    parser.add_argument("--seed",type=int,default=20260925)
    parser.add_argument("--output",default="q2")
    parser.add_argument("--control-seconds",type=float,default=360.)
    parser.add_argument("--smoke",action="store_true")
    args=parser.parse_args()
    if args.seconds<=0 or not 1<=args.workers<=8:parser.error("invalid budget or worker count")
    Search(args).run()
