"""Isolated multi-start Q3 search; every archive entry passes physical replay.

Consumes only validated Q2 elites. A screenshot supplies aspiration thresholds,
never physical inputs. Original routes, terrain, inventory and station deadlines
remain binding. No release or paper files are written.
"""
from pathlib import Path
import argparse
import collections
import copy
import csv
import hashlib
import json
import math
import os
import random
import shutil
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
BASE = PROJECT / 'review_runs/20260924_background_v3/cases/q3_routes_and_local_sites'


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path).resolve()
    assert path.is_relative_to(HERE.resolve()), path
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False, default=str), encoding='utf-8')
    os.replace(tmp, path)


def station_audit(folder):
    def rows(name):
        with (folder / name).open(encoding='utf-8-sig', newline='') as handle:
            return list(csv.DictReader(handle))
    ends = {(r['sortie'], r['visit']): float(r['departure']) for r in rows('stop_events.csv')}
    deliveries = []
    for row in rows('deliveries.csv'):
        complete = ends[row['sortie'], row['visit_index']]
        hard = float(row['hard_due']) if row['hard_due'] else None
        deliveries.append(dict(box=row['box'], station_complete=complete,
                               expected=float(row['expected_s']), hard_due=hard,
                               priority=float(row['priority']),
                               lateness=max(0., complete - float(row['expected_s'])),
                               hard_slack=None if hard is None else hard-complete))
    hard = [r for r in deliveries if r['hard_slack'] is not None]
    return dict(unique_boxes=len({r['box'] for r in deliveries}), boxes=len(deliveries),
                hard_boxes=len(hard), hard_violations=sum(r['hard_slack'] < -1e-6 for r in hard),
                late_boxes=sum(r['lateness'] > 1e-6 for r in deliveries),
                D_station=sum(r['priority'] * r['lateness'] for r in deliveries),
                min_hard_slack=min(r['hard_slack'] for r in hard), rows=deliveries)


def route_key(rows):
    return hashlib.sha256('|'.join(sorted(r['route']['id'] for r in rows)).encode()).hexdigest()[:16]


class Search:
    def __init__(self, args):
        self.args = args
        self.started = time.monotonic()
        self.deadline = self.started + args.seconds
        self.out = (HERE / args.output).resolve()
        assert self.out.is_relative_to(HERE.resolve())
        self.out.mkdir(parents=True, exist_ok=True)
        self.cases = self.out / 'cases'
        self.cases.mkdir(exist_ok=True)
        self.stop_path = HERE / 'STOP'
        self.rng = random.Random(args.seed)
        self.archive = []
        self.q2 = {}
        self.attempts = collections.Counter()
        self.records = []
        for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
            os.environ[key] = '1'
        os.environ['NUMBA_CACHE_DIR'] = str(self.out / 'numba_cache')
        sys.path.insert(0, str(HERE / 'src/q3'))
        from setup_q3 import inputs
        from routes import Physics
        from communication import Radio
        import joint_batch
        self.joint = joint_batch
        self.joint.OUT = self.cases
        self.P = Physics()
        self.data = inputs()
        self.radio = Radio(self.data)
        self.base = read(BASE / 'solution_q3.json')
        self.sites = read(BASE / 'relay_sites.json')
        self.site_ids = {s['id'] for s in self.sites}
        self.atoms = read(BASE / 'coverage_atoms.json')
        self.base_sites = copy.deepcopy(self.sites)
        self.atom_site_version = {rid: len(self.sites) for rid in self.atoms}
        self.route_bank = {r['id']: r for r in read(BASE / 'candidate_pool.json')}
        self.geometry_attempts = []
        self.site_seen = {(round(s['lon'], 10), round(s['lat'], 10), round(s['agl'], 4)) for s in self.sites}
        self.validate = __import__('validate_q3').run
        self.import_q2()

    def stopped(self, reserve=0):
        return self.stop_path.exists() or time.monotonic() + reserve >= self.deadline

    def pulse(self, phase, **extra):
        best = min(self.archive, key=lambda r: (r['metrics']['C'], r['metrics']['E'])) if self.archive else None
        status = dict(pid=os.getpid(), phase=phase, elapsed_s=time.monotonic()-self.started,
                      budget_s=self.args.seconds, cases=len(self.records), accepted=len(self.archive),
                      q2_structures=len(self.q2), sites=len(self.sites),
                      best=None if best is None else {k:best[k] for k in ('id', 'path', 'metrics')}, **extra)
        write(self.out / 'status.json', status)
        print(json.dumps(status, ensure_ascii=False), flush=True)

    def import_q2(self):
        sources = []
        initial = [PROJECT / 'review_runs/20260924_background_v3/cases/q2_fast_critical_three_routes/solution.json',
                   PROJECT / 'review_runs/20260924_v1/q2/results/ABC_batch_reopt_24/solution.json']
        sources.extend((p, 'verified_current_release') for p in initial)
        index = HERE / 'q2/elites/index.json'
        if index.exists():
            try:
                for item in read(index).get('elites', []):
                    path = (HERE / item['path']).resolve()
                    if not path.is_relative_to(HERE.resolve()):
                        continue
                    folder = path if path.is_dir() else path.parent
                    report = folder / 'candidate_review.json'
                    if report.exists() and read(report).get('accepted'):
                        sources.append((folder / 'solution.json', 'new_Q2_independent_replay_pass'))
            except (OSError, ValueError, KeyError):
                pass  # Writers publish atomically; a transient missing entry is retried.
        for path, label in sources:
            if not path.exists():
                continue
            rows = read(path)
            if not isinstance(rows, list) or not rows:
                continue
            c = max(r['return'] for r in rows)
            energy = sum(r['route']['energy'] for r in rows)
            if c > 6900 or energy > 72:
                continue
            key = route_key(rows)
            previous = self.q2.get(key)
            if previous and previous['C'] <= c + 1e-7:
                continue
            self.q2[key] = dict(key=key, rows=rows, C=c, E=energy, N=len(rows),
                                source=str(path.relative_to(PROJECT)), sha256=sha(path), validation=label)
            for row in rows:
                route = row['route']
                checked = self.P.evaluate(route['model'], route['stops'])
                if checked is not None and checked['id'] == route['id']:
                    self.route_bank[route['id']] = checked
        write(self.out / 'q2_sources.json', [{k:v for k,v in r.items() if k != 'rows'} for r in self.q2.values()])

    def accept(self, directory, source):
        solution = read(directory / 'solution_q3.json')
        if list(solution.get('resources', [])) != [2, 6]:
            raise ValueError('Original two relay aircraft / six energy components must be preserved.')
        self.pulse('independent_continuous_replay', candidate=directory.name)
        checked = self.validate(directory / 'solution_q3.json', margin=8, obstacle=10, save=True)
        station = station_audit(directory / 'transport_validation')
        write(directory / 'station_delivery_validation.json', station)
        s = checked['summary']
        valid = (s['valid'] and s['D'] < 1e-6 and station['D_station'] < 1e-6 and
                 station['late_boxes'] == 0 and station['hard_violations'] == 0 and
                 station['hard_boxes'] == 31 and station['boxes'] == station['unique_boxes'] == 80 and
                 s['gap_seconds'] < 1e-9 and s['unknown_intervals'] == 0)
        metrics = dict(C=s['C_joint'], E=s['E_total'], N=s['N_transport'] + s['N_relay'],
                       N_transport=s['N_transport'], N_relay=s['N_relay'], D=s['D'],
                       D_station=station['D_station'], late_boxes=station['late_boxes'],
                       hard_violations=station['hard_violations'], gap_seconds=s['gap_seconds'])
        caps = read(directory/'input_contract.json') if (directory/'input_contract.json').exists() else {}
        cap_checks = dict(C=caps.get('max_C') is None or metrics['C'] <= caps['max_C']+1e-6,
                          E=caps.get('max_E') is None or metrics['E'] <= caps['max_E']+1e-9,
                          N_transport=caps.get('max_transport') is None or metrics['N_transport'] <= caps['max_transport'])
        valid = valid and all(cap_checks.values())
        report = dict(accepted=valid, metrics=metrics, validation=s, station={k:v for k,v in station.items() if k != 'rows'},
                      source=source, resources=[2, 6], promotion_allowed=False, needs_Q4_recompute=True,
                      geometry='All continuous open intervals and separate event points, plus independent GEOS ray cross-checks.',
                      cap_checks=cap_checks, solution_sha256=sha(directory / 'solution_q3.json'))
        write(directory / 'candidate_review.json', report)
        if not valid:
            return report
        ident = report['solution_sha256'][:18]
        if any(a['id'] == ident for a in self.archive):
            return report
        elite = self.out / 'elites' / ident
        if not elite.exists():
            shutil.copytree(directory, elite)
        entry = dict(id=ident, path=elite.relative_to(HERE).as_posix(), metrics=metrics,
                     route_key=route_key(solution['transport']), source=source,
                     solution_sha256=report['solution_sha256'])
        self.archive.append(entry)
        # Keep all verified structures in the index; selection is diverse and does
        # not discard a slower intermediate merely because it is dominated.
        write(self.out / 'elites/index.json', dict(updated_at=time.time(), elites=self.archive,
                                                 physical_inventory=[2, 6], all_station_zero_lateness=True))
        best = min(self.archive, key=lambda r:(r['metrics']['C'], r['metrics']['E']))
        write(self.out / 'best.json', best)
        return report

    def new_sites(self, warm, round_number):
        from setup_q3 import INVERSE
        from sites import relay_metrics
        if len(self.sites) >= 96:
            return
        active = [r['site'] for r in warm['relay']]
        # Different radii, orientations, heights and remote existing seeds escape
        # the former +/-120 m neighborhood. Every point retains exact terrain.
        anchors = active + self.rng.sample(self.base_sites, min(3, len(self.base_sites)))
        radius = [120., 350., 700., 1600., 70., 2500.][round_number % 6]
        self.rng.shuffle(anchors)
        added = []
        for anchor in anchors:
            angle = self.rng.randrange(8) * math.pi / 4
            for h in [anchor['agl'], self.rng.choice([150., 200., 250., 280., 300.])]:
                if self.stopped(35) or len(added) >= 4:
                    break
                x = anchor['x'] + radius * math.cos(angle)
                y = anchor['y'] + radius * math.sin(angle)
                lon, lat = INVERSE.transform(x, y)
                token = (round(lon, 10), round(lat, 10), round(h, 4))
                if token in self.site_seen:
                    continue
                self.site_seen.add(token)
                m = relay_metrics(self.data, lon, lat, h)
                record = dict(parent=anchor['id'], radius=radius, lon=lon, lat=lat, agl=h, accepted=False)
                if m is None or m['max_service'] <= 0:
                    record['reason'] = 'outside_DEM_or_energy'
                else:
                    back = self.radio.point(self.data['gateway'], [m['x'],m['y'],m['z']], 'backhaul')
                    if back['valid']:
                        sid = 'S4_' + hashlib.sha256(json.dumps(token).encode()).hexdigest()[:12]
                        m.update(id=sid, cover=[], parent_site=anchor['id'])
                        self.sites.append(m)
                        self.site_ids.add(sid)
                        added.append(sid)
                        record.update(accepted=True, id=sid, backhaul_margin=back['margin'])
                    else:
                        record.update(reason='backhaul', backhaul_margin=back['margin'])
                self.geometry_attempts.append(record)
            if len(added) >= 4:
                break
        write(self.out / 'site_search.json', dict(attempts=self.geometry_attempts, sites=self.sites))

    def ensure_atoms(self, pool, prep_seconds=80):
        from atoms import build_route, all_pass
        from communication import phases
        begun = time.monotonic()
        result = {}
        for route in pool:
            if self.stopped(25) or time.monotonic() - begun > prep_seconds:
                return None
            rid = route['id']
            if rid not in self.atoms:
                self.atoms[rid], _ = build_route(route, self.P, self.radio, self.sites, max_block=30)
                self.atom_site_version[rid] = len(self.sites)
            elif self.atom_site_version[rid] < len(self.sites):
                extra = self.sites[self.atom_site_version[rid]:]
                phase_map = {p['phase']:p for p in phases(route, self.P)}
                profile_cache = {}
                refined = []
                for atom in self.atoms[rid]:
                    p = phase_map[atom['phase']]
                    dt = p['b'] - p['a']
                    if atom['phase'] not in profile_cache:
                        profile_cache[atom['phase']] = {
                            s['id']: self.radio.profile([s['x'],s['y'],s['z']], p['p0'],p['p1'],'access') for s in extra}
                    profiles = profile_cache[atom['phase']]
                    lo, hi = (atom['a']-p['a'])/dt, (atom['b']-p['a'])/dt
                    cuts = {lo, hi}
                    for profile in profiles.values():
                        for a,b,_ in profile['pieces']:
                            if lo < a < hi:cuts.add(a)
                            if lo < b < hi:cuts.add(b)
                        cuts.update(v for v in profile['events'] if lo < v < hi)
                    ordered = sorted(cuts)
                    for a,b in zip(ordered, ordered[1:]):
                        available = list(atom['sites']) + [sid for sid,prof in profiles.items() if all_pass(prof,a,b)]
                        refined.append(dict(a=p['a']+a*dt,b=p['a']+b*dt,sites=available,phase=atom['phase']))
                self.atoms[rid] = refined
                self.atom_site_version[rid] = len(self.sites)
            result[rid] = self.atoms[rid]
        return result

    def mutations(self, rows, limit=25):
        """Add complete 2-task replacements, including relocation/merge/model swaps.

        This generates new physical columns and does not constrain search to the
        old pool. Boxes in every replacement union are conserved exactly.
        """
        routes = [r['route'] for r in rows]
        pool = {}
        candidates = list(routes)
        self.rng.shuffle(candidates)
        for route in candidates[:6]:
            for model in self.P.models:
                r = self.P.evaluate(model, route['stops'])
                if r is not None:pool[r['id']] = r
        for _ in range(30):
            if len(pool) >= limit or self.stopped(35):
                break
            a,b = self.rng.sample(routes, 2)
            move = self.rng.choice(a['boxes'])
            residual = [(s,[x for x in bs if x != move]) for s,bs in a['stops']]
            dest = self.P.boxes[move]['service']
            merged = [(s,list(bs)) for s,bs in b['stops']]
            if any(s == dest for s,_ in merged):
                next(bs for s,bs in merged if s == dest).append(move)
            else:
                merged.insert(self.rng.randrange(len(merged)+1), (dest,[move]))
            aa = [self.P.evaluate(model,residual) for model in self.P.models] if len(a['boxes']) > 1 else [None]
            bb = [self.P.evaluate(model,merged) for model in self.P.models]
            aa = [x for x in aa if x is not None] if len(a['boxes']) > 1 else [None]
            bb = [x for x in bb if x is not None]
            if aa and bb:
                key = self.rng.choice(['energy','duration'])
                replacement = ([] if aa == [None] else [min(aa,key=lambda r:r[key])]) + [min(bb,key=lambda r:r[key])]
                assert set(x for r in replacement for x in r['boxes']) == set(a['boxes']) | set(b['boxes'])
                for r in replacement:pool[r['id']] = r
        return list(pool.values())

    def warm_solution(self, round_number):
        ranked = sorted(self.archive, key=lambda a:(a['metrics']['C'],a['metrics']['E']))
        if round_number % 4 in (0,1):
            item = ranked[0]
        elif round_number % 4 == 2:
            close = [r for r in ranked if r['metrics']['C'] <= ranked[0]['metrics']['C'] + 400]
            item = min(close,key=lambda r:r['metrics']['E'])
        else:
            item = self.rng.choice(ranked)
        sol = read(HERE / item['path'] / 'solution_q3.json')
        for j,row in enumerate(sorted(sol['relay'],key=lambda r:r['start'])):
            row['slot'] = j
        return sol, item

    def run_round(self, number):
        self.import_q2()
        warm, parent = self.warm_solution(number)
        choices = sorted(self.q2.values(), key=lambda r:(self.attempts[r['key']],r['C'],r['E']))
        target = choices[0] if choices else None
        if target:self.attempts[target['key']] += 1
        mode = number % 8
        fixed_shape = mode in (1,5) and target is not None
        if number > 0 and number % 3 == 0:
            self.new_sites(warm, number)
        if fixed_shape:
            pool = {r['route']['id']:r['route'] for r in target['rows']}
        else:
            pool = {r['route']['id']:r['route'] for r in warm['transport']}
            if target is not None:
                pool.update({r['route']['id']:r['route'] for r in target['rows']})
            if mode in (2,4,6,7):
                others = list(self.q2.values())
                if others:
                    other = self.rng.choice(others)
                    pool.update({r['route']['id']:r['route'] for r in other['rows']})
                for r in self.mutations(warm['transport']):pool[r['id']] = r
        self.pulse('geometry_preparation', iteration=number, pool=len(pool), fixed_shape=fixed_shape)
        atoms = self.ensure_atoms(list(pool.values()), prep_seconds=100)
        if atoms is None:
            return dict(iteration=number,status='preparation_budget', pool=len(pool))
        # Incomplete-site alternatives are removed before solving, never relaxed.
        uncovered = [rid for rid,aa in atoms.items() if any(not a['sites'] for a in aa)]
        if fixed_shape and uncovered:
            return dict(iteration=number,status='fixed_route_without_candidate_coverage', routes=uncovered)
        for rid in uncovered:
            pool.pop(rid,None);atoms.pop(rid,None)
        c_best = min(r['metrics']['C'] for r in self.archive)
        best_e = min(r['metrics']['E'] for r in self.archive if r['metrics']['C'] <= c_best+120)
        caps = [c_best+.1, max(6350.,c_best+120), c_best+180, max(5940.,c_best-60), c_best+300,
                max(6600.,c_best+250), c_best+60, max(6000.,c_best-20)]
        cap = caps[mode]
        objective = ('E','C') if mode in (2,4,6) else ('C','E')
        energy_cap = None if fixed_shape or mode == 4 else (best_e+.75 if mode in (2,6) else 72.)
        max_transport = 23 if mode == 7 else None
        slots = [4,4,5,4,6,6,5,4][mode]
        name = f'round_{number:04d}_{"fixed_q2" if fixed_shape else "joint"}_{objective[0]}_r{slots}'
        directory = self.cases / name
        directory.mkdir(exist_ok=True)
        contract = dict(iteration=number, mode=mode, seed=self.args.seed+number*1009, slots=slots,
                        resources=[2,6], pool=len(pool), atoms=sum(len(a) for a in atoms.values()),
                        sites=len(self.sites), max_C=cap, max_E=energy_cap, max_transport=max_transport,
                        objectives=objective, zero_station_lateness=True, fixed_route_set=fixed_shape,
                        parent=parent, q2_source=None if target is None else {k:v for k,v in target.items() if k != 'rows'},
                        delivery='all handover at stop completed', grid_s=.1, no_global_optimality_claim=True)
        write(directory / 'input_contract.json', contract)
        write(directory / 'candidate_pool.json', list(pool.values()))
        write(directory / 'relay_sites.json', self.sites)
        write(directory / 'coverage_atoms.json', atoms)
        remaining = self.deadline-time.monotonic()-22
        if remaining <= 2 or self.stop_path.exists():
            return dict(iteration=number,status='deadline_before_solver')
        # Early shorter restarts improve structural diversity. Later cases spend
        # more time on each neighborhood, instead of one four-hour trapped solve.
        seconds = min(150. if number < 8 else 240., max(1.,remaining/len(objective)))
        self.pulse('joint_solver', candidate=name, per_stage_seconds=seconds, contract=contract)
        result = self.joint.solve(name, seconds=seconds, slots=slots, seed=contract['seed'],
                                  pool=list(pool.values()), atoms=atoms, sites_override=self.sites,
                                  zero_late=True, resources=(2,6), max_C=cap, max_E=energy_cap,
                                  max_transport=max_transport, objectives=objective, workers=self.args.workers,
                                  warm=None if fixed_shape else warm, complete_warm=not fixed_shape,
                                  fix_route_ids=set(pool) if fixed_shape else None,
                                  deadline=self.deadline-18, stop_path=self.stop_path)
        if result is None:
            write(directory / 'candidate_review.json', dict(accepted=False, status='no_incumbent',
                  note='A bounded search without an incumbent does not prove physical infeasibility.'))
            return dict(iteration=number,status='no_incumbent', path=directory.relative_to(HERE).as_posix())
        report = self.accept(directory, dict(type='new_joint_search', contract=str((directory/'input_contract.json').relative_to(HERE))))
        return dict(iteration=number,status='accepted' if report['accepted'] else 'rejected',
                    path=directory.relative_to(HERE).as_posix(),metrics=report['metrics'])

    def run(self):
        write(self.out / 'run_contract.json', dict(started_at=time.time(), budget_seconds=self.args.seconds,
              seed=self.args.seed, workers=self.args.workers, baseline=str(BASE.relative_to(PROJECT)),
              baseline_sha256=sha(BASE/'solution_q3.json'), input_hashes={p.name:sha(p) for p in (HERE/'inputs').glob('*.json')},
              source_sha256={p.relative_to(HERE).as_posix():sha(p) for p in
                             [HERE/'q3_search.py']+[HERE/'src/q3'/n for n in
                              ['joint_batch.py','atoms.py','validate_q3.py','communication.py','sites.py','setup_q3.py']]+[
                              HERE/'src/q2'/n for n in ['routes.py','validate.py','prepare.py']]},
              target=dict(C_joint_below_s=5940,E_total_below_kwh=69,N_transport=23,N_relay=4),
              aspiration_only=True, original_constraints_preserved=True, promotion_allowed=False,
              algorithm='Multiple complete transport route sets, physical 2-route replacement columns, CP-SAT joint scheduling, multi-radius lawful relay sites, epsilon-constraint Pareto exploration, independent continuous replay.',
              stop_file=str(self.stop_path), stages_may_stop_early_only_at_budget_or_STOP=True))
        self.pulse('baseline_replay')
        baseline = self.cases / 'baseline'
        baseline.mkdir(exist_ok=True)
        write(baseline/'solution_q3.json',self.base)
        report = self.accept(baseline,dict(type='verified_v3_baseline',path=str(BASE.relative_to(PROJECT))))
        if not report['accepted']:
            raise RuntimeError('Baseline independent replay failed; stop search.')
        # Retain any independently verified pilot/resume improvements. Replaying
        # them here avoids treating an old search log as current certification.
        startup = {}
        for index in HERE.glob('q3*/elites/index.json'):
            try:
                for item in read(index).get('elites', []):
                    folder = (HERE/item['path']).resolve()
                    if not folder.is_relative_to(HERE.resolve()) or not (folder/'candidate_review.json').exists():continue
                    review = read(folder/'candidate_review.json')
                    metrics = review.get('metrics', {})
                    if not review.get('accepted') or metrics.get('C',1e9)>6400:continue
                    if metrics.get('C',1e9)>=report['metrics']['C']-1e-6 and metrics.get('E',1e9)>=report['metrics']['E']-1e-9:continue
                    startup[sha(folder/'solution_q3.json')] = (folder, metrics)
            except (OSError,ValueError,KeyError):
                continue
        for digest,(folder,metrics) in sorted(startup.items(),key=lambda kv:(kv[1][1]['C'],kv[1][1]['E']))[:5]:
            if self.stopped(40):break
            saved = read(folder/'solution_q3.json')
            for row in saved['relay']:
                if row['site']['id'] not in self.site_ids:
                    self.sites.append(row['site']);self.site_ids.add(row['site']['id'])
            seed = self.cases/('seed_'+digest[:16]);seed.mkdir(exist_ok=True)
            write(seed/'solution_q3.json',saved)
            self.accept(seed,dict(type='independently_replayed_pilot_or_resume',path=folder.relative_to(HERE).as_posix()))
        number = 0
        while not self.stopped(28):
            try:
                record = self.run_round(number)
            except Exception as exc:
                record = dict(iteration=number,status='error',error=str(exc),traceback=traceback.format_exc())
                print(record['traceback'],flush=True)
            self.records.append(record)
            write(self.out/'iterations.json',self.records)
            self.pulse('iteration_complete',last=record)
            number += 1
            if len(self.records)>=3 and all(r['status']=='error' for r in self.records[-3:]):
                raise RuntimeError('Three consecutive implementation failures; see iterations.json.')
        self.pulse('stopped_by_request' if self.stop_path.exists() else 'budget_completed')
        return self.archive


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds',type=float,default=14400)
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--seed',type=int,default=20260925)
    parser.add_argument('--output',default='q3')
    args = parser.parse_args()
    assert args.seconds > 0 and args.workers > 0
    runner = None
    try:
        runner = Search(args)
        runner.run()
    except Exception as exc:
        out = HERE / args.output
        write(out/'fatal_error.json',dict(error=str(exc),traceback=traceback.format_exc()))
        if runner:runner.pulse('failed',error=str(exc))
        raise


if __name__ == '__main__':
    main()
