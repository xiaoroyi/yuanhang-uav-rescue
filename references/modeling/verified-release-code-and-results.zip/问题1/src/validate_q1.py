"""Independent checker: original inputs, separate float physics, GEOS terrain.

No optimizer, pattern generator or flight_physics import is used.
"""
import bootstrap
import math
from collections import Counter
from data_io import read_inputs
from terrain import independent_geometry

def validate(data,rows,rho=.2,geometry=None,eta_scale=1.):
    errors=[]; details=[]
    if geometry is None:
        geometry={s:independent_geometry(data,s) for s in data['services']}
    byid={b['id']:b for b in data['boxes']}
    observed=[]; total_fly=0; Csorties=0; Cboxes=0; work=0
    def fail(batch,kind,actual=None,limit=None):
        errors.append(dict(batch=batch,kind=kind,actual=actual,limit=limit))
    for row in rows:
        ident=row.get('batch','unknown'); ids=row['boxes']; observed.extend(ids)
        if not ids: fail(ident,'empty_batch'); continue
        if any(x not in byid for x in ids): fail(ident,'unknown_box'); continue
        bs=[byid[x] for x in ids]
        s=row['service']; g=row['model']
        if g not in data['models'] or s not in data['services']: fail(ident,'invalid_model_or_service'); continue
        if any(b['service']!=s for b in bs): fail(ident,'cross_service')
        m=data['models'][g]; mass=sum(b['weight'] for b in bs); volume=sum(b['volume_L'] for b in bs); n=len(bs)
        if mass>m['Q']: fail(ident,'mass_exceeded',mass,m['Q'])
        if volume>m['volume_L']: fail(ident,'volume_exceeded',volume,m['volume_L'])
        distance,H=geometry[s]; origin=data['nodes']['O01']['z']; target=data['nodes'][s]['z']+30
        effective=m['L0']-(m['L0']-m['LF'])*(mass/m['Q'])**1.5
        if effective<=0: fail(ident,'invalid_effective_range'); continue
        # Separate outgoing and empty returning legs, calculated here directly.
        energy=m['Euse']*distance/effective+(m['m0']+mass)*9.81*(H-origin)/(m['eta']*eta_scale*3600000)
        energy+=m['Euse']*distance/m['L0']+m['m0']*9.81*(H-target)/(m['eta']*eta_scale*3600000)
        soc=1-energy/m['Euse']
        fly=(H-origin)/m['up']+distance/m['speed']+(H-target)/m['down']+(H-target)/m['up']+distance/m['speed']+(H-origin)/m['down']
        prep=m['prep']+n*m['load']; hand=m['handover']+n*m['handover_box']; operation=prep+fly+hand
        if energy>(1-rho)*m['Euse']+1e-10: fail(ident,'energy_exceeded',energy,(1-rho)*m['Euse'])
        expected=dict(mass_kg=mass,volume_L=volume,E=energy,SOC=soc,flight_time_s=fly,preparation_time_s=prep,handover_time_s=hand,air_time_s=fly+hand,operation_time_s=operation,T=operation)
        for key,value in expected.items():
            if key not in row or not math.isclose(float(row[key]),value,rel_tol=1e-11,abs_tol=1e-9): fail(ident,'wrong_'+key,row.get(key),value)
        details.append(dict(batch=ident,mass_slack_kg=m['Q']-mass,volume_slack_L=m['volume_L']-volume,energy_slack_kwh=(1-rho)*m['Euse']-energy,SOC_slack=soc-rho,recomputed_E_kwh=energy,recomputed_T_s=operation))
        total_fly+=fly; work+=operation; Csorties+=g=='C'; Cboxes+=n if g=='C' else 0
    if Counter(observed)!=Counter(byid.keys()):
        fail('all','box_coverage',dict(Counter(observed)-Counter(byid.keys())),dict(Counter(byid.keys())-Counter(observed)))
    identity=total_fly+450*len(rows)+60*len(observed)+30*Csorties+6*Cboxes
    if not math.isclose(work,identity,abs_tol=1e-7): fail('all','time_identity',work,identity)
    return dict(status='PASS' if not errors else 'FAIL',errors=errors,checked_batches=len(rows),checked_boxes=len(observed),details=details,time_identity_s=identity,total_energy_kwh=sum(r['recomputed_E_kwh'] for r in details),total_operation_s=work)

if __name__=='__main__':
    import argparse,json
    from data_io import dump
    parser=argparse.ArgumentParser()
    parser.add_argument('solution'); parser.add_argument('--rho',type=float,default=.2)
    args=parser.parse_args()
    data=read_inputs()
    rows=json.load(open(args.solution,encoding='utf-8'))
    result=validate(data,rows,args.rho)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result['status']=='PASS' else 1)
