"""Plot only saved numerical evidence. PNG plus PDF, no interactive window."""
import bootstrap
import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

def plot_results(out):
    def read(name):
        with (out/name).open(encoding='utf-8-sig') as f: return list(csv.DictReader(f))
    figs=out/'figures';figs.mkdir(exist_ok=True)
    font='Microsoft YaHei' if any(f.name=='Microsoft YaHei' for f in font_manager.fontManager.ttflist) else 'DejaVu Sans'
    manifest=[]
    def save(fig,name,source,caption):
        for ext in ('png','pdf'): fig.savefig(figs/f'{name}.{ext}',dpi=250,facecolor='white')
        manifest.append(dict(figure=name,source=source,caption=caption,png_dpi=250,figsize_inches=fig.get_size_inches().tolist()))
        plt.close(fig)
    with plt.rc_context({'font.family':font,'font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42}):
        caps=read('safe_capacity.csv');sites=sorted({r['service'] for r in caps})
        fig,axes=plt.subplots(1,3,figsize=(13,4.8),layout='constrained',sharey=True)
        for ax,g,color in zip(axes,'ABC',['#0072B2','#D55E00','#009E73']):
            rs=[next(r for r in caps if r['service']==s and r['model']==g) for s in sites]
            y=np.arange(len(sites))
            ax.barh(y,[float(r['capacity_kg']) if r['capacity_kg'] else 0 for r in rs],color=color,alpha=.75,label='连续安全载荷')
            ax.scatter([float(r['attainable_kg']) if r['attainable_kg'] else 0 for r in rs],y,marker='x',color='#222222',label='本区实际可装质量',zorder=3)
            ax.set(yticks=y,yticklabels=sites,xlabel='载荷 / kg',title=f'{g}型：20%安全余量',xlim=(0,{'A':27,'B':32,'C':84}[g])); ax.grid(axis='x',alpha=.2)
        axes[0].invert_yaxis()
        handles,labels=axes[2].get_legend_handles_labels()
        fig.legend(handles,labels,loc='outside lower center',ncol=2,fontsize=9)
        save(fig,'45项安全载荷',['safe_capacity.csv'],'连续质量能量边界与本区不可拆货箱可装载质量；同图不同机型横轴上限不同。')
        events=read('reserve_events.csv');intervals=[r for r in events if r['kind']=='open_interval' and r['feasible']=='True']
        ss=json.loads((out/'sensitivity_summary.json').read_text(encoding='utf-8'))
        fig,axes=plt.subplots(2,1,figsize=(9,7),layout='constrained',sharex=True)
        x=[float(r['left'])*100 for r in intervals]; end=float(ss['feasibility_limit'])*100
        for ax,key,ylabel in zip(axes,['N','E_kwh'],['最优架次数','主优先级总能耗 / kWh']):
            values=[float(r[key]) for r in intervals]
            ax.step(x+[end],values+[values[-1]],where='post',color='#0072B2')
            ax.axvline(20,color='#222222',linestyle='--',label='基准20%')
            ax.axvline(float(ss['stable_rho'])*100,color='#D55E00',linestyle=':',label='当前方案稳定上界')
            ax.axvline(end,color='#CC79A7',linestyle='-.',label='全任务可行极限')
            ax.set(ylabel=ylabel,xlim=(0,100));ax.grid(alpha=.2)
            ax.axvspan(end,100,color='#eeeeee');ax.text((end+100)/2,.88,'不可行',transform=ax.get_xaxis_transform(),ha='center')
        axes[0].legend(fontsize=8,loc='upper left');axes[1].set_xlabel('统一返航安全余量 / %')
        save(fig,'安全余量临界分析',['reserve_events.csv','sensitivity_summary.json'],'阶梯表示开区间解；精确临界点含边界时采用左侧可行解，详见事件表。灰色为不可行。')
        priorities=read('objective_priorities.csv');fig,ax=plt.subplots(figsize=(7,4.8),layout='constrained')
        grouped={}
        for r in priorities:
            grouped.setdefault((r['T_s'],r['E_kwh'],r['N']),[]).append(r['priority'])
        for ((t,e,n),names),mark in zip(grouped.items(),['o','^','s','D']):
            ax.scatter(float(t)/3600,float(e),s=65,marker=mark,label=f"{' = '.join(names)}：{n}架次")
        ax.set(xlabel='累计作业 / 架次·小时（不是并行完工时间）',ylabel='总能耗 / kWh',title='不同目标优先级的真实取舍');ax.grid(alpha=.2);ax.legend()
        save(fig,'目标优先级对比',['objective_priorities.csv'],'不同词典序偏好产生不同架次、能耗与累计作业时间；不是完整Pareto前沿。')
        geos=json.loads((out/'terrain_evidence.json').read_text(encoding='utf-8'));inputs=json.loads((out/'normalized_inputs.json').read_text(encoding='utf-8'))
        fig,ax=plt.subplots(figsize=(8,6.5),layout='constrained')
        for s,g in geos.items():
            ll=np.array(g['route_lonlat']);ax.plot(ll[:,0],ll[:,1],color='#0072B2',lw=1,alpha=.65)
            n=inputs['nodes'][s];ax.scatter(n['lon'],n['lat'],color='#D55E00',s=20);ax.annotate(s,(n['lon'],n['lat']),xytext=(4,4),textcoords='offset points',fontsize=8)
            ax.scatter(g['highest_lon'],g['highest_lat'],marker='x',s=25,color='#333333')
        n=inputs['nodes']['O01'];ax.scatter(n['lon'],n['lat'],marker='*',s=160,color='#222222',label='O01');ax.annotate('O01',(n['lon'],n['lat']),xytext=(-20,-15),textcoords='offset points')
        ax.scatter([],[],marker='x',color='#333333',label='各航段最高DEM像元');ax.set(xlabel='经度 / °E',ylabel='纬度 / °N',title='Q1规定直线航段与最高地形像元（非绕障路径）');ax.set_aspect(1/np.cos(np.deg2rad(23)));ax.ticklabel_format(useOffset=False);ax.legend();ax.grid(alpha=.2)
        save(fig,'航段与最高像元',['terrain_evidence.json','normalized_inputs.json'],'米制直线反投影；每线标记原始DEM最高接触像元，无底图插值。')
    (figs/'figure_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
