import bootstrap
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from flight_physics import D
from solver import summary

def model(data,patterns,rho=D('.2')):
    ps=[p for p in patterns if p['SOC']>=rho]
    matrix=np.zeros((len(data['services'])*4,len(ps)))
    rhs=np.array([n for s in data['services'] for n in data['counts'][s]])
    for j,p in enumerate(ps):
        i=data['services'].index(p['service'])*4
        matrix[i:i+4,j]=p['counts']
    costs=np.array([[1.,float(p['E']),float(p['T'])] for p in ps]).T
    return ps,matrix,rhs,costs

def optimize(data,patterns,order=(0,1,2),n_cap=None,t_cap=None):
    ps,A,b,costs=model(data,patterns)
    constraints=[LinearConstraint(A,b,b)]
    if n_cap is not None: constraints.append(LinearConstraint(costs[0],-np.inf,n_cap))
    if t_cap is not None: constraints.append(LinearConstraint(costs[2],-np.inf,t_cap))
    stages=[]; chosen=None
    for obj in order:
        res=milp(costs[obj],integrality=np.ones(len(ps)),bounds=Bounds(0,np.inf),constraints=constraints,options={'mip_rel_gap':0.,'time_limit':60.})
        stage=dict(objective=['N','E','T'][obj],status=int(res.status),message=res.message,objective_value=None if res.fun is None else float(res.fun),dual_bound=None if getattr(res,'mip_dual_bound',None) is None else float(res.mip_dual_bound),gap=None if getattr(res,'mip_gap',None) is None else float(res.mip_gap))
        stages.append(stage)
        if not res.success:
            return None,stages
        counts=np.rint(res.x).astype(int)
        assert np.max(abs(res.x-counts))<1e-5 and np.all(A@counts==b)
        chosen=[p for p,k in zip(ps,counts) for _ in range(k)]
        value=float(costs[obj]@counts)
        stage['recomputed_integer_objective']=value
        stage['raw_to_integer_objective_difference']=value-float(res.fun)
        # MIP feasibility is floating point. Explicit energy/time budget tolerance,
        # then compare final unrounded totals to high precision DP independently.
        tol=0 if obj==0 else (1e-8 if obj==1 else 1e-5)
        stage['fix_tolerance']=tol
        constraints.append(LinearConstraint(costs[obj],value-tol,value+tol))
    return chosen,stages

def sampled_tradeoffs(data,patterns,nstar,save_and_validate):
    rows=[]; evidence=[]
    for k in range(3):
        energy,stages=optimize(data,patterns,order=(1,2),n_cap=nstar+k)
        fast,stages_t=optimize(data,patterns,order=(2,1),n_cap=nstar+k)
        evidence.extend([dict(N_cap=nstar+k,kind='min_energy',stages=stages),dict(N_cap=nstar+k,kind='min_time',stages=stages_t)])
        if energy is None or fast is None: continue
        save_and_validate(f'epsilon_N{nstar+k}_energy_endpoint',energy)
        save_and_validate(f'epsilon_N{nstar+k}_time_endpoint',fast)
        et,tt=summary(energy)['T_s'],summary(fast)['T_s']
        for sample,theta in enumerate(np.linspace(tt,et,5)):
            sol,ev=optimize(data,patterns,order=(1,),n_cap=nstar+k,t_cap=float(theta)+1e-5)
            evidence.append(dict(N_cap=nstar+k,time_cap_s=float(theta),stages=ev))
            values=summary(sol)
            if sol is not None:
                assert values['N']<=nstar+k and values['T_s']<=float(theta)+1e-4
                save_and_validate(f'epsilon_N{nstar+k}_sample{sample}',sol)
            rows.append(dict(kind='epsilon_sample',N_cap=nstar+k,time_cap_s=float(theta),**values,validation='PASS' if sol is not None else 'infeasible_or_unsolved'))
    for r in rows:
        r['nondominated_in_sample']=r['feasible'] and not any(v['feasible'] and all(v[k]<=r[k]+1e-7 for k in ('N','E_kwh','T_s')) and any(v[k]<r[k]-1e-7 for k in ('N','E_kwh','T_s')) for v in rows)
    return rows,evidence
