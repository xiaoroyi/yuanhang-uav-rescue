import bootstrap
from flight_physics import D, safe_capacity
from solver import solve_all, summary, local_dp, assign_boxes
from validate_q1 import validate

def run_sensitivity(data,geos,patterns,main):
    geometry={s:(g['distance_m'],g['cruise_m']) for s,g in geos.items()}
    grid=[]; capacities=[]
    for rho in ('.10','.15','.20','.25','.30','.35','.40'):
        sol=solve_all(data,patterns,D(rho))
        report=None if sol is None else validate(data,assign_boxes(data,sol),float(rho),geometry)
        assert report is None or report['status']=='PASS'
        bad=[s for s in data['services'] if local_dp(data['counts'][s],[p for p in patterns if p['service']==s and p['SOC']>=D(rho)],(0,1,2)) is None] if sol is None else []
        grid.append(dict(rho=float(rho),**summary(sol),validation='infeasible' if report is None else report['status'],infeasible_services=bad))
        for s in data['services']:
            for g,m in data['models'].items():
                capacities.append(dict(service=s,model=g,**safe_capacity(m,geos[s],D(rho))))
    # Cache by actual feasible local pattern set; many global events do not change a site.
    cache={}; grouped={s:[p for p in patterns if p['service']==s] for s in data['services']}
    def event_solution(rho):
        chosen=[]; bad=[]
        for s,ps in grouped.items():
            feasible=[p for p in ps if p['SOC']>=rho]
            key=(s,tuple(p['id'] for p in feasible))
            if key not in cache: cache[key]=local_dp(data['counts'][s],feasible,(0,1,2))
            result=cache[key]
            if result is None: bad.append(s)
            else: chosen.extend(result[1])
        if not bad:
            check=validate(data,assign_boxes(data,chosen),float(rho),geometry)
            assert check['status']=='PASS',check['errors']
        return None if bad else chosen,bad
    critical=sorted({D(0),D(1)}|{p['SOC'] for p in patterns if 0<p['SOC']<1})
    events=[]; breaks=[]; last=None; previous=None
    for idx,c in enumerate(critical):
        sol,bad=event_solution(c)
        at=dict(kind='boundary',rho=str(c),left=str(c),right=str(c),**summary(sol),infeasible_services=bad)
        events.append(at)
        if idx+1<len(critical):
            nxt=critical[idx+1]; representative=(c+nxt)/2
            sol,bad=event_solution(representative)
            interior=dict(kind='open_interval',rho=str(representative),left=str(c),right=str(nxt),**summary(sol),infeasible_services=bad)
            events.append(interior)
            state=tuple(interior.get(k) for k in ('feasible','N','E_kwh','T_s'))
            if last is not None and state!=last:
                lost=[p for p in patterns if p['SOC']==c]
                breaks.append(dict(critical_rho=str(c),inclusive_boundary_N=at['N'],before=previous,after=interior,lost_patterns=[p['id'] for p in lost]))
            last=state; previous=interior
    singles=[]
    for b in data['boxes']:
        candidates=[p for p in patterns if p['service']==b['service'] and p['box_count']==1 and p['counts'][('MED','WAT','FOD','HYG').index(b['category'])]==1]
        if not candidates: raise ValueError('box has no physical carrier: '+b['id'])
        best=max(candidates,key=lambda p:p['SOC'])
        singles.append(dict(box=b['id'],service=b['service'],category=b['category'],model=best['model'],rho=best['SOC']))
    bottleneck=min(singles,key=lambda x:x['rho'])
    bound=bottleneck['rho']
    feasible_at,_=event_solution(bound)
    greater=next((c for c in critical if c>bound),D(1))
    above,_=event_solution((bound+greater)/2)
    assert feasible_at is not None and above is None
    stable=min(p['SOC'] for p in main)
    info=dict(stable_rho=str(stable),stable_limiting_patterns=[p['id'] for p in main if p['SOC']==stable],feasibility_limit=str(bound),limiting_boxes=[{**b,'rho':str(b['rho'])} for b in singles if b['rho']==bound],feasible_at_limit=True,infeasible_above_limit=True,candidate_events=len(critical)-2,intervals=len(critical)-1,local_dp_cache_entries=len(cache),analysis_range=[0,1])
    return grid,capacities,events,breaks,info
