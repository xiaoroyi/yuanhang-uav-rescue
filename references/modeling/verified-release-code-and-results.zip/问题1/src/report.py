from bootstrap import ROOT
from pathlib import Path

def mdtable(headers,rows):
    return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(str(x) for x in r)+' |\n' for r in rows)

def write_report(data,geos,m,capacities,services,baselines,priorities,sens,grid,breaks,validation,checks,stages,stress):
    out=ROOT/'results'
    geo_table=mdtable(['服务区','距离m','沿途最高地形m','巡航海拔m','经过像元'],[(s,f"{g['distance_m']:.3f}",f"{g['highest_dem_m']:.3f}",f"{g['cruise_m']:.3f}",g['cell_count']) for s,g in geos.items()])
    cap_table=mdtable(['服务区','A连续/可装kg','B连续/可装kg','C连续/可装kg'],[(s,*[next(f"{r['capacity_kg']:.6f} / {r['attainable_kg']}" if r['capacity_kg'] is not None else '空载不可行' for r in capacities if r['service']==s and r['model']==g) for g in 'ABC']) for s in data['services']])
    service_table=mdtable(['服务区','容量下界','最优架次','A/B/C架次','能耗kWh','作业时间s'],[(r['service'],r['lower_bound'],r['N'],f"{r['A']}/{r['B']}/{r['C']}",f"{r['E_kwh']:.6f}",f"{r['T_s']:.3f}") for r in services])
    def compare_table(rows,name):
        return mdtable([name,'架次','能耗kWh','累计作业s','A/B/C','最小SOC'],[(r[name],r['N'],f"{r['E_kwh']:.6f}" if r['feasible'] else '不可行',f"{r['T_s']:.3f}" if r['feasible'] else '—',f"{r.get('A','—')}/{r.get('B','—')}/{r.get('C','—')}",f"{r['min_SOC']:.4%}" if r['feasible'] else '—') for r in rows])
    after=[r for r in breaks if float(r['critical_rho'])>=.2]
    first=after[0] if after else None
    first_text='未发现' if first is None else f"{float(first['critical_rho']):.9%}，越过后架次由 {first['before']['N']} 变为 {first['after']['N']}（目标或机型变化详见临界表）。"
    report=rf'''# D题第一问：方案核对、模型与完整运行结果

## 1 结论与适用范围

在本报告明确的能耗补充、空间口径与 lex(N,E,T) 目标下，基准20%安全余量得到 **{m['N']}架次、总能耗{m['E_kwh']:.9f} kWh、累计作业时间{m['T_s']:.6f} s（{m['T_s']/3600:.6f}架次·小时）**。机型为 A/B/C={m['A']}/{m['B']}/{m['C']}；最低返航SOC={m['min_SOC']:.9%}。

累计作业时间是各架次准备开始至返航历时之和，**不是多机并行配送完成时间**。第一问不安排具体无人机、电池、时刻或通信。未以本结果声明第二问时限满足或实飞能耗准确。

全部80箱、758kg、2011L恰好交付一次，独立检查{validation['checked_batches']}架次无硬约束违规。架次达到{m['capacity_lower_bound']}的容量下界；在固定最少架次内，数量DP优化能耗及时间，MILP核验一致。

## 2 对 Pro 方案的详细核对

- 第一问边界正确：单点往返、不得跨区；不引入库存、充电和时限排程。
- 数量压缩成立：同一区同类箱子的质量、体积、处理时间相同；第一问不使用逐箱截止时间区分成本。原始箱号、首批身份和截止字段全部保留。
- 644个状态、1887个过滤前模式由原表复算。合法质量体积模式742个；不永久按20%能耗删除，敏感性时重新过滤。
- 各区可分性及DP递推正确。任何组批均可拆出一个模式和剩余状态，完整枚举不会漏分割。相同模式可重复使用。共用词典序且成本可加，所以逐区最优可以组合成全场最优；全场额外时间预算则用MILP，不能误用此分解结论。
- 连续安全载荷随载荷能耗单调，使用二分可行端；实际可装质量还受体积、箱型限制，两者单列。
- 18架次下界正确，而且本次找到达到下界的可行方案，故首目标已证最优。不能把该证明扩大成所有目标同时各自最优。
- 原文爬升公式中的逗号等排版残留按上下文还原为乘号；效率置于分母。两项分量并非原题明确给出，详见下一节。
- 模板“往返时间”没有唯一明示解释，本次按Pro建议填含交接、不含准备的空中任务历时，保留其他时间字段供改口径。
- 几何使用闭像元接触规则与独立GEOS复核，5米/1米折线集合一致；这是数值验证，不是连续投影曲线的解析无漏格证明。
- 有限模式模型的最优性以50位计算与固定30位小数系数为准；每架次能耗/时间系数舍入误差≤5×10⁻³¹，80架次累计≤4×10⁻²⁹。空间输入仍是双精度；不声称无限精度实数或真实飞行全局最优。

## 3 明确采用的假设与公式

节点海拔用Excel；巡航海拔 H=max(原始经过像元)+50m；O01作业高度z0，服务区zi+30m。UTM49N米制直线，EPSG4326原栅格不重采样；5m反投影折线逐段完整遍历，独立1m折线矩形相交。像元中心与边界区分，北向南行序经检查。

$$L_g(q)=L_g^0-(L_g^0-L_g^F)(q/Q_g)^{{3/2}}.$$

补充关系：水平耗电 $E^{{hor}}=E_g^{{use}}d/L_g(q)$；爬升耗电 $E^{{up}}=(m_g^0+q)9.81h^+/[\eta_g(3.6\times10^6)]$。

去程装载q，返程0；四个能耗分项独立保存。空载质量含电池；下降有时间无附加能耗、无能量回收；运输悬停无独立功率字段，不自行补耗电。官方若提供不同能耗关系，须整体重跑。

$$E^{{RT}}_{{gi}}(q)=E_g^{{use}}d_i[1/L_g(q)+1/L_g^0]+\frac{{9.81[(m_g^0+q)(H_i-z_0)+m_g^0(H_i-z_i-30)]}}{{\eta_g(3.6\times10^6)}}.$$

安全条件 $E^{{RT}}\le(1-\rho)E_g^{{use}}$，SOC=$1-E^{{RT}}/E_g^{{use}}$。20%下完整往返限额A/B/C=3.6/3.2/6.4kWh。

飞行时间为 $2d/v_c+(2H-z_0-z_i-30)(1/v_\uparrow+1/v_\downarrow)$；准备装载300+30n秒；交接A/B为150+30n，C为180+36n。目标T=飞行+准备装载+交接。独立校验 $T=\sum t_{{fly}}+450N+4800+30N_C+6B_C$ 已通过。

按每类箱数枚举装载向量a，筛掉超质量、整数升体积、能耗限制的模式。递推 $F_i(r)=\min_{{lex}}[F_i(r-a)+(1,E_{{iga}},T_{{iga}})]$，从零状态回溯。正整数箱数保证无循环，最终映射回80个唯一箱号。

## 4 航段地形与45项载荷

{geo_table}

下面“连续/可装”分别是仅质量与能量边界、以及本区现有货箱在体积及不可拆约束下单架次可装最大质量。完整根区间和残差见safe_capacity.csv。

{cap_table}

## 5 主方案分区结果

{service_table}

逐架次箱号、四个能耗分项、全部时间口径和SOC在batches.csv；逐箱元数据与分配在box_assignment.csv；正式模板副本结果提交_Q1.xlsx只填第一问，其他工作表与原模板相同。

## 6 基线及目标优先级的实际权衡

混合贪心按max(质量/最大质量容量,体积/最大体积容量)降序，尝试既有批次并允许重选三种机型，以能耗增量、时间增量、批次顺序破并列；无法放入才开新批，最后合法合并。与主模型完全相同的物理、体积、安全约束。逐箱单送仅是80架次的简单上界。仅C型为限制机型诊断。

{compare_table(baselines,'method')}

{compare_table(priorities,'priority')}

N/E/T分别是架次/能耗/完整作业时间；字母顺序表示严格词典序。若E优先方案用了更多架次，应表述为取舍，不能宣称主方案所有指标同时最好。

objective_tradeoffs.csv在N*、N*+1、N*+2架次上限下，选取能耗最小和时间最短端点间有限时间预算，再求最小能耗。这是采样的权衡点，不是完整Pareto前沿；求解状态、对偶界、gap保存在tradeoff_solver_evidence.json。

## 7 安全余量敏感性与极限

{compare_table([dict(r,scenario=f"rho={{r['rho']:.0%}}") for r in []],'scenario') if False else mdtable(['统一余量','架次','能耗kWh','累计作业s','最小SOC'],[(f"{r['rho']:.0%}",r['N'],f"{r['E_kwh']:.6f}" if r['feasible'] else '不可行',f"{r['T_s']:.3f}" if r['feasible'] else '—',f"{r['min_SOC']:.6%}" if r['feasible'] else '—') for r in grid])}

基准这个最优方案在统一安全余量从20%提高至 **{float(sens['stable_rho']):.9%}（含端点）**仍可行且保持原词典序最优。理由是其成本不变、可行集缩小；不把该结论误解为高于端点所有并列最优方案都消失。

基准之上的首个真实目标转折：{first_text}

完整货物可交付的统一余量上限为 **{float(sens['feasibility_limit']):.9%}**，限制对象：{', '.join(b['box']+'（'+b['model']+'型）' for b in sens['limiting_boxes'])}。此处按每箱单送的最佳机型SOC取最小，利用Q1无资源排程耦合且能耗随载荷上升，构成充要条件；已分别验算边界可行和边界以上不可行。

对[0,1]内{sens['candidate_events']}个不同模式临界SOC，保存每个闭边界和相邻开区间的解（reserve_events.csv）；开区间内模式集合及成本不变。真正改变最优N/E/T的事件单独保存在reserve_breakpoints.csv。模式事件不等于解变化，连续载荷曲线与离散架次阶梯分开解释。

## 8 验证证据与压力测试

- 原始Excel独立读取、53行汇总逐箱一致、整数升精确转换、唯一80箱与总量守恒通过。
- 15条路线的两种像元提取方法集合一致，坐标范围/方向/无效值检查通过；完整像元索引保存在terrain_evidence.json。
- 独立检查器不调用优化器/物理模块，重新累加原箱质量体积，重新计算去回程能耗、SOC与时间，输出逐批余量。
- 14个箱数≤8服务区逐箱位掩码DP与数量DP的三个目标一致；全场模式MILP三个阶段成功且记录对偶界和gap。MILP固定能量容差1e-8kWh、时间1e-5s，最终与高精度DP比较容差1e-7kWh/1e-4s。
- {len(checks['checks'])}项实际执行检查通过，含几何沿边/穿角/端点交换、单像元山脊、能耗/载荷单调、合成穷举、箱号改名和{len(checks['error_injections'])}类错误注入。详情见tests.json，不将其称实飞标定。
- 压力场景将爬升效率乘0.95和0.90；固定主方案重新验算能耗与约束，另重优化。两种结果均保留，不能用重优化掩盖原方案违规。

{mdtable(['效率倍率','固定方案硬约束违规','固定能耗kWh','重优化架次','重优化能耗kWh'],[(s['eta_scale'],s['fixed_constraint_violations'],f"{s['fixed_E_kwh']:.6f}",s['reoptimized']['N'],f"{s['reoptimized']['E_kwh']:.6f}" if s['reoptimized']['feasible'] else '不可行') for s in stress])}

## 9 文件与后续衔接

- 主结果：solution_summary.json、batches.csv、box_assignment.csv、结果提交_Q1.xlsx。
- 几何/载荷：leg_geometry.csv、terrain_evidence.json、safe_capacity.csv。
- 检查：validation.json、tests.json、bitmask_verification.json、milp_verification.json。
- 对照/敏感性：baselines.csv、objective_priorities.csv、objective_tradeoffs.csv、reserve_*.csv、sensitivity_summary.json、stress_tests.json。
- 复现：run_manifest.json记录真实耗时、峰值内存、环境、输入与源码哈希。运行命令见上级运行说明.md。

Q2可复用节点/货箱/空间/物理口径，但可重新组批与选机型；这里没有伪造实际交付时刻。标准DP/MILP没有改名成新算法，价值在于物理、分解、可核验最优性及临界阈值证据。

软件接口核对：[SciPy MILP](https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html)、[PyProj Transformer](https://pyproj4.github.io/pyproj/stable/api/transformer.html)。二者仅支持软件实现，不作为能耗补充的物理来源。

绘图流程参考 scientific-visualization 技能的数据来源、尺度和导出检查规范；并非用该技能替代模型判断。软件方法参考：Kassis, T., Agarwal, V., He, Y., Patel, D., & Brueckner, A. M. (2026). *Scientific Agent Skills: A Library of Procedural Knowledge for Research Agents*. [arXiv:2609.00065](https://doi.org/10.48550/arXiv.2609.00065)，元数据核验于2026-09-23。
'''
    (out/'第一问完整报告.md').write_text(report,encoding='utf-8')
