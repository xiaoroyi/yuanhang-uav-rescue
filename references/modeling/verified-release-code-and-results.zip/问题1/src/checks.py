import bootstrap
import copy
import itertools
import math
from collections import Counter
from flight_physics import D, metrics, safe_capacity, equivalent_range
from terrain import supercover_segment, geos_cells
from solver import local_dp, solve_all, summary
from validate_q1 import validate

def run_checks(data,geos,patterns,chosen,rows):
    checks=[]
    def record(name,ok,detail=None):
        checks.append(dict(name=name,status='PASS' if ok else 'FAIL',detail=detail))
        assert ok, (name,detail)
    cases=[((.2,.2),(3.8,.2)),((.2,.2),(.2,3.8)),((.5,.5),(3.5,3.5)),((1.,.2),(1.,3.8)),((.2,1.),(3.8,1.)),((1.,1.),(2.,2.))]
    for i,(p,q) in enumerate(cases):
        cells=supercover_segment(p,q)
        record(f'geometry_closed_cells_{i}',cells==geos_cells([p,q]) and cells==supercover_segment(q,p))
    touched=supercover_segment((.1,.1),(3.9,2.9))
    sparse={(math.floor(y),math.floor(x)) for x,y in [(.1,.1),(3.9,2.9)]}
    record('single_pixel_ridge_not_missed',bool(touched-sparse),dict(peak_cell=list(sorted(touched-sparse)[0]),sparse_misses_peak=True))
    for g,m in data['models'].items():
        record(f'range_endpoints_{g}',equivalent_range(m,0)==D(m['L0']) and equivalent_range(m,m['Q'])==D(m['LF']))
        for s,geo in geos.items():
            energies=[metrics(m,geo,D(m['Q'])*j/20,1)['E'] for j in range(21)]
            record(f'energy_monotone_{s}_{g}',all(a<b for a,b in zip(energies,energies[1:])))
            caps=[safe_capacity(m,geo,r)['capacity_kg'] for r in (.1,.2,.4,.7,.95)]
            nums=[-1 if v is None else v for v in caps]
            record(f'reserve_capacity_monotone_{s}_{g}',all(a>=b for a,b in zip(nums,nums[1:])))
        a=metrics(m,geos['S001'],3,1); b=metrics(m,geos['S001'],6,2)
        record(f'handling_increment_{g}',b['T']-a['T']==D(m['load']+m['handover_box']))
        record(f'eta_stress_{g}',metrics(m,geos['S001'],3,1,.9)['E']>a['E'])
    # Synthetic complete partition enumeration independent of recurrence.
    toy=[dict(counts=(1,0),E=D(2),T=D(3)),dict(counts=(0,1),E=D(3),T=D(2)),dict(counts=(1,1),E=D(4),T=D(7)),dict(counts=(2,0),E=D(3),T=D(5))]
    brute=[]
    for use in itertools.product(range(4),repeat=len(toy)):
        if tuple(sum(k*p['counts'][j] for k,p in zip(use,toy)) for j in range(2))==(2,1):
            brute.append((D(sum(use)),sum((k*p['E'] for k,p in zip(use,toy)),D(0)),sum((k*p['T'] for k,p in zip(use,toy)),D(0))))
    record('toy_exhaustive_partition',local_dp((2,1),toy,(0,1,2))[0]==min(brute))
    relaxed=solve_all(data,patterns,D('.1')); tight=solve_all(data,patterns,D('.4'))
    record('reserve_sorties_monotone',len(relaxed)<=len(chosen) and (tight is None or len(chosen)<=len(tight)))
    geometry={s:(g['distance_m'],g['cruise_m']) for s,g in geos.items()}
    tests={}
    bad=copy.deepcopy(rows); bad[0]['boxes'].append(bad[0]['boxes'][0]); tests['duplicate_box']=bad
    bad=copy.deepcopy(rows); bad[0]['boxes'].pop(); tests['missing_box']=bad
    bad=copy.deepcopy(rows); bad[0]['boxes'][0]=next(b['id'] for b in data['boxes'] if b['service']!=bad[0]['service']); tests['cross_service']=bad
    bad=copy.deepcopy(rows); bad[0]['SOC']+=.01; tests['wrong_soc']=bad
    bad=copy.deepcopy(rows); bad[0]['T']-=bad[0]['preparation_time_s']; tests['missing_preparation']=bad
    bad=copy.deepcopy(rows); bad[0]['air_time_s']-=bad[0]['handover_time_s']; tests['missing_handover']=bad
    bad=copy.deepcopy(rows); bad[0]['E']+=.1; tests['loaded_return_or_wrong_energy']=bad
    bad=copy.deepcopy(rows)
    idx=next(i for i,r in enumerate(bad) if r['service']=='S009')
    bad[idx]['model']='A'; bad[idx]['boxes']=[b['id'] for b in data['boxes'] if b['service']=='S009']; tests['volume_exceeded']=bad
    injections=[]
    for name,bad in tests.items():
        v=validate(data,bad,geometry=geometry)
        record('injection_'+name,v['status']=='FAIL')
        injections.append(dict(name=name,caught_errors=sorted(set(e['kind'] for e in v['errors']))))
    # Renaming physically identical boxes cannot influence count DP.
    renamed=copy.copy(data); renamed['boxes']=[dict(b,id='renamed_'+str(i)) for i,b in enumerate(reversed(data['boxes']))]
    record('box_rename_and_reorder',summary(solve_all(renamed,patterns))==summary(chosen))
    return dict(status='PASS',checks=checks,error_injections=injections)
