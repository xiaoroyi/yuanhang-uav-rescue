from setup_q3 import *
from communication import Radio
from atoms import build_route
from routes import Physics
from joint import solve
from validate_q3 import run
import time

def main():
    P=Physics();d=inputs();engine=Radio(d);sites=json.loads((OUT/'relay_sites.json').read_text(encoding='utf-8'));atoms=json.loads((OUT/'coverage_atoms.json').read_text(encoding='utf-8'))
    pool={};paths=[PROJECT/'问题2/results/solution.json',PROJECT/'问题2/results/tradeoffs/extra_60/solution.json',PROJECT/'问题2/results/baselines/single_stop/solution.json',PROJECT/'问题2/results/baselines/multi_greedy/solution.json',PROJECT/'问题2/results/sensitivity/M_C_+1/solution.json']
    for p in paths:
        if p.exists():
            for r in json.loads(p.read_text(encoding='utf-8')):pool[r['route']['id']]=r['route']
    # Keep single-box alternatives for every box where independently feasible.
    for b in P.boxes.values():
        for g in P.models:
            r=P.evaluate(g,[(b['service'],[b['id']])])
            if r is not None:pool[r['id']]=r
    began=time.time()
    for i,(rid,r) in enumerate(pool.items()):
        if rid not in atoms:atoms[rid],_=build_route(r,P,engine,sites)
        if i%25==0:print('expanded atom routes',i,len(pool),'s',round(time.time()-began),flush=True)
    dump(OUT/'expanded_routes.json',list(pool.values()));dump(OUT/'expanded_atoms.json',atoms)
    warm=json.loads((OUT/'three_site_seed/solution_q3.json').read_text(encoding='utf-8'))
    res=solve('joint_expanded',seconds=150,slots=3,site_ids=['P001','P009','P010'],slot_sites=['P001','P009','P010'],pool=list(pool.values()),atoms=atoms,zero_late=True,max_C=6043.4,objectives=('C','E','N'),warm=warm)
    if res:run(OUT/'joint_expanded/solution_q3.json')

if __name__=='__main__':main()
