from setup_q3 import *
from finalize_q3 import readcsv,union_length
import datetime,platform,importlib.metadata as metadata

def mdtable(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(str(x) for x in r)+' |' for r in rows])

def main():
    sol=json.loads((OUT/'solution_q3.json').read_text(encoding='utf-8'));s=json.loads((OUT/'solution_summary.json').read_text(encoding='utf-8'));q2=json.loads((PROJECT/'问题2/results/solution_summary.json').read_text(encoding='utf-8'));summary2=json.loads((OUT/'transport_validation/validation.json').read_text(encoding='utf-8'))['summary']
    other=json.loads((OUT/'tradeoffs/extra_180/solution_summary.json').read_text(encoding='utf-8'));resource=json.loads((OUT/'resource_summary.json').read_text(encoding='utf-8'));radio=inputs()['radio']
    rows=[]
    names=[('Q2时刻冻结后补中继','fixed_q2_baseline'),('Q2路线重排，三个初始位置','three_site_seed'),('位置联合选择','site_joint'),('311条运输候选、初始三个位置','joint_expanded'),('局部位置与高度细化（主方案）','refined_joint'),('311条候选、细化后的三个位置','final_joint_search'),('允许完工增加180秒的节能备选','tradeoffs/extra_180')]
    for label,name in names:
        p=OUT/name/'solution_summary.json';ev=json.loads((OUT/name/'solver_evidence.json').read_text(encoding='utf-8'))
        if p.exists():
            x=json.loads(p.read_text(encoding='utf-8'));rows.append([label,x['D'],f"{x['C_joint']:.6f}",f"{x['E_total']:.6f}",str(x['N_transport'])+'+'+str(x['N_relay']),'; '.join(e['stage']+':'+e['status'] for e in ev)])
        else:rows.append([label,'—','—','—','—',ev[-1]['status']+'（仅当前有限模型）'])
    comparisons=mdtable(['实验','D','联合完工/s','总能耗/kWh','运输+中继架次','求解状态'],rows)
    table(OUT/'baselines_q3.csv',[dict(zip(['scenario','D','C_joint','E_total','sorties','status'],r)) for r in rows])
    rr=mdtable(['中继架次','实体/组件','位置','开始/s','建链完成/s','服务结束/s','返回/s','能耗/kWh','SOC'],[[r['sortie'],r['aircraft']+'/'+r['component'],r['site']['id'],f"{r['start']:.3f}",f"{r['link_complete']:.6f}",f"{r['service_end']:.3f}",f"{r['return']:.6f}",f"{r['energy']:.6f}",f"{r['SOC']:.4%}"] for r in sol['relay']])
    coords=mdtable(['位置','经度/°','纬度/°','当地DEM/m','离地高度/m','悬停海拔/m','回传剩余裕量/dB'],[[r['site']['id'],f"{r['site']['lon']:.10f}",f"{r['site']['lat']:.10f}",f"{r['site']['ground']:.6f}",r['site']['agl'],f"{r['site']['z']:.6f}",f"{float(next(v for v in readcsv(OUT/'relay_trips_q3.csv') if v['sortie']==r['sortie'])['backhaul_margin']):.6f}"] for r in sol['relay']])
    trans=mdtable(['架次','机型/实体/电池','访问顺序','准备开始/s','返航/s','能耗/kWh'],[[r['sortie'],r['route']['model']+'/'+r['aircraft']+'/'+r['battery'],'→'.join(a for a,_ in r['route']['stops']),f"{r['start']:.3f}",f"{r['return']:.6f}",f"{r['route']['energy']:.6f}"] for r in sol['transport']])
    sen=readcsv(OUT/'final_sensitivities.csv');sens=mdtable(['固定主方案压力条件','完整可行','累计客户失联时间/s','说明'],[[x['scenario'],x['valid'],f"{float(x['gap_seconds']):.6f}",'资源缩减后保持原方案' if x['scenario'].startswith('components') else '门限收紧，原方案不能直接照用'] for x in sen])
    seeds=[]
    for i in (1,2,3):
        x=json.loads((OUT/f'experiments/seed_{i}/solution_summary.json').read_text(encoding='utf-8'));seeds.append(dict(seed=i,C=x['C_joint'],E=x['E_total'],D=x['D'],min_hard_slack=x['min_hard_slack']))
    table(OUT/'independent_seeds.csv',seeds)
    # Q2 true gap unions, keeping simultaneous customers separate.
    gaps=readcsv(OUT/'q2_communication_audit.csv');bytrip={}
    for r in gaps:bytrip.setdefault(r['sortie'],[]).append((float(r['start']),float(r['end'])))
    merged=[]
    for rid,vals in bytrip.items():
        ans=[]
        for a,b in sorted(vals):
            if ans and a<=ans[-1][1]+1e-7:ans[-1][1]=max(ans[-1][1],b)
            else:ans.append([a,b])
        merged.extend(dict(sortie=rid,start=a,end=b,duration=b-a) for a,b in ans)
    table(OUT/'q2_merged_communication_gaps.csv',merged)
    gapstats=dict(cumulative_customer_seconds=sum(r['duration'] for r in merged),longest_single_trip_gap=max(r['duration'] for r in merged),wallclock_union_seconds=union_length([(r['start'],r['end']) for r in merged]),conservative_boundary_expansion_s=1e-5)
    dump(OUT/'q2_gap_metrics.json',gapstats)
    # Conservative ownership interpretation for Q4: a relay sortie stays whole.
    hand=json.loads((OUT/'q4_handover.json').read_text(encoding='utf-8'));parent={f'S{i:03d}':f'S{i:03d}' for i in range(1,16)}
    def find(x):
        while parent[x]!=x:x=parent[x]
        return x
    for group in hand['transport_components']+[r['transport_destination_union'] for r in hand['relay_relations']]:
        for x in group[1:]:parent[find(x)]=find(group[0])
    groups={}
    for x in parent:groups.setdefault(find(x),[]).append(x)
    hand['whole_relay_sortie_ownership_components']=list(groups.values());hand['whole_relay_sortie_ownership_component_count']=len(groups);dump(OUT/'q4_handover.json',hand)
    text=r'''# 第三问完整报告：全过程通信约束下的运输与中继联合调度

本报告对应原题问题三。全部数值从冻结方案与独立核验结果生成，运输与中继库存使用原附件参数。主方案采用及时性优先的字典序目标；能耗不是货币成本。

## 1. 结果与结论边界

80箱、758 kg、2.011 m³物资全部唯一交付。31个医疗/首批硬截止全部满足，所有货箱均在各自期望时刻之前送达，故加权延期D=0。运输25架次（A12、B7、C6），中继3架次，由2架中继机执行并实际使用2组可更换能源组件。

| 指标 | 结果 |
| --- | ---: |
| 联合最后返航 | @C@ s = @CMIN@ min |
| 运输最后返航 | @CT@ s |
| 中继最后返航 | @CR@ s |
| 运输总能耗 | @ET@ kWh |
| 中继总能耗 | @ER@ kWh |
| 联合总能耗 | @E@ kWh |
| 最紧硬截止提前量 | @SLACK@ s |
| 运输最低返航SOC | @TSOC@ |
| 中继最低返航SOC | @RSOC@ |
| 已核验开区间/事件点 | 363 / 550 |
| 已发现失联时间/未认证区间 | 0 s / 0 |

这些结果是在本报告的物理补充、操作约定和冻结DEM像元几何下通过的完整可行方案。D≥0而本方案D=0，因此**原问题的延期目标这一层达到全局下界**；联合完工、能耗、架次数不能宣称原连续选址问题全局最优。有限候选模型的OPTIMAL状态也不能扩大解释。

## 2. 对Pro方案的核对与实际改进

Pro提出的联合选路、选址、变驻留调度及全过程通信检查方向正确。实现时修正/落实了以下关键点：

1. 货箱覆盖写成每箱恰属一条被选运输路线；不照抄损坏的数学下标。中继300 m上限是当地离地高度，不是海拔上限。
2. 直连、接入、回传分别计算双向门限。山体遮挡只增加10 dB损耗，不能简单判为绝对断连。
3. 转场巡航高度同时高于沿途DEM加50 m净空、调度中心和悬停终点；中继23.5 kg已含通信模块，不重复加质量。
4. 建链、无客户等待和有效服务全计驻留能耗。组件从返航开始充电，机体从返航开始300 s周转，两个释放时刻独立计算。
5. 运输和中继在同一调度模型内重定时，不分别套用第二问的提前递推，以免提前运输后中继尚未建链。
6. 从视线扫掠几何提取遮挡区间，显式检查全部事件点，增加独立GEOS几何交叉核验及错误注入。
7. 在不改变前四层目标的条件下，以硬截止最小提前量作为末级平局规则；并在末班中继附近细化位置与高度，缩短返航时间。

实际搜索包括路线可变的311候选联合模型。其最好解未改善及时性优先主方案，故最终沿用了第二问的25条运输路线，但重新优化了开始时刻、逐箱顺序和中继计划。不能把“最终路线相同”写成“从未进行联合选路”，也不能声称路线重组改善了该主方案。放宽完工约束后的24架次节能备选另列取舍。

## 3. 公共物理规则与补充假设

运输载荷、体积、航段净空、速度、逐箱交接、能耗和两阶段充电沿用第一、二问。运输作业从准备开始占用同型机体与满电电池，返航释放机体；电池返航充满后才能再次使用。运输库存A/B/C机体为4/2/2，电池为6/4/4，电池数包括已安装的电池。

载重—航程的3/2指数及航段能耗等于水平与爬升分量之和，均由题设附录2给出；前两问对两个能耗分量采用如下具体计算关系：

$$L_g(q)=L_g(0)-[L_g(0)-L_g(Q_g)](q/Q_g)^{1.5},$$
$$E_{g,hor}=E_g^{use}d/L_g(q),\qquad E_{g,up}={(m_g+q)g_0\Delta h\over\eta_g\,3.6\times10^6}.$$

各段载荷按交付后减少，下降按题设不计额外能耗，重力加速度g0取9.81 m/s²。指数1.5和分量叠加均来自题设；水平分量按可用能量与航程比折算、爬升分量按重力势能与效率计算，这两项具体分量关系才是本项目补充解释，不声称直接摘自题目文献4、5。此前报告对公式来源的表述已纠正，计算公式及前三问冻结结果不变。逐箱串行交付完成时刻的操作解释继续保留。

中继单架次选择一个固定悬停位置；准备180 s，水平速度15 m/s，爬升4 m/s，下降3 m/s，巡航功率1.15 kW，悬停加通信功率1.10 kW，可用能量3.2 kWh，20%安全余量对应每架次E≤2.56 kWh。中继2架、组件6组、组件充满1800 s。一架中继可以同时服务多个运输机，未另加附件没有规定的客户容量限制。禁止中继多跳。

设中继位置地面高程为z_dem，离地高度h满足0<h≤300，悬停海拔z=z_dem+h。取转场巡航海拔

$$H=\max\{z_O,z,\max_{O\to p}z_{DEM}+50\}.$$

令水平距离为d，则往程和返程飞行时间分别为

$$t^{out}=(H-z_O)/4+d/15+(H-z)/3,$$
$$t^{back}=(H-z)/4+d/15+(H-z_O)/3.$$

准备开始Y、到达A=Y+180+t_out、建链完成B=A+30、离开F、返航R=F+t_back。中继能耗为

$$E_R=1.15\,{2d/15\over3600}+{23.5g_0(2H-z_O-z)\over0.72\cdot3.6\times10^6}+1.10\,{F-A\over3600}.$$

最后一项从到达计至离开，包含建链与全部空档。SOC=1−E_R/3.2，充电函数为

$$\chi(s)=\begin{cases}1800[0.65(0.9-s)/0.9+0.35],&s<0.9,\\1800\cdot0.35(1-s)/0.1,&s\ge0.9.\end{cases}$$

因此中继机体占用[Y,R+300)，组件占用[Y,R+χ)。最终完工只计算最后返航，不加末次充电与周转。

## 4. 通信模型：双向预算与地形遮挡

原附件频率2400 MHz、系统损耗3 dB、遮挡附加损耗10 dB、接收灵敏度−98 dBm、安全裕量8 dB。固定网关G01天线高20 m，海拔127.7+20=147.7 m。

$$PL(a,b)=32.45+20\log_{10}(2400)+20\log_{10}(d_{ab}/1000)+10I_{obs}(a,b).$$

对设备对a,b，取双向可容许损耗较小者

$$L_{ab}^{max}=\min\{P_a+G_a+G_b-L_{sys},P_b+G_b+G_a-L_{sys}\}-P_{sens}-M.$$

| 链路 | 正向/反向门限 dB | 双向门限 dB | 有遮挡可通距离/m | 无遮挡可通距离/m |
| --- | --- | ---: | ---: | ---: |
| 运输—G01直连 | 122 / 129 | 122 | 3956.296 | 12510.906 |
| 运输—中继接入 | 116 / 116 | 116 | 1982.845 | 6270.306 |
| 中继回传—G01 | 126 / 134 | 126 | 6270.306 | 19828.450 |

任意飞行时刻，直连有效则优先直连；否则必须存在已完成建链、尚未离开的中继，其接入与回传同时满足双向预算。覆盖包括全部爬升、巡航、下降、交接及最后返程，起飞前准备不属于飞行通信区间。

### 连续区间检查为何优于固定采样

单个匀速阶段的位置为p(u)=(1−u)p0+up1，u∈[0,1]；固定通信端a与移动端形成扫掠三角形

$$q=a+\lambda_1(p_0-a)+\lambda_2(p_1-a),\quad \lambda_1,\lambda_2\ge0,\ \lambda_1+\lambda_2\le1.$$

将此三角形与每个DEM投影像元的竖直地形柱相交：四条平面边界加地形高度约束都是λ坐标的线性半空间。若相交，映射u=λ2/(λ1+λ2)，得到该像元造成的闭遮挡区间；对全部相关像元取并集。竖直升降使用同一表示，不把水平投影长度为零当作没有遮挡。

再加入无遮挡/有遮挡距离阈值的二次方程根，以及中继服务开始/结束时刻，将阶段分成状态确定的开区间。每个开区间的距离最大值由端点包络确定；全部分割事件点另行核验。这样可发现两个采样点之间的短暂山脊遮挡，也能处理孤立接触点。

几何采用原始DEM高度和UTM49N投影四角构成的凸像元，边界向外缓冲2 mm。1000像元、2000条边的曲线投影细分检查最大观测弦差为0.000006802 m，低于缓冲量；这只是数值抽样证据，不是所有像元曲线误差的解析上界。通信“全程”是该冻结像元几何中的连续时间结论，不能外推为真实山体、随机衰落或实飞保证。

## 5. 数学模型与实际求解方法

模型类别为**异构多航次车辆路径问题的集合划分模型，耦合可更新资源调度与时间区间覆盖**；实现采用OR-Tools CP-SAT约束规划。它不是自创的算法名称，也没有实现ALNS、Benders分解或全空间分支定界。

运输候选r包含机型、装载箱集B_r、访问顺序和逐段物理量。二元变量x_r决定采用路线，S_r为准备开始，箱在停靠点的交付名次通过AllDifferent约束确定：

$$\sum_{r:b\in B_r}x_r=1,\qquad C_b\le d_b^{hard}\quad(b\text{有硬截止}).$$

对每个机型，以可选区间[S_r,R_r)和[S_r,R_r+χ_r)分别施加机体与电池Cumulative容量约束。能量和装载可行性在候选生成及独立回放中检查。资源同质可交换时，区间图着色把容量解转成实际无人机和电池编号。

将每条运输候选中直连不充分的部分分成通信需求块c=[a_rc,b_rc]，K_rc为能完整覆盖该块且回传合格的候选中继位置集合。中继槽j具有激活变量y_j、位置k_j、准备时刻Y_j和服务结束F_j。若z_rcj表示由它覆盖需求块，则

$$\sum_j z_{rcj}=x_r,\quad z_{rcj}\le y_j,$$
$$z_{rcj}=1\Longrightarrow k_j\in K_{rc},\quad B_j\le S_r+a_{rc},\quad F_j\ge S_r+b_{rc}.$$

中继的可变长度区间[Y_j,R_j+300)和[Y_j,R_j+χ_j)分别受2架机体、6组组件的容量约束。中继服务允许并发客户，不能对通信客户错误施加NoOverlap。

采用字典序目标

$$\min_{lex}(D,C_J,E_J,N_J),\qquad D=\sum_b w_b\max(C_b-d_b^{exp},0),$$
$$C_J=\max(\max_rR_r,\max_jR_j),\quad E_J=\sum_rE_rx_r+\sum_jE_j,\quad N_J=\sum_rx_r+\sum_jy_j.$$

主方案在D=0下搜索。某层到时只得到FEASIBLE时，将其已取得的目标值作为下一层上界，保留最好可行解，不声称前层已最优。最后在前四层网格目标不变条件下扩大最小硬截止提前量，避免只因平局规则造成贴线交付。

实际时间网格0.1 s；资源持续时间向上取整，覆盖开始向外下取整、结束向外上取整。物理轨迹和最终返航采用未截断实数回算。运输能耗用微kWh整数系数、中继能耗采用保守整数表达，故网格目标与实数回算存在微小差异；能量可行性以独立物理重算为准。

初始在900 m网格、每格高点和节点形成400个水平候选，以150/300 m高度筛选，经覆盖模式筛选保留66个活动位置。针对末班位置P010，使用150 m平面偏移步长及200/250/300 m高度局部细化，新增16个位置，总池82个。主方案局部模型使用P001/P009/P010与16个新增点共19个位置，3个中继槽、25条继承路线，需求块最大30 s。该局部模型的C/E/N/H网格阶段均取得OPTIMAL；扩大到311条运输路线、固定最终三个位置后，C/E仅取得FEASIBLE，没有改进主方案。

## 6. 完整联合方案

### 6.1 中继位置与时刻

@COORDS@

@RELAYS@

R01先执行Q3R-001，返航后组件01于3243.711846 s充满、机体于2787.594452 s周转完毕，随后在3911.2 s开始Q3R-003。R02执行Q3R-002。中继与组件峰值均为2；组件03—06本方案未使用，不等于它们对其他方案或扰动没有价值。末次组件充满7055.671187 s不计入联合完工。

### 6.2 运输方案

@TRANSPORT@

每个架次的逐箱装载、交付次序、交付时刻、逐段载荷、能耗和返航SOC分别见transport_trips_q3.csv、deliveries_q3.csv、transport_leg_events_q3.csv。运输机体峰值A/B/C为4/2/2，电池峰值6/4/4。共3个两点架次，其余为单点；第三问运输时刻不得用第二问工作表替代。

![地形与联合方案](figures/Q3_地形与联合方案.png)

![联合资源调度](figures/Q3_联合资源调度.png)

### 6.3 通信保障结果

@DIRECT@客户秒由G01直连保障，@RELAYTIME@客户秒由中继保障。客户秒是对运输机分别积分后求和，多个客户同时连接同一中继时可大于墙钟驻留时间。中继Q3R-001/002/003分别最多同时保障4/5/3架运输机。

完整复核包含363个开区间与550条分阶段事件点记录，已发现失联为0、未认证区间为0。保守最小链路剩余裕量约为0 dB（浮点值−4.12×10⁻¹³ dB），这是包含原题8 dB安全裕量后的剩余值，不能表述为还具有显著额外通信余量。

工作簿通信表包含913条记录：正长度记录表述开区间，零长度记录单独保障事件点；相邻物理阶段共有的边界点可能重复列出。该表示避免把不适用同一保障来源的端点强行并入一条闭区间。

![全过程通信保障](figures/Q3_全过程通信保障.png)

## 7. 基线、搜索改进与权衡

@COMPARISONS@

第二问无中继回放有约@GAP@累计客户秒直连缺口，最长单架次连续缺口约@LONGGAP@ s；这是客户时间总和，不是整个任务停摆相同长的墙钟时间。缺口计算边界扩张10⁻⁵ s以保守纳入接触事件。

冻结第二问路线和时刻、在初始66个位置及8个中继槽的模型内补中继，CP-SAT证明该有限模型不可行。这不能证明整个DEM上不存在后置补中继方案。允许联合重排后获得完整可行方案，说明在本候选体系中联合时序是必要的改进。

主方案相对第二问已知可行方案完工增加@DELTA_C@ s，总能耗增加@DELTA_E@ kWh。第二问的5939.476694 s是已知可行上界，不能当作第三问原问题完工下界；本次差值也不能当作“通信的理论最小代价”。

节能备选仍为D=0、无硬截止和通信违规，采用24个运输架次+3个中继架次，完工@ALT_C@ s、总能耗@ALT_E@ kWh。相对主方案晚@ALT_DELTA_C@ s，节约@ALT_DELTA_E@ kWh。它的最紧硬截止提前量仅@ALT_SLACK@ s，明显比主方案贴线；应作为时间—能耗取舍样本，不替换及时性优先主方案，也不能称完整Pareto前沿。

旧位置组合下进行了三次独立种子试验（1/2/3）：相同25条初始路线、固定三个位置、同一热启动方案和每层25 s预算。三次C/E均得到6043.276671 s、70.104939 kWh，硬截止提前量不同。这里只能说明该有限试验的目标稳定，不能统计推断全空间收敛或实飞可靠概率。新细化位置的实验不混入这组三次重复。

## 8. 敏感性与压力传播

@SENSITIVITY@

提高至10/12 dB安全裕量会收紧所有链路，原方案均失败。此前旧位置池的10 dB重新优化在45 s内返回UNKNOWN，12 dB出现候选覆盖空缺；没有取得两种增强裕量下的新可行证书。最终主方案的压力回放已更新，旧池重优化结果不冒充最终82点池的结论。

中继组件减少到4组，原方案仍完整可行。一个中继实体的受限25路线、3位置、4槽模型不可行，仅能作为该模型的资源瓶颈证据，不能说任何位置、路线下至少需要两架。

所有中继到达至离开的驻留功率统一上浮5%，三架次能耗分别为0.648477、1.369502、0.581567 kWh，最小SOC为57.2031%。重新计算组件充满时刻后无冲突，因此保留原实体顺序传播的延迟为0，运输时刻与中继服务窗口完全不变，全程通信证书继续适用。该情景已经可行，未另行优化；它不代表风速变化或飞行时间上浮的鲁棒性。

运输部分仍继承前两问约1.199%的统一能耗上浮余量，不能因中继SOC较高就把联合方案描述为全面鲁棒。位置细化和30 s通信需求块提高的是离散搜索表达，不改变底层按事件分割的连续检查。

## 9. 验证与可追溯性

1. 从原始Excel/DEM重新核对80箱唯一覆盖、目的地、31项硬截止、逐箱序、机型容量、逐段能耗、返航SOC、共享电池充电和全部实体占用。
2. 中继独立重算到达、建链、全部驻留能耗、返航、SOC、充电、300 s周转与编号。同一路径用GEOS对整条投影线段和DEM像元求交，检查转场净空，未沿路稀疏采样作结论。
3. 由真实轨迹重新建立直连/接入剖面，不信任求解器输出的“可行”标签；完整区间重放并对63条关键射线/回传链路使用独立GEOS实现交叉核验。
4. 49项几何、预算、充电与资源表达检查通过。其中包含两端采样均通但内部山脊遮挡的反例；小型测试核对累计资源表达与显式实体分配等价。它不是完整小型车辆路径枚举验证，不能夸大。
5. 8类故障注入均被拒绝：伪造SOC、漏300 s周转、第7组件、实体重叠、提前声明建链、错误返航、删除全部中继、离地高度越限。
6. 结果提交工作簿全精度读回、逐单元格与冻结JSON/CSV比较，再重建运输与中继计划进行全物理核验；Q1/Q2/Q4原表的值和数字格式保持一致。未通过增大容差掩盖打印小数引起的假重叠。

主要结果文件：solution_q3.json、solution_summary.json、validation_q3.json、结果提交_Q3.xlsx；通信区间、事件点及JSONL证书；运输/中继/电池/组件时间线；独立测试、压力回放与solver_evidence.json。运行环境、源文件哈希和每次求解的真实墙钟时间见run_manifest.json及各实验日志。完整历史CPU累计和峰值内存未记录，清单明确留空，未填造统计值。

## 10. 与第四问的衔接和后续适用范围

冻结运输多点关系形成12个不可拆服务区连通分量。进一步按“整个中继架次不得跨组拆分”的较强归属解释，把同一中继实际保障的运输架次目的地区合并，得到@JOINTGROUPS@个分量：@GROUPLIST@。这保留了2组和3组分区的组合可能性，但均衡性和资源缺口仍需第四问正式求解，不能仅凭分量数宣称资源可行。

q4_handover.json保留运输访问关系、中继实际服务关系和强归属分量。本问未为了分区静默修改运输或通信任务。第四问应先据题意说明跨组中继的归属规则，不能复制一个物理中继架次后仍声称原方案与关系完全不变。

目前没有完成原连续选址空间全局最优性证明、完整小型运输—中继联合枚举、最终扩充池的10/12 dB重优化成功证书，以及含随机风场/衰落的实飞验证。这些是结论边界，不影响原题给定基准参数下本方案已通过核验的可行性。

依据为原题问题三、附录2/3和五份原始Excel；能耗补充与交接约定追溯第一、二问。Pro文档作为执行设计参考，不当作已经验证的运行结果或外部学术文献。
'''
    tokens={'C':f"{s['C_joint']:.9f}",'CMIN':f"{s['C_joint']/60:.6f}",'CT':f"{s['C_transport']:.9f}",'CR':f"{s['C_relay']:.9f}",'ET':f"{s['E_transport']:.9f}",'ER':f"{s['E_relay']:.9f}",'E':f"{s['E_total']:.9f}",'SLACK':f"{s['min_hard_slack']:.6f}",'TSOC':f"{s['min_transport_SOC']:.6%}",'RSOC':f"{s['min_relay_SOC']:.6%}",'COORDS':coords,'RELAYS':rr,'TRANSPORT':trans,'COMPARISONS':comparisons,'SENSITIVITY':sens,'DIRECT':f"{s['direct_customer_seconds']:.6f}",'RELAYTIME':f"{s['relay_customer_seconds']:.6f}",'GAP':f"{gapstats['cumulative_customer_seconds']:.6f}",'LONGGAP':f"{gapstats['longest_single_trip_gap']:.6f}",'DELTA_C':f"{s['C_joint']-5939.476694411532:.6f}",'DELTA_E':f"{s['E_total']-67.58049820509788:.6f}",'ALT_C':f"{other['C_joint']:.6f}",'ALT_E':f"{other['E_total']:.6f}",'ALT_DELTA_C':f"{other['C_joint']-s['C_joint']:.6f}",'ALT_DELTA_E':f"{s['E_total']-other['E_total']:.6f}",'ALT_SLACK':f"{other['min_hard_slack']:.6f}",'JOINTGROUPS':str(len(groups)),'GROUPLIST':'；'.join('、'.join(g) for g in groups.values())}
    for k,v in tokens.items():text=text.replace('@'+k+'@',v)
    assert '@' not in text
    audit_path=OUT/'communication_interface_audit.json'
    if audit_path.exists():
        audit=json.loads(audit_path.read_text(encoding='utf-8'))
        text+='\n\n## 11. 第四问前的接口复核与来源订正\n\n原始DOCX公式结构确认，载荷—航程指数3/2和总能耗为水平与爬升分量之和来自题设；只有两个分量的具体计算关系属于补充解释。pro_review_q3.json保留原公式及文件哈希。此次只订正来源文字，冻结方案哈希和全部物理结果不变。\n\n'
        text+=f"逐条重算确认{audit['interval_records']}个开区间、{audit['event_records']}条事件记录保存的是唯一实际保障来源。事件按架次与精确时刻合并后为{audit['unique_exact_events']}个，其中{audit['duplicated_event_records']}条是阶段公共边界的重复记录，来源全部一致。零长事件仍保留用于第四问归属，未用候选覆盖集合替代实际关系。见communication_interface_audit.json。\n\n"
        text+='另外补测了扫掠坐标零分母、孤立相切端点及无效事件对相邻有效区间的覆盖优先规则，均通过。第四问允许分区前重新分配同型资源编号的解释将显式声明，物理任务、时刻和实际通信来源保持冻结。\n'
    (OUT/'第三问完整报告.md').write_text(text,encoding='utf-8')
    print('Report written',len(text),'characters',flush=True)

def manifest():
    packages={}
    for name in ('numpy','scipy','ortools','numba','llvmlite','pyproj','shapely','matplotlib','openpyxl'):
        try:packages[name]=metadata.version(name)
        except metadata.PackageNotFoundError:packages[name]='unknown'
    logs={str(p.relative_to(OUT)):json.loads(p.read_text(encoding='utf-8')) for p in OUT.rglob('solver_evidence.json')}
    code={str(p.relative_to(ROOT)):sha(p) for p in list((ROOT/'src').glob('*.py'))+list((ROOT/'src').glob('*.mjs'))+[ROOT/'run_q3.py'] if p.exists()}
    files={str(p.relative_to(ROOT)):sha(p) for p in OUT.glob('*') if p.is_file() and p.name!='run_manifest.json'}
    figures={str(p.relative_to(ROOT)):sha(p) for p in (OUT/'figures').glob('*') if p.is_file()}
    shared={str(p.relative_to(PROJECT)):sha(p) for sub in ('问题1/src','问题2/src') for p in (PROJECT/sub).glob('*.py')}
    dump(OUT/'run_manifest.json',dict(status='completed_with_explicit_candidate_and_geometry_limits',finished=datetime.datetime.now().isoformat(),python=sys.version,platform=platform.platform(),packages=packages,inputs=inputs()['audit']['inputs'],code=code,shared_code=shared,outputs=files,figures=figures,solver_runs=logs,solver_total_wall_seconds=sum(e['seconds'] for rows in logs.values() for e in rows),historical_peak_RSS_bytes=None,historical_total_CPU_seconds=None,performance_note='Per-stage measured solver wall times only; no invented full-history CPU/RSS statistics',canonical_solution_sha256=sha(OUT/'solution_q3.json'),paper_scope='Q2 appended to external paper; Q3 solution/report produced separately as requested'))
    q2root=PROJECT/'问题2';keys=['src/pro_review_patch.py','src/write_paper_q2.py','results/export_precision_audit.json','results/q1_fixed_all_orders_certificate.json','results/q1_fixed_all_orders_certificate.csv','results/pro_review_changes.json','results/sensitivity_resources.csv','results/第二问完整报告.md','论文正文_问题二.md','论文交接文档.md','论文工作/论文_写至问题二_正式.doc','论文工作/论文_写至问题二_正式.docx','论文工作/delivery_verification.json']
    dump(q2root/'results/revision_manifest_20260923.json',dict(status='Q2_evidence_and_paper_completed',optimization_unchanged=True,original_run_manifest_sha256=sha(q2root/'results/run_manifest.json'),canonical_solution_sha256=sha(q2root/'results/solution.json'),revised_files={k:sha(q2root/k) for k in keys if (q2root/k).exists()},paper_delivery=json.loads((q2root/'论文工作/delivery_verification.json').read_text(encoding='utf-8')),note='Original solver manifest retained as history; this revision records updated proof, export precision, resource labels and paper.'))
    print('Manifests written',flush=True)

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='manifest':manifest()
    else:main()
