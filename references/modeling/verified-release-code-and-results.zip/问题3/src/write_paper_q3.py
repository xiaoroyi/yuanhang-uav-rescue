"""Append verified Q3 to the existing paper; preserve earlier native mathematics."""
from pathlib import Path
import sys,json,csv,re,hashlib,copy,ast,datetime
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;WORK=ROOT/'论文工作';WORK.mkdir(exist_ok=True)
# Use the bundled document runtime. latex2mathml is a pure-Python missing capability.
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree
sys.path.append(str(PROJECT/'问题1/论文工作/deps'))
from latex2mathml.converter import convert
R=ROOT/'results'
def read(n):return json.loads((R/n).read_text(encoding='utf-8'))
def rows(n):return list(csv.DictReader((R/n).open(encoding='utf-8-sig')))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
S=read('solution_summary.json');SOL=read('solution_q3.json');INTERFACE=read('communication_interface_audit.json');REVIEW=read('pro_review_q3.json')
assert S['valid'] and INTERFACE['valid'] and read('workbook_audit.json')['valid']
assert REVIEW['canonical_solution_sha256']==sha(R/'solution_q3.json')
previous=PROJECT/'问题2/论文工作/论文_写至问题二_正式.docx'
delivery=json.loads((PROJECT/'问题2/论文工作/delivery_verification.json').read_text(encoding='utf-8'))
assert sha(PROJECT.parent/'论文.doc')==delivery['sha256'],'User paper changed; preserve new changes first.'
doc=Document(previous)
transform=etree.XSLT(etree.parse(r'C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL'))
md=[];eqno=max(map(int,re.findall(r'式（(\d+)）',(PROJECT/'问题2/论文正文_问题二.md').read_text(encoding='utf-8'))))
tree=ast.parse((PROJECT/'问题1/论文工作/build_paper.py').read_text(encoding='utf-8'))
names={'native_math','inline','para','heading','equation','table'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'<verified-format-helpers>','exec'))
def figure(name,caption,width=16):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(WORK/'figures'/name),width=Cm(width));p._p.xpath('.//wp:docPr')[0].set('descr',caption)
    doc.add_paragraph(caption,style='PaperCaption');md.append(f'![{caption}](论文工作/figures/{name})\n')

# Minimal global clarification; earlier Q1 correctly attributed the exponent already.
for p in list(doc.paragraphs):
    if p.text.startswith('AI辅助使用说明：'):p._element.getparent().remove(p._element)
    if p.text=='以下假设和计算约定用于问题一；题目已经明确的规则直接执行，不将其重复包装为额外假设。':
        p.text='以下为公共物理计算约定，后续各问的调度与通信操作解释在对应模型中给出。题目明确规定的规则直接执行，不将其重复包装为额外假设。'
    if p.text.startswith('假设2：'):
        p.text=p.text+' 其中等效航程关系中的3/2指数，以及航段能耗为水平与爬升分量之和，均由题设附录2给出。'
    if p.text.startswith('假设5：'):
        p.text=p.text.replace('假设5：基准方案','假设5：问题一基准方案')
    if p.text.startswith('关键词：'):
        a=p.insert_paragraph_before(style='PaperBody');a.add_run('针对问题三，构建全过程通信约束下的运输与中继联合调度模型。根据双向链路预算和DEM视线扫掠几何划分连续通信区间，将中继位置、驻留、实体与能源组件周转嵌入候选路径调度。所得方案以25个运输架次和3个中继架次完成全部配送，联合最后返航为100.449分钟，总能耗70.0984 kWh；31项硬截止全部满足，冻结地形几何下未发现通信缺口。通过位置细化、节能备选和通信裕量压力回放说明方案的效率与适用边界。')
        p.text='关键词：无人机应急运输；动态规划；路径与调度；共享电池；连续通信；中继选址'

heading('5.3 问题三 全过程通信约束下的运输与中继联合调度',2)
heading('5.3.1 新增约束与模型衔接',3)
para('第三问要求运输无人机自起飞至返航始终保持通信，覆盖爬升、巡航、下降、交接及最后返程。中继既须连接运输机，又须维持与固定网关的回传，其转场、建链、驻留和返航还受机体与能源组件周转限制。因此，不能在第二问调度后仅按服务区位置补设静态覆盖点，而应联合确定运输开始时刻、中继位置和服务窗口。')
para('公共装载、飞行、交接与能源口径沿用前两问。其中，载荷—航程的3/2指数以及水平、爬升两类能耗相加来自题设；按可用电量和等效航程折算水平分量、以重力势能除以效率计算爬升分量，才是前文明确的补充关系。第三问不改变这些计算值。')
para('中继单架次保持一个悬停位置，可同时保障多个运输客户，不另设题目未给出的客户容量限制。准备和建链分别为180 s、30 s，返航后机体周转300 s；组件从返航开始独立充电，允许与机体周转并行。建链及驻留空档均计入悬停与通信耗电，起飞前准备不纳入运输连续通信区间。')
heading('5.3.2 双向链路预算与连续遮挡判定',3)
para(r'设固定通信端为 $a$，运输机瞬时位置为 $p$，三维距离为 $d(a,p)$。按附录3，自由空间损耗与地形遮挡附加损耗构成总路径损耗，其中 $I_{\mathrm{obs}}$ 表示视线是否接触地形。距离以m代入，频率为2400 MHz，有')
equation(r'PL(a,p)=32.45+20\log_{10}(2400)+20\log_{10}\!\left[\frac{d(a,p)}{1000}\right]+10I_{\mathrm{obs}}(a,p).')
para(r'系统损耗3 dB、接收灵敏度−98 dBm、安全裕量8 dB。链路必须双向满足门限，以发射功率 $P_a,P_b$ 和天线增益 $G_a,G_b$ 表示，其允许路径损耗为')
equation(r'L_{ab}^{\max}=\min\{P_a+G_a+G_b-L_{\mathrm{sys}},P_b+G_b+G_a-L_{\mathrm{sys}}\}-P_{\mathrm{sens}}-M.')
table('表11 三类链路的双向预算及距离阈值',['链路','正/反向门限 dB','双向门限 dB','有遮挡距离 m','无遮挡距离 m'],[['运输—G01','122 / 129','122','3956.296','12510.906'],['运输—中继接入','116 / 116','116','1982.845','6270.306'],['中继回传—G01','126 / 134','126','6270.306','19828.450']],[3.5,3.5,2.8,3.3,3.3])
para('固定网关G01天线海拔为127.7+20=147.7 m。遮挡并不等于失联：近距离即使附加10 dB损耗仍可能连通；反之，无遮挡的远距离链路也可能失败。接入与回传分别使用相应设备参数，不能混用中继回传天线增益。')
para(r'将每条实际轨迹按匀速爬升、平飞、下降和定点交接分段。对一段轨迹 $p(u)=(1-u)p_0+up_1$，固定端 $a$ 与移动端之间的全部视线形成扫掠三角形：')
equation(r'q=a+\lambda_1(p_0-a)+\lambda_2(p_1-a),\quad\lambda_1,\lambda_2\ge0,\quad\lambda_1+\lambda_2\le1.')
para(r'把三角形与DEM像元构成的地形柱求交。像元的四条投影边界及高程约束在 $\lambda$ 坐标中均为线性半空间；非空交集经 $u=\lambda_2/(\lambda_1+\lambda_2)$ 映射为闭遮挡区间。对所有相关像元取并集，再加入通信距离阈值的二次方程根和中继服务窗口边界，得到链路状态恒定的开区间。每个开区间利用端点距离包络核验，所有事件点另行检查。')
para('该方法直接追踪遮挡与距离变化，不依赖固定时间步长采样。实现对零分母、竖直轨迹及孤立相切端点单独处理，避免两个采样端点均通却漏掉中间短遮挡。几何采用UTM 49N投影凸像元、原始DEM高程及2 mm外扩缓冲；抽取2000条像元边进行投影细分，最大观测弦差约6.80×10⁻⁶ m。该检查支持数值表示的稳定性，但不构成所有投影曲线误差的解析上界。')
heading('5.3.3 中继飞行与可变驻留资源模型',3)
para(r'中继j的悬停海拔为 $z_j=z_{\mathrm{DEM},j}+h_j$，当地离地高度满足 $0<h_j\le300$ m，位置必须在DEM内。设调度中心至悬停点的水平距离为 $d_j$，考虑悬停终点与沿线净空，其转场巡航海拔为')
equation(r'H_j=\max\{z_O,z_j,\max_{v\in\mathcal C_{Oj}}z_{\mathrm{DEM},v}+50\}.')
para('水平速度15 m/s，爬升与下降速度分别4、3 m/s。往程与返程须分别计入两端的升降，悬停位置较高时不能仍使用低于终点的巡航海拔。')
equation(r't_j^{\mathrm{out}}=\frac{H_j-z_O}{4}+\frac{d_j}{15}+\frac{H_j-z_j}{3},\qquad t_j^{\mathrm{back}}=\frac{H_j-z_j}{4}+\frac{d_j}{15}+\frac{H_j-z_O}{3}.')
para(r'设准备开始为 $Y_j$，到达为 $A_j=Y_j+180+t_j^{\mathrm{out}}$，建链完成为 $B_j=A_j+30$，离开悬停点为 $F_j$，返航为 $R_j=F_j+t_j^{\mathrm{back}}$。23.5 kg为含通信模块的计划起飞总质量，不再重复加模块质量。两程飞行能耗与全部驻留耗电为')
equation(r'E_j^R=1.15\frac{2d_j/15}{3600}+\frac{23.5g_0(2H_j-z_O-z_j)}{0.72\cdot3.6\times10^6}+1.10\frac{F_j-A_j}{3600}\le2.56.')
para(r'可用能量3.2 kWh、返航安全余量20%，故单架次上限为2.56 kWh。中继机体有2架，能源组件6组，组件等效充满时间1800 s。由 $s_j=1-E_j^R/3.2$ 代入前文两阶段充电函数得到 $\chi_R(s_j)$。资源分别满足')
equation(r'\sum_j\mathbf1\{t\in[Y_j,R_j+300)\}\le2,\qquad\sum_j\mathbf1\{t\in[Y_j,R_j+\chi_R(s_j))\}\le6.')
para('两类占用从准备开始计，采用半开区间，同刻允许先释放再占用。中继服务窗口决定驻留能耗，能耗又影响充满时刻，故不能将补电时间预设为一个与服务长度无关的常数。最后一次返航后的周转与充电不延长题目定义的联合完工时间。')
heading('5.3.4 集合划分与联合约束规划',3)
para(r'沿用第二问的运输候选 $r$、箱集 $B_r$、选择变量 $x_r$ 与准备时刻 $S_r$。每个箱恰好选择一次，医疗与首批硬截止必须满足，运输机体、电池继续采用按机型区分的可选区间累计约束。中继采用可选槽j，联合决定是否启用、位置、开始及服务结束时刻。')
para(r'将候选r中直连不足的部分分为需求块 $c=[a_{rc},b_{rc}]$，令 $K_{rc}$ 为能完整覆盖该块且回传合格的位置集合，$z_{rcj}$ 表示该块交由中继j保障。设 $y_j$ 为槽激活变量、$k_j$ 为所选位置，则')
equation(r'\sum_{r:b\in B_r}x_r=1,\qquad \sum_jz_{rcj}=x_r,\qquad z_{rcj}\le y_j.')
equation(r'z_{rcj}=1\ \Longrightarrow\ k_j\in K_{rc},\quad B_j\le S_r+a_{rc},\quad F_j\ge S_r+b_{rc}.')
para('一架中继允许覆盖多个同时发生的需求块，因此通信客户之间不设置互斥。模型属于路径集合划分、可更新资源调度与时间区间覆盖的耦合，以CP-SAT约束规划求解。仍采用及时性优先的字典序目标，将中继的能耗、架次数和最后返航纳入评价：')
equation(r'\min_{\mathrm{lex}}(D,C_J,E_J,N_J),\quad C_J=\max\{\max_rR_r,\max_jR_j\}.')
equation(r'E_J=\sum_rx_rE_r^T+\sum_jE_j^R,\qquad N_J=\sum_rx_r+\sum_jy_j.')
para('初始从900 m平面网格、网格高点与任务节点形成400个水平候选，以150/300 m离地高度筛选出66个活动位置；再对末班候选位置使用150 m水平偏移及200/250/300 m高度细化，新增16点。先在25条继承路线中联合重排时间与中继，再将运输候选扩大至311条比较。最终及时性优先方案仍采用第二问的路线集合，但开始时刻、逐箱顺序与中继计划已重新确定。')
para('开始时刻以0.1 s网格表示，资源长度向上取整，保障需求边界向外取整；最终按未舍入物理量重算。每层搜索仅得到可行解时，以当前最好值约束下一层，保留其未证明最优的状态。前四层网格目标相同时，增加最小硬截止提前量作为平局规则。主方案局部25路线、19位置模型得到网格最优；311路线扩充模型尚未闭合上下界。仅D=0可由非负下界证明原问题该层最优。')
heading('5.3.5 联合方案与全过程保障',3)
para(f"主方案全部80箱唯一且按期交付，31项硬截止无违规，最小提前量{S['min_hard_slack']:.3f} s。运输25架次，其中A/B/C型为12/7/6次；中继3架次，由2架实体执行。联合最后返航{S['C_joint']:.6f} s（{S['C_joint']/60:.3f} min），运输与中继能耗分别为{S['E_transport']:.6f}、{S['E_relay']:.6f} kWh，总计{S['E_total']:.6f} kWh。")
relay=rows('relay_trips_q3.csv')
table('表12 中继悬停位置及回传余量',['位置','经度 °E','纬度 °N','离地高度 m','悬停海拔 m','回传余量 dB'],[[r['id'],f"{float(r['lon']):.8f}",f"{float(r['lat']):.8f}",f"{float(r['agl']):.0f}",f"{float(r['z']):.3f}",f"{float(r['backhaul_margin']):.3f}"] for r in relay],[1.5,3.5,3.4,2.4,2.9,2.7])
table('表13 中继实体与服务窗口安排',['架次','实体/组件','准备开始 s','建链完成 s','服务结束 s','返航 s'],[[r['sortie'].replace('Q3R-','R-'),r['aircraft']+'/'+r['component'][-2:],f"{float(r['start']):.3f}",f"{float(r['link_complete']):.3f}",f"{float(r['service_end']):.3f}",f"{float(r['return']):.3f}"] for r in relay],[1.7,2.4,3,3.1,3.1,3.1])
para('表中R-001至R-003分别对应正式提交的Q3R-001至Q3R-003，组件01/02为独立能源组件。R01完成首次任务后，机体于2787.594 s周转完毕、组件01于3243.712 s充满，均早于第二次准备开始3911.200 s；R02执行中间长驻留架次。中继机体和组件峰值均为2，运输机体峰值A/B/C为4/2/2，电池峰值6/4/4，均满足原始库存。')
figure('Q3_地形与联合方案.png','图5 地形约束下的运输航线与中继悬停位置')
para('图5灰线为实际运输航段，红线标出需要中继保障的巡航子段，虚线为固定回传，AGL表示当地离地高度。升降与交接阶段另由时间区间核验，不能从平面航线图直接推断其通信状态。')
figure('Q3_联合资源调度.png','图6 运输机体和中继机体及能源组件的执行时间线')
para('图6竖虚线表示最后返航；其后的机体周转和组件充电保留于资源核算，但不计入联合完工。运输电池的完整逐实体使用与补电记录另列于结果表。中继实际只使用两组组件，不代表备用组件在其他位置、时序或扰动情景下没有作用。')
figure('Q3_全过程通信保障.png','图7 运输无人机从起飞至返航的实际通信保障来源')
para(f"图7各条带覆盖相应架次的全部起飞至返航过程，不含起飞前准备。直连与中继保障分别累计{S['direct_customer_seconds']:.3f}、{S['relay_customer_seconds']:.3f}客户秒；允许并发客户，因此该统计不可等同于中继驻留墙钟时间。三个中继架次最多同时保障4、5、3架运输机。")
para('最终记录包括363个开区间与550条事件点，事件按架次与精确时刻合并为388个，162条重复阶段边界的来源全部一致。依据直连优先和固定中继顺序确定唯一实际来源，逐条核验后冻结该映射，而非保存多个可行备选供第四问任意切换。已发现失联和未认证区间均为0。')
heading('5.3.6 对照与资源能耗取舍',3)
table('表14 同一物理与通信口径下的方案比较',['方案','联合完工 min','总能耗 kWh','运输/中继架次','最紧硬裕量 s'],[['初始三位置重排','100.721','70.468031','25 / 3','61.542'],['细化位置主方案','100.449','70.098400','25 / 3','61.542'],['放宽完工的节能备选','102.614','68.894397','24 / 3','0.026']],[4.4,3.1,3.2,3.1,2.6])
para('第二问原方案无中继回放累计存在12925.278客户秒直连缺口，最长单架次连续缺口约1206.012 s，不能直接作为第三问可行方案。在初始66位置与8中继槽内固定第二问路线和时刻补中继，得到有限模型不可行；允许联合重排后获得完整可行解。这支持本候选体系中联合时序的价值，不能证明整个DEM上不存在其他后置补中继方案。')
para('主方案较第二问已知可行方案的完工晚87.443 s、总能耗增加2.517901 kWh。第二问结果不是完工下界，因此该差值不能称为通信保障的理论最小代价。三个位置附近的嵌套细化使联合返航较初始方案再缩短16.357 s，说明末班中继位置与高度会直接影响联合完工。')
para('节能备选保持D=0和连续通信可行，晚129.900 s全部返航，节约1.204002 kWh并少用1个运输架次，但最紧硬截止仅提前0.026 s。它体现了完工、能耗与时间裕量的取舍，不全面优于主方案；有限样本不构成完整Pareto前沿。旧固定位置组合下三个独立种子、相同热启动与每层25 s预算均得到6043.276671 s和70.104939 kWh，仅说明该组有限实验目标稳定。')
table('表15 固定主方案的通信与中继能源压力回放',['情景','结果','累计客户失联 s','解释'],[['安全裕量8 dB','通过','0','原题基准'],['安全裕量10 dB','不通过','5750.741','原方案不能直接照用'],['安全裕量12 dB','不通过','9853.228','原方案不能直接照用'],['中继组件减至4组','通过','0','原方案仅使用2组'],['中继驻留功率增加5%','通过','0','补电重算无冲突']],[4.5,2.1,4.0,5.8])
para('功率压力回放把到达至离开的全部驻留耗电提高5%，重新计算SOC和充满时间后，原有实体顺序不产生等待传播，最小中继SOC仍为57.2031%，故轨迹与保障窗口不变。该结论不代表飞行时间或随机风场扰动的鲁棒性。运输部分统一能耗上浮约1.199%便触及最紧能量限额，仍是联合方案的敏感环节。')
para('增加通信安全裕量后，原方案失效。已有受限旧池10 dB重优化在时限内返回UNKNOWN，12 dB出现候选覆盖空缺，均未获得增强裕量下的新可行证书。基准最小额外链路余量近0 dB，浮点量级负值约4.12×10⁻¹³ dB；这已扣除题设8 dB安全裕量，不能再表述为具有显著额外余量。')
heading('5.3.7 独立验证与冻结接口',3)
para('核验器重读原始Excel和DEM，重建逐段载荷、飞行与交接、逐箱完成时刻、SOC、充电及实体占用。通信剖面从真实轨迹重新生成，不信任求解器的可行标签；63条关键射线和回传链路采用独立GEOS交叉核验，中继转场则用整条投影线段与DEM像元求交检查净空。49项专项测试、8类故障注入以及新增3项几何边界测试均通过。')
para('工作簿采用全精度底层数值、显示位数与计算精度分离。读回后逐单元格核对并重建方案进行完整回放，比较6086个单元格未发现数值差异。运输飞行与交接累计34455.797254 s，与直连和中继客户秒之和相差约2.91×10⁻¹¹ s；同时逐区间与事件点检查排除了仅总量相等但局部缺口抵消的可能。')
para('连续性结论限于冻结的DEM投影像元、给定无线参数及数值容差，不外推为真实地形、随机衰落或实飞保证。第四问据此冻结运输组批、访问顺序、机型、时刻、中继任务及实际保障来源；资源编号是否允许在组间重新配置须另作明确解释，不能通过移动任务或删除孤立保障事件降低分区资源需求。')
para('AI辅助使用说明：代码实现、核验与文字整理使用OpenAI Codex辅助；网页版ChatGPT Pro用于方案讨论。所有结果以本地原始附件与实际运行输出为依据，外部建议中的条件预核算不直接充作本地结果。',small=True)
doc.core_properties.subject='论文正文至问题三';doc.save(WORK/'论文_写至问题三_正式.docx')
(ROOT/'论文正文_问题三.md').write_text('\n'.join(md),encoding='utf-8')
files=['solution_q3.json','solution_summary.json','validation_q3.json','relay_trips_q3.csv','baselines_q3.csv','final_sensitivities.csv','final_power_stress.json','workbook_audit.json','tests_q3.json','fault_injection_tests.json','communication_interface_audit.json','pro_review_q3.json','第三问完整报告.md']
freeze=dict(scope='Q3 paper verified solution package',authorization='用户明确要求完善第三问并写入论文，授权自主判断改进；沿用已验证及时性优先主方案及原报告结论边界。',source_hashes={n:sha(R/n) for n in files},metrics=S,figure_source_sha256=sha(R/'solution_q3.json'),equations_total=eqno,tables_total=len(doc.tables),previous_paper_sha256=sha(previous),external_paper_before_sha256=delivery['sha256'],claim_limits=['D=0 original objective global lower bound only','Other objectives finite pool and grid, not global continuous optimum','Continuous geometry finite precision','8dB nominal margin only; 10/12dB fixed plan fails'])
(WORK/'frozen_numbers.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'docx':str(WORK/'论文_写至问题三_正式.docx'),'equations_total':eqno,'tables_total':len(doc.tables)},ensure_ascii=False))
