from setup_q3 import *
from validate_q3 import run
from communication import Radio
from routes import charge
import copy,contextlib,io,shapely,time

def main(path=None):
    path=Path(path or OUT/'solution_q3.json');sol=json.loads(path.read_text(encoding='utf-8'))
    directory=OUT/'final_checks';directory.mkdir(exist_ok=True)
    def audit(obj,name,**kwargs):
        p=directory/(name+'.json');dump(p,obj)
        with contextlib.redirect_stdout(io.StringIO()):v=run(p,save=False,**kwargs)
        dump(directory/(name+'_validation.json'),v);return v
    positive=audit(sol,'original');assert positive['summary']['valid']
    cases=[]
    def fault(name,change):
        obj=copy.deepcopy(sol);change(obj);r=audit(obj,name)
        assert not r['summary']['valid'],name
        cases.append(dict(name=name,detected=True,error_codes=sorted({e['code'] for e in r['errors']})))
        print('fault detected',name,flush=True)
    fault('wrong_soc',lambda s:s['relay'][0].update(SOC=.99))
    fault('missing_turnaround',lambda s:s['relay'][0].update(aircraft_ready=s['relay'][0]['return']))
    fault('component_7',lambda s:s['relay'][0].update(component='R-COMP-07'))
    fault('overlapping_aircraft',lambda s:s['relay'][1].update(aircraft=s['relay'][0]['aircraft']))
    fault('link_before_actual_arrival',lambda s:s['relay'][0].update(link_complete=s['relay'][0]['arrival']))
    fault('incorrect_return',lambda s:s['relay'][2].update(return_=0,**{'return':s['relay'][2]['return']-5}))
    fault('no_relays_full_return_audit',lambda s:s.update(relay=[]))
    fault('height_above_limit',lambda s:s['relay'][0]['site'].update(agl=301))
    dump(OUT/'fault_injection_tests.json',dict(passed=len(cases),source_sha256=sha(path),checks=cases))
    stress=[]
    for margin in (10,12):
        r=audit(sol,f'margin_{margin}',margin=margin);stress.append(dict(scenario=f'margin_{margin}_fixed',**r['summary']))
    reduced=copy.deepcopy(sol);reduced['resources']=[2,4];r=audit(reduced,'components_4');assert r['summary']['valid'];stress.append(dict(scenario='components_4_fixed',**r['summary']))
    power=[];conflicts=[]
    for r in sol['relay']:
        e=r['site']['fly_energy']+1.05*1.1*(r['service_end']-r['arrival'])/3600
        power.append(dict(sortie=r['sortie'],component=r['component'],start=r['start'],return_s=r['return'],energy=e,SOC=1-e/3.2,component_ready=r['return']+charge(1-e/3.2,1800),energy_feasible=e<=2.56))
    for c in {r['component'] for r in power}:
        ordered=sorted((r for r in power if r['component']==c),key=lambda r:r['start'])
        conflicts += [(a['sortie'],b['sortie']) for a,b in zip(ordered,ordered[1:]) if a['component_ready']>b['start']+1e-6]
    feasible=not conflicts and all(r['energy_feasible'] for r in power)
    dump(OUT/'final_power_stress.json',dict(source_sha256=sha(path),power_factor=1.05,rows=power,all_energy_feasible=feasible,component_conflicts=conflicts,propagated_delays_s=0 if feasible else None,scope='All dwell including link and waiting stressed; charge recomputed. If feasible, all starts and communication windows unchanged, zero delay propagation; no new optimization claimed.'))
    table(OUT/'final_sensitivities.csv',stress)
    # Independent GEOS intersection over the entire projected flight segment.
    d=inputs();eng=Radio(d);geometry=[]
    for r in sol['relay']:
        site=r['site'];a=np.r_[d['gateway'][:2],-1e6];b=np.array([site['x'],site['y'],-1e6]);vs,hs=eng.cells(a,b,b)
        hit=shapely.intersects(shapely.polygons(vs),shapely.LineString([a[:2],b[:2]]))
        groundmax=float(np.max(hs[hit]));required=max(d['nodes']['O01']['z'],site['z'],groundmax+50)
        geometry.append(dict(sortie=r['sortie'],independent_dem_max=groundmax,required_cruise=required,actual_cruise=site['cruise'],passed=site['cruise']>=required-1e-7,visited_cells=int(np.sum(hit))))
    assert all(x['passed'] for x in geometry),geometry
    dump(OUT/'relay_transfer_geometry_audit.json',dict(source_sha256=sha(path),method='GEOS exact projected pixel/whole-segment intersection, no along-path sampling',rows=geometry))
    print('final checks complete',flush=True)

if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else None)
