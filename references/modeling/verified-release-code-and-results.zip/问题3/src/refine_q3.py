from setup_q3 import *
from communication import Radio
from sites import relay_metrics
from atoms import build_route
from routes import Physics
from joint import solve
from validate_q3 import run
import math

def main():
    d=inputs();P=Physics();radio=Radio(d);allsite=json.loads((OUT/'relay_sites.json').read_text(encoding='utf-8'));center=next(s for s in allsite if s['id']=='P010');nodes=d['nodes'];candidates=[]
    for dx in (-300,-150,0,150,300):
        for dy in (-300,-150,0,150,300):
            for agl in (200,250,300):
                lon,lat=INVERSE.transform(center['x']+dx,center['y']+dy);m=relay_metrics(d,lon,lat,agl);p=[m['x'],m['y'],m['z']]
                if not radio.point(d['gateway'],p,'backhaul')['valid']:continue
                cover=[]
                for name,n in nodes.items():
                    if name=='O01':continue
                    t=n['xy']+[n['z']+30]
                    if radio.profile(p,t,t,'access')['pieces'][0][2]:cover.append(name)
                if 'S004' not in cover:continue
                m['cover']=cover;candidates.append(m)
    candidates.sort(key=lambda s:(s['back'],-len(s['cover'])))
    added=[]
    for s in candidates[:18]:
        if any(abs(s['lon']-old['lon'])<1e-10 and abs(s['lat']-old['lat'])<1e-10 and abs(s['agl']-old['agl'])<1e-10 for old in allsite):continue
        s['id']=f'P{len(allsite)+1:03d}';allsite.append(s);added.append(s['id'])
    dump(OUT/'relay_sites.json',allsite);table(OUT/'relay_sites.csv',allsite)
    dump(OUT/'site_refinement.json',dict(parent='P010',offsets_m=[-300,-150,0,150,300],heights=[200,250,300],accepted=len(candidates),activated=added))
    ids=['P001','P009','P010']+added;sites=[s for s in allsite if s['id'] in ids];atoms={};rows=json.loads((PROJECT/'问题2/results/solution.json').read_text(encoding='utf-8'))
    for r in rows:atoms[r['route']['id']],_=build_route(r['route'],P,radio,sites,max_block=30)
    dump(OUT/'refined_atoms.json',atoms)
    warm=json.loads((OUT/'experiments/seed_2/solution_q3.json').read_text(encoding='utf-8'))
    result=solve('refined_joint',seconds=90,slots=3,site_ids=ids,atoms=atoms,warm=warm,zero_late=True,max_C=6043.4,objectives=('C','E','N','H'))
    if result:run(OUT/'refined_joint/solution_q3.json')

if __name__=='__main__':main()
