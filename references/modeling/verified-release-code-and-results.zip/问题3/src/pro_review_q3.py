"""Check source attribution and corner cases without changing the Q3 schedule."""
from setup_q3 import *
from communication import blocked_kernel,merge
from validate_q3 import state
import zipfile,xml.etree.ElementTree as ET,datetime,csv

def main():
    source=PROJECT.parent/'D题/山区洪涝灾害下无人机运输与通信协同优化.docx'
    with zipfile.ZipFile(source) as z:doc=ET.fromstring(z.read('word/document.xml'))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
    eqs=[''.join(x.itertext()) for x in doc.findall('.//m:oMath',ns)]
    power=[e for e in eqs if '3/2' in e]
    addition=[e for e in eqs if 'hor' in e and 'up' in e and '+' in e]
    assert power and addition,(len(eqs),eqs)
    frozen=OUT/'solution_q3.json';sol=json.loads(frozen.read_text(encoding='utf-8'))
    rows=list(csv.DictReader((OUT/'communication_intervals_q3.csv').open(encoding='utf-8-sig')))
    physical=sum(r['return']-r['start']-r['route']['prep'] for r in sol['transport'])
    communication=sum(float(r['end'])-float(r['start']) for r in rows)
    assert abs(physical-communication)<1e-7
    checks=[]
    def check(n,c):assert c,n;checks.append(dict(name=n,passed=True))
    # Anchor inside a terrain column gives lambda1=lambda2=0: handle without division.
    vs=np.array([[[-1,1],[1,1],[1,-1],[-1,-1]]],float)
    iv=merge(blocked_kernel(np.array([0.,0.,0.]),np.array([3.,-1.,3.]),np.array([3.,1.,3.]),vs,np.array([1.]),0.))
    check('lambda denominator zero anchor inside terrain',iv==[[0.,1.]])
    # Swept ray just touches one pixel corner at the end event; it must survive.
    vs=np.array([[[1.,2.],[2.,2.],[2.,1.],[1.,1.]]])
    a=np.array([0.,0.,1.]);p0=np.array([2.,0.,1.]);p1=np.array([2.,1.,1.])
    iv=merge(blocked_kernel(a,p0,p1,vs,np.array([2.]),0.))
    check('isolated tangent endpoint retained',bool(iv) and abs(iv[-1][0]-1)<1e-8 and abs(iv[-1][1]-1)<1e-8)
    check('explicit invalid event overrides neighboring pass interval',not state({'pieces':[[0.,1.,True]],'events':[.5]},.5,True))
    report=dict(date=datetime.datetime.now().isoformat(),source_docx=str(source),source_sha256=sha(source),source_equations={'range_given_in_appendix_2':power,'additive_energy_given_in_appendix_2':addition},correction='Exponent 3/2 and sum Ehor+Eup are given. Only specific component equations are supplementary.',optimization_changed=False,canonical_solution_sha256=sha(frozen),physical_flight_handover_seconds=physical,communication_customer_seconds=communication,total_duration_difference=communication-physical,corner_checks=checks,remaining_interface_audit='Q4 independently checks actual source uniqueness, duplicate event consistency, per-group resource identities; no source reassignment authorized')
    dump(OUT/'pro_review_q3.json',report);print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
