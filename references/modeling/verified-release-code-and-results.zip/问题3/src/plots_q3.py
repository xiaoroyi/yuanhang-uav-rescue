from setup_q3 import *
from finalize_q3 import readcsv
from communication import phases
from routes import Physics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from collections import defaultdict

def main():
    out=OUT/'figures';out.mkdir(exist_ok=True)
    sol=json.loads((OUT/'solution_q3.json').read_text(encoding='utf-8'));d=inputs();P=Physics();iv=readcsv(OUT/'communication_intervals_q3.csv')
    plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    colors={'G01':'#326A96','Q3R-001':'#A65F16','Q3R-002':'#31735A','Q3R-003':'#775398'}
    def save(fig,name):
        for ext in ('png','pdf','svg'):fig.savefig(out/(name+'.'+ext),dpi=300,facecolor='white')
        plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,7),layout='constrained')
    nodes=d['nodes'];lon=np.array([n['lon'] for n in nodes.values()]);lat=np.array([n['lat'] for n in nodes.values()]);dx=d['lon'][1]-d['lon'][0];dy=d['lat'][0]-d['lat'][1]
    maskc=(d['lon']>=lon.min()-.015)&(d['lon']<=lon.max()+.015);maskr=(d['lat']>=lat.min()-.015)&(d['lat']<=lat.max()+.015);cs=np.flatnonzero(maskc);rs=np.flatnonzero(maskr)
    im=ax.imshow(d['dem'][rs[0]:rs[-1]+1,cs[0]:cs[-1]+1],extent=[d['lon'][cs[0]]-dx/2,d['lon'][cs[-1]]+dx/2,d['lat'][rs[-1]]-dy/2,d['lat'][rs[0]]+dy/2],origin='upper',cmap='terrain',alpha=.6,interpolation='nearest',aspect=1/np.cos(np.deg2rad(23)))
    visited=set()
    for r in sol['transport']:
        names=['O01']+[s for s,_ in r['route']['stops']]+['O01']
        for a,b in zip(names,names[1:]):
            if tuple(sorted((a,b))) in visited:continue
            visited.add(tuple(sorted((a,b))));ax.plot([nodes[a]['lon'],nodes[b]['lon']],[nodes[a]['lat'],nodes[b]['lat']],c='#495463',lw=.8,alpha=.6,zorder=2)
    phase={(r['sortie'],str(p['phase'])):(r,p) for r in sol['transport'] for p in phases(r['route'],P)}
    for row in iv:
        if row['source']=='G01':continue
        r,p=phase[row['sortie'],row['phase']]
        if p['type']!='巡航':continue
        u=(np.array([float(row['start']),float(row['end'])])-r['start']-p['a'])/(p['b']-p['a']);ps=np.array(p['p0'])[None,:]+u[:,None]*(np.array(p['p1'])-p['p0'])[None,:];ll,tt=INVERSE.transform(ps[:,0],ps[:,1]);ax.plot(ll,tt,c='#A63836',lw=1.7,alpha=.8,zorder=3)
    for name,n in nodes.items():
        ax.scatter(n['lon'],n['lat'],s=42 if name=='O01' else 24,marker='s' if name=='O01' else 'o',c='#152435',edgecolors='white',linewidths=.5,zorder=5)
        ax.annotate(name,(n['lon'],n['lat']),xytext=(4,4),textcoords='offset points',fontsize=8,zorder=6)
    for r in sol['relay']:
        s=r['site'];ax.plot([nodes['O01']['lon'],s['lon']],[nodes['O01']['lat'],s['lat']],ls='--',c=colors[r['sortie']],lw=1.4,zorder=4)
        ax.scatter(s['lon'],s['lat'],marker='^',s=88,c=colors[r['sortie']],edgecolors='white',zorder=7)
        offset=(-112,14) if s['id']=='P009' else (6,12) if s['id']=='P067' else (5,-16)
        ax.annotate(f"{s['id']} ({s['agl']:.0f} m AGL)",(s['lon'],s['lat']),xytext=offset,textcoords='offset points',fontsize=9,zorder=8,arrowprops={'arrowstyle':'-','color':'#555555','lw':.6} if s['id']=='P009' else None)
    ax.set(xlabel='经度 (°E)',ylabel='纬度 (°N)',title='第三问：地形、运输航线与中继位置')
    ax.ticklabel_format(useOffset=False,style='plain');fig.colorbar(im,ax=ax,pad=.02,shrink=.65,label='DEM 海拔 (m)')
    ax.legend(handles=[Line2D([],[],c='#495463',lw=1,label='运输航线'),Line2D([],[],c='#A63836',lw=2,label='需要中继的巡航段'),Line2D([],[],c='#555555',ls='--',label='固定回传链路'),Line2D([],[],c='#555555',marker='^',ls='',label='中继悬停点')],loc='lower left',fontsize=8,frameon=True)
    save(fig,'Q3_地形与联合方案')
    fig,axs=plt.subplots(3,1,figsize=(11,9),sharex=True,layout='constrained',gridspec_kw={'height_ratios':[4,1.6,1.6]})
    names=sorted({r['aircraft'] for r in sol['transport']});index={x:i for i,x in enumerate(names)};mc={'A':'#326A96','B':'#31735A','C':'#775398'}
    for r in sol['transport']:
        y=index[r['aircraft']];takeoff=r['start']+r['route']['prep'];axs[0].barh(y,r['route']['prep']/60,left=r['start']/60,height=.58,color='#D9DDE2');axs[0].barh(y,(r['return']-takeoff)/60,left=takeoff/60,height=.58,color=mc[r['route']['model']]);axs[0].text((takeoff+r['return'])/120,y,r['sortie'][-3:],ha='center',va='center',color='white',fontsize=8)
    axs[0].set(yticks=range(len(names)),yticklabels=names,title='A  运输无人机：准备与完整往返');axs[0].invert_yaxis()
    for r in sol['relay']:
        y=int(r['aircraft'][-2:])-1;c=colors[r['sortie']];s=r['start'];b=r['link_complete'];f=r['service_end'];ret=r['return']
        axs[1].barh(y,(b-s)/60,left=s/60,height=.52,color='#CED5DC');axs[1].barh(y,(f-b)/60,left=b/60,height=.52,color=c);axs[1].barh(y,(ret-f)/60,left=f/60,height=.52,color='#CED5DC');axs[1].barh(y,5,left=ret/60,height=.52,facecolor='none',edgecolor='#666666',hatch='///');axs[1].text((b+f)/120,y,r['sortie']+' '+r['site']['id'],ha='center',va='center',fontsize=8,color='white')
        k=int(r['component'][-2:])-1;axs[2].barh(k,(ret-s)/60,left=s/60,height=.52,color=c);axs[2].barh(k,r['charge']/60,left=ret/60,height=.52,color='#E1D8EA',edgecolor='#775398',hatch='...')
    axs[1].set(yticks=[0,1],yticklabels=['R01','R02'],title='B  中继无人机：建链后驻留与返航周转');axs[1].invert_yaxis()
    axs[2].set(yticks=[0,1],yticklabels=['组件 01','组件 02'],xlabel='从任务开始计时 (min)',title='C  实际使用的中继能源组件：任务占用与补电');axs[2].invert_yaxis()
    for ax in axs:ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True);ax.axvline(max(r['return'] for r in sol['relay'])/60,c='#333333',ls=':',lw=1);ax.set_xlim(0,120)
    axs[0].legend(handles=[Patch(color='#D9DDE2',label='准备'),Patch(color=mc['A'],label='A型'),Patch(color=mc['B'],label='B型'),Patch(color=mc['C'],label='C型')],loc='upper right',ncol=4,fontsize=8)
    axs[1].legend(handles=[Patch(color='#CED5DC',label='准备/转场/建链'),Patch(facecolor='none',edgecolor='#666666',hatch='///',label='返航后周转300 s')],loc='upper right',ncol=2,fontsize=8)
    axs[2].legend(handles=[Patch(facecolor='#E1D8EA',edgecolor='#775398',hatch='...',label='返航后组件充电')],loc='upper right',fontsize=8)
    axs[0].set_ylim(len(names)-.5,-1.15)
    axs[1].set_ylim(1.5,-.85);axs[2].set_ylim(1.5,-.85)
    save(fig,'Q3_联合资源调度')
    fig,ax=plt.subplots(figsize=(11,10),layout='constrained');rows=sorted(sol['transport'],key=lambda r:r['sortie']);pos={r['sortie']:i for i,r in enumerate(rows)}
    hatches={'G01':'','Q3R-001':'//','Q3R-002':'..','Q3R-003':'xx'}
    for r in iv:ax.barh(pos[r['sortie']],(float(r['end'])-float(r['start']))/60,left=float(r['start'])/60,height=.66,color=colors[r['source']],hatch=hatches[r['source']],edgecolor='white',linewidth=0)
    ax.set(yticks=range(len(rows)),yticklabels=[r['sortie']+'  '+'→'.join(s for s,_ in r['route']['stops']) for r in rows],xlabel='从任务开始计时 (min)',xlim=(0,103),title='第三问：25个运输架次起飞至返航的全过程通信保障')
    ax.tick_params(axis='y',labelsize=8);ax.invert_yaxis();ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
    ax.legend(handles=[Patch(color=c,hatch=hatches[k],label='G01 直连' if k=='G01' else k) for k,c in colors.items()],loc='upper center',bbox_to_anchor=(.5,-.065),ncol=4,fontsize=9)
    save(fig,'Q3_全过程通信保障')
    dump(out/'figure_provenance.json',dict(source_sha256=sha(OUT/'solution_q3.json'),communication_sha256=sha(OUT/'communication_intervals_q3.csv'),destination='mathematical modeling report, provisional general scientific style',formats=['png 300dpi','pdf','svg'],map_transform='DEM cropped, original height raster, nearest-neighbor display; longitude latitude geographic map',timeline_units='minutes; actual source seconds divided by 60',coverage_semantics='time bars from certified open intervals; all event points checked separately in CSV, no invented coverage circles',captions={'Q3_地形与联合方案':'灰线为所有实际航段，红线为实际需要中继保障的巡航子段；爬升、下降、交接的通信状态见条带图。AGL为当地离地高度。','Q3_联合资源调度':'显示运输飞机和中继飞机/组件的时间线；运输电池完整逐实体记录另见battery_timeline.csv。竖虚线为联合最后返航，之后充电、周转不计入完工。','Q3_全过程通信保障':'每条覆盖整个起飞至返航区间；不含起飞前准备；事件点单独核验。条带之间空白表示不同架次的未飞行时段。'}))
    print('3 figures exported',flush=True)

if __name__=='__main__':main()
