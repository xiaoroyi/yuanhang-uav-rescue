from setup_q3 import *
from communication import Radio,blocked_kernel,merge
from validate_q3 import independent_ray,run
from routes import charge
from ortools.sat.python import cp_model as cp
import tempfile,copy,math,time

def main():
    checks=[]
    def test(name,condition):
        assert condition,name;checks.append(dict(name=name,passed=True))
    d=inputs();radio=Radio(d)
    test('bidirectional budgets',radio.limits=={'direct':122,'access':116,'backhaul':126})
    test('gateway antenna',d['gateway'][2]==147.7)
    test('direction asymmetric gateway',d['radio']['direct']['forward']==122 and d['radio']['direct']['reverse']==129)
    test('relay mass includes module',d['relay']['mass']==23.5)
    test('relay charging boundary',abs(charge(.9,1800)-630)<1e-8)
    test('relay charge at reserve',abs(charge(.2,1800)-1540)<1e-8)
    for e in (.01,.32,.320001,1.,2.56):
        formula=1968.75*e if e<=.32 else 500+406.25*e
        test('charging '+str(e),abs(formula-charge(1-e/3.2,1800))<1e-8)
    vs=np.array([[[1.4,.4],[1.6,.4],[1.6,.2],[1.4,.2]]]);hs=np.array([11.]);a=np.array([0.,0.,10.]);p0=np.array([3.,-1.,10.]);p1=np.array([3.,2.,10.])
    iv=merge(blocked_kernel(a,p0,p1,vs,hs,0.))
    test('short obstruction inside sweep',len(iv)>0 and iv[0][0]>0 and iv[-1][1]<1)
    test('endpoint samples miss interior ridge',len(blocked_kernel(a,p0,p0,vs,hs,0.))==0 and len(blocked_kernel(a,p1,p1,vs,hs,0.))==0)
    test('flat terrain clear',len(blocked_kernel(a,p0,p1,vs,np.array([0.]),0.))==0)
    # Vertical projection remains valid under barycentric clipping.
    v0=np.array([3.,.6,0.]);v1=np.array([3.,.6,30.]);iv=merge(blocked_kernel(a,v0,v1,vs,np.array([6.]),0.))
    test('vertical ascent has partial shadow',bool(iv) and iv[0][0]==0 and iv[0][1]<1)
    rng=np.random.default_rng(23);nodes=list(d['nodes'].values())
    for i in range(30):
        n=nodes[i%len(nodes)];p=np.array(n['xy']+[n['z']+float(rng.uniform(30,300))]);a=d['gateway']
        test('independent GEOS ray '+str(i),bool(radio.blocked(a,p,p))==independent_ray(radio,a,p))
    # Quantify curved projected-edge approximation at 2000 sampled cell edges.
    errors=[]
    for _ in range(1000):
        rr=int(rng.integers(0,d['dem'].shape[0]));cc=int(rng.integers(0,d['dem'].shape[1]));lon=d['lon'][cc];lat=d['lat'][rr]
        for vertical in (False,True):
            if vertical:lons=np.full(5,lon-radio.dx/2);lats=np.linspace(lat-radio.dy/2,lat+radio.dy/2,5)
            else:lons=np.linspace(lon-radio.dx/2,lon+radio.dx/2,5);lats=np.full(5,lat-radio.dy/2)
            xx,yy=FORWARD.transform(lons,lats);pts=np.column_stack([xx,yy]);v=pts[-1]-pts[0];t=((pts-pts[0])@v)/np.dot(v,v);errors.extend(np.linalg.norm(pts-(pts[0]+t[:,None]*v),axis=1))
    test('sampled projection curvature below 2mm buffer',max(errors)<.002)
    dump(OUT/'geometry_approximation_audit.json',dict(sampled_edges=2000,subdivisions=4,maximum_observed_chord_deviation_m=max(errors),buffer_m=.002,scope='numerical approximation audit, not an analytic bound over all curved pixels'))
    # Explicit/aggregate interval model equivalence on bounded micro instance.
    costs=[]
    for explicit in (False,True):
        model=cp.CpModel();ss=[model.new_int_var(0,30,'s'+str(i)) for i in range(4)];ends=[model.new_int_var(0,40,'e'+str(i)) for i in range(4)];dur=[4,6,3,7];ints=[];ent=[[],[]]
        for i in range(4):
            iv=model.new_interval_var(ss[i],dur[i],ends[i],'i'+str(i));ints.append(iv)
            if explicit:
                z=[model.new_bool_var(f'z{i}{j}') for j in range(2)];model.add(sum(z)==1)
                for j in range(2):ent[j].append(model.new_optional_interval_var(ss[i],dur[i],ends[i],z[j],f'o{i}{j}'))
        if explicit:
            for es in ent:model.add_no_overlap(es)
        else:model.add_cumulative(ints,[1]*4,2)
        # One fixed relay service window for two clients can overlap freely.
        for i in (0,1):model.add(ss[i]>=2);model.add(ends[i]<=15)
        c=model.new_int_var(0,40,'c');model.add_max_equality(c,ends);model.minimize(c);solver=cp.CpSolver();status=solver.solve(model)
        test('small optimal '+str(explicit),status==cp.OPTIMAL);costs.append(solver.value(c))
    test('small aggregate equals explicit',costs[0]==costs[1])
    dump(OUT/'tests_q3.json',dict(passed=len(checks),checks=checks,small_instance_objectives=costs,scope='geometry, radio, charging and resource expression tests; full solution replay separate'))
    print('PASS',len(checks),flush=True)

if __name__=='__main__':main()
