from setup_q3 import *
from communication import Radio
from atoms import build_route
from routes import Physics,charge
from joint import solve
from validate_q3 import run
import copy,time

def main():
    directory=OUT/'experiments';directory.mkdir(exist_ok=True)
    p=OUT/'site_joint/solution_q3.json';warm=json.loads(p.read_text(encoding='utf-8'));ids=list(dict.fromkeys(r['site']['id'] for r in warm['relay']));siteall=json.loads((OUT/'relay_sites.json').read_text(encoding='utf-8'));sites=[s for s in siteall if s['id'] in ids];P=Physics();data=inputs();rows=[]
    # This is actual solver replication: same inputs, bounded budget, fresh solver.
    for seed in (1,2):
        s=solve(f'experiments/seed_{seed}',seconds=25,slots=3,site_ids=ids,slot_sites=[r['site']['id'] for r in warm['relay']],zero_late=True,max_C=6043.4,objectives=('C','E'),warm=warm,seed=seed)
        if s:
            report=run(OUT/f'experiments/seed_{seed}/solution_q3.json');rows.append(dict(scenario=f'seed_{seed}',**report['summary']))
    for margin in (10,12):
        fixed=run(p,margin=margin,save=False);dump(directory/f'fixed_margin_{margin}.json',fixed);rows.append(dict(scenario=f'fixed_margin_{margin}',**fixed['summary']))
        eng=Radio(data,margin=margin);allowed=[s for s in siteall if eng.point(data['gateway'],[s['x'],s['y'],s['z']],'backhaul')['valid']];atoms={}
        for r in warm['transport']:atoms[r['route']['id']],_=build_route(r['route'],P,eng,allowed)
        missing=sum(not a['sites'] for aa in atoms.values() for a in aa)
        dump(directory/f'margin_{margin}_atom_audit.json',dict(usable_sites=len(allowed),uncovered_atoms=missing,scope='candidate-site limitation if uncovered; not global infeasibility'))
        if missing:continue
        s=solve(f'experiments/reopt_margin_{margin}',seconds=45,slots=5,site_ids=[v['id'] for v in allowed],pool=[r['route'] for r in warm['transport']],atoms=atoms,objectives=('D','C'))
        if s:
            report=run(OUT/f'experiments/reopt_margin_{margin}/solution_q3.json',margin=margin);rows.append(dict(scenario=f'reopt_margin_{margin}',**report['summary']))
    # Component reduction: reuse the same all-physics-valid solution if inventory fits.
    reduced=copy.deepcopy(warm);reduced['resources']=[2,4];dump(directory/'four_components.json',reduced);report=run(directory/'four_components.json',save=False);dump(directory/'four_components_validation.json',report);rows.append(dict(scenario='components_4_fixed',**report['summary']))
    one=solve('experiments/one_relay',seconds=35,slots=4,resources=(1,6),site_ids=ids,objectives=('D','C'))
    if one:rows.append(dict(scenario='one_relay',**run(OUT/'experiments/one_relay/solution_q3.json')['summary']))
    # Power stress: fixed timeline recomputation; update energy/charging then audit
    # resources explicitly. Transport and geometric windows stay unchanged.
    stress=[]
    for r in warm['relay']:
        e=r['site']['fly_energy']+1.05*1.1*(r['service_end']-r['arrival'])/3600
        stress.append(dict(sortie=r['sortie'],energy=e,SOC=1-e/3.2,component_ready=r['return']+charge(1-e/3.2,1800),component=r['component'],start=r['start'],energy_feasible=e<=2.56))
    violations=[]
    for comp in {r['component'] for r in stress}:
        rr=sorted([r for r in stress if r['component']==comp],key=lambda r:r['start'])
        for a,b in zip(rr,rr[1:]):
            if a['component_ready']>b['start']+1e-6:violations.append((a['sortie'],b['sortie']))
    dump(directory/'relay_power_plus5.json',dict(rows=stress,component_conflicts=violations,all_energy_feasible=all(r['energy_feasible'] for r in stress),scope='fixed complete timelines; no time change required when no resource conflict; no invented reliability probability'))
    table(OUT/'sensitivities_q3.csv',rows)

if __name__=='__main__':main()
