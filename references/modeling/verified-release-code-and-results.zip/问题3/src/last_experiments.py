from setup_q3 import *
from joint import solve
from validate_q3 import run

warm=json.loads((OUT/'refined_joint/solution_q3.json').read_text(encoding='utf-8'))
pool=json.loads((OUT/'expanded_routes.json').read_text(encoding='utf-8'));atoms=json.loads((OUT/'final_pool_atoms.json').read_text(encoding='utf-8'));ids=[r['site']['id'] for r in warm['relay']]
r=solve('tradeoffs/extra_180',seconds=60,slots=3,site_ids=ids,slot_sites=ids,pool=pool,atoms=atoms,zero_late=True,max_C=6207.,objectives=('E','C','N'),warm=warm)
if r:run(OUT/'tradeoffs/extra_180/solution_q3.json')
warm=json.loads((OUT/'site_joint/solution_q3.json').read_text(encoding='utf-8'));ids=[r['site']['id'] for r in warm['relay']]
r=solve('experiments/seed_3',seconds=25,slots=3,site_ids=ids,slot_sites=ids,zero_late=True,max_C=6043.4,objectives=('C','E'),warm=warm,seed=3)
if r:run(OUT/'experiments/seed_3/solution_q3.json')
