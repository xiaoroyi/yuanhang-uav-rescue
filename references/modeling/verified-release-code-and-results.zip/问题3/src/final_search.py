from setup_q3 import *
from communication import Radio
from atoms import build_route
from routes import Physics
from joint import solve
from validate_q3 import run
import time

def main():
    warm=json.loads((OUT/'refined_joint/solution_q3.json').read_text(encoding='utf-8'))
    pool=json.loads((OUT/'expanded_routes.json').read_text(encoding='utf-8'))
    ids=[r['site']['id'] for r in warm['relay']]
    sites=[s for s in json.loads((OUT/'relay_sites.json').read_text(encoding='utf-8')) if s['id'] in ids]
    eng=Radio(inputs());p=Physics();atoms={};beg=time.time()
    for i,r in enumerate(pool):
        atoms[r['id']],_=build_route(r,p,eng,sites,max_block=30)
        if i%50==0:print('final pool atoms',i,len(pool),round(time.time()-beg),flush=True)
    dump(OUT/'final_pool_atoms.json',atoms)
    dump(OUT/'final_search_contract.json',dict(routes=len(pool),sites=ids,slots=3,time_grid=.1,seconds_per_stage=60,source='refined_joint',objectives=['C','E','N','H']))
    result=solve('final_joint_search',seconds=60,slots=3,site_ids=ids,slot_sites=ids,pool=pool,atoms=atoms,zero_late=True,max_C=6027.0,objectives=('C','E','N','H'),warm=warm)
    if result:run(OUT/'final_joint_search/solution_q3.json')
    result=solve('tradeoffs/extra_180',seconds=60,slots=3,site_ids=ids,slot_sites=ids,pool=pool,atoms=atoms,zero_late=True,max_C=6207.,objectives=('E','C','N'),warm=warm)
    if result:run(OUT/'tradeoffs/extra_180/solution_q3.json')

if __name__=='__main__':main()
