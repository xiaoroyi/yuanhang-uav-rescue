"""Freeze independently verified solution and prepare full precision exports."""
from setup_q3 import *
from validate_q3 import run
from communication import Radio,phases
from routes import Physics
from validate import peak
from openpyxl import load_workbook
import csv,shutil,collections,datetime,platform

def readcsv(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def union_length(iv):
    ans=[]
    for a,b in sorted(iv):
        if ans and a<=ans[-1][1]+1e-8:ans[-1][1]=max(ans[-1][1],b)
        else:ans.append([a,b])
    return sum(b-a for a,b in ans)

def freeze():
    candidates=[]
    for name in ['three_site_seed','site_joint','experiments/seed_1','experiments/seed_2','experiments/seed_3','refined_joint','joint_expanded','final_joint_search','tradeoffs/extra_180']:
        p=OUT/name/'solution_summary.json'
        if p.exists():
            s=json.loads(p.read_text(encoding='utf-8'))
            if s['valid']:candidates.append((s['D'],s['C_joint'],s['E_total'],s['N_transport']+s['N_relay'],-s['min_hard_slack'],name))
    chosen=min(candidates)[-1];src=OUT/chosen/'solution_q3.json';shutil.copy2(src,OUT/'solution_q3.json')
    dump(OUT/'freeze_record.json',dict(chosen=chosen,source_sha256=sha(src),selection='true independently recalculated lexicographic D,C,E,N; then larger hard slack',candidates=candidates,time=datetime.datetime.now().isoformat(),legacy_grid_H_note='refined_joint H stores 0.1-second ticks; use independent min_hard_slack in seconds'))
    run(OUT/'solution_q3.json')
    for old,new in [('sorties.csv','transport_trips_q3.csv'),('deliveries.csv','deliveries_q3.csv'),('leg_events.csv','transport_leg_events_q3.csv'),('stop_events.csv','transport_stop_events_q3.csv'),('aircraft_timeline.csv','aircraft_timeline.csv'),('battery_timeline.csv','battery_timeline.csv')]:shutil.copy2(OUT/'transport_validation'/old,OUT/new)
    print('FROZEN',chosen,flush=True)

def exports():
    sol=json.loads((OUT/'solution_q3.json').read_text(encoding='utf-8'));summary=json.loads((OUT/'solution_summary.json').read_text(encoding='utf-8'))
    intervals=readcsv(OUT/'communication_intervals_q3.csv');points=readcsv(OUT/'communication_event_points_q3.csv');deliveries=readcsv(OUT/'deliveries_q3.csv')
    stages={(r['sortie'],r['phase']):r['stage'] for r in intervals}
    transport={r['sortie']:r for r in sol['transport']};relays={r['sortie']:r for r in sol['relay']}
    stats=[]
    for rid,r in relays.items():
        used=[(float(x['start']),float(x['end'])) for x in intervals if x['source']==rid];length=union_length(used)
        stats.append(dict(sortie=rid,service_length=r['service_end']-r['link_complete'],client_seconds=sum(b-a for a,b in used),active_union_seconds=length,service_utilization=length/(r['service_end']-r['link_complete']),max_concurrent_clients=peak(used)))
    table(OUT/'relay_utilization.csv',stats)
    timelines=readcsv(OUT/'relay_resource_timeline.csv')
    for typ,name in [('relay','relay_timeline.csv'),('component','component_timeline.csv')]:table(OUT/name,[r for r in timelines if r['resource']==typ])
    dump(OUT/'resource_summary.json',dict(relay_peak=peak([(r['start'],r['aircraft_ready']) for r in sol['relay']]),component_peak=peak([(r['start'],r['component_ready']) for r in sol['relay']]),used_components=sorted({r['component'] for r in sol['relay']}),last_component_charge_complete=max(r['component_ready'] for r in sol['relay']),last_relay_turn_complete=max(r['aircraft_ready'] for r in sol['relay'])))
    # Q4: transport connectivity; preserve actual relay assignment relationships.
    parent={f'S{i:03d}':f'S{i:03d}' for i in range(1,16)}
    def find(x):
        while parent[x]!=x:x=parent[x]
        return x
    for r in sol['transport']:
        ss=[s for s,_ in r['route']['stops']]
        for s in ss[1:]:parent[find(s)]=find(ss[0])
    groups=collections.defaultdict(list)
    for s in parent:groups[find(s)].append(s)
    relations=[]
    for rid in relays:
        trips=sorted({x['sortie'] for x in intervals if x['source']==rid})
        services=sorted({s for t in trips for s,_ in transport[t]['route']['stops']})
        relations.append(dict(relay_sortie=rid,transport_sorties=trips,transport_destination_union=services,transport_components=sorted({find(s) for s in services})))
    dump(OUT/'q4_handover.json',dict(source_sha256=sha(OUT/'solution_q3.json'),transport_components=list(groups.values()),component_count=len(groups),relay_relations=relations,transport_only_allows_K2_K3=len(groups)>=3,scope='Transport components only are not sufficient to certify Q4 feasibility. Relay crossing components requires original Q4 ownership rules; do not duplicate sorties.'))
    # Preserve exact template columns, append separate Q3 transport/delivery sheets.
    w=load_workbook(PROJECT/'问题2/results/结果提交_Q2.xlsx',data_only=False)
    payload=[]
    def add(name,rows,headers=None,formats=None,widths=None):
        new=headers is not None
        if headers is None:headers=[c.value for c in w[name][1]][:len(rows[0])]
        payload.append(dict(sheet=name,headers=headers,rows=rows,new=new,lastCol=chr(64+len(headers)),formats=formats or {},widths=widths or {}))
    rr=[[r['sortie'],r['aircraft'],r['component'],r['start'],r['site']['lon'],r['site']['lat'],r['site']['z'],r['link_complete'],r['service_end'],r['return'],r['energy']] for r in sol['relay']]
    add('Q3_中继架次',rr,formats={'D':'0.000','E':'0.00000000','F':'0.00000000','G':'0.000000','H':'0.000','I':'0.000','J':'0.000','K':'0.000000'},widths={'A':20,'B':20,'C':20,'D':21,'E':23,'F':23,'G':22,'H':25,'I':23,'J':24,'K':23})
    cc=[[r['sortie'],r['stage'],float(r['start']),float(r['end']),'直连' if r['source']=='G01' else '中继',None if r['source']=='G01' else r['source']] for r in intervals]
    cc += [[r['sortie'],stages[r['sortie'],r['phase']],float(r['time']),float(r['time']),'直连' if r['source']=='G01' else '中继',None if r['source']=='G01' else r['source']] for r in points]
    cc.sort(key=lambda r:(r[0],r[2],r[3]))
    add('Q3_通信保障',cc,formats={'C':'0.000000','D':'0.000000'},widths={'A':22,'B':18,'C':23,'D':23,'E':18,'F':22})
    tt=[[r['sortie'],r['aircraft'],r['route']['model'],r['battery'],r['start'],'→'.join(s for s,_ in r['route']['stops']),r['return'],r['route']['energy']] for r in sol['transport']]
    add('Q3_运输架次',tt,headers=[c.value for c in w['Q2_运输架次'][1]],formats={'E':'0.000','G':'0.000','H':'0.000000'},widths={'A':20,'B':18,'C':15,'D':19,'E':22,'F':25,'G':25,'H':22})
    dd=[[r['box'],r['sortie'],r['service'],float(r['complete'])] for r in deliveries]
    add('Q3_逐箱交付',dd,headers=[c.value for c in w['Q2_逐箱交付'][1]],formats={'D':'0.000000'},widths={'A':26,'B':21,'C':21,'D':28})
    notes=[['完工定义','运输与中继全部返回O01，末次充电和周转不计入完工。'],['方案编号','Q3运输使用Q3T编号，Q3通信表不引用Q2运输时刻。'],['中继开始时刻','准备开始时刻，含180秒准备；到达后再建链30秒。'],['时间精度','单元格保存完整双精度值，显示小数不作为重放输入。'],['通信区间','开始小于结束的记录描述开区间，开始等于结束的记录单独保障事件点。'],['边界重复','相邻飞行阶段的公共事件点可重复记录，不增加时长。'],['通信判定','双向链路达标；直连优先；中继须接入与回传同时达标。'],['几何范围','冻结DEM投影像元和2毫米缓冲下的连续时间检查。'],['高度','中继表为海拔高度，当地离地高度见relay_trips_q3.csv。'],['目标','按延期、联合返航完工、总能耗、总架次依次优化。'],['最优性','D=0达到原问题该层下界；其余仅有限候选集与时间网格。'],['来源','原题与原始附件；Q1/Q2保留已冻结结果，Q4留空。']]
    add('Q3_说明',notes,headers=['项目','说明'],widths={'A':24,'B':105})
    w.close();dump(OUT/'workbook_payload.json',payload)
    # Certificate detail: interval geometry, selected source, budget and true phases.
    data=inputs();engine=Radio(data);P=Physics();phase_map={(r['sortie'],str(p['phase'])):(r,p) for r in sol['transport'] for p in phases(r['route'],P)}
    with (OUT/'communication_certificates.jsonl').open('w',encoding='utf-8') as f:
        for row in intervals:
            r,p=phase_map[row['sortie'],row['phase']];ta=float(row['start']);tb=float(row['end']);start=r['start']+p['a'];duration=p['b']-p['a'];v=np.array(p['p1'])-p['p0'];x0=np.array(p['p0'])+(ta-start)/duration*v;x1=np.array(p['p0'])+(tb-start)/duration*v
            rid=row['source'];anchor=data['gateway'] if rid=='G01' else np.array([relays[rid]['site'][k] for k in ('x','y','z')]);kind='direct' if rid=='G01' else 'access';profile=engine.profile(anchor,x0,x1,kind)
            detail=dict(**row,decision='PASS',p0=x0.tolist(),p1=x1.tolist(),anchor=anchor.tolist(),path_loss_limit_db=engine.limits[kind],max_distance_m=max(np.linalg.norm(x0-anchor),np.linalg.norm(x1-anchor)),profile=profile,backhaul_margin_db=None if rid=='G01' else engine.point(data['gateway'],anchor,'backhaul')['margin'],event_points_file='communication_event_points_q3.csv')
            f.write(json.dumps(detail,ensure_ascii=False)+'\n')
    print('export payload',[(p['sheet'],len(p['rows'])) for p in payload],flush=True)

def audit_workbook():
    payload=json.loads((OUT/'workbook_payload.json').read_text(encoding='utf-8'));path=OUT/'结果提交_Q3.xlsx';w=load_workbook(path,data_only=False);base=load_workbook(PROJECT/'问题2/results/结果提交_Q2.xlsx',data_only=False);count=0;maxerr=0
    for item in payload:
        sh=w[item['sheet']]
        for i,row in enumerate([item['headers']]+item['rows'],1):
            for j,want in enumerate(row,1):
                got=sh.cell(i,j).value
                if isinstance(want,(int,float)):
                    err=abs(got-want);maxerr=max(maxerr,err);assert err<=2e-10,(item['sheet'],i,j,got,want)
                else:assert got==want,(item['sheet'],i,j,got,want)
                count+=1
    retained=['Q1_单点组批','Q2_运输架次','Q2_逐箱交付','Q4_分区配置']
    for name in retained:
        a=base[name];b=w[name]
        for row in a:
            for c in row:
                z=b[c.coordinate];assert z.value==c.value,(name,c.coordinate)
                assert z.number_format==c.number_format,(name,c.coordinate,'number format')
    # Reconstruct numerical schedule from exported cells and replay full physics.
    sol=json.loads((OUT/'solution_q3.json').read_text(encoding='utf-8'));trs={r['sortie']:r for r in sol['transport']};rs={r['sortie']:r for r in sol['relay']}
    for vals in w['Q3_运输架次'].iter_rows(min_row=2,max_row=26,values_only=True):
        rid,u,g,b,s,stops,ret,e=vals[:8];r=trs[rid];r.update(start=s,aircraft=u,battery=b,**{'return':ret});assert g==r['route']['model'] and abs(e-r['route']['energy'])<1e-10
    for vals in w['Q3_中继架次'].iter_rows(min_row=2,max_row=4,values_only=True):
        rid,u,k,s,lon,lat,z,ready,end,ret,e=vals[:11];r=rs[rid];r.update(aircraft=u,component=k,start=s,link_complete=ready,service_end=end,energy=e,**{'return':ret});r['site'].update(lon=lon,lat=lat,z=z)
    dump(OUT/'workbook_replay_solution.json',sol);rep=run(OUT/'workbook_replay_solution.json',save=False);assert rep['summary']['valid']
    dump(OUT/'workbook_audit.json',dict(valid=True,compared_cells=count,max_numeric_error=maxerr,retained_sheets=retained,full_physics_replay=rep['summary'],source_sha256=sha(OUT/'solution_q3.json'),workbook_sha256=sha(path)))
    w.close();base.close()

if __name__=='__main__':
    action=sys.argv[1] if len(sys.argv)>1 else 'freeze'
    if action=='freeze':freeze();exports()
    elif action=='export':exports()
    elif action=='audit':audit_workbook()
