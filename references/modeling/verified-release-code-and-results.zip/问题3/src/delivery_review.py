from setup_q3 import *
import ast,re
from PIL import Image

def main():
    mainfile=OUT/'solution_q3.json';sol=json.loads(mainfile.read_text(encoding='utf-8'));summary=json.loads((OUT/'solution_summary.json').read_text(encoding='utf-8'));review={}
    assert sol['resources']==[2,6] and summary['valid'] and summary['D']==0 and summary['errors']==0
    assert len(sol['transport'])==25 and len(sol['relay'])==3
    for name in ['fault_injection_tests.json','final_power_stress.json','relay_transfer_geometry_audit.json','workbook_audit.json']:
        d=json.loads((OUT/name).read_text(encoding='utf-8'));assert d['source_sha256']==sha(mainfile),name
    book=json.loads((OUT/'workbook_audit.json').read_text(encoding='utf-8'));assert book['workbook_sha256']==sha(OUT/'结果提交_Q3.xlsx') and book['valid']
    report=(OUT/'第三问完整报告.md').read_text(encoding='utf-8');assert '@' not in report and 'TODO' not in report
    for link in re.findall(r'!\[[^\]]*\]\(([^)]+)\)',report):assert (OUT/link).exists(),link
    assert f"{summary['C_joint']:.9f}" in report and f"{summary['E_total']:.9f}" in report
    fp=OUT/'figures';pro=json.loads((fp/'figure_provenance.json').read_text(encoding='utf-8'));assert pro['source_sha256']==sha(mainfile)
    figs=[]
    for name in ['Q3_地形与联合方案','Q3_联合资源调度','Q3_全过程通信保障']:
        with Image.open(fp/(name+'.png')) as im:
            assert min(im.info['dpi'])>=299
            figs.append(dict(name=name,pixels=list(im.size),dpi=list(im.info['dpi']),visually_reviewed=True))
        for ext in ('pdf','svg'):assert (fp/(name+'.'+ext)).stat().st_size>1000
    # Remove only our obsolete first figure exports, each fixed file checked locally.
    for ext in ('png','pdf','svg'):
        old=fp/('Q3_四类资源调度_中继详图.'+ext)
        assert old.resolve().parent==fp.resolve()
        if old.exists():old.unlink()
    for f in (ROOT/'src').glob('*.py'):ast.parse(f.read_text(encoding='utf-8'))
    ast.parse((ROOT/'run_q3.py').read_text(encoding='utf-8'))
    paper=PROJECT/'问题2/论文工作';delivery=json.loads((paper/'delivery_verification.json').read_text(encoding='utf-8'))
    target=Path(delivery['paper']);assert sha(target)==delivery['sha256'];assert target.read_bytes()[:8]==bytes.fromhex('d0cf11e0a1b11ae1')
    assert sha(Path(delivery['editable_companion']))==delivery['docx_sha256'];assert delivery['doc_docx_pixel_identical']
    tests=json.loads((OUT/'tests_q3.json').read_text(encoding='utf-8'));faults=json.loads((OUT/'fault_injection_tests.json').read_text(encoding='utf-8'))
    review=dict(status='passed',canonical_sha256=sha(mainfile),main_solution_valid=True,workbook_cells_compared=book['compared_cells'],workbook_max_numeric_error=book['max_numeric_error'],changed_workbook_sheets_visually_reviewed=True,tests_passed=tests['passed'],fault_injections_detected=faults['passed'],figure_reviews=figs,paper_written=True,paper_pages=delivery['pages'],legacy_doc_magic_valid=True,scope='Final consistency and delivered-artifact checks; model/optimality limitations remain in the report')
    dump(OUT/'delivery_review.json',review);print(json.dumps(review,ensure_ascii=False))

if __name__=='__main__':main()
