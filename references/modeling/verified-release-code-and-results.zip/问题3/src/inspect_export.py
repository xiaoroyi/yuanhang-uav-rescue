from setup_q3 import *
from openpyxl import load_workbook
w=load_workbook(PROJECT/'问题2/results/结果提交_Q2.xlsx',data_only=False)
for s in w:
    print(s.title,s.max_row,s.max_column,list(next(s.values)))
w.close()
