"""Preserve all previous paper content and append the full Q4 account."""
from pathlib import Path
import sys,json,csv,re,hashlib,copy,ast
from fractions import Fraction as F
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;W=ROOT/'论文工作';R=ROOT/'results'
sys.path.append(str(PROJECT/'问题1/论文工作/deps'))
from latex2mathml.converter import convert
def read(n):return json.loads((R/n).read_text(encoding='utf-8'))
def rows(n):return list(csv.DictReader((R/n).open(encoding='utf-8-sig')))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def num(x,n=3):return f'{float(F(x)):.{n}f}'
def vec(x):return '('+','.join(map(str,x[:3]))+'; '+','.join(map(str,x[3:6]))+'; '+','.join(map(str,x[6:]))+')'
frozen=json.loads((W/'frozen_numbers.json').read_text(encoding='utf-8'))
for n,h in frozen['source_hashes'].items():assert sha(R/n)==h,n
S=frozen['summary'];SOL={k:frozen['solutions'][str(k)] for k in [2,3]};C=read('components_q4.json');SUB=read('group_subsets_q4.json');PARTS=rows('all_partitions_q4.csv');MET=rows('paper_utilization_q4.csv')
previous=PROJECT/'问题3/论文工作/论文_写至问题三_正式.docx'
delivery=json.loads((PROJECT/'问题3/论文工作/delivery_verification.json').read_text(encoding='utf-8'))
assert sha(PROJECT.parent/'论文.doc')==delivery['sha256'],'External paper changed; preserve user edits.'
doc=Document(previous);md=[];eqno=38
transform=etree.XSLT(etree.parse(r'C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL'))
tree=ast.parse((PROJECT/'问题1/论文工作/build_paper.py').read_text(encoding='utf-8'))
names={'native_math','inline','para','heading','equation','table'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'<verified-format-helpers>','exec'))
def figure(name,caption):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(W/'figures'/name),width=Cm(16));p._p.xpath('.//wp:docPr')[0].set('descr',caption)
    doc.add_paragraph(caption,style='PaperCaption');md.append(f'![{caption}](论文工作/figures/{name})\n')
# Keep all prior prose, equations, tables, figures and keywords. Move disclosure intact to the end.
disclosures=[]
for p in list(doc.paragraphs):
    if p.text.startswith('AI辅助使用说明：'):
        disclosures.append(copy.deepcopy(p._element));p._element.getparent().remove(p._element)
    if p.text.startswith('关键词：'):
        a=p.insert_paragraph_before(style='PaperBody')
        a.paragraph_format.keep_together=True
        a.add_run('针对问题四，在冻结第三问物理任务和实际通信关系、允许执行前重新配置同型资源的解释下，构造运输与中继任务超图，得到4个不可拆分单元，完全枚举7种二分与6种三分。以区间图着色求各组最小资源配置：资源优先二分须新增B型运输机和电池各1个，三分须新增A/B/C型运输机及对应电池各1个。一个包含12个服务区的单元承担80.383%的设备作业量，从结构上限制组间均衡；均衡优先方案可改善负荷分配，但增加专属装备需求。该结论精确适用于冻结方案，不扩大为运输与分区整体的全局最优。')
        p.add_run('；任务超图；区间图着色；独立资源配置')

heading('5.4 问题四 冻结联合方案下的任务分区与独立资源配置',2)
heading('5.4.1 固定方案与独立执行的操作解释',3)
para('第四问在第三问已确定的运输和中继任务上划分两个或三个非空任务组。货箱组批、访问与箱内交付顺序、机型、准备和执行时刻、飞行轨迹、能耗、荷电状态、中继悬停位置及实际通信保障关系均保持不变。因此，本问优化对象是任务归属和各组专属资源数量，不再通过改变路线、移动任务时刻或替换通信来源改善结果。')
para('为核算各组独立执行的最小资源配置，本文采用以下主操作解释：执行前可在同型同质资源内部重新分配机体、电池及能源组件的实体编号，任务执行期间则不允许跨组借用。这是对资源配置问题的明确建模解释，并非题目逐字给出的编号豁免。原编号保留用于追溯；完全冻结原实体编号的情形另作解释敏感性分析。')
para('一个完整中继架次保持单一组归属，不拆分、不复制。若同一固定中继架次先后服务的运输任务属于不同组，则要么中继在任务中跨组调配，要么复制该架次，要么重新安排服务，均不满足本文固定任务集合和独立执行的解释。因此，同一中继架次的全部实际客户必须同组，即使其服务时段互不重叠。允许复制中继架次可构成另一放松问题，但会改变第三问任务数量，本文不将其作为第四问正式方案。')
para('调度中心O01与固定网关G01保留为公共基础设施，不因共同使用固定设施而强行合并服务区。分区由任务关系决定，地理连片不作为额外硬约束。三类运输机和对应电池、中继机及中继组件共八类资源，其向量顺序统一为(A机,B机,C机; A电池,B电池,C电池; 中继机,中继组件)，现库存为(4,2,2; 6,4,4; 2,6)。')

heading('5.4.2 实际运输与通信关系的超图收缩',3)
para(r'以15个服务区为顶点，运输架次 $r$ 所访问的服务区集合记为 $D_r$。若完整中继架次 $j$ 的实际运输客户集合为 $F_j$，则运输与通信分别产生不可拆超边：')
equation(r'\mathcal E_T=\{D_r:r\in\mathcal R\},\qquad H_j=\bigcup_{r\in F_j}D_r,\qquad\mathcal E_R=\{H_j:j\in\mathcal J\}.')
para('实际客户集合来自第三问已核验并冻结的通信来源记录，包含正长度保障区间和零长度切换事件。能覆盖但未被选用的中继不产生合并关系；不能仅按服务区位置、候选覆盖范围或近邻关系构图。相邻阶段重复边界须具有一致的唯一来源，否则先纠正接口而不进入分区。')
para('命题4（超图分量与合法任务分区等价）。在完整运输及中继架次不能跨组的条件下，任一合法分区必须是超图连通分量的并；反之，将完整连通分量分入各组，必然满足运输与通信任务的组归属约束。')
para('证明：任一超边的顶点必须同组，沿相交超边逐次传递，可知每个连通分量整体同组。反之，超边全部包含于某个连通分量，完整分量分组后不存在跨组超边。该逆向结论保证任务归属合法，具体执行仍需配置足够专属资源。由此可在不损失合法解的前提下将原问题收缩。')
para('仅使用多点运输关系时有12个分量，加入实际中继服务关系后收缩为表16中的4个不可拆单元。并查集结果与独立二部图遍历一致。记这些单元为C1—C4，后续加号表示合并到同组，斜线表示组间分隔。')
table('表16 冻结运输与通信关系形成的不可拆任务单元',['单元','服务区','运输/中继架次','设备作业量 s'],[[a['id'],'、'.join(a['services']),f"{len(a['transport'])}/{len(a['relay'])}",num(SUB[str(1<<i)]['W'])] for i,a in enumerate(C['atoms'])],[1.3,8.0,3.2,3.9])
edge_rows=[]
for e in C['edges']:
    if e['kind']=='relay':edge_rows.append([e['id'].replace('Q3R-','R-'),len(e['transports']),'、'.join(e['services'])])
table('表17 完整中继架次所连接的实际运输服务区',['中继架次','运输客户数','关联服务区'],edge_rows,[2.3,2.8,11.3])
para('表17中的运输客户数指该中继架次在全时段内服务过的不同运输架次总数，不等于同时服务峰值。R-001与R-002通过S012关联，R-003又与R-002共享S004、S008、S012，从而形成大通信分量；多点任务中的S007—S015—S003等传递关系一并保留。S001、S006和S011没有因候选中继覆盖或共同网关而被额外合并。')

heading('5.4.3 区间图最优着色与各组最小资源',3)
para(r'以 $\ell$ 表示任务组、$h$ 表示资源类别，机型仍用 $g$ 表示。沿用准备开始 $S_r,Y_j$、返航 $R_r,R_j$ 及根据返航SOC计算的补满时长 $\chi_g,\chi_R$。运输和中继的机体与能源占用区间分别为')
equation(r'I_r^{U_g}=[S_r,R_r),\qquad I_r^{B_g}=[S_r,R_r+\chi_g(s_r)).')
equation(r'I_j^{U_R}=[Y_j,R_j+300),\qquad I_j^{B_R}=[Y_j,R_j+\chi_R(s_j)).')
para('占用均从准备开始计。运输机体返航即释放；电池必须补至100%后才能再次使用。中继返航后的300 s机体周转与组件补电并行，各自决定可用时刻。区间统一左闭右开，同一时刻先释放再占用，真实正长度重叠不能因展示舍入而消失。')
para(r'设组 $\ell$ 对资源 $h$ 的任务区间集合为 $\mathcal I_{\ell h}$，构建区间重叠图 $G_{\ell h}$：区间是顶点，重叠表示不能使用同一实体。最小资源配置满足')
equation(r'n_{\ell h}=\chi(G_{\ell h})=\omega(G_{\ell h})=\max_t\sum_{I\in\mathcal I_{\ell h}}\mathbf1\{t\in I\}.')
para('命题5（区间峰值即最小配置）。峰值时刻若有p项任务同时占用，至少需要p个实体。按开始时刻依次处理区间，优先复用已经释放的实体；仅当全部实体仍被占用时才新增。新增第p个实体的时刻恰有p项并发占用，故构造方案达到峰值下界。由此既得到最少数量，也可恢复逐任务实体编号。')
para('在同型可拆换、初始电量全满、再次使用前必须充满且补电可独立并行的规则下，机体和能源分别着色可以实现联合任务。计算某组需求时必须先合并该组全部区间再求峰值，不能直接相加各单元峰值；后者会忽略组内错峰复用。对4个单元的15个非空子集，本文均重算8类资源峰值，并保存达到峰值的任务集合作为最小性见证。')

heading('5.4.4 资源冗余 库存缺口与工作量指标',3)
para(r'设分区的资源总数为 $N_h=\sum_\ell n_{\ell h}$，全场共享执行同一冻结任务时的最低需求为 $N_h^{\mathrm{shared}}$，现库存为 $I_h$。分别定义分区共享损失、库存缺口和未配置库存：')
equation(r'L_h^{\mathrm{share}}=N_h-N_h^{\mathrm{shared}},\quad\Delta_h^+=\max(0,N_h-I_h),\quad\Delta_h^-=\max(0,I_h-N_h).')
para('共享损失刻画禁止跨组复用引起的附加专属配置，是本问分区资源冗余的主要来源；库存缺口表示需要增配的数量；未配置库存表示当前方案尚未分配的存量。三者不能混称冗余，也不能将一种设备的未配置库存抵消另一种设备的缺口。全场共享需求为(4,2,2; 6,4,4; 2,2)，因而6组中继组件中的4组未配置量并非分区新增的冗余。')
para(r'组 $\ell$ 的工作量采用全部运输与中继从准备到返航的设备作业秒，中继服务多个客户时仍只计一次设备工时，不计返航后的补电与等待：')
equation(r'W_\ell=\sum_{r\in\mathcal R_\ell}(R_r-S_r)+\sum_{j\in\mathcal J_\ell}(R_j-Y_j).')
equation(r'\bar W=\frac1K\sum_\ell W_\ell,\qquad CV_K^2=\frac{K\sum_\ell W_\ell^2}{(\sum_\ell W_\ell)^2}-1,\qquad B_K=\max_\ell\frac{|W_\ell-\bar W|}{\bar W}.')
para('设备作业秒衡量设备任务负荷，不等同于地面人员工时，也不等同于任务组最后返航时刻。CV²为工作量变异系数的平方，B为最大相对均值偏差，均越小越均衡；改变工作量定义的影响另行检验。')
para('考虑装备增配压力，正式表采用资源优先的字典序规则；同时并列计算均衡优先备选，不将二者合成为未经题目给定的采购价格或唯一总评分。以基准库存作为固定归一化标尺，定义')
equation(r'J_{\mathrm{gap}}=\sum_h\frac{\Delta_h^+}{I_h},\qquad J_{\mathrm{size}}=\sum_h\frac{N_h}{I_h}.')
equation(r'\min_{\mathrm{lex}}(J_{\mathrm{gap}},J_{\mathrm{size}},CV_K^2),\qquad\min_{\mathrm{lex}}(CV_K^2,J_{\mathrm{gap}},J_{\mathrm{size}}).')
para('第一条规则先降低归一化库存缺口，再降低配置规模，最后改善均衡；第二条先改善均衡，再考虑资源。归一化仅提供透明的比较尺度，不表示机体、电池与中继组件可以相互替代。库存压力情景中仅改变缺口计算所用库存，归一化分母保留基准值，以免同时改变资源偏好。')

heading('5.4.5 完全枚举与独立集合划分核验',3)
para('四个不可拆单元的无标签非空分区数由第二类Stirling数给出：二分为S(4,2)=7，三分为S(4,3)=6。使用限制增长序列消除组标签置换的重复，枚举全部13种合法分区。对每种分区，查询各组对应单元子集的区间峰值、恢复实体分配并计算目标。故不存在由于启发式搜索未充分而遗漏更好合法分区的问题。')
para(r'作为独立求解，将4个原子单元的每个非空子集 $A$ 设为一个候选任务组，二元变量 $y_A$ 表示是否选择该组。令 $n_{Ah}$、$W_A$ 为该组预计算的最少资源和工作量，建立集合划分约束：')
equation(r'\sum_{A:c\in A}y_A=1\ (c=1,\ldots,4),\qquad\sum_Ay_A=K,\qquad y_A\in\{0,1\}.')
equation(r'N_h=\sum_A n_{Ah}y_A,\qquad\delta_h\ge N_h-I_h,\quad\delta_h\ge0,\quad\delta_h\in\mathbb Z.')
para(r'以非负缺口变量 $\delta_h$ 表示第一层目标；总工作量固定时，最小化 $CV_K^2$ 等价于最小化 $\sum_A W_A^2y_A$，因此独立模型仍为整数线性规划。逐层固定已证最优的前层目标，两种K共六层求解均闭合上下界，与完整枚举一致。该最优性针对冻结任务、主操作解释和所声明的目标顺序成立，不是第三问连续路径、选址、调度与分区整体的最优证明。')
para('数值实现保留原始全精度区间端点，以十进制数处理事件同刻关系，并以有理数比较枚举目标。独立整数规划使用归一化目标的等价整数缩放和工时平方缩放。小数显示仅用于表述，不反向输入冲突判定。')

heading('5.4.6 两种分区规模的正式资源方案',3)
main=[]
for k,s in SOL.items():
    for i,g in enumerate(s['groups'],1):main.append([k,f'G{i}','+'.join(g['atoms']),vec(g['N']),num(g['W'])])
table('表18 资源优先方案的各组最小专属配置',['K','组','不可拆单元','资源配置向量','设备作业量 s'],main,[.8,1.0,3.6,6.6,4.4])
para('二分方案将S011单独配置，其余14个服务区合为一组；三分方案将S006、S011分别独立，其余13个服务区合为一组。二分总配置为(4,3,2; 6,5,4; 2,2)，需新增B型运输机1架和B型电池1组。三分总配置为(5,3,3; 7,5,5; 2,2)，需新增A/B/C型运输机各1架、对应电池各1组；两种方案均无需新增中继机或中继组件。')
para('资源优先二分的归一化缺口为1/2+1/4=3/4；三分为1/4+1/2+1/2+1/6+1/4+1/4=23/12。两者的可执行状态均为“补足指定资源后，可按原时序独立执行”，不能写成现库存已经足够。')
table('表19 分区后的任务量与能源守恒',['K/组','箱数','质量 kg','体积 L','运输作业 s','中继作业 s','能耗 kWh'],[[f'{k}/G{i}',g['boxes'],g['mass'],g['volume_L'],num(g['Wtransport']),num(g['Wrelay']),num(g['energy'],6)] for k,s in SOL.items() for i,g in enumerate(s['groups'],1)],[1.4,1.1,1.8,1.8,3.5,3.4,3.4])
para('分区前后均为80箱、758 kg、2011 L，25个运输和3个中继架次各归属一个组，不新增或减少任务；联合最后返航保持6026.919808 s，总能耗保持70.098400 kWh，逐箱交付时刻与及时性不变。这体现第四问增加的是资源独立性要求，而非额外配送工作。')

heading('5.4.7 全部合法分区与资源均衡取舍',3)
compare=[]
for k,s in SOL.items():
    for name,key in [('资源优先','selected'),('均衡优先','balanced')]:
        p=s[key];compare.append([k,name,p['partition'],vec(p['N']),p['Jgap'],num(p['CV2'],6),num(p['max_deviation'],6)])
table('表20 资源优先与均衡优先的并列比较',['K','偏好','分区','资源总配置','Jgap','CV²','相对偏差B'],compare,[.65,2.1,3.4,4.45,1.3,2.2,2.3])
para('均衡优先二分将12区大分量独立，另三个单元合并，CV²由0.913168降至0.369245，但资源总配置增加至(5,3,4; 8,5,6; 2,2)。均衡优先三分将大分量、S001分别独立，S006与S011合并，CV²由1.584289降至0.999752，总配置为(6,3,4; 9,5,6; 2,2)。因此正式表选择资源优先，是为了控制设备增配压力；若偏好组间负荷平衡，则应选对应备选并接受其装备代价。')
table('表21 全部13种合法分区及其完整资源比较',['编号','原子分组','八类资源总配置','Jgap','CV²','非支配'],[[p['id'],p['partition'],vec(json.loads(p['N'])),p['Jgap'],num(p['CV2'],6),'是' if p['pareto']=='True' else '否'] for p in PARTS],[1.6,3.8,5.7,1.3,2.2,1.8])
for ri,row in enumerate(doc.tables[-1].rows):
    for cell in row.cells:
        for p in cell.paragraphs:p.paragraph_format.keep_with_next=ri<len(doc.tables[-1].rows)-1
para('表21按八类资源总配置与CV²共同判断支配：若一方案在全部九个指标上不劣且至少一个严格较优，则支配另一方案。K=2的7种方案均非支配；K=3中只有K3-04被K3-06支配，两者资源向量相同而后者更均衡。高维非支配关系保留了资源种类差异，但本实例对最终选择的筛选能力有限，仍需明确偏好。图8用归一化缺口和CV²展示全部方案，作为直观二维投影，不以投影上的支配关系替代完整定义。')
figure('Q4_全部分区的资源均衡取舍.png','图8 全部合法分区的新增资源压力与工作量均衡取舍')
para('对全部13种分区逐一核算，现库存下没有任何一种能够独立执行。该结论来自穷尽合法分区及组内最少配置证明，不是求解超时或未找到可行解。以完整单元为对象的工作量贪心在本例恰得到两套均衡最优方案，不能据此夸大精确算法对该贪心的性能优势；精确方法的价值是给出完整候选空间和最优性证据。作为结构负面对照，单纯经纬度K-means的二分与三分均切开2条不可拆超边，不能作为合法备选。')

heading('5.4.8 均衡的结构下界与错峰共享损失',3)
para('四个单元设备作业量合计53530.665754 s，其中C2为43029.422338 s，占80.382752%。由于C2不能拆分，任一合法分区必有一组承担至少这一份额。若最大单元份额记为α，则最大相对均值偏差满足')
equation(r'\alpha=\frac{\max_c W_c}{\sum_c W_c}=0.8038275208,\qquad B_K\ge K\alpha-1\quad(\alpha\ge1/K).')
para('证明：包含最大单元的组，其工作量不少于α倍总量；组均值为总量的1/K，因此该组相对均值的正偏差至少Kα−1。对于二分、三分，下界分别为0.607655和1.411483；均衡优先方案的最大相对偏差分别达到这两个下界。该结论解释了为何即使完全枚举也无法达到二等分或三等分。注意B的下界不直接等同于CV²的下界，后者的最优值由完全枚举证明。')
para(r'独立分区还失去了组间错峰复用。令 $q_{\ell h}(t)$ 为组 $\ell$ 的瞬时资源需求，则')
equation(r'N_h=\sum_\ell\max_t q_{\ell h}(t)\ \ge\ \max_t\sum_\ell q_{\ell h}(t)=N_h^{\mathrm{shared}}.')
para('以二分的B型资源为例，大组在48.0 s同时占用两架B机，对应Q3T-005、Q3T-014；在1869.8 s达到四组B电池占用峰值，对应Q3T-005、Q3T-007、Q3T-012、Q3T-014。S011的Q3T-025较晚执行，原全场方案可复用已释放的B机和电池；独立成组后，即使错峰，也需要额外专属机体和电池。图9显示同一B电池任务占用曲线，充满后才释放。')
figure('Q4_B电池错峰共享损失.png','图9 二分方案中B型电池的错峰共享损失')
table('表22 分区共享损失 库存缺口与未配置库存',['资源','现库存','全场共享','K2配置/损失/缺口','K3配置/损失/缺口','K2/K3未配置'],[[h,S['stock'][i],S['pooled'][i],'/'.join(str(x) for x in [SOL[2]['selected']['N'][i],SOL[2]['selected']['N'][i]-S['pooled'][i],SOL[2]['selected']['gap'][i]]),'/'.join(str(x) for x in [SOL[3]['selected']['N'][i],SOL[3]['selected']['N'][i]-S['pooled'][i],SOL[3]['selected']['gap'][i]]),f"{max(0,S['stock'][i]-SOL[2]['selected']['N'][i])}/{max(0,S['stock'][i]-SOL[3]['selected']['N'][i])}"] for i,h in enumerate(['A机','B机','C机','A电池','B电池','C电池','中继机','中继组件'])],[2.1,1.6,2.0,4.0,4.0,2.7])
para('各组已经分别达到最小配置，不存在删除某一组专属资源仍保持全部原时序可行的空间。表22中的附加数量是相对于可跨区共享的参照，而不是组内算法浪费。4组未配置中继组件属于本冻结任务下未投入的库存，既不能补偿运输资源缺口，也不意味着在其他救援任务或扰动情景中没有价值。')

heading('5.4.9 任务期机体占用与能源恢复期占用',3)
para('资源占用率必须明确统计时域。联合任务于6026.919808 s最后返航，而所有资源恢复可再投入的统一时刻为8468.920371 s。后者包含末批运输电池的补电尾段，若直接作为飞机机体利用率的分母，会把任务完成后的时间也解释成任务执行期空闲。因此本文分别报告机体任务期占用率与能源恢复期占用率。')
para(r'对运输机和中继机，以第三问最后返航时刻 $C_J$ 截断占用区间，定义机体任务期占用率；对电池和中继组件，以该资源类别最后恢复可用的时刻 $H_h$ 作为统计终点：')
equation(r'U_h^{\mathrm{mission}}=\frac{\sum_{I\in\mathcal I_h}|I\cap[0,C_J]|}{N_hC_J},\qquad h\in\{U_A,U_B,U_C,U_R\}.')
equation(r'H_h=\max_{I\in\mathcal I_h}\sup I,\qquad U_h^{\mathrm{recovery}}=\frac{\sum_{I\in\mathcal I_h}|I|}{N_hH_h},\qquad h\in\{B_A,B_B,B_C,B_R\}.')
para('机体占用含准备及任务期内的中继周转，不等同于纯飞行时长占比；能源占用包括执行和充电，不表示电能转换效率。两类指标使用不同时间域，可在同类资源的两种分区之间比较，不能忽略分母差异直接跨类型评价效率。所有分区沿用相同任务集合，各类恢复终点不因重新分配编号而改变。')
metricrows=[]
for i,h in enumerate(S['resource_order']):
    rr=[next(r for r in MET if int(r['K'])==k and r['resource']==h) for k in [2,3]]
    metricrows.append([['A机','B机','C机','A电池','B电池','C电池','中继机','中继组件'][i],'任务期' if h.startswith('U_') else '能源恢复期',num(rr[0]['denominator_horizon_seconds']),f"{float(rr[0]['occupancy'])*100:.2f}%",f"{float(rr[1]['occupancy'])*100:.2f}%"])
table('表23 两种正式分区下按资源类型定义的占用率',['资源','统计口径','统计终点 s','K2占用率','K3占用率'],metricrows,[2.5,3.3,4.0,3.3,3.3])
para('例如，二分A机任务期占用率为86.69%，三分降至69.36%，下降来自固定任务量由更多专属机体承担。二分C机任务期占用率98.26%，三分为65.51%。中继任务及配置均未改变，两个分区的中继机任务期占用率均为78.66%，组件恢复期占用率均为82.90%。这些值是冻结计划的描述性指标，不构成随机环境下的利用率预测。')
para('为保留统计可追溯性，原报告以全部资源统一恢复终点8468.920371 s计算的指标仍保留，并明确命名为“统一恢复周期资源占用率”。例如二分A机在该口径下为61.70%，组件为69.06%；这与表23不矛盾，区别在于统计终点。新口径的16项结果均由区间长度求和与独立事件积分交叉复核一致，分区、最少资源数和库存缺口完全不变。')

heading('5.4.10 解释敏感性 资源压力与独立验证',3)
para('严格冻结第三问原实体编号时，同一机体或能源实体执行的全部任务也必须同组，需进一步加入身份超边。例如U01连接S001与S006，U06连接S007、S009、S010、S011，U03连接S001、S002、S003、S015；与已有通信超边传递合并后，15个服务区仅剩一个连通分量。因此，严格身份解释下二分和三分均结构不可行。增加新库存不能解除“既有任务必须继续绑定原实体且同一实体只能属于一组”的矛盾。')
para('这一结果与主解释的库存不足不同：主解释允许执行前配置同型专属资源，补足缺口即可保持原时序；严格身份解释首先阻断分区本身。二者并列说明任务冻结与资产编号冻结不是相同约束，不以重新命名掩盖任务或通信关系改变。')
sens=rows('sensitivities_q4.csv');inventory=[]
for scenario,label in [('inventory_base','现库存'),('inventory_B_aircraft_plus1','仅B机增加1架'),('inventory_B_battery_plus1','仅B电池增加1组'),('inventory_B_both_plus1','B机与B电池各增加1'),('inventory_ABC_aircraft_and_battery_plus1','A/B/C机及电池各增加1')]:
    chosen=[next(r for r in sens if r['scenario']==scenario and r['K']==str(k)) for k in [2,3]]
    inventory.append([label]+[re.search(r'feasible partitions (\d+)',r['detail']).group(1) for r in chosen])
table('表24 库存增配情景下可独立执行的合法分区数',['库存情景','K2可行分区数','K3可行分区数'],inventory,[9.2,3.6,3.6])
charge=[]
for mult in ['1.05','1.10']:
    rr=[next(r for r in sens if r['scenario']=='charge_multiplier_'+mult and r['K']==str(k)) for k in [2,3]]
    charge.append([f'充电时长×{mult}']+[vec(json.loads(r['N'])) for r in rr])
table('表25 充电速度下降时的资源优先最小配置',['压力情景','K2配置','K3配置'],charge,[3.8,6.3,6.3])
para('充电压力情景只延长能源资源占用，不移动运输或中继的物理任务时刻。充电时长增加5%和10%后，主分区未改变，但需要进一步增配能源资源，表25给出其数量。由此可见，当前最小配置对充电速度变化并非无条件稳健；所报告的是保证同一物理任务时序所需的资源响应。')
balance=[]
for key,label in [('priority_balance','运输与中继设备秒'),('balance_Wtransport','仅运输设备秒'),('balance_Wturn','计入中继返航后周转'),('balance_boxes','按货箱数量')]:
    rr=[next(r for r in sens if r['scenario']==key and r['K']==str(k)) for k in [2,3]]
    balance.append([label,rr[0]['partition'],num(rr[0]['CV2'],6),rr[1]['partition'],num(rr[1]['CV2'],6)])
table('表26 工作量口径变化下的均衡优先方案',['工作量定义','K2分区','K2 CV²','K3分区','K3 CV²'],balance,[4.0,4.3,1.9,4.3,1.9])
para('三种替代工作量定义下，二分和三分的均衡优先分组均保持不变，但CV²的数值随衡量对象改变，不宜混作同一指标的改善幅度。将资源偏好改为等权设备总数优先、或机体先于能源资源优先，两种K的资源优先分区也保持不变。相关30个场景均有全量结果保存；这些离散确定性检验不代表未知风场、故障概率或需求随机变化下的鲁棒保证。')
para('验证从第三问完整物理与通信重放开始，363个通信区间、550条事件记录的实际来源逐条一致，其中388个唯一架次—时刻事件和162条重复边界均无来源冲突。对于全部13种分区逐条检查运输客户与实际中继是否同组；由于轨迹、时刻、参数及来源不变，原通信几何证书可在重新配置同型实体后继承。')
para('资源最小性采用区间峰值与贪心着色互证，并对8类资源建立显式冲突颜色模型，均获得最优状态；分区目标另经六层整数规划求解核对。共29项检查通过，其中9类故障注入能够识别任务时刻篡改、中继遗漏、架次途中跨组、实际来源被候选替换、零长度事件删除、重复边界来源冲突、忽略补电、忽略机体周转及错峰跨组借用实体。半开边界、极小正重叠、原子峰值错误相加及传递连接均另作检查。')
para('输出工作簿重新读取后核验分区、资源数量和逐任务实体归属，既有8张工作表的22689个单元格值与样式保持一致。正式结果表保留原11列，分别填写二分2组、三分3组。全部区间端点保留计算精度，展示位数不参与再计算；完整逐任务新旧编号、增配标记与峰值见证明细随代码交付。')
para('本问给出的精确性来自任务结构收缩、全部分区枚举和区间图最小资源证明。它说明冻结通信服务会限制分区自由度，独立执行会损失错峰共享，而设备增配与负荷均衡存在可量化取舍；这些结论均依赖既有第三问方案及明确的资源归属解释，不能外推为其他联合运输通信方案必然具有相同缺口。')
for p in disclosures:doc._body._body.insert(len(doc._body._body)-1,p)
doc.core_properties.subject='论文正文至问题四'
doc.save(W/'论文_写至问题四_正式.docx')
(ROOT/'论文正文_问题四.md').write_text('\n'.join(md),encoding='utf-8')
frozen.update(equations_total=eqno,tables_total=len(doc.tables),previous_paper_sha256=sha(previous),external_paper_before_sha256=delivery['sha256'],preserve_previous_content=True)
(W/'frozen_numbers.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(equations_total=eqno,tables_total=len(doc.tables),Q4_characters=len('\n'.join(md))),ensure_ascii=False))
