"""Audit revised utilization definitions without changing tasks or partitions."""
from pathlib import Path
from decimal import Decimal as D
from fractions import Fraction as F
import csv,json,hashlib
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results';W=ROOT/'论文工作';W.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
S=read(R/'run_summary.json');sols={k:read(R/f'solution_k{k}.json') for k in (2,3)}
iv=rows(R/'resource_intervals_q4.csv');q3=read(ROOT.parent/'问题3/results/solution_summary.json');CJ=D(str(q3['C_joint']));H=D(S['horizon'])
assert read(R/'verification_q4.json')['valid'] and read(R/'workbook_audit.json')['valid']
def sweep_integral(rr,end):
    events={D(0):0,end:0}
    for r in rr:
        a=max(D(0),D(r['start']));b=min(end,D(r['end']))
        if a<b:events[a]=events.get(a,0)+1;events[b]=events.get(b,0)-1
    total=D(0);active=0;prev=D(0)
    for t,delta in sorted(events.items()):total+=(t-prev)*active;active+=delta;prev=t
    assert active==0
    return total
out=[]
for k,sol in sols.items():
    for i,h in enumerate(S['resource_order']):
        rr=[r for r in iv if r['resource']==h];n=sol['selected']['N'][i]
        energy=h.startswith('BAT_') or h=='COMP_R'
        hh=max(D(r['end']) for r in rr);end=hh if energy else CJ
        busy=sum((D(r['end'])-D(r['start']) for r in rr),D(0))
        mission=sum((max(D(0),min(CJ,D(r['end']))-max(D(0),D(r['start']))) for r in rr),D(0))
        numerator=busy if energy else mission
        assert numerator==sweep_integral(rr,end)
        value=numerator/(n*end);assert 0<=value<=1
        stock=S['stock'][i];shared=S['pooled'][i]
        out.append(dict(K=k,resource=h,N=n,stock=stock,shared=shared,shared_loss=n-shared,deficit=max(0,n-stock),unallocated_stock=max(0,stock-n),metric='energy_recovery_occupancy' if energy else 'airframe_mission_occupancy',numerator_seconds=str(numerator),denominator_horizon_seconds=str(end),class_recovery_horizon_seconds=str(hh),occupancy=str(value),old_common_cycle_occupancy=str(busy/(n*H))))
with (R/'paper_utilization_q4.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
audit=dict(valid=True,C_joint=str(CJ),old_common_horizon=str(H),partition_recomputed=False,main_results_changed=False,independent_interval_integration='all 16 resource/group-count cases exact Decimal equality',definitions={'airframe':'sum clipped occupancy over [0,C_joint] divided by N*C_joint; includes preparation and relay turnaround inside mission horizon','energy':'sum full occupancy divided by N*latest release of that resource type; includes charging, not discharge efficiency','old':'common recovery-cycle occupancy, retained for traceability'},source_hashes={n:sha(R/n) for n in ['solution_k2.json','solution_k3.json','resource_intervals_q4.csv','结果提交_Q4.xlsx']},metrics=out)
(R/'pro_review_q4.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
sources=['run_summary.json','components_q4.json','group_subsets_q4.json','solution_k2.json','solution_k3.json','all_partitions_q4.csv','balance_structural_bound.json','sensitivities_q4.csv','verification_q4.json','workbook_audit.json','paper_utilization_q4.csv','pro_review_q4.json']
frozen=dict(rigor_profile='submission',authorization='用户在已授权第四问方案基础上要求借鉴Pro意见并自主把握写入论文；保留既有方法、资源优先主方案、均衡备选及条件最优范围。',decision_source='本轮用户请求及问题4/assumptions_q4.md；未新增用户未作出的偏好选择',source_hashes={n:sha(R/n) for n in sources},solutions=sols,summary=S,balance=read(R/'balance_structural_bound.json'),metrics=out,claim_map=[dict(id='Q4_STRUCTURE',source='components_q4.json; balance_structural_bound.json',claim='4 components; 7+6 partitions; dominant workload share',support='DSU/BFS agreement; full enumeration',limit='fixed actual communication and indivisible relay sortie'),dict(id='Q4_RESOURCES',source='solution_k2.json; solution_k3.json',claim='minimum counts and deficits',support='interval peaks/coloring; independent MILP',limit='homogeneous reassignment allowed; stock augmentation needed'),dict(id='Q4_TRADEOFF',source='all_partitions_q4.csv; sensitivities_q4.csv',claim='resource and workload preference tradeoff',support='all legal partitions and alternative metrics',limit='conditional objective, not one universal best'),dict(id='Q4_OCCUPANCY',source='paper_utilization_q4.csv; pro_review_q4.json',claim='mission/recovery occupancy',support='direct interval sum equals independent sweep integration',limit='different horizons across resource types; no energy-efficiency interpretation')])
(W/'frozen_numbers.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2),encoding='utf-8')
(W/'q4_solution_package_for_writer.md').write_text('''# 第四问写作冻结包

最终方法与结果：`../results/第四问完整报告.md`、`../assumptions_q4.md`。
授权依据：用户已授权自主实现第四问，现要求借鉴Pro观点并由助手把握写入论文。沿用资源优先主方案与均衡优先备选，不宣称无偏好的总最优。
数值、来源哈希和论断映射：`frozen_numbers.json`。独立资源与任务核验：`../results/verification_q4.json`；新占用率复核：`../results/pro_review_q4.json`。
允许同型资源在执行前重新配置是主操作解释；不拆、不复制完整中继架次。严格原编号解释下仅1分量，单独报告。
采用Pro建议：定义共享损失、库存缺口和未配置库存；机体按任务期、能源按各类恢复期计算占用率；并列呈现两类偏好，突出大分量80.383%的均衡限制。原方案、时间、能耗、正式工作簿不改。
正文展示全部13方案的缺口—均衡投影，完整8维非支配结果保留详细报告。计算工程细节留交接材料。
新增论文图为原全精度结果的排版重绘，来源和变换保存在`figures/figure_manifest.json`；未作插值或虚构性能比较。
''',encoding='utf-8')
print(json.dumps([dict(K=r['K'],resource=r['resource'],percent=float(r['occupancy'])*100,horizon=r['denominator_horizon_seconds']) for r in out],ensure_ascii=False,indent=2))
