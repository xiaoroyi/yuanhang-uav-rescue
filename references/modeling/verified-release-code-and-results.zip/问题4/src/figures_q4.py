from solve_q4 import *
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.font_manager import FontProperties

def run():
    out=OUT/'figures';out.mkdir(exist_ok=True);font=FontProperties(fname='C:/Windows/Fonts/msyh.ttc');plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
    comp=read(OUT/'components_q4.json');summary=read(OUT/'run_summary.json');subs=read(OUT/'group_subsets_q4.json');parts=rows(OUT/'all_partitions_q4.csv');data=inputs();palette=['#0072B2','#D55E00','#009E73','#CC79A7'];saved=[]
    def save(fig,name,caption):
        for ext in ('png','pdf','svg'):fig.savefig(out/f'{name}.{ext}',dpi=300)
        plt.close(fig);saved.append(dict(name=name,caption=caption,source='components_q4.json; all_partitions_q4.csv; solution_k2/k3.json; resource_intervals_q4.csv',formats=['png','pdf','svg']))
    fig,axs=plt.subplots(1,3,figsize=(13,5.2),layout='constrained')
    o=np.array(data['nodes']['O01']['xy']);markers=['o','s','^','D']
    groupings=[(comp['atoms'],'不可拆任务分量')]+[(read(OUT/f'solution_k{k}.json')['groups'],f'K={k} 资源优先分区') for k in (2,3)]
    for ax,(groups,title) in zip(axs,groupings):
        for gi,g in enumerate(groups):
            xy=np.array([data['nodes'][s]['xy'] for s in g['services']]);xy=(xy-o)/1000
            ax.scatter(xy[:,0],xy[:,1],color=palette[gi],marker=markers[gi],s=42,label=(g.get('id') or f'G{gi+1}')+f'（{len(g["services"])}区）',zorder=3)
            for s,(x,y) in zip(g['services'],xy):ax.annotate(s[1:],(x,y),xytext=(3,4),textcoords='offset points',fontsize=8)
        ax.scatter(0,0,color='#222222',marker='*',s=90);ax.annotate('O01',(0,0),xytext=(4,4),textcoords='offset points',fontsize=8);ax.set(title=title,xlabel='相对东向距离 / km',ylabel='相对北向距离 / km');ax.set_aspect('equal');ax.legend(fontsize=8,loc='upper center',bbox_to_anchor=(.5,-.18),ncol=2,frameon=False);ax.grid(alpha=.2)
    save(fig,'01_任务分量与主分区','点表示服务区；数字为服务区编号。分区由实际任务与通信关系决定，不以地理连片为约束。')
    fig,axs=plt.subplots(1,2,figsize=(11.5,4.2),layout='constrained');labels=['A机','B机','C机','A电池','B电池','C电池','中继机','组件'];xx=np.arange(8)
    for ax,k in zip(axs,(2,3)):
        p=read(OUT/f'solution_k{k}.json')['selected'];ax.bar(xx-.22,summary['stock'],.22,label='现有库存',color='#999999');ax.bar(xx,summary['pooled'],.22,label='全场共享最少',color='#56B4E9',hatch='//');ax.bar(xx+.22,p['N'],.22,label='独立组配置',color='#D55E00');
        for x,n,g in zip(xx,p['N'],p['gap']):
            if g:ax.text(x+.22,n+.12,f'+{g}',ha='center',fontsize=9,color='#8A2700')
        ax.set_xticks(xx,labels,rotation=25);ax.set_ylim(0,9);ax.set(title=f'K={k}：加号表示库存缺口',ylabel='架 / 组');ax.legend(fontsize=8);ax.grid(axis='y',alpha=.2)
    save(fig,'02_逐类资源配置与缺口','比较现库存、同一冻结方案全场共享最少需求以及分区独立配置。零起点柱图，资源种类不可互换。')
    fig,axs=plt.subplots(1,2,figsize=(11,4.5),layout='constrained')
    for ax,k in zip(axs,(2,3)):
        ps=[p for p in parts if int(p['K'])==k];solution=read(OUT/f'solution_k{k}.json')
        for p in ps:
            x=float(F(p['Jgap']));y=float(F(p['CV2']));is_front=p['pareto']=='True';ax.scatter(x,y,s=55,marker='o' if is_front else 'x',color='#0072B2' if is_front else '#777777');offset=(-48,14) if p['id']=='K3-04' else (-48,-17) if p['id']=='K3-06' else (4,4);ax.annotate(p['id'],(x,y),xytext=offset,textcoords='offset points',fontsize=8)
        for which,marker,color_,label in [('selected','s','#D55E00','资源优先'),('balanced','*','#009E73','均衡优先')]:
            p=solution[which];ax.scatter(float(F(p['Jgap'])),float(F(p['CV2'])),s=150,marker=marker,facecolors='none',edgecolors=color_,linewidths=1.6,label=label,zorder=5)
        ax.set(title=f'K={k} 全部{len(ps)}种合法分区',xlabel='归一化库存缺口 Jgap',ylabel='设备作业秒均衡 CV²（越小越好）',xlim=(0,max(float(F(p['Jgap'])) for p in ps)+.45),ylim=(0,max(float(F(p['CV2'])) for p in ps)*1.12));ax.grid(alpha=.2);ax.legend(fontsize=8)
    save(fig,'03_完整分区的资源均衡取舍','展示全部13种分区。实心圆为8维资源向量与CV²非支配解，叉为被支配解；横轴仅投影缺口，不能代替完整非支配定义。')
    iv=rows(OUT/'resource_intervals_q4.csv');g2=read(OUT/'solution_k2.json')['groups'];fig,axs=plt.subplots(2,1,figsize=(10,5),sharex=True,layout='constrained')
    for ax,g,ttl in zip(axs,g2,['G1：14个服务区','G2：S011']):
        rr=[r for r in iv if r['resource']=='BAT_B' and r['task'] in g['transport']];ev=sorted({D(r[z]) for r in rr for z in ('start','end')});x=[0.]+[float(t)/60 for t in ev]+[float(summary['horizon'])/60];y=[0]+[sum(D(r['start'])<=t<D(r['end']) for r in rr) for t in ev]+[0];ax.step(x,y,where='post',color='#0072B2',linewidth=2);ax.fill_between(x,y,step='post',alpha=.18,color='#0072B2');ax.axhline(g['N'][4],color='#D55E00',linestyle='--',label=f'专属配置 {g["N"][4]} 组');ax.set(title=ttl,ylabel='B型电池占用数',ylim=(0,4.7));ax.legend(loc='upper right');ax.grid(alpha=.2)
    axs[-1].set_xlabel('相对任务开始的时刻 / min');save(fig,'04_B电池错峰共享损失','G1需要4组B电池，G2需要1组。需求发生时段错开，全场共享仅需4组，分区专属则需5组。充电完成才释放。')
    dump(OUT/'figure_manifest.json',saved);print('Saved',len(saved),'figure families')

if __name__=='__main__':run()
