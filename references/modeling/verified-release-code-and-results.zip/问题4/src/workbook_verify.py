"""Preserve pre-Q4 OOXML parts verbatim, merge artifact-authored Q4/style additions."""
from audit_q4 import *
from openpyxl import load_workbook
from xml.etree import ElementTree as ET
import zipfile,copy
NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main';N='{'+NS+'}'
ET.register_namespace('x',NS)

def sheet_path(z,name):
    w=ET.fromstring(z.read('xl/workbook.xml'));rid=next(e.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'] for e in w.find(N+'sheets') if e.attrib['name']==name)
    r=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'));target=next(e.attrib['Target'] for e in r if e.attrib['Id']==rid);return target[1:] if target.startswith('/') else 'xl/'+target

def preserve():
    source=Q3/'结果提交_Q3.xlsx';authored=OUT/'artifact_authored_Q4.xlsx';target=OUT/'结果提交_Q4.xlsx'
    with zipfile.ZipFile(source) as z,zipfile.ZipFile(authored) as a:
        q4=sheet_path(z,'Q4_分区配置');authq4=sheet_path(a,'Q4_分区配置');origstyles=ET.fromstring(z.read('xl/styles.xml'));newstyles=ET.fromstring(a.read('xl/styles.xml'));maps={}
        # Only append styles; existing indices remain unchanged for every older worksheet.
        for name in ('fonts','fills','borders','cellStyleXfs'):
            dst=origstyles.find(N+name);src=newstyles.find(N+name);mapping={}
            for i,element in enumerate(src):
                cp=copy.deepcopy(element)
                if name=='cellStyleXfs':
                    for prop,parent in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:
                        if prop in cp.attrib:cp.attrib[prop]=str(maps[parent][int(cp.attrib[prop])])
                mapping[i]=len(dst);dst.append(cp)
            dst.set('count',str(len(dst)));maps[name]=mapping
        dstnum=origstyles.find(N+'numFmts');srcnum=newstyles.find(N+'numFmts');numMap={}
        if srcnum is not None:
            if dstnum is None:dstnum=ET.Element(N+'numFmts');origstyles.insert(0,dstnum)
            nextid=max([163]+[int(x.attrib['numFmtId']) for x in dstnum])+1
            for x in srcnum:
                cp=copy.deepcopy(x);old=int(cp.attrib['numFmtId']);numMap[old]=nextid;cp.set('numFmtId',str(nextid));nextid+=1;dstnum.append(cp)
            dstnum.set('count',str(len(dstnum)))
        for x in origstyles.find(N+'cellStyleXfs'):
            # Original cellStyleXfs must not be modified; remap new appended records only below.
            pass
        origcount=len(origstyles.find(N+'cellStyleXfs'))-len(newstyles.find(N+'cellStyleXfs'))
        for x in list(origstyles.find(N+'cellStyleXfs'))[origcount:]:
            if int(x.attrib.get('numFmtId','0')) in numMap:x.set('numFmtId',str(numMap[int(x.attrib['numFmtId'])]))
        dst=origstyles.find(N+'cellXfs');mapping={}
        for i,e in enumerate(newstyles.find(N+'cellXfs')):
            cp=copy.deepcopy(e)
            for prop,parent in [('fontId','fonts'),('fillId','fills'),('borderId','borders'),('xfId','cellStyleXfs')]:
                if prop in cp.attrib:cp.set(prop,str(maps[parent][int(cp.attrib[prop])]))
            if int(cp.attrib.get('numFmtId','0')) in numMap:cp.set('numFmtId',str(numMap[int(cp.attrib['numFmtId'])]))
            mapping[i]=len(dst);dst.append(cp)
        dst.set('count',str(len(dst)))
        sheet=ET.fromstring(a.read(authq4));strings=[]
        if 'xl/sharedStrings.xml' in a.namelist():strings=[''.join(e.itertext()) for e in ET.fromstring(a.read('xl/sharedStrings.xml'))]
        for c in sheet.iter(N+'c'):
            if 's' in c.attrib:c.set('s',str(mapping[int(c.attrib['s'])]))
            if c.attrib.get('t')=='s':
                val=strings[int(c.find(N+'v').text)];c.remove(c.find(N+'v'));c.set('t','inlineStr');ET.SubElement(ET.SubElement(c,N+'is'),N+'t').text=val
        for c in sheet.iter(N+'col'):
            if 'style' in c.attrib:c.set('style',str(mapping[int(c.attrib['style'])]))
        for c in sheet.iter(N+'row'):
            if 's' in c.attrib:c.set('s',str(mapping[int(c.attrib['s'])]))
        replacements={q4:ET.tostring(sheet,encoding='utf-8',xml_declaration=True),'xl/styles.xml':ET.tostring(origstyles,encoding='utf-8',xml_declaration=True)}
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as dstzip:
            for entry in z.infolist():dstzip.writestr(entry,replacements.get(entry.filename,z.read(entry.filename)))
    return target

def verify():
    target=preserve();source=Q3/'结果提交_Q3.xlsx';old=load_workbook(source,data_only=False);new=load_workbook(target,data_only=False);errors=[];checked=0
    assert old.sheetnames==new.sheetnames
    for name in old.sheetnames:
        if name=='Q4_分区配置':continue
        a=old[name];b=new[name];assert (a.max_row,a.max_column)==(b.max_row,b.max_column)
        for row in a:
            for cell in row:
                v=b[cell.coordinate];checked+=1
                if cell.value!=v.value or cell._style!=v._style:errors.append((name,cell.coordinate,'value/style'))
    payload=read(OUT/'workbook_payload.json');actual=[[c.value for c in row] for row in new['Q4_分区配置'].iter_rows(min_row=1,max_row=6,max_col=11)];assert actual==[payload['headers']]+payload['rows'];assert not errors
    # Readback fields drive independent ownership/resource validation using canonical task assignments.
    from solve_q4 import ownership,H
    from verify_q4 import validate_partition
    sol=read(Q3/'solution_q3.json');ints=rows(Q3/'communication_intervals_q3.csv');pts=rows(Q3/'communication_event_points_q3.csv');ass=rows(OUT/'group_resource_assignment.csv')
    for k in (2,3):
        gs=read(OUT/f'solution_k{k}.json')['groups'];rr=[r for r in actual[1:] if r[0]==k]
        for g,r in zip(gs,rr):assert g['services']==[s.strip() for s in r[2].split(',')];g['N']=r[3:]
        assert validate_partition(sol,gs,[r for r in ass if int(r['K'])==k],ints,pts,sol,ints,pts)
    with zipfile.ZipFile(source) as a,zipfile.ZipFile(target) as b:
        changed=[p for p in a.namelist() if a.read(p)!=b.read(p)];assert set(changed)=={'xl/styles.xml',sheet_path(a,'Q4_分区配置')}
    result=dict(valid=True,Q4_headers_unchanged=True,Q4_rows=5,prior_sheets=len(old.sheetnames)-1,prior_cells_value_style_exactly_equal=checked,changed_zip_parts=changed,all_other_parts_byte_identical=True,readback_full_partition_resource_validation=True,errors=errors,source_sha=sha(source),output_sha=sha(target))
    old.close();new.close();dump(OUT/'workbook_audit.json',result);print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':verify()
