from audit_q4 import *
from openpyxl import load_workbook
import zipfile
from xml.etree import ElementTree as ET

def run():
    wb=load_workbook(Q3/'结果提交_Q3.xlsx',read_only=True,data_only=False);sh=wb['Q4_分区配置'];headers=[c.value for c in next(sh.rows)][:11];wb.close();rr=[]
    for k in (2,3):
        for i,g in enumerate(read(OUT/f'solution_k{k}.json')['groups'],1):rr.append([k,f'K{k}-G{i}',',\n'.join(', '.join(g['services'][j:j+7]) for j in range(0,len(g['services']),7))]+g['N'])
    dump(OUT/'workbook_payload.json',dict(headers=headers,rows=rr))
    p=Path('C:/Users/26099/.codex/attachments/f9fd53d2-ff43-4f1b-b026-17335be317cb/pasted-text.txt');v=json.loads(p.read_text(encoding='utf-8'));dump(OUT/'pro_attachment_structure.json',{'input_sha':sha(p),'top_level':{k:(type(x).__name__,len(x) if hasattr(x,'__len__') else None) for k,x in v.items()}})
    print('Headers:',headers)
    with zipfile.ZipFile(Q3/'结果提交_Q3.xlsx') as z:
        main=ET.fromstring(z.read('xl/workbook.xml'));ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};rid=next(s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'] for s in main.find('m:sheets',ns) if s.attrib['name']=='Q4_分区配置');rel=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'));target=next(s.attrib['Target'] for s in rel if s.attrib['Id']==rid);target='xl/'+target if not target.startswith('/') else target[1:];print('sheet',target, z.read(target).decode()[:3000])

if __name__=='__main__':run()
