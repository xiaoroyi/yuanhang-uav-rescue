from solve_q4 import *

def run():
    sol=read(Q3/'solution_q3.json');ints=rows(Q3/'communication_intervals_q3.csv');pts=rows(Q3/'communication_event_points_q3.csv');data=inputs();comp=components(sol,ints,pts);atoms=comp['atoms'];iv,_=intervals(sol,data);subsets,horizon=precompute(atoms,iv,sol,data);stock=read(OUT/'run_summary.json')['stock'];parts=enumerate_all(subsets,len(atoms),stock);out=[]
    def save(scenario,k,p,work='W',detail=''):
        out.append(dict(scenario=scenario,K=k,partition=p['partition'],N=p['N'],gap=p['gap'],Jgap=str(p['Jgap']),Jsize=str(p['Jsize']),CV2=float(p['CV2']),workload=work,detail=detail))
    for k in (2,3):
        pp=[p for p in parts if p['K']==k]
        for mode in ('resource','balance'):save('priority_'+mode,k,min(pp,key=lambda p:key(p,mode)))
        for work in ('Wtransport','Wturn','boxes'):
            alternate=[p|metrics([subsets[a] for a in p['masks']],stock,work=work) for p in pp];save('balance_'+work,k,min(alternate,key=lambda p:key(p,'balance')),work)
        # Workload greedy on indivisible components, largest first.
        loads=[D(0)]*k;masks=[0]*k
        for i in sorted(range(len(atoms)),key=lambda i:subsets[1<<i]['W'],reverse=True):
            g=min(range(k),key=lambda j:(loads[j],j));loads[g]+=subsets[1<<i]['W'];masks[g]|=1<<i
        found=next(p for p in pp if set(p['masks'])==set(masks));save('legal_workload_greedy',k,found,detail='Whole components only; exact resource peaks afterwards')
        save('equal_count_priority',k,min(pp,key=lambda p:(sum(p['gap']),sum(p['N']),p['CV2'])))
        save('aircraft_before_energy_resources',k,min(pp,key=lambda p:(sum(p['gap'][i] for i in [0,1,2,6]),sum(p['gap'][i] for i in [3,4,5,7]),p['CV2'])))
        for name,deltas in [('base',{}),('B_aircraft_plus1',{1:1}),('B_battery_plus1',{4:1}),('B_both_plus1',{1:1,4:1}),('ABC_aircraft_and_battery_plus1',{i:1 for i in range(6)})]:
            scenario=[n+deltas.get(i,0) for i,n in enumerate(stock)];candidate=[p|metrics([subsets[a] for a in p['masks']],scenario,scale=stock) for p in pp];best=min(candidate,key=key);save('inventory_'+name,k,best,detail='Stock '+str(scenario)+'; normalization stays at base inventory; feasible partitions '+str(sum(not any(p['gap']) for p in candidate)))
        for factor in (D('1.05'),D('1.10')):
            mod=copy.deepcopy(iv);rets={r['sortie']:r['return'] for r in sol['transport']+sol['relay']}
            for r in mod:
                if r['resource'].startswith('BAT') or r['resource']=='COMP_R':r['end']=rets[r['task']]+factor*(r['end']-rets[r['task']])
            subs,_=precompute(atoms,mod,sol,data);pp2=enumerate_all(subs,len(atoms),stock);best=min((p for p in pp2 if p['K']==k),key=key);save('charge_multiplier_'+str(factor),k,best,detail='All physical tasks frozen; energy resource intervals only extended; allocate extra resources, no rescheduling')
    # Negative geographic baseline: deterministic Lloyd k-means, no scientific performance ranking.
    import numpy as np
    coords={s:data['nodes'][s]['xy'] for a in atoms for s in a['services']};names=sorted(coords);X=np.array([coords[s] for s in names]);negative=[]
    for k in (2,3):
        centers=X[np.linspace(0,len(X)-1,k,dtype=int)].copy()
        for _ in range(100):
            labels=np.argmin(((X[:,None,:]-centers[None,:,:])**2).sum(2),axis=1);new=np.array([X[labels==j].mean(0) if np.any(labels==j) else centers[j] for j in range(k)])
            if np.array_equal(new,centers):break
            centers=new
        groups=dict(zip(names,map(int,labels)));violated=[e for e in comp['edges'] if len({groups[s] for s in e['services']})>1];negative.append(dict(K=k,services=groups,violated_edges=[{'kind':e['kind'],'id':e['id'],'services':e['services']} for e in violated],legal=not violated))
    table(OUT/'sensitivities_q4.csv',out);dump(OUT/'geographic_negative_baseline.json',negative)
    # Machine-readable conditional lower bound imposed by the largest indivisible workload.
    W=sum(subsets[1<<i]['W'] for i in range(len(atoms)));largest=max(subsets[1<<i]['W'] for i in range(len(atoms)));share=F(largest)/F(W)
    dump(OUT/'balance_structural_bound.json',dict(largest_atomic_workload=largest,total_workload=W,share=str(share),share_float=float(share),relative_max_deviation_lower_bounds={k:float(k*share-1) for k in (2,3)}))
    print(json.dumps(dict(sensitivity_rows=len(out),geographic_violations=[len(r['violated_edges']) for r in negative]),ensure_ascii=False))

if __name__=='__main__':run()
