from solve_q4 import *

def num(x,n=6):return f'{float(F(x)):.{n}f}'
def vec(x):return '('+','.join(map(str,x))+')'
def mdtable(headers,rr):return '\n'.join(['|'+'|'.join(headers)+'|','|'+'|'.join('---' for _ in headers)+'|']+['|'+'|'.join(str(v) for v in r)+'|' for r in rr])

def run():
    summary=read(OUT/'run_summary.json');comp=read(OUT/'components_q4.json');subs=read(OUT/'group_subsets_q4.json');parts=rows(OUT/'all_partitions_q4.csv');audit=read(OUT/'q3_interface_audit.json');val=read(OUT/'verification_q4.json');wb=read(OUT/'workbook_audit.json');solutions={k:read(OUT/f'solution_k{k}.json') for k in (2,3)};bounds=read(OUT/'balance_structural_bound.json');sens=rows(OUT/'sensitivities_q4.csv');q3=read(Q3/'solution_summary.json');witness=read(OUT/'resource_peak_witnesses.json');decomp=rows(OUT/'deficit_decomposition.csv')
    component_table=mdtable(['单元','服务区','运输/中继架次','设备作业秒','资源向量'],[[a['id'],','.join(a['services']),f'{len(a["transport"])}/{len(a["relay"])}',num(subs[str(1<<i)]['W']),vec(subs[str(1<<i)]['N'])] for i,a in enumerate(comp['atoms'])])
    edge_table=mdtable(['完整中继架次','实际服务运输架次','连通服务区','证据记录数'],[[e['id'],','.join(e['transports']),','.join(e['services']),len(e['records'])] for e in comp['edges'] if e['kind']=='relay'])
    main_rows=[];compare=[];work=[]
    for k,s in solutions.items():
        for i,g in enumerate(s['groups'],1):main_rows.append([k,f'G{i}',','.join(g['services']),vec(g['N']),num(g['W'])]);work.append([k,f'G{i}',g['boxes'],g['mass'],g['volume_L'],num(g['Wtransport']),num(g['Wrelay']),num(g['energy'])])
        for label,field in [('资源优先','selected'),('均衡优先','balanced')]:
            p=s[field];compare.append([k,label,p['partition'],vec(p['N']),vec(p['gap']),str(p['Jgap']),num(p['CV2']),num(p['max_deviation'])])
    all_table=mdtable(['编号','分量分组','资源向量','Jgap','CV²','非支配'],[[p['id'],p['partition'],vec(json.loads(p['N'])),p['Jgap'],num(p['CV2']),'是' if p['pareto']=='True' else '否'] for p in parts])
    peakB=next(w for w in witness if w['K']==2 and w['group']==1 and w['resource']=='BAT_B');peakU=next(w for w in witness if w['K']==2 and w['group']==1 and w['resource']=='U_B')
    identity=[e for e in comp['identity_edges'] if e['identity'][-1] in ('U01','U03','U06') and e['identity'][1]=='aircraft']
    text=rf'''# 第四问完整报告：冻结联合方案下的任务分区与独立资源配置

## 1. 结论及适用边界

以问题三正式联合方案为固定输入，采用**带不可拆任务超边的集合分区、区间图最优着色与完全枚举**，分别获得 K=2、K=3 的资源优先最优分区，并给出均衡优先备选和完整非支配集。

资源优先二分将 S011 单独成组，其余14区成组，需增配 **B型运输机1架、B型电池1组**。资源优先三分将 S006、S011 分别单独成组，其余13区成组，需增配 **A/B/C型运输机各1架、A/B/C型电池各1组**。全部7种二分和6种三分均不能在现库存内独立执行。

这是冻结本次问题三任务及实际通信关系下的精确结果。它不表示任意重新调度后的第三问方案都存在同样缺口，也不表示第三问本身已全局最优。正式配置状态为：**补足指定资源后可按原时序独立执行**。

主解释允许在执行前为各组配置专属同型资源并重新分配实体编号。若把第三问原机体和电池编号也禁止改变，15区会合为一个不可拆分量，K=2、3均结构不可分，增加库存不能解除这种固定身份矛盾。

## 2. 问题三交接审核

本地重新执行第三问完整物理检查，使用原始数据、DEM、独立运输校验器与连续通信几何核验。25个运输和3个中继架次、80箱均保留，硬截止违规为0、通信失联时长为0。重算的363条正长度开区间与550条事件记录逐条与正式来源表完全一致。

550条事件对应388个唯一“运输架次—时刻”，162条为相邻阶段重复边界，重复记录的实际来源全部一致。每条记录只有一个来源 G01 或一个中继架次，没有将候选覆盖范围当作实际保障关系。资源和任务时间保留JSON/CSV序列化小数，事件扫描使用 Decimal，不将微小正重叠舍入消除。

冻结主结果保持：D=0，联合末次返航 {num(q3['C_joint'],9)} s，运输能耗 {num(q3['E_transport'],9)} kWh，中继能耗 {num(q3['E_relay'],9)} kWh，总能耗 {num(q3['E_total'],9)} kWh。问题四所有分区均保持这些值及逐箱交付时刻不变。

第三问报告中把指数1.5和能耗分项相加都称为项目补充的措辞需纠正：指数3/2及 E=Ehor+Eup 来自题设；具体水平与势能表达是前两问采用的补充关系。此项属于公式来源归属纠正，不改变数值计算。问题四不改写第三问源文件。

独立通信结论的范围仍为冻结DEM像元几何及其数值处理，最小额外裕量接近零，不扩大成实飞环境保障。

## 3. 固定任务、独立组和资源含义

冻结货箱组批、运输机型、访问及箱内交付顺序、准备/起飞/交付/返回时刻、轨迹、能耗和SOC；冻结中继位置高度、准备/建链/驻留/返回时刻；冻结每条通信实际来源及开闭边界。任务不复制、不拆分、不整体平移，也不重新选中继来源。

运输和通信任务只属于一个组。一个完整中继架次服务过的所有运输任务必须同组，即使服务时段不重叠。同一中继实体在执行前可以重新编号，同一悬停点或同一原编号不自动作为主解释的合并边。O01、G01继续作为公共固定设施，地理距离和地域连片不是额外硬约束。

八类资源顺序统一为：

`(A机,B机,C机; A电池,B电池,C电池; 中继机,中继组件)`。

从原始表读取现库存为 `{vec(summary['stock'])}`。原编号用于追溯，新编号区分 `STOCK`（现有资源）与 `ADD`（需增配）；分组后所有任务都由组专属资源承担。

## 4. 不可拆超图与原子单元

对运输架次 r，将其目的服务区集合 D_r 作为超边；对完整中继架次 j，以实际客户集合 F_j 构造 H_j=∪(r∈F_j)D_r。正长度区间和零长度事件均计入 F_j。

采用并查集收缩，并用独立二部图 BFS 验证。仅运输多点关系形成12个分量；加入实际中继关系后形成4个原子单元，结果没有硬编码：

{component_table}

实际中继连接证据如下，逐条通信行号保存在 `components_q4.json` 的 records 字段：

{edge_table}

![任务分量与主分区](figures/01_任务分量与主分区.png)

S007—S015—S003 的传递关系得到完整保留。三个单点分量不因地图接近、共享网关或候选中继覆盖而强行并入大分量。

## 5. 固定时序资源配置模型与最小性

运输机与电池占用区间分别为

$$I_r^{{U_g}}=[S_r,R_r),\qquad I_r^{{BAT_g}}=[S_r,R_r+\chi_g(E_r)).$$

中继机与能源组件占用区间分别为

$$I_j^{{U_R}}=[Y_j,R_j+300),\qquad I_j^{{COMP_R}}=[Y_j,R_j+\chi_R(E_j)).$$

周转和充电从返航时刻分别开始，可以并行。若返航SOC为s，等效全充时间为T，则

$$\chi(s)=\begin{{cases}}T[0.65(0.9-s)/0.9+0.35],&s<0.9,\\T\,0.35(1-s)/0.1,&s\ge0.9.\end{{cases}}$$

独立复算的资源释放时刻与冻结值最大差为 {summary['max_charge_recompute_error']} s，属于浮点序列化误差。正式事件扫描使用冻结全精度端点，无放宽资源冲突容差。

对某组g和资源h，其最小配置为

$$n_{{gh}}=\max_t\sum_{{I\in\mathcal I_{{gh}}}}\mathbf1\{{t\in I\}}.$$

下界：峰值时刻有p项任务同时占用，即至少需要p个资源。上界：按开始时刻排列，使用最早释放的资源，若全忙则新增；新增时同时占用数量恰好等于新资源总数。因此贪心区间着色达到下界。机体和能源独立着色，因初始全满、满充复用、同型可拆换且补电无附加容量约束，所得数量可实现。

必须先合并同组全部区间再求峰值，不能把各原子单元峰值直接相加。所有15种非空分量子集均已预计算，逐类峰值与堆着色一致；另用显式颜色变量和两两冲突约束，对8类资源建立独立 CP-SAT 最少着色模型，全得 OPTIMAL 并与扫描峰值相同。

所有资源释放的统一统计时域为 [0,{num(summary['horizon'],9)}] s，包含末次运输电池补电。下文历史指标明确命名为“统一恢复周期资源占用率”，它不等同于任务执行期设备利用率，任务完工仍保持 {num(q3['C_joint'],9)} s。论文修订新增机体任务期与能源分类恢复期口径，见本报告末尾。

## 6. 目标、完全枚举和独立整数规划

设N_h=Σ_g n_gh，δ_h=max(0,N_h−I_h)。资源优先采用

$$\min_{{lex}}\left(J_{{gap}}=\sum_h\frac{{\delta_h}}{{I_h}},\quad J_{{size}}=\sum_h\frac{{N_h}}{{I_h}},\quad CV_K^2\right).$$

工作量 W_g 为该组所有运输和中继从准备到返航的设备作业秒。中继同时服务多架运输机时，其设备工时只记一次。均衡指标为

$$CV_K^2=\frac{{K\sum_gW_g^2}}{{(\sum_gW_g)^2}}-1.$$

均衡优先备选采用 lex(CV²,Jgap,Jsize)。这些是透明的偏好规则，不是假设的采购成本。归一化分母固定于基准库存，库存敏感性只改变缺口，不暗改目标权重。

限制增长序列完整枚举无标签分区：S(4,2)=7、S(4,3)=6。全部比较使用Fraction有理数，避免微小差异造成错误排名。

独立集合划分整数规划以每个非空原子子集A对应二元变量y_A，满足各原子恰被一个子集覆盖、Σ_A y_A=K。组资源峰值为常量，缺口引入非负整数变量。前两层目标乘12转为整数，第三层以工时平方缩放为小时平方建立线性目标。SciPy/HiGHS六次分层求解全部最优、gap为0，与精确枚举各层结果一致。

当前完整非支配集：K=2有 {sum(p['pareto']=='True' for p in parts if p['K']=='2')} 个，K=3有 {sum(p['pareto']=='True' for p in parts if p['K']=='3')} 个，按8维资源向量与CV²共同判断。它是本固定问题的完整前沿，不是第三问连续搜索空间的前沿。

## 7. 正式分区与配置

{mdtable(['K','组','服务区','最少配置向量','设备作业秒'],main_rows)}

{mdtable(['K','组','箱数','质量/kg','体积/L','运输工时/s','中继工时/s','能耗/kWh'],work)}

80箱、758 kg、2011 L在分区后守恒。全部25个运输和3个中继架次恰归一组，不增加或减少任务。

{mdtable(['K','偏好','原子分组','总配置','库存缺口','Jgap','CV²','最大相对均值偏差'],compare)}

![逐类资源配置](figures/02_逐类资源配置与缺口.png)

均衡优先方案把大通信分量独立保留，K=2将另三个单元合并，K=3将S006与S011合并、S001独立。它改善设备作业秒均衡，但增加运输机和电池专属配置。工作量贪心基线恰好得到这两套均衡最优分区，本实例不夸大“精确法战胜贪心”的性能差距。

大通信分量工作量占比为 {float(bounds['share_float'])*100:.6f}%。任何合法分区都至少有一组承担该份额。K=2/3最大相对均值偏差下界分别为 {bounds['relative_max_deviation_lower_bounds']['2']:.6f}、{bounds['relative_max_deviation_lower_bounds']['3']:.6f}。因此不可能在维持任务关系的前提下达到二等分或三等分。

## 8. 全部合法分区

{all_table}

![全部分区的资源均衡取舍](figures/03_完整分区的资源均衡取舍.png)

这些13种分区全部有库存缺口，而非求解超时或启发式未找到可行解。作为负面对照，经纬度K-means二分/三分均拆开2条不可拆超边，属于非法分区，不进入合法方案排名。

## 9. 缺口、共享损失、未配置库存与统一恢复周期占用率

全场共享同一冻结方案最低需求为 `{vec(summary['pooled'])}`。分组增加需求的原因是 Σ_g max_t n_gh(t) ≥ max_t Σ_g n_gh(t)，组间不能借用错峰空闲资源。

K=2大组B机在 {peakU['time']} s 同时占用 {peakU['count']} 架，任务为 {','.join(peakU['tasks'])}；B电池在 {peakB['time']} s 达到 {peakB['count']} 组，任务为 {','.join(peakB['tasks'])}。S011另需专属B机及B电池，尽管其任务在较晚时段，可共享运行时复用大组已空闲的资源，独立配置却不能借用。

![B电池错峰共享损失](figures/04_B电池错峰共享损失.png)

{mdtable(['K','资源','现库存','全场共享最少','分区总配置','比共享增加','库存缺口','未配置库存','统一恢复周期占用率'],[[r['K'],r['resource'],r['stock'],r['pooled'],r['partition_total'],r['additional_vs_pool'],r['deficit'],r['unallocated_stock'],f"{float(r['utilization'])*100:.2f}%"] for r in decomp])}

独立运行附加资源、库存未配置量和时间空闲是不同概念。6组中继组件中只需配置2组，余下4组不能抵消任何B型电池缺口。中继组件统一恢复周期占用率约69.06%，不能据此称另4组设备在其他救援任务中无用。

## 10. 验证、敏感性和解释边界

全部合法分区逐条继承363个通信区间、550个事件记录并核查实际来源在同组。轨迹、时刻、位置、链路参数和实际来源不变，故原连续通信几何条件不变；重新分配实体编号不改变同型设备通信参数。原始链路证书缺失、来源改变、零长事件删除或组外借用都被拒绝。

共有 {len(val['checks'])} 项已执行检查，含 {len(val['fault_injections'])} 类错误注入：改任务开始时刻、漏中继、架次中途换组、用候选替换实际来源、删零长度中继事件、重复边界来源冲突、忽略充电、忽略中继周转、错峰跨组借同一实体。另检验半开同刻释放、皮秒级真实重叠、原子峰值错误相加、孤立事件合并、传递性、随机更名不变性和独立标签全枚举。

库存敏感性：K=2仅增B机或仅增B电池均不能消除全部缺口；两者同时各增1，可使资源优先方案独立执行。A/B/C运输机和电池各增1时，有3种二分和1种三分能在该情景库存内执行。主归一化标尺不随库存情景更改。

充电时间乘1.05时，二分配置变为(4,3,2;7,5,4;2,2)，三分变为(5,3,3;8,5,5;2,2)。充电时间乘1.10时，分别变为(4,3,2;7,6,4;2,2)和(5,3,3;8,6,5;2,2)。各任务物理时刻均未平移，通过增配能源资源实现原时序，而非修改任务来消除冲突。

均衡口径改为运输设备秒、含中继周转设备秒或箱数，两种K的均衡优先分组均保持不变。等权设备数优先和机体先于能源资源优先，也保持资源优先分组不变。30个场景全表见 `sensitivities_q4.csv`。

严格原编号解释的合并证据包括：{'; '.join(e['identity'][-1]+'连接'+','.join(e['services']) for e in identity)}。并查集得到1个分量，故无法在不改原实体归属的同时划为2或3组。此处是归属解释造成的结构不可分，与主解释的可补足库存缺口应区分。

## 11. 数据文件与复现

- `solution_k2.json`、`solution_k3.json`：主配置、均衡备选和分组明细。
- `components_q4.json`：运输/中继超边、实际记录行号、原子单元和严格身份敏感性。
- `all_partitions_q4.csv`、`pareto_q4.csv`：全部13分区及完整非支配集。
- `group_resource_assignment.csv`：逐任务专属资源、新增资源明确标记，原编号保留追溯。
- `resource_peak_witnesses.json`：所有正式组各类资源最小性见证。
- `coverage_ownership_q4.csv`：每条通信记录对应的运输组和实际中继组。
- `verification_q4.json`、`q3_interface_audit.json`：验证及错误注入证据。
- `结果提交_Q4.xlsx`：在原11列中填写正式5行，其他8张工作表的22689个单元格值与样式逐项完全一致；除Q4工作表和追加样式定义外，其他OOXML部件逐字节保持原样。工作簿读回后重新验证分区、配置及资源编号。

运行入口为 `python 问题4/run_q4.py --stage all`。也可分别选择 audit、solve、verify、experiments、figures、export、report。Python环境沿用前三问，依赖版本和输入/源码哈希见 `run_manifest.json`。核心精确分区与MILP实测约 {summary['elapsed_seconds']:.3f} s，不含首次导入、前置DEM物理复核、出图和工作簿导出。

所有最优结论均限定于本冻结输入、完整中继架次单一归属和所声明目标。没有以分区名义调整第三问方案，也没有把未测量的峰值内存或实际无线环境误差伪造为验证结果。
'''
    if (OUT/'paper_utilization_q4.csv').exists():
        rates=rows(OUT/'paper_utilization_q4.csv')
        text+='\n## 12. 论文整合时的指标完善\n\n采用Pro建议并独立复核：同型资源执行前重配作为主操作解释，严格原编号作为敏感性；完整中继任务不拆、不复制。全部主分区、资源数量、缺口和正式工作簿不变。\n\n共享损失为 Npartition−Nshared；库存缺口为 max(0,Npartition−I)；未配置库存为 max(0,I−Npartition)。\n\n机体任务期占用率采用区间与[0,Cjoint]交集长度之和除以 N*Cjoint，含准备及任务期内周转。能源恢复期占用率采用完整占用长度之和除以 N*该类资源最后释放时刻，含充电。二者不能忽略分母差异跨类型比较，也不表示纯飞行占比或能量转换效率。旧统一恢复周期指标完整保留。\n\n'
        text+=mdtable(['K','资源','口径','统计终点 s','占用率'],[[r['K'],r['resource'],'任务期' if r['metric']=='airframe_mission_occupancy' else '能源恢复期',num(r['denominator_horizon_seconds']),f"{float(r['occupancy'])*100:.4f}%"] for r in rates])
        text+='\n\n16项新指标由区间长度求和与独立事件积分复核一致，详见pro_review_q4.json及paper_utilization_q4.csv。论文保留全部13种分区和详细验证、敏感性材料，不按页数删减前面三问。\n'
    (OUT/'第四问完整报告.md').write_text(text,encoding='utf-8')
    dump(OUT/'delivery_summary.json',dict(status='complete_with_explicit_resource_deficits',resource_order=H,solutions={k:{field:s[field] for field in ('selected','balanced')} for k,s in solutions.items()},all13_within_stock=False,checks=len(val['checks']),fault_injections=len(val['fault_injections']),workbook_valid=wb['valid']))
    print('Report written',len(text),'characters')

if __name__=='__main__':run()
