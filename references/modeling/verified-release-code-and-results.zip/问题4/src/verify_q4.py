from solve_q4 import *
import random

def validate_partition(sol,groups,assign,ints,pts,canonical_sol,canonical_ints,canonical_pts):
    assert sol==canonical_sol,'frozen task changed'
    assert ints==canonical_ints and pts==canonical_pts,'actual source or endpoint records changed'
    services=[s for g in groups for s in g['services']];assert len(services)==len(set(services))==15
    assert all(g['services'] for g in groups)
    for kind in ('transport','relay'):
        tt=[t for g in groups for t in g[kind]];assert len(tt)==len(set(tt))==len(sol[kind]);assert set(tt)=={r['sortie'] for r in sol[kind]}
    ownership(groups,ints,pts)
    canonical=rows(OUT/'resource_intervals_q4.csv');ci={(r['task'],r['resource']):r for r in canonical}
    assert len(assign)==len(ci)
    for r in assign:
        cr=ci[r['task'],r['resource']]
        assert D(str(r['start']))==D(cr['start']) and D(str(r['end']))==D(cr['end']),'resource release changed'
        assert r['task'] in groups[int(r['group'])-1]['transport']+groups[int(r['group'])-1]['relay']
    by=defaultdict(list)
    for r in assign:by[(r['resource'],r['new_id'])].append(r)
    for identity,rr in by.items():
        assert len({r['group'] for r in rr})==1,'cross-group entity loan'
        seq=sorted((D(str(r['start'])),D(str(r['end']))) for r in rr)
        assert all(b<=c for (a,b),(c,d) in zip(seq,seq[1:])),'resource overlap'
    for i,g in enumerate(groups,1):
        for h,n in zip(H,g['N']):assert len({r['new_id'] for r in assign if int(r['group'])==i and r['resource']==h})==n
    return True

def tests():
    sol=read(Q3/'solution_q3.json');ints=rows(Q3/'communication_intervals_q3.csv');pts=rows(Q3/'communication_event_points_q3.csv');comp=components(sol,ints,pts)
    allassign=rows(OUT/'group_resource_assignment.csv');checks=[]
    def add(name,ok,detail=None):assert ok,name;checks.append(dict(name=name,passed=bool(ok),detail=detail))
    for k in (2,3):
        gs=read(OUT/f'solution_k{k}.json')['groups'];ass=[r for r in allassign if int(r['K'])==k]
        add(f'K{k}_full_partition_resource_ownership',validate_partition(sol,gs,ass,ints,pts,sol,ints,pts))
    gs=read(OUT/'solution_k2.json')['groups'];ass=[r for r in allassign if int(r['K'])==2]
    mutants=[]
    def mutation(name,fn):
        payload=copy.deepcopy([sol,gs,ass,ints,pts]);fn(payload);rejected=False
        try:validate_partition(*payload,sol,ints,pts)
        except (AssertionError,KeyError):rejected=True
        add(name,rejected);mutants.append(name)
    mutation('reject_task_start_change',lambda x:x[0]['transport'][0].__setitem__('start',x[0]['transport'][0]['start']+1))
    mutation('reject_missing_relay',lambda x:x[1][0]['relay'].pop())
    mutation('reject_mid_sortie_relay_group_change',lambda x:x[1][1]['relay'].append(x[1][0]['relay'].pop()))
    mutation('reject_actual_source_replaced_by_candidate',lambda x:next(r for r in x[3] if r['source']!='G01').__setitem__('source','G01'))
    mutation('reject_delete_zero_length_relay_event',lambda x:x[4].remove(next(r for r in x[4] if r['source']!='G01')))
    mutation('reject_duplicate_boundary_inconsistent_source',lambda x:x[4].append(dict(x[4][0],source='Q3R-001')))
    mutation('reject_charge_ignored',lambda x:next(r for r in x[2] if r['resource']=='BAT_B').__setitem__('end',next(t['return'] for t in sol['transport'] if t['sortie']==next(r for r in x[2] if r['resource']=='BAT_B')['task'])))
    mutation('reject_relay_turn_ignored',lambda x:next(r for r in x[2] if r['resource']=='U_R').__setitem__('end',D(next(r for r in x[2] if r['resource']=='U_R')['end'])-300))
    mutation('reject_cross_group_resource_even_nonoverlapping',lambda x:next(r for r in x[2] if r['group']=='2' and r['resource']=='U_B').__setitem__('new_id',next(r['new_id'] for r in x[2] if r['group']=='1' and r['resource']=='U_B')))
    def item(t,a,b):return dict(task=t,start=D(a),end=D(b))
    seq=[item('a','0','1'),item('b','1','2')];add('half_open_exact_tie',sweep(seq)['count']==color(seq)[0]==1)
    seq=[item('a','0','1.000000000001'),item('b','1','2')];add('real_picosecond_overlap_not_rounded_away',sweep(seq)['count']==color(seq)[0]==2)
    seq=[item('a','0','1'),item('b','2','3')];add('union_peak_not_sum_atomic_peaks',sweep(seq)['count']==1 and sum(sweep([r])['count'] for r in seq)==2)
    # A relay connection only at a singleton event must still merge its clients.
    toy={'transport':[{'sortie':'a','route':{'stops':[['X',[]]]}},{'sortie':'b','route':{'stops':[['Y',[]]]}}], 'relay':[{'sortie':'r'}]}
    for i,r in enumerate(toy['transport']):r.update(aircraft=f'U{i}',battery=f'B{i}')
    toy['relay'][0].update(aircraft='R',component='C')
    tc=components(toy,[{'sortie':'a','source':'r'}],[{'sortie':'b','source':'r'}]);add('singleton_only_relay_hyperedge',len(tc['atoms'])==1)
    add('transitive_multi_stop',any({'S003','S007','S015'}<=set(a['services']) for a in comp['atoms']))
    add('enumeration_stirling_counts',[len(list(rgs(4,k))) for k in (2,3,4,5)]==[7,6,1,0])
    # Independently enumerate all labelled maps, canonicalize, and compare RGS.
    for k in (2,3):
        canonical=set()
        for labels in product(range(k),repeat=4):
            if len(set(labels))!=k:continue
            mapping={};seq=[]
            for z in labels:
                if z not in mapping:mapping[z]=len(mapping)
                seq.append(mapping[z])
            canonical.add(tuple(seq))
        add(f'K{k}_labelled_exhaustion',canonical==set(map(tuple,rgs(4,k))))
    # Rename all service/task/entity IDs and reorder records. Structure and interval counts must be invariant.
    rng=random.Random(20260923);ren=copy.deepcopy(sol);mapping={s:f'V{n:02d}' for n,s in enumerate(reversed(sorted({s for r in sol['transport'] for s,_ in r['route']['stops']})))}
    tm={r['sortie']:'X'+str(i) for i,r in enumerate(sol['transport']+sol['relay'])}
    for r in ren['transport']:
        r['sortie']=tm[r['sortie']];r['route']['stops']=[[mapping[s],b] for s,b in r['route']['stops']];r['aircraft']='u'+r['aircraft'];r['battery']='b'+r['battery']
    for r in ren['relay']:r['sortie']=tm[r['sortie']];r['aircraft']='r'+r['aircraft'];r['component']='c'+r['component']
    ri=[dict(r,sortie=tm[r['sortie']],source=tm.get(r['source'],r['source'])) for r in ints];rp=[dict(r,sortie=tm[r['sortie']],source=tm.get(r['source'],r['source'])) for r in pts];rng.shuffle(ri);rng.shuffle(rp)
    rc=components(ren,ri,rp);add('random_renaming_structure_invariant',sorted(len(a['services']) for a in rc['atoms'])==sorted(len(a['services']) for a in comp['atoms']))
    # Explicit color-assignment CP-SAT: pairwise conflicts, no interval-sweep input coefficients.
    from ortools.sat.python import cp_model
    ii=rows(OUT/'resource_intervals_q4.csv');explicit=[]
    for h in H:
        ss=[dict(task=r['task'],start=D(r['start']),end=D(r['end'])) for r in ii if r['resource']==h];n=len(ss);model=cp_model.CpModel();colorvars=[model.new_int_var(0,n-1,f'c{i}') for i in range(n)];mx=model.new_int_var(0,n-1,'max');model.add_max_equality(mx,colorvars)
        for i,j in combinations(range(n),2):
            if max(ss[i]['start'],ss[j]['start'])<min(ss[i]['end'],ss[j]['end']):model.add(colorvars[i]!=colorvars[j])
        model.minimize(mx);solver=cp_model.CpSolver();solver.parameters.max_time_in_seconds=10;solver.parameters.num_search_workers=1;solver.parameters.random_seed=0;status=solver.solve(model);ok=status==cp_model.OPTIMAL and solver.value(mx)+1==sweep(ss)['count'];add('explicit_color_'+h,ok);explicit.append(dict(resource=h,status=solver.status_name(status),colors=solver.value(mx)+1,walltime=solver.wall_time))
    source_manifest=read(OUT/'q3_snapshot_manifest.json');add('frozen_q3_source_files_unchanged',all(sha(p)==v for p,v in source_manifest['files'].items()))
    result=dict(valid=True,checks=checks,fault_injections=mutants,explicit_color_models=explicit,scope='All 13 legal partitions checked for ownership; all 15 subsets exact sweep/color. Full source equality for chosen partition replay. Q3 geometry verified once and inherited under fixed tasks.')
    dump(OUT/'verification_q4.json',result);print(json.dumps(dict(valid=True,checks=len(checks),fault_injections=len(mutants)),ensure_ascii=False))
    return result

if __name__=='__main__':tests()
