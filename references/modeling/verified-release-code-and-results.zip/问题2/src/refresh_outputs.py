"""Refresh comparisons, fixed-plan perturbations and exports after final consolidation."""
import env
from env import OUT
from experiments import stress,comparisons
from validate import check
from data_io import table,dump
from finalize import payload
import json,csv
def read_csv(name):
    with (OUT/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
base=json.loads((OUT/'solution.json').read_text(encoding='utf-8'));s=check(base)['summary']
rr=read_csv('sensitivity_resources.csv')
for r in rr:
    if int(r['delta'])<=0:continue
    if tuple(round(s[k],6) for k in ('D','Cmax','E','N'))<tuple(round(float(r[k]),6) for k in ('D','Cmax','E','N')):
        M={'A':4,'B':2,'C':2};K={'A':6,'B':4,'C':4};(M if r['resource']=='M' else K)[r['model']]+=int(r['delta'])
        val=check(base,OUT/r['name']/'retained_final_baseline',M=M,K=K);assert val['summary']['valid'];r.update(val['summary']);r['status']='RETAINED_FINAL_BASELINE';r['solution_source']='retained_final_baseline/solution.json'
table(OUT/'sensitivity_resources.csv',rr)
rr=read_csv('sensitivity_reserve.csv')
for r in rr:
    if float(r['rho'])==.2:r.update(s)
table(OUT/'sensitivity_reserve.csv',rr)
rr=read_csv('tradeoffs.csv')
for r in rr:
    if int(r['extra_seconds'])==0:r.update(s)
    elif r.get('valid')=='True':assert float(r['D'])<=s['D']+1e-6 and float(r['Cmax'])<=s['Cmax']+int(r['extra_seconds'])+1e-6
table(OUT/'tradeoffs.csv',rr)
stress(reoptimize=False);comparisons();payload()
dump(OUT/'final_refresh.json',dict(main=s,pressure_replays='recomputed on final published plan; existing independently validated scenario reoptimization solutions retained',comparisons='updated to final main; resource-increase cases retain final incumbent when better'))
print('Final comparisons, stress replays and export payload refreshed')
