﻿from pathlib import Path
import sys,json,csv,re,hashlib,copy,ast
ROOT=Path(__file__).resolve().parents[1]; PROJECT=ROOT.parent;WORK=ROOT/'论文工作';WORK.mkdir(exist_ok=True)
sys.path.insert(0,str(PROJECT/'问题1/论文工作/deps'))
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from lxml import etree
from latex2mathml.converter import convert
R=ROOT/'results'
def read(n):return json.loads((R/n).read_text(encoding='utf-8'))
def csvrows(n):return list(csv.DictReader((R/n).open(encoding='utf-8-sig')))
S=read('solution_summary.json');assert S['valid'] and read('export_precision_audit.json')['valid']
doc=Document(PROJECT/'问题1/论文工作/论文_写至问题一.docx')
# Freeze the template's cached cover logo instead of updating its stale external
# INCLUDEPICTURE path on another user's machine. Embedded image is preserved.
for ins in list(doc._element.xpath('.//w:instrText')):
    if 'INCLUDEPICTURE' in (ins.text or ''):
        p=ins
        while p.tag!=qn('w:p'):p=p.getparent()
        for n in list(p.xpath('.//w:fldChar | .//w:instrText')):n.getparent().remove(n)
transform=etree.XSLT(etree.parse(r'C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL'))
md=[];eqno=max(map(int,re.findall(r'式（(\d+)）',(PROJECT/'问题1/论文正文_至问题一.md').read_text(encoding='utf-8'))))
# Reuse only formatting functions, never execute the old document builder.
tree=ast.parse((PROJECT/'问题1/论文工作/build_paper.py').read_text(encoding='utf-8'))
names={'native_math','inline','para','heading','equation','table','figure'}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),'<q1-format-helpers>','exec'))
for p in list(doc.paragraphs):
    if p.text.startswith('AI辅助使用说明：'):p._element.getparent().remove(p._element)
# Extend abstract without changing previously verified Q1 results.
abstract='针对问题二，建立考虑共享电池周转的异构无人机路径—调度联合优化模型，将运输候选的非线性能耗预计算与飞机、电池双资源累计约束相结合，通过候选扩充和局部重组进行分层求解。所得方案以25架次完成80箱交付，31项硬时限全部满足，加权迟到为0；最后返航时间为98.991分钟，总能耗为67.5805 kWh。该结果证明迟到目标达到下界，其余目标不作全局最优声明。'
for p in doc.paragraphs:
    if p.text.startswith('关键词：'):
        new=p.insert_paragraph_before(style='PaperBody');new.add_run(abstract)
        p.text='关键词：无人机应急运输；整数规划；动态规划；路径与调度；共享电池';break
heading('5.2 问题二 共享电池约束下的异构无人机路径与调度联合优化',2)
heading('5.2.1 从独立组批到资源耦合',3)
para('第二问允许一个运输架次连续访问多个服务区，并将机型选择落实为具体无人机、电池和执行时刻。机体返航后可以更换另一组满电电池立即执行任务，而原电池仍需补电，因此仅约束飞机数量或将充电时间附加在机体周转上，均会改变可行域。本文保留第一问的地形、能耗和不可拆货箱规则，重新确定组批及访问顺序，建立带硬时间窗的异构多航次路径与双资源调度模型。')
para('原始库存为A/B/C型无人机4/2/2架，共享电池6/4/4组，电池总数已包含初始装机电池。80箱物资中，医疗与首批要求的并集为31箱，其硬截止按同时适用条件的较早者确定。其余期望时间用于评价配送及时性，不能全部改写为题设硬约束。')
para('采用准备开始即占用飞机和满电电池、返航即可拆下电池并行补电的操作解释。每站先完成一次基础交接，再串行处理各箱，逐箱完成时刻由处理次序决定；这一口径为补充假设。未引入附件未给出的装载工位、有限充电器及额外换电时间。')
heading('5.2.2 路线候选与集合划分',3)
para(r'令 $\mathcal R$ 为当前可行运输候选集合。候选r包含机型 $g_r$、实际箱集合 $B_r$、有序访问及各站卸货集合。逐航段更新剩余载荷，按第一问的等效航程与势能补充关系计算能耗；每次投送后从当地30米作业高度重新爬升，返程为空载。候选只有在质量、体积与完整返航能量检查通过后才进入主模型。')
equation(r'e_r=\sum_{(i,j)\in r}\left[E_{g_r}^{\mathrm{use}}\frac{d_{ij}}{L_{g_r}(q_{rij})}+\frac{(m_{g_r}^{0}+q_{rij})g_0h_{ij}^{+}}{3.6\times10^6\eta_{g_r}}\right]\le(1-\rho_{g_r})E_{g_r}^{\mathrm{use}}.')
para(r'用二元变量 $x_r$ 表示候选是否执行。集合划分约束要求每个真实箱号恰好交付一次，而非仅满足各区总重量。候选存在共同箱号时自然互斥，同一服务区允许由多个架次拆批服务。')
equation(r'\sum_{r:b\in B_r}x_r=1\quad(\forall b),\qquad x_r\in\{0,1\}.')
para(r'将候选的准备、逐段飞行和交接时长之和记为 $\tau_r$。若选中候选，则准备开始时刻 $S_r\ge0$，返航时刻 $R_r=S_r+\tau_r$。设到第i站的相对到达时刻为 $a_{ri}$，该站基础交接与每箱处理时长分别为 $\alpha_{g_r},\beta_{g_r}$，局部顺序 $k_{rb}$ 为1至该站箱数的互异整数。')
equation(r'C_b=S_r+a_{ri}+\alpha_{g_r}+\beta_{g_r}k_{rb}\quad(x_r=1,b\in B_{ri}),\qquad C_b\le d_b^{\mathrm{hard}}\quad(b\in\mathcal B_H).')
heading('5.2.3 两阶段充电与双资源调度',3)
para(r'设某机型等效完全充电时间为 $T_g$，返航荷电状态 $s_r=1-e_r/E_g^{\mathrm{use}}$。按附录规定，90%以下和以上采用不同充电速率，补满时长为')
equation(r'\chi_g(s)=\begin{cases}T_g[0.65(0.9-s)/0.9+0.35],&0\le s<0.9,\\T_g\,0.35(1-s)/0.1,&0.9\le s\le1.\end{cases}')
para('在SOC=90%处两段连续。例如B型SOC=30%时需1880秒，不能用耗电比例乘完全充电时间替代。对固定路线候选，其能耗与补电时间均为常数，因此可将非线性物理计算置于调度求解之外。')
equation(r'\sum_{r:g_r=g}x_r\mathbf1\{t\in[S_r,R_r)\}\le M_g,\qquad\sum_{r:g_r=g}x_r\mathbf1\{t\in[S_r,R_r+\chi_g(s_r))\}\le K_g\quad(\forall g,t).')
para('第一组累计约束管理机体，第二组管理使用和补电中的电池。区间采用左闭右开，同一时刻允许先释放后占用。在单基地、同型资源同质、初始满电和同型共享假设下，分别对两套区间图着色即可恢复具体飞机与电池编号；区间图最少着色数等于峰值重叠数，因此累计容量与存在合法实体分配相容。')
heading('5.2.4 多目标分层求解与候选改进',3)
para('原题要求综合考虑及时性、全部任务完成时间、能耗及架次数，并未规定唯一权重。本文采用及时性优先、其次压缩救援完成时间的优先关系；在前层指标不劣于已获值的条件下优化后层，保留节能替代方案以展示决策取舍。')
equation(r'D=\sum_b\omega_b\max(0,C_b-d_b),\quad C_{\max}=\max_{r:x_r=1}R_r,\quad E=\sum_rx_re_r,\quad N=\sum_rx_r;\qquad\min_{\mathrm{lex}}(D,C_{\max},E,N).')
para('实现采用CP-SAT可选区间和累计容量约束。先建立单点及多点候选，联合决定是否选择、开始时间与箱序；随后围绕末班任务、重载架次和相邻服务区重新组批，保持其他任务也可重排。累计生成7581条候选，探测包含四、五站及重复访问；候选未穷尽，最终方案最多访问两站不构成两站充分性的理论结论。')
para('主调度网格为0.1秒，飞行与补电分别保守向上取整，最后对固定路线采用0.01秒精修并按原始浮点物理时长重放。给定机体和电池前后序后，可由前序返航及补满约束递推最早开始；该无通信紧化只用于第二问，不能直接搬到第三问破坏中继服务窗口。四项主指标相同后，以增大最小硬时限裕量作为第五项破并列准则。')
para('有限候选池与有限搜索预算使该方法属于分层启发式。只有D=0可以由非负下界证明全问题最优；CP-SAT报告的池内界不能充当完整路线空间的全局界。计算得到的通用完工下界1960.543秒较松，不能据此宣称当前完工时间接近全局最优。')
heading('5.2.5 调度结果及对照',3)
para(f"最终25架次覆盖80个唯一箱号，交付758 kg、2011 L物资；A/B/C型分别执行12/7/6架次，其中3个架次访问两站。全部31项硬截止满足，最小裕量{S['min_hard_slack']:.3f}秒；逐箱口径下期望送达达标率100%，D=0。最后返航{S['Cmax']:.3f}秒（{S['Cmax']/60:.3f}分钟），总能耗{S['E']:.6f} kWh，最低返航SOC为{S['min_SOC']:.6%}。")
table('表7 第二问同口径方案对照',['方案','D','完工/min','能耗/kWh','架次'],[['单点联合优化','0','112.378','73.843540','28'],['多点贪心后调度','0','138.625','88.954631','25'],['候选扩充联合优化','0','98.991','67.580498','25']],[4.8,1.3,3.4,3.9,1.7])
para('相比单点联合优化结果，主方案缩短完工时间约11.91%，降低能耗约8.48%，减少3架次。由于候选和有限预算搜索质量也发生变化，该改善不能全部归因于多点访问本身；尤其不能只拿第一问累计作业时间与本问多机并行完工时间比较。')
figure('无人机甘特图.png','图3 运输无人机执行与复用时间安排',16)
figure('共享电池甘特图.png','图4 共享电池使用和补电时间安排',16)
para('两幅时间图分别展示机体与电池的占用，飞机返航并不意味着原电池已经可用。A/B/C机体峰值为4/2/2，电池峰值为6/4/4，均达到但不超过各型库存。完整25架次箱号、路径、实体分配和逐箱交付由提交表及附带CSV给出。')
heading('5.2.6 固定第一问方案的不可行证书',3)
para('固定第一问的组批与机型后，存在五个含3600秒硬截止货箱的B型任务，而B型仅两架，故至少一架必须连续完成其中三个。即使忽略电池充电这一限制，第三个任务也只能在前两个任务返航后开始。为了不将不佳箱序误认为不可行原因，对每个三箱批次枚举全部6种站内交付顺序，取最宽松的允许开始上界。')
cert=read('q1_fixed_all_orders_certificate.json')
table('表8 五个紧迫B型任务的连续时间证书',['服务区','完整时长/s','最晚开始上界/s','箱序枚举数'],[[r['service'],f"{r['duration']:.3f}",f"{r['latest_start_over_all_orders']:.3f}",r['all_order_count']] for r in cert['routes']],[3,4.5,5.3,2.3])
equation(r'S_{\mathrm{third}}\ge1510.470280+1555.376902=3065.847182>2567.231527\ge S_r^{\mathrm{latest}}.')
para('不等式两侧相差498.616秒，产生矛盾。因此不可行性源于连续时间与实体资源限制，非求解网格或箱序选择所致。具体箱号、硬截止及最佳箱序保存在证书附表；第三问同样不能将第一问机型安排固定后只增加通信。')
heading('5.2.7 权衡分析与适用边界',3)
table('表9 保持零迟到下的完工与节能取舍',['方案','完工/s','能耗/kWh','架次','最小硬裕量/s'],[['完工优先','5939.477','67.580498','25','61.545'],['节能替代','5969.043','66.601256','24','91.545']],[3.5,3.6,3.6,1.5,3.9])
para('节能替代方案仅晚29.567秒，节省0.979243 kWh（约1.449%），并减少1架次；因而主方案不全面支配该方案。采用主方案是完工优先规则的结果。有限完工上限扫描仅形成若干非支配样本，不能称为完整Pareto前沿。')
res=csvrows('sensitivity_resources.csv')
table('表10 中继介入前的运输资源单因素情景',['库存变化','变化后库存','完工/min','能耗/kWh','架次'],[[r['label'],r['absolute_inventory'],f"{float(r['Cmax'])/60:.3f}",f"{float(r['E']):.4f}",r['N']] for r in res],[3.3,3.2,3.4,3.9,1.3])
para('资源情景均重新求解并保留合法原方案，单因素变化外的参数不变。增加一架C型飞机在当前搜索下略改善完工；增加一组C型电池未找到优于最终主方案的结果。这些启发式结果不是资源边际价值的精确估计，未改善也不证明理论边际价值为零。减少C型飞机导致较大性能损失，不能直接推导其他分区配置的必然结果。')
para('能耗最紧架次为Q2-020，能耗6.324181 kWh，而C型限额为6.4 kWh；固定方案整体能耗上浮约1.199%即触及该限额。因此基准可行不等于具有较大能耗鲁棒性。已有整体能耗与飞行时间压力回放记录了超电及硬迟到，延迟发车不能修复超电；相关情景属于确定性扰动，不报告缺乏概率模型支持的可靠率。')
para('交付口径也影响临界结论：若将同站所有箱子统一记在整站交接结束，现方案仍无硬截止违规，但S001-WAT-08会比期望时间晚约5.81秒。因此100%期望达标的结论限于明确采用的逐箱处理口径，不能隐去该操作假设。')
heading('5.2.8 独立复核与第三问接口',3)
para('独立检查器重读原始Excel，并用经双方法核对的地形缓存重建逐段载荷、时间、能耗、交付及两类资源区间；不把优化器返回可行作为验证结论。55项检查及3区8箱小实例的累计资源／显式编号模型交叉核验通过。小实例验证模型表达，不证明全场搜索的全局最优性。')
para('正式XLSX以未舍入数值存储，仅设置三位时间、六位能耗的显示格式。重新读回后重建调度与逐箱交付，最大数值差小于10的负12次方，资源复核通过；展示表的舍入值不能用于零容差重放。第三问继承公共物理与数据，重新决定运输和中继计划，并对起飞至返回全过程施加通信约束。')
para('AI辅助使用说明：代码实现、核验与文字整理使用OpenAI Codex辅助；网页版ChatGPT Pro用于方案讨论。数值依据为本地原始附件与实际运行输出，未将外部建议中的预期结果作为计算结果。',small=True)
doc.core_properties.subject='论文正文至问题二';doc.save(WORK/'论文_写至问题二_正式.docx')
(ROOT/'论文正文_问题二.md').write_text('\n'.join(md),encoding='utf-8')
sources=['solution_summary.json','export_precision_audit.json','q1_fixed_all_orders_certificate.json','pro_review_changes.json','baselines.csv','tradeoffs.csv','sensitivity_resources.csv','tests.json','stress_tests.json']
freeze={n:{'sha256':hashlib.sha256((R/n).read_bytes()).hexdigest(),'value':read(n) if n.endswith('.json') else csvrows(n)} for n in sources}
(WORK/'frozen_numbers.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'论文交接文档.md').write_text('# 第二问论文交接\n\n用户明确授权完善第二问并续写论文，按既定及时性优先政策表述；主结果未改动。\n\n正文为论文正文_问题二.md；完整DOCX为论文工作/论文_写至问题二_正式.docx，从5.2接写并扩充摘要。数值来源与哈希见论文工作/frozen_numbers.json。\n\n必保留边界：逐箱交接补充假设、能耗分量补充关系、D=0仅证明迟到层最优、其余候选池启发式、1.199%能耗上浮阈值；主方案不支配节能替代。\n\n新增：导出全精度独立重放、5个紧迫B任务全箱序不可行证书、资源变化正负号及绝对库存。\n\n第三问继承物理与数据，不冻结Q2路线或独立提前其时刻。论文尚未包含第三问结果。\n',encoding='utf-8')
print(json.dumps({'docx':str(WORK/'论文_写至问题二_正式.docx'),'equations_total':eqno,'tables_total':len(doc.tables)},ensure_ascii=False))


