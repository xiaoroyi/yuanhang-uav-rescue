"""Audit the exported values, enumerate all local orders for the Q1 certificate."""
import env
from env import OUT, ROOT, PROJECT
from data_io import dump, table, sha
from prepare import load
from routes import Physics
from validate import check
from openpyxl import load_workbook
import json, copy, itertools

def run():
    data=load(); P=Physics(); boxes=P.boxes
    rows=json.loads((OUT/'solution.json').read_text(encoding='utf-8'))
    wb=load_workbook(OUT/'结果提交_Q2.xlsx',data_only=True)
    trips={v[0]:v for v in list(wb['Q2_运输架次'].values)[1:] if v[0]}
    delivered={v[0]:v for v in list(wb['Q2_逐箱交付'].values)[1:] if v[0]}
    clone=copy.deepcopy(rows);maxerr=0
    for r in clone:
        v=trips[r['sortie']]
        assert (v[1],v[2],v[3])==(r['aircraft'],r['route']['model'],r['battery'])
        for a,b in [(v[4],r['start']),(v[6],r['return']),(v[7],r['route']['energy'])]:maxerr=max(maxerr,abs(a-b))
        r['start']=v[4];r['return']=v[6];r['route']['energy']=v[7]
        for j,order in enumerate(r['orders']):
            r['orders'][j]=sorted(order,key=lambda b:delivered[b][3])
            m=P.models[r['route']['model']]
            for k,b in enumerate(r['orders'][j],1):
                expected=r['start']+r['route']['arrivals'][j]+m['handover']+m['handover_box']*k
                assert delivered[b][1]==r['sortie'] and delivered[b][2]==boxes[b]['service']
                maxerr=max(maxerr,abs(expected-delivered[b][3]))
    verified=check(clone,data=data);assert verified['summary']['valid'],verified
    assert maxerr<1e-8,maxerr
    dump(OUT/'export_precision_audit.json',dict(valid=True,maximum_numeric_roundtrip_error=maxerr,display='3 decimals time / 6 decimals energy; underlying cell values unrounded',physical_tolerance_unchanged=True,replayed=verified))
    cert=json.loads((OUT/'baselines/q1_fixed/continuous_infeasibility_certificate.json').read_text(encoding='utf-8'))
    batches=json.loads((PROJECT/'问题1/results/batches.json').read_text(encoding='utf-8'))
    detail=[]
    for old in cert['routes']:
        b=next(b for b in batches if b['service']==old['service'] and b['model']=='B')
        route=P.evaluate('B',[(b['service'],b['boxes'])]);m=P.models['B'];offset=route['arrivals'][0]+m['handover']
        candidates=[]
        for order in itertools.permutations(b['boxes']):
            latest=min(boxes[b]['hard_due']-offset-m['handover_box']*k for k,b in enumerate(order,1) if boxes[b]['hard_due'] is not None)
            candidates.append((latest,order))
        latest,order=max(candidates);assert abs(latest-old['max_start'])<1e-7
        detail.append(dict(service=b['service'],boxes=b['boxes'],hard_due={b:boxes[b]['hard_due'] for b in b['boxes']},arrival_offset=route['arrivals'][0],base_handover=m['handover'],per_box=m['handover_box'],all_order_count=len(candidates),best_order=list(order),latest_start_over_all_orders=latest,duration=route['duration']))
    lower=sum(sorted(r['duration'] for r in detail)[:2]);upper=max(r['latest_start_over_all_orders'] for r in detail)
    assert lower>upper
    dump(OUT/'q1_fixed_all_orders_certificate.json',dict(valid=True,minimum_third_start=lower,maximum_allowed_start=upper,gap=lower-upper,routes=detail,argument='Pigeonhole 5 jobs / 2 aircraft; best local order exhaustively checked; battery ignored as a relaxation'))
    table(OUT/'q1_fixed_all_orders_certificate.csv',detail)
    resource=list(__import__('csv').DictReader((OUT/'sensitivity_resources.csv').open(encoding='utf-8-sig')))
    for r in resource:
        delta=int(r['delta']);r['label']=f"{r['resource']}({r['model']}){delta:+d}";r['absolute_inventory']=data[r['resource']][r['model']]+delta
    table(OUT/'sensitivity_resources.csv',resource)
    energy_limit=min((1-.2)*P.models[r['route']['model']]['Euse']/r['route']['energy']-1 for r in rows)
    dump(OUT/'pro_review_changes.json',dict(status='verified',optimization_changed=False,export_full_precision=True,all_local_orders_certificate=True,uniform_energy_headroom=energy_limit,authorization='用户要求完善第二问并写入论文；授权自主核对和改进'))
    report=OUT/'第二问完整报告.md';text=report.read_text(encoding='utf-8')
    text=text.replace('M(C) 1','M(C)+1（共3架）').replace('K(C) 1','K(C)+1（共5组）').replace('M(C) -1','M(C)-1（共1架）').replace('K(C) -1','K(C)-1（共3组）')
    marker='\n## 13. Pro复核后的补充核验'
    if marker in text:text=text.split(marker)[0]
    text+=marker+f'\n\n正式XLSX保存未舍入底层数值，读回与独立重放均通过，最大数值误差{maxerr:.3g}。展示表保留三位小数，不能将展示值作为精确资源冲突判断依据；未放宽物理检查容差。\n\n固定Q1不可行证书已对5个B型任务的全部站内排列各6种进行枚举，最晚准备开始上界有效；详见q1_fixed_all_orders_certificate.csv/json。\n\n固定主方案整体能耗上浮阈值为{energy_limit:.6%}，因此不得表述为具有较大能耗鲁棒余量。权衡方案晚29.566783秒、少0.979243 kWh及1架次，主方案不全面支配它。\n'
    report.write_text(text,encoding='utf-8')
    print(json.dumps(dict(export_valid=True,max_error=maxerr,certificate_gap=lower-upper,energy_headroom=energy_limit)))

if __name__=='__main__':run()
