import env
from env import OUT,ROOT,PROJECT
from data_io import dump,table,sha
from validate import check
from routes import read_pool,Physics
from prepare import load
import json,csv,sys,platform,datetime,collections,statistics
from openpyxl import load_workbook

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def csvrows(name):
    with (OUT/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def payload():
    ss=csvrows('sorties.csv');dd=csvrows('deliveries.csv')
    source=load_workbook(PROJECT/'问题1/results/结果提交_Q1.xlsx',data_only=False,read_only=True)
    result=[dict(sheet='Q2_运输架次',lastCol='H',headers=[c.value for c in source['Q2_运输架次'][1]],numericCols=['E','G','H'],widths={'A':14,'B':14,'C':12,'D':17,'E':19,'F':45,'G':23,'H':23},rows=[[r['sortie'],r['aircraft'],r['model'],r['battery'],float(r['start']),'O01→'+'→'.join(s for s,bs in json.loads(r['stops']))+'→O01',float(r['return_s']),float(r['energy_kwh'])] for r in ss]),dict(sheet='Q2_逐箱交付',lastCol='D',headers=[c.value for c in source['Q2_逐箱交付'][1]],numericCols=['D'],widths={'A':25,'B':16,'C':16,'D':27},rows=[[r['box'],r['sortie'],r['service'],float(r['complete'])] for r in sorted(dd,key=lambda r:r['box'])])]
    source.close();dump(OUT/'workbook_payload.json',result)

def verify_workbook():
    before=load_workbook(PROJECT/'问题1/results/结果提交_Q1.xlsx',data_only=False,read_only=True);after=load_workbook(OUT/'结果提交_Q2.xlsx',data_only=False,read_only=True)
    checks={};checks['sheet_names']=before.sheetnames==after.sheetnames
    for name in before.sheetnames:
        a=list(before[name].values);b=list(after[name].values)
        if name.startswith('Q2_'):checks[name+'_headers']=a[0]==b[0]
        else:checks[name+'_unchanged']=a==b
    for part in read(OUT/'workbook_payload.json'):
        actual=list(after[part['sheet']].values)[1:];wanted=[tuple(r) for r in part['rows']]
        checks[part['sheet']+'_values']=len(actual)==len(wanted) and all(all(abs(a-b)<1e-8 if isinstance(a,(float,int)) and isinstance(b,(float,int)) else a==b for a,b in zip(aa,bb)) for aa,bb in zip(actual,wanted))
    ids=[r[0] for r in after['Q2_逐箱交付'].values if r[0] is not None][1:]
    checks['box_count']=len(ids)==80 and len(set(ids))==80
    assert all(checks.values()),checks
    dump(OUT/'workbook_validation.json',dict(passed=True,checks=checks));before.close();after.close()

def report():
    data=load();rows=read(OUT/'solution.json');v=check(rows);assert v['summary']['valid'];s=v['summary'];pool=read_pool(OUT/'route_pool.jsonl');tests=read(OUT/'tests.json');small=read(OUT/'small_exact_verification.json')
    stats=dict(total=len(pool),by_model=dict(collections.Counter(r['model'] for r in pool.values())),by_stops=dict(collections.Counter(len(r['stops']) for r in pool.values())),repeated_visit_candidates=sum(len({s for s,b in r['stops']})<len(r['stops']) for r in pool.values()),coverage={b:{g:sum(b in r['boxes'] and r['model']==g for r in pool.values()) for g in 'ABC'} for b in [b['id'] for b in data['boxes']]},complete=False)
    dump(OUT/'route_pool_stats.json',stats)
    baselines=csvrows('baselines.csv');res=csvrows('sensitivity_resources.csv');rho=csvrows('sensitivity_reserve.csv');stress=read(OUT/'stress_tests.json');trade=csvrows('tradeoffs.csv');lb=read(OUT/'global_lower_bounds.json')
    text=[f'# 第二问：方案审核、模型、求解与验证\n\n正式结果已通过独立事件检查。本文仅研究无通信条件下的第二问。\n\n## 1. 结果先读\n\n80箱（758 kg、2011 L）各交付一次，31箱硬截止均满足；期望时间达标率{s["on_time_rate"]:.1%}，加权迟到D={s["D"]:.3f}。全部任务完成时间{s["Cmax"]:.3f} s（{s["Cmax"]/60:.3f} min），总运输能耗{s["E"]:.6f} kWh，共{s["N"]}架次。A/B/C架次为{s["by_model"].get("A",0)}/{s["by_model"].get("B",0)}/{s["by_model"].get("C",0)}；其中{s["multi_stop_sorties"]}个多点架次，最长{s["max_stops"]}站。最低返航SOC为{s["min_SOC"]:.6%}，最小硬时限裕量{s["min_hard_slack"]:.3f} s。\n\n无人机峰值占用{s["aircraft_peak"]}，电池峰值占用{s["battery_peak"]}，均不超过原库存。完工是最后返航，不包含最后一次补电。\n\n**D=0达到全问题显然下界，证明全部及时性目标最优。Cmax、能耗和架次没有原问题全局最优证书，报告的是已经验证的最好可行解。**\n',
    '## 2. 对Pro方案的审核与改进\n\n主框架正确，硬截止、逐段剩余载荷、两阶段充电和双资源长区间均与原题相符。修正了附件排版损坏的硬截止、覆盖及能耗分母公式。逐箱基础交接后串行处理、准备开始占用满电电池为显式补充假设。第一问的分区独立性、18架次下界和A型不用均不推广到第二问。\n\n实现中保留80个真实箱号，优化每站交付顺序；120对无向地形航段均用5m完整接触像元与1m GEOS相交复算，未更改Q1公共物理或原输入。飞行成本有地形影响，不使用未经证明的三角不等式或直返能耗剪枝。\n\n求解升级：保留可行方案进行保守网格热启动；先联合重选重排，再针对末班任务、重载机与相邻地区开展局部重组。局部模型仍允许全部既定任务重新安排时间，避免把其他无人机时序完全锁死。重复访问在数据结构及探测候选中支持，站数上限是搜索限制而非题设。\n',
    '## 3. 模型口径\n\n1. 架次由O01准备装载开始S，占用同型飞机直到R；电池占用至R+χ。初始14组均满电，不增加充电工位约束。\n2. 每段按剩余载荷计算 Euse·d/L(q)+(m0+q)·9.81·h/(η·3.6e6)；返程空载，每次服务区投送后重新爬升。下降和交接不添加未经题设参数支持的耗电。\n3. 逐箱完成C=S+到达偏移+基础交接+每箱处理×次序；31个硬箱按医疗期望与首批截止取适用最小值。\n4. 两阶段充电χ(s)按附录2，在SOC=90%连续；B型SOC30%需1880秒。\n5. 覆盖约束Σ(r:b∈B_r)x_r=1；三个机型分别设置飞机和电池两个累计容量。半开区间，同刻先释放后占用。\n6. 目标分层为加权迟到D→完工Cmax→能耗E→架次N。前层未证最优时后层维持不劣于当前前层值，称分层启发式，不冒称严格全局词典序最优。\n\n同型同质、单基地、满电共享、并行充电且无独立换电时间下，按开始时刻给飞机短区间和电池长区间分别着色即可恢复实体编号，与聚合容量等价。固定这两套资源次序后，S=max(0,前机返航,前电池充满)给出连续时间最早安排，逐箱完成不增加。\n',
    f'## 4. 数值与证书范围\n\n当前累计保存{len(pool)}条候选；站数分布{stats["by_stops"]}，含重复到访的候选{stats["repeated_visit_candidates"]}条。候选池未穷尽80箱组合与全部路线，因此CP的bound只适用于其当次池与整数网格。\n\n主网格0.1秒；按每条航段向上取整后累加到站及返航，充电单独上取整。最终固定路线还运行0.01秒核查，并按未舍入时长连续紧化。能耗目标单位1e-6 kWh，系数四舍五入；最多80架次的总系数误差界4e-5 kWh。物理能量可行性使用未舍入值。\n\n全问题通用下界：D≥0，N≥10，Cmax≥{lb["Cmax"]:.3f} s。该Cmax界为逐箱、逐型的有向最短飞行路径放松，忽略能耗和资源，比较松，不能据此宣称接近全局最优。各次求解状态、目标、界、时间和线程数在对应solver_evidence.json；UNKNOWN表示预算内未找到新解，保留并重新验证既有方案，不视为不可行。\n',
    '## 5. 路线与具体执行安排\n\n|架次|飞机|电池|访问顺序|箱数|准备开始/s|返航/s|能耗/kWh|\n|---|---|---|---|---:|---:|---:|---:|']
    for r in rows:text.append(f'|{r["sortie"]}|{r["aircraft"]}|{r["battery"]}|'+ '→'.join(s for s,bs in r['route']['stops'])+f'|{len(r["route"]["boxes"])}|{r["start"]:.3f}|{r["return"]:.3f}|{r["route"]["energy"]:.6f}|')
    text+=['\n全部逐箱交付与截止值见deliveries.csv，完整载荷和爬升/巡航/下降事件见leg_events.csv，两个资源时间表分别见aircraft_timeline.csv和battery_timeline.csv。电池编号为程序创建的追踪号，不冒称来自附件的原始逐组编号。\n',
    '## 6. 同约束对照\n\n|方案|状态|加权迟到|完工/min|能耗/kWh|架次|\n|---|---|---:|---:|---:|---:|']
    for b in baselines:
        good=b.get('valid')=='True';text.append(f'|{b["name"]}|'+('可行' if good else b.get('status','不可行'))+('|'+'|'.join([f'{float(b["D"]):.3f}',f'{float(b["Cmax"])/60:.3f}',f'{float(b["E"]):.6f}',b['N']]) if good else '|—|—|—|—')+'|')
    text+=['\n固定Q1的18个批次和机型后，被证明无法满足Q2硬时限。单点联合模型允许重新组批和选机型，属于正确可比基线；多点贪心先构造完整分配再由同一调度器安排时间。主方法与单点结果之差包含有限预算搜索质量差异，不能全部解释为已经证明的多点理论收益。候选扩充的运行轨迹见convergence.json和local_convergence.json；没有实现自适应算子权重，不称ALNS；没有定价子问题，不称列生成。\n',
    '## 7. 资源、安全余量与权衡\n\n情景有限预算结果，均保留原始参数以外的其余约束。增资源/降余量场景保留原可行解，避免把搜索波动误当资源负收益。情景候选采用记录的有限池并增加适合新资源的构造路线，不作为全局边际价值。\n\n|资源变化|状态|D|完工/min|能耗/kWh|架次|\n|---|---|---:|---:|---:|---:|']
    for r in res:
        good=r.get('valid')=='True';text.append(f'|{r["resource"]}({r["model"]}) {r["delta"]}|'+('可行' if good else r.get('status','未知'))+('|'+'|'.join([f'{float(r["D"]):.2f}',f'{float(r["Cmax"])/60:.3f}',f'{float(r["E"]):.4f}',r['N']]) if good else '|—|—|—|—')+'|')
    text+=['\n|安全余量|状态|D|完工/min|能耗/kWh|架次|\n|---|---|---:|---:|---:|---:|']
    for r in rho:
        good=r.get('valid')=='True';text.append(f'|{float(r["rho"]):.0%}|'+('可行' if good else r.get('status','未知'))+('|'+'|'.join([f'{float(r["D"]):.2f}',f'{float(r["Cmax"])/60:.3f}',f'{float(r["E"]):.4f}',r['N']]) if good else '|—|—|—|—')+'|')
    text+=['\n放宽完工上限以节能的有限扫描见tradeoffs.csv；它不是完整Pareto前沿。ρ只改变路线可行性阈值；固定路线的能耗、实际SOC与补电时间不会因单独改变ρ而变化。\n',
    '## 8. 压力回放\n\n以下是人为确定性压力情景，没有概率分布，不报告“95%可靠”。固定表直接回放、按原资源先后传播延迟、已知扰动后重优化分别保存。若超电，不把推迟任务解释为能够安全飞行。\n\n|情景|固定表错误数|固定表硬迟到箱数|传播后状态|重优化状态|\n|---|---:|---:|---|---|']
    for r in stress:text.append(f'|{r["scenario"]}|{r["fixed_summary"]["errors"]}|{r["fixed_summary"]["hard_violations"]}|'+('存在超电架次，不可照飞' if r['energy_infeasible_sorties'] else f'硬迟到{r["propagated_summary"]["hard_violations"]}箱')+'|'+('可行' if r['reoptimized']['valid'] else r['reoptimized']['status'])+'|')
    text += [f'\n## 9. 独立验证\n\n独立检查器直接重读原始Excel，使用已双方法核对的几何缓存，从每架次实际箱号与次序重新推导质量、体积、分段能耗、逐箱完成、资源重叠与补电。没有调用路线候选求值函数或CP求解器。\n\n{tests["passed"]}项检查通过；包含充电边界、截止字段、Q1物理回归、原输入和代码哈希，以及重复/缺失货箱、错目的地、医疗/首批迟到、跨型电池、超质量/体积/能量和资源重叠等故障注入。\n\n小实例实际为{len(small["services"])}个区、{len(small["boxes"])}箱；枚举{small["enumerated_raw"]}项原始组合，{small["feasible_candidates"]}条可行候选。在每服务区至多访问一次的明确限制下全枚举箱子子集、站序和机型，累计资源与显式编号模型均证最优，目标一致={small["same_objectives"]}。它验证模型表达，不证明大实例全局最优。另有一机两电池、两机一电池、一机一电池及末次充电晚于完工的微型资源反例。\n',
    '## 10. 文件与复现\n\n- 正式提交：结果提交_Q2.xlsx，保留Q1数据，只填Q2两表；Q3/Q4保持空白。开始时刻为准备开始。\n- 完整实体方案：solution.json；主指标：solution_summary.json；独立检查：validation.json。\n- 候选与地形：route_pool.jsonl、route_pool_stats.json、terrain_evidence_all.json、leg_geometry_all.csv。\n- 对照与情景：baselines.csv、tradeoffs.csv、sensitivity_resources.csv、sensitivity_reserve.csv、stress_tests.json。\n- 图：figures/；源码和运行入口：上级src/、run_all.py；操作说明见上级运行说明.md。\n\n多worker的CP-SAT不保证逐位相同的重优化结果；冻结输入、源码、候选、方案和独立复核支持复查。原始附件和Q1代码/结果不覆盖。没有实现有限充电器、风场、实飞标定或通信；这些不属于本次第二问题设模型。起飞时才占用电池的另一操作口径未作为主结果混用。\n',
    '## 11. 第一问审核附记\n\nPro的舍入几何复算与Q1正式结果的微小差异是几何舍入造成，不能覆盖正式数值。混合贪心节能约0.17857%，应如实表述；整体能耗+5%会使原S004架次超20%余量，说明爬升效率单一扰动稳定不等于整体鲁棒。Q1的运行证据位于问题1/results/tests.json、milp_verification.json及run_manifest.json。本次原输入与Q1源码哈希一致，未改写Q1主结果或论文。\n\n实现参考：[CP-SAT官方文档](https://developers.google.com/optimization/cp/cp_solver)、[官方调度约束说明](https://github.com/google/or-tools/blob/stable/ortools/sat/docs/scheduling.md)。题设和附件为物理、资源和时限的主依据。']
    certificate=read(OUT/'baselines/q1_fixed/continuous_infeasibility_certificate.json')
    seeds=read(OUT/'seed_stability.json');ss=[r['Cmax'] for r in seeds['results'] if r.get('valid')]
    probe=read(OUT/'long_routes_probe.json')
    text.append(f'\n## 12. 补充证据与明确的取舍\n\n固定Q1连续时间不可行证书：5个3600秒硬截止的B型架次只能用2架B型执行。至少一架执行3次，第三次准备开始不早于最短两个架次时长之和{certificate["minimum_third_job_start"]:.3f}秒；但这5个架次允许的准备开始最晚只有{certificate["latest_allowed_start_among_urgent"]:.3f}秒，产生矛盾。这不是仅由离散网格造成的不可行。\n\n同一{seeds["pool"]}条路线池、同一初始方案、同阶段预算下，3种子均找到D=0的可行解。连续重放完工时间范围{min(ss):.3f}—{max(ss):.3f}秒，均值{statistics.mean(ss):.3f}秒，样本标准差{statistics.stdev(ss):.3f}秒；见seed_stability.json。它是搜索稳定性记录，不是实飞统计置信区间。\n\n四/五站放宽探测实际评估{probe["attempts"]}项，产生{probe["feasible_unique"]}条不同可行路线，其中4站{probe["by_stops"]["4"]}条、5站{probe["by_stops"]["5"]}条；没有把三站上限当成题设。探测只取各区最轻原始货箱并使用三个确定顺序，未完整枚举所有4/5站装箱或更长路线。新求解的改进不能单独归因于长路线，最终实际选中站数以方案为准。\n\n补充的负载均衡选路仅作为可行方案种子，经真实调度器和独立检查后才可使用，放松模型不取代资源时序。最终对固定路线先保持四个指标，再以最大化最小硬截止裕量作为显式第五顺序破并列；这是有限网格中的辅助安排，没有改变“及时性→完工→能耗→架次”的主顺序。\n')
    text.append('\n|允许额外完工时间/s|实际完工/s|能耗/kWh|架次|\n|---:|---:|---:|---:|')
    for r in trade:
        if r.get('valid')=='True':text.append(f'|{r["extra_seconds"]}|{float(r["Cmax"]):.3f}|{float(r["E"]):.6f}|{r["N"]}|')
    if (OUT/'cross_scenario_consolidation.json').exists():
        con=read(OUT/'cross_scenario_consolidation.json');text.append(f'\n情景搜索也可能发现可用于原参数的新方案。已将发现的方案恢复原参数、按原库存重新复算并比较，最终收录来源为{con["source"]}。这避免把已知更好的原题可行方案遗漏在情景文件中。最终压力回放和提交表均以最后冻结方案为准。')
    text=[part.replace('证明全部及时性目标最优','证明加权迟到这一层目标全局最优') for part in text]
    text.insert(1,'正式主方案的返航安全余量统一为20%。某个更好装箱方案虽在15%情景搜索中被发现，但已恢复20%原规则重新核验，所有实际返航SOC均满足20%；没有降低主方案的安全标准。\n')
    (OUT/'第二问完整报告.md').write_text('\n'.join(text),encoding='utf-8')
    import ortools,numpy,scipy
    code={str(p.relative_to(ROOT)):sha(p) for p in [ROOT/'run_all.py']+list((ROOT/'src').glob('*.py'))+list((ROOT/'src').glob('*.mjs'))}
    outputs={str(p.relative_to(OUT)):sha(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ('run_manifest.json','python_review.json','run_summary.json')}
    dump(OUT/'run_manifest.json',dict(status='completed_with_explicit_optimality_limits',finished=datetime.datetime.now().astimezone().isoformat(),inputs=data['audit']['inputs'],code=code,results=outputs,environment=dict(python=sys.version,executable=sys.executable,platform=platform.platform(),ortools=ortools.__version__,numpy=numpy.__version__,scipy=scipy.__version__),warnings=['Cmax/E/N not certified global optimal','candidate pools incomplete','CP-SAT multithread runs not bitwise deterministic']))
    dump(OUT/'python_review.json',dict(question='Q2',checks={'syntax':dict(status='PASS',evidence='all delivered modules executed'),'input_contract':dict(status='PASS',evidence='raw workbook audit + 120 geometry pairs independently checked + Q1 hashes'),'method_alignment':dict(status='PASS',evidence='explicit assumptions; 3-region8box cumulative/explicit cross-check'),'reproducibility':dict(status='PASS',evidence='frozen inputs/code/results and independent replay; multithread search non-bitwise noted'),'output_contract':dict(status='PASS',evidence='80 deliveries, resource/event tables, template round-trip validation, actual experiment files')},verdict='PASSED_WITH_OPTIMALITY_LIMITS',final_validation=v['summary'],tests=tests['passed']))
    dump(OUT/'run_summary.json',dict(schema_version=1,question='Q2',implementation_target='python',authorization='用户明确要求审核后执行且授权自主改进',main='candidate expansion + CP-SAT dual resource scheduling',baseline='single-stop joint scheduling',metrics_summary=s,independent_validation=v['summary']['valid'],warnings=['restricted candidate heuristic; global Cmax optimality unproved'],results='results/solution_summary.json'))

if __name__=='__main__':
    {'payload':payload,'verify_workbook':verify_workbook,'report':report}[sys.argv[1] if len(sys.argv)>1 else 'report']()
