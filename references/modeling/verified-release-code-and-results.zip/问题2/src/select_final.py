import env
from env import OUT,ROOT
import sys
sys.path.insert(0,str(ROOT))
from data_io import dump
from routes import Physics,read_pool,save_pool
from master import solve
from run_all import persist
from validate import check
import json

def run():
    P=Physics();allpaths=[OUT/'solution.json']+sorted((OUT/'workload_seeds').glob('seed*/solution.json'))
    valid=[]
    for path in allpaths:
        rows=json.loads(path.read_text(encoding='utf-8'));v=check(rows)
        if v['summary']['valid']:valid.append((tuple(v['summary'][k] for k in ('D','Cmax','E','N')),path,rows))
    _,origin,best=min(valid,key=lambda v:v[0])
    # Controlled three-seed experiment: same pool, identical incumbent and budget.
    mix={r['route']['id']:r['route'] for k,p,rs in valid for r in rs};starting=best;seedstats=[]
    for seed in (0,1,2):
        result=solve(P,mix,seconds=40,seed=seed,q=.1,warm=starting,objectives=('D','C','E','N'))
        candidate=persist(P,result,OUT/f'controlled_seeds/seed{seed}')
        if candidate:
            metric=check(candidate)['summary'];kk=tuple(metric[k] for k in ('D','Cmax','E','N'));seedstats.append(dict(seed=seed,**metric,seconds=result['seconds']))
            if kk<tuple(check(best)['summary'][k] for k in ('D','Cmax','E','N')):best=candidate;origin=OUT/f'controlled_seeds/seed{seed}/solution.json'
        else:seedstats.append(dict(seed=seed,valid=False,seconds=result['seconds']))
    dump(OUT/'seed_stability.json',dict(pool=len(mix),same_initial_incumbent=True,same_stage_budget_s=40,workers=4,results=seedstats))
    res=solve(P,{r['route']['id']:r['route'] for r in best},seconds=45,q=.01,warm=best,objectives=('D','C','E','N'))
    new=persist(P,res,OUT/'selected_final_grid')
    if new:
        a=check(new)['summary'];b=check(best)['summary']
        if tuple(a[k] for k in ('D','Cmax','E','N'))<tuple(b[k] for k in ('D','Cmax','E','N')):best=new
    val=check(best,OUT);s=val['summary'];pool=read_pool(OUT/'route_pool.jsonl');pool.update({r['route']['id']:r['route'] for r in best});save_pool(pool,OUT/'route_pool.jsonl')
    dump(OUT/'solution_summary.json',dict(**s,solver_grid_objectives=res['grid_objectives'] if best is new else None,continuous_replayed_objectives={k:s[k] for k in ('D','Cmax','E','N')},independent_validation=True,candidate_pool_complete=False,time_quantum=.01 if best is new else .1,energy_quantum_kwh=1e-6,optimality_scope='D=0 global minimum; Cmax/E/N restricted-pool heuristic, not global proof',source=str(origin.relative_to(OUT))))
    dump(OUT/'final_selection.json',dict(source=str(origin.relative_to(OUT)),objective=[s[k] for k in ('D','Cmax','E','N')],candidates=[dict(path=str(p.relative_to(OUT)),objective=k) for k,p,r in valid]))

if __name__=='__main__':run()
