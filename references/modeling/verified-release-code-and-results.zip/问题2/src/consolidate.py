"""Retain any experimentally discovered solution that is better under the original rules."""
import env
from env import OUT,ROOT
import sys,json,copy,csv
sys.path.insert(0,str(ROOT))
from routes import Physics,read_pool,save_pool
from validate import check
from data_io import dump,table
P=Physics();base=json.loads((OUT/'solution.json').read_text(encoding='utf-8'));best=base;best_s=check(base)['summary'];source='existing main';considered=[]
paths=sorted((OUT/'sensitivity').glob('*/solution.json'))+sorted((OUT/'stress').glob('*/reoptimized/solution.json'))
for path in paths:
    rs=json.loads(path.read_text(encoding='utf-8'));readyU={};readyB={};rebuilt=[];eligible=True
    for row in sorted(rs,key=lambda r:(r['start'],r['sortie'])):
        r=copy.deepcopy(row);g=r['route']['model']
        if r['aircraft'] not in P.data['aircraft'] or r['battery'] not in {f'{g}-BAT-{i:02d}' for i in range(1,P.data['K'][g]+1)}:eligible=False;break
        route=P.evaluate(g,r['route']['stops'])
        if route is None:eligible=False;break
        r['route']=route;r['start']=max(readyU.get(r['aircraft'],0),readyB.get(r['battery'],0));r['return']=r['start']+route['duration'];r['battery_ready']=r['return']+route['charge'];readyU[r['aircraft']]=r['return'];readyB[r['battery']]=r['battery_ready'];rebuilt.append(r)
    if not eligible:continue
    val=check(rebuilt);s=val['summary']
    if not s['valid']:continue
    considered.append(dict(path=str(path.relative_to(OUT)),objective=[s[k] for k in ('D','Cmax','E','N')]))
    if tuple(round(s[k],6) for k in ('D','Cmax','E','N'))<tuple(round(best_s[k],6) for k in ('D','Cmax','E','N')):best=rebuilt;best_s=s;source=str(path.relative_to(OUT))
if source!='existing main':
    check(best,OUT);dump(OUT/'solution_summary.json',dict(**best_s,solver_grid_objectives=None,continuous_replayed_objectives={k:best_s[k] for k in ('D','Cmax','E','N')},independent_validation=True,candidate_pool_complete=False,time_quantum=.1,energy_quantum_kwh=1e-6,optimality_scope='Best feasible after original-parameter replay of scenario discoveries; no global Cmax/E/N proof',source=source))
pool=read_pool(OUT/'route_pool.jsonl');pool.update({r['route']['id']:r['route'] for r in best});save_pool(pool,OUT/'route_pool.jsonl')
dump(OUT/'cross_scenario_consolidation.json',dict(source=source,considered=considered,improved=source!='existing main',original=check(base)['summary'],final=best_s))
print('CONSOLIDATION',source,best_s,flush=True)
