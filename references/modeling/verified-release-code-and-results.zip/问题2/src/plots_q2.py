import env
from env import OUT
from prepare import load
from data_io import dump,sha
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

def rows(name):
    with (OUT/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def make():
    data=load();solution=json.loads((OUT/'solution.json').read_text(encoding='utf-8'));sorties=rows('sorties.csv');deliv=rows('deliveries.csv');figdir=OUT/'figures';figdir.mkdir(exist_ok=True)
    colors={'A':'#4477AA','B':'#228833','C':'#CC6677'};manifest=[]
    plt.rcParams.update({'font.family':['Microsoft YaHei','DejaVu Sans'],'axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    def save(fig,name,sources):
        for suffix in ('png','pdf','svg'):fig.savefig(figdir/f'{name}.{suffix}',dpi=200)
        manifest.append(dict(name=name,sources={s:sha(OUT/s) for s in sources},width_inches=fig.get_size_inches().tolist(),formats=['PNG200dpi','PDF','SVG']))
        plt.close(fig)
    # DEM is displayed as raster cells, with common bounds/color scale across types.
    fig,axes=plt.subplots(1,3,figsize=(16,6),layout='constrained')
    nodes=data['nodes'];xmin=min(n['lon'] for n in nodes.values())-.01;xmax=max(n['lon'] for n in nodes.values())+.01;ymin=min(n['lat'] for n in nodes.values())-.009;ymax=max(n['lat'] for n in nodes.values())+.009
    for ax,g in zip(axes,'ABC'):
        im=ax.imshow(data['dem'],extent=(data['lon'][0],data['lon'][-1],data['lat'][-1],data['lat'][0]),cmap='Greys',origin='upper',vmin=0,vmax=900,interpolation='nearest',alpha=.65)
        for r in solution:
            if r['route']['model']!=g:continue
            ids=['O01']+[s for s,_ in r['route']['stops']]+['O01'];xy=[(nodes[n]['lon'],nodes[n]['lat']) for n in ids]
            ax.plot(*zip(*xy),color=colors[g],alpha=.5,lw=1.1)
            for a,b in zip(xy,xy[1:]):ax.annotate('',xy=(.6*a[0]+.4*b[0],.6*a[1]+.4*b[1]),xytext=(.65*a[0]+.35*b[0],.65*a[1]+.35*b[1]),arrowprops=dict(arrowstyle='->',lw=.8,color=colors[g]))
        for n,v in nodes.items():
            ax.scatter(v['lon'],v['lat'],s=50 if n=='O01' else 16,c='black',marker='*' if n=='O01' else 'o',zorder=5)
            ax.annotate(n,(v['lon'],v['lat']),xytext=(3,3),textcoords='offset points',fontsize=8)
        ax.set(xlim=(xmin,xmax),ylim=(ymin,ymax),xlabel='经度 / °',ylabel='纬度 / °',title=f'{g}型运输路线')
        ax.set_aspect(1/np.cos(np.deg2rad(23)))
    fig.colorbar(im,ax=axes,shrink=.65,label='DEM高程 / m');save(fig,'多点运输路线',['solution.json','terrain_evidence_all.json'])
    fig,ax=plt.subplots(figsize=(12,5),layout='constrained');aircraft=sorted(data['aircraft'])
    for r in sorties:
        y=aircraft.index(r['aircraft']);s=float(r['start'])/60;t=float(r['takeoff'])/60;e=float(r['return_s'])/60;c=colors[r['model']]
        ax.barh(y,t-s,left=s,height=.63,color='white',edgecolor=c,hatch='////',linewidth=.8)
        ax.barh(y,e-t,left=t,height=.63,color=c,alpha=.86)
        ax.text((s+e)/2,y,r['sortie'].split('-')[1],ha='center',va='center',fontsize=8,color='black')
    ax.set(yticks=range(8),yticklabels=aircraft,xlabel='任务开始后时间 / min',title='无人机准备、执行与返航时序（标签为架次编号）');ax.invert_yaxis();ax.grid(axis='x',alpha=.2)
    ax.legend(handles=[Patch(facecolor='white',edgecolor='gray',hatch='////',label='准备与装载')]+[Patch(color=colors[g],label=f'{g}型飞行与交接') for g in 'ABC'],loc='upper center',bbox_to_anchor=(.5,-.13),ncol=4)
    save(fig,'无人机甘特图',['sorties.csv'])
    fig,ax=plt.subplots(figsize=(12,7),layout='constrained');bids=[f'{g}-BAT-{i:02d}' for g in 'ABC' for i in range(1,data['K'][g]+1)]
    for r in sorties:
        y=bids.index(r['battery']);s=float(r['start'])/60;e=float(r['return_s'])/60;c=float(r['battery_ready'])/60
        ax.barh(y,e-s,left=s,height=.65,color=colors[r['model']]);ax.barh(y,c-e,left=e,height=.65,color='#DDDDDD',edgecolor='#888888',hatch='///',lw=.5)
        ax.text((s+e)/2,y,r['sortie'].split('-')[1],ha='center',va='center',fontsize=7)
    for r in rows('battery_timeline.csv'):
        if r['next_use'] and float(r['full_wait'])>0:ax.barh(bids.index(r['battery']),float(r['full_wait'])/60,left=float(r['charging_end'])/60,height=.65,color='#F2E5BA',edgecolor='#AA9944',lw=.5)
    C=max(float(r['return_s']) for r in sorties)/60;ax.axvline(C,color='black',ls='--',lw=1,label='任务完工（最后返航）')
    ax.set(yticks=range(len(bids)),yticklabels=bids,xlabel='任务开始后时间 / min',title='14组共享电池的执行、补电与满电等待');ax.invert_yaxis();ax.grid(axis='x',alpha=.2)
    ax.legend(handles=[Patch(color='#4477AA',label='任务占用（颜色对应机型）'),Patch(facecolor='#DDDDDD',hatch='///',label='补电'),Patch(color='#F2E5BA',label='两任务间满电等待'),plt.Line2D([0],[0],color='black',ls='--',label='最后返航')],loc='upper center',bbox_to_anchor=(.5,-.08),ncol=4)
    save(fig,'共享电池甘特图',['sorties.csv','battery_timeline.csv'])
    hard=sorted([d for d in deliv if d['hard_due']],key=lambda d:(float(d['hard_due']),d['box']))
    fig,ax=plt.subplots(figsize=(11,9),layout='constrained')
    for y,d in enumerate(hard):
        C=float(d['complete'])/60;due=float(d['hard_due'])/60
        ax.plot([C,due],[y,y],color='#BBBBBB',lw=1)
    ax.scatter([float(d['complete'])/60 for d in hard],range(len(hard)),c='#4477AA',s=25,label='实际完成');ax.scatter([float(d['hard_due'])/60 for d in hard],range(len(hard)),c='#AA3377',marker='|',s=130,label='硬截止')
    ax.set(yticks=range(len(hard)),yticklabels=[d['box'] for d in hard],xlabel='任务开始后时间 / min',title='31个硬时限货箱的交付与截止');ax.invert_yaxis();ax.set_xlim(left=0);ax.grid(axis='x',alpha=.2);ax.legend(loc='upper right');save(fig,'硬时限逐箱核查',['deliveries.csv'])
    baselines=rows('baselines.csv');valid=[r for r in baselines if r.get('valid')=='True'];labels={'single_stop':'单点联合调度','multi_greedy':'多点贪心＋调度','expanded_joint':'多点扩充联合优化','q1_fixed':'固定Q1组批'}
    fig,axes=plt.subplots(1,2,figsize=(11,4.6),layout='constrained')
    for ax,field,unit in [(axes[0],'Cmax','完工时间 / min'),(axes[1],'E','运输能耗 / kWh')]:
        vals=[float(r[field])/(60 if field=='Cmax' else 1) for r in valid];bars=ax.bar(range(len(valid)),vals,color=['#88AADD','#DDCC77','#66AA88'][:len(valid)])
        ax.set(xticks=range(len(valid)),xticklabels=[labels[r['name']] for r in valid],ylabel=unit,ylim=(0,max(vals)*1.15));ax.tick_params(axis='x',labelsize=9)
        ax.bar_label(bars,fmt='%.2f',padding=3);ax.grid(axis='y',alpha=.2)
    fig.suptitle('同一资源与硬约束下的方案对照；固定Q1方案不可行');save(fig,'主要方案对照',['baselines.csv'])
    if (OUT/'sensitivity_reserve.csv').exists():
        rr=rows('sensitivity_reserve.csv');ok=[r for r in rr if r.get('valid')=='True']
        fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
        for ax,key,unit in [(axes[0],'Cmax','完工时间 / min'),(axes[1],'E','能耗 / kWh')]:
            ax.plot([float(r['rho'])*100 for r in ok],[float(r[key])/(60 if key=='Cmax' else 1) for r in ok],marker='o',color='#4477AA');ax.set(xlabel='返航安全余量 / %',ylabel=unit);ax.grid(alpha=.2)
        fig.suptitle('有限候选与运行预算下的安全余量情景');save(fig,'安全余量敏感性',['sensitivity_reserve.csv'])
    dump(figdir/'figure_manifest.json',dict(audience='研究生数模竞赛论文与复核',method='all figures use saved validated result files; no manual number transcription; DEM nearest pixel display; no statistical confidence intervals',figures=manifest))

if __name__=='__main__':make()
