import env
from env import OUT,PROJECT
import sys
sys.path.insert(0,str(env.ROOT))
from run_all import persist,warm_rows
from routes import Physics,read_pool,save_pool,expand,greedy_construct,add
from master import solve
from validate import check
from data_io import dump,table
from collections import Counter
import json,copy,math,random
import numpy as np
from scipy.sparse.csgraph import shortest_path

def read(path):return json.loads(path.read_text(encoding='utf-8'))

def run_case(name,P,pool,warm=None,M=None,K=None,seconds=30,fixed_D=None,max_C=None,objectives=('D','C','E','N')):
    # Scenario runs use a documented bounded pool; retain incumbent plus all
    # singleton coverage and a deterministic mix of efficient and random routes.
    if len(pool)>1400:
        candidates=sorted(pool.values(),key=lambda r:r['id']);rng=random.Random(2026)
        active={r['id']:r for r in candidates if len(r['boxes'])==1}
        for r in sorted(candidates,key=lambda r:r['duration']/len(r['boxes']))[:350]:add(active,r)
        for r in sorted(candidates,key=lambda r:r['energy']/len(r['boxes']))[:250]:add(active,r)
        for r in rng.sample(candidates,min(500,len(candidates))):add(active,r)
        if warm:
            for v in warm:
                if v['route']['id'] in pool:add(active,pool[v['route']['id']])
        pool=active
    if warm is None and len(pool)>100:
        seedpool={}
        for seed in range(16):
            constructed,extra=greedy_construct(P,seed,3)
            if constructed:seedpool.update(extra)
        if seedpool:
            pres=solve(P,seedpool,seconds=12,q=.1,M=M,K=K,workers=2,objectives=('D','C'))
            # Always independent validation before using a heuristic as an incumbent.
            kwargs=dict(rho=P.rho,energy_scale=P.es,flight_scale=P.fs,horizontal_scale=P.hs)
            if M:kwargs['M']=M
            if K:kwargs['K']=K
            warm=persist(P,pres,OUT/name/'seed',**kwargs)
            pool.update(seedpool)
    (OUT/name).mkdir(exist_ok=True,parents=True)
    save_pool(pool,OUT/name/'scenario_pool.jsonl')
    res=solve(P,pool,seconds=seconds,q=.1,seed=2026,warm=warm,M=M,K=K,fixed_D=fixed_D,max_C=max_C,objectives=objectives,workers=2)
    kwargs=dict(rho=P.rho,energy_scale=P.es,flight_scale=P.fs,horizontal_scale=P.hs)
    if M:kwargs['M']=M
    if K:kwargs['K']=K
    rows=persist(P,res,OUT/name,**kwargs);retained=False
    if rows is None and warm and check(warm,**kwargs)['summary']['valid']:
        rows=warm;check(rows,OUT/name,**kwargs);retained=True
    summary=check(rows,**kwargs)['summary'] if rows else {'valid':False,'D':None,'Cmax':None,'E':None,'N':None}
    status=res['evidence'][-1]['status'] if res['evidence'] else 'no_stage'
    report=dict(name=name,**summary,status='RETAINED_VALID_INCUMBENT' if retained else status,search_status=status,pool=len(pool))
    if retained:dump(OUT/name/'solution_summary.json',dict(**report,solver_grid_objectives=None,candidate_pool_complete=False))
    return report,rows

def q1_fixed():
    P=Physics();pool={}
    for b in read(PROJECT/'问题1/results/batches.json'):add(pool,P.evaluate(b['model'],[(b['service'],b['boxes'])]))
    assert len(pool)==18
    row,sol=run_case('baselines/q1_fixed',P,pool,seconds=45)
    urgent=[r for r in pool.values() if r['model']=='B' and any(P.boxes[b]['hard_due']==3600 for b in r['boxes'])]
    lengths=sorted(r['duration'] for r in urgent);latest=max(r['max_start'] for r in urgent)
    certificate=dict(urgent_B_routes=len(urgent),B_aircraft=P.data['M']['B'],minimum_third_job_start=sum(lengths[:2]),latest_allowed_start_among_urgent=latest,contradiction=len(urgent)>2*P.data['M']['B'] and sum(lengths[:2])>latest,proof='5 early-deadline B sorties on2B aircraft force at least3 on one aircraft. Earliest third preparation is at least the sum of the two shortest durations, larger than every allowed start. This is a continuous-time pigeonhole certificate.',routes=[dict(id=r['id'],service=r['stops'][0][0],duration=r['duration'],max_start=r['max_start']) for r in urgent])
    dump(OUT/'baselines/q1_fixed/continuous_infeasibility_certificate.json',certificate)
    return row

def greedy_baseline():
    P=Physics();constructed=[]
    for seed in range(30):
        rs,_=greedy_construct(P,seed,3)
        if not rs:continue
        tard=0
        for v in rs:
            r=v['route'];m=P.models[r['model']]
            for j,(_,bs) in enumerate(r['stops']):
                order=sorted(bs,key=lambda b:(P.boxes[b]['hard_due'] or P.boxes[b]['expected_s'],-P.boxes[b]['priority']))
                for k,b in enumerate(order,1):
                    C=v['start']+r['arrivals'][j]+m['handover']+m['handover_box']*k
                    tard+=P.boxes[b]['priority']*max(0,C-P.boxes[b]['expected_s'])
        constructed.append((tard,max(v['start']+v['route']['duration'] for v in rs),rs,seed))
    _,_,rs,seed=min(constructed,key=lambda v:v[:2])
    row,sol=run_case('baselines/multi_greedy',P,{v['route']['id']:v['route'] for v in rs},seconds=30)
    dump(OUT/'baselines/multi_greedy/construction.json',dict(seed=seed,attempted_seeds=30,complete_constructs=len(constructed),selection='construction weighted tardiness then makespan; fixed partition and types passed to same scheduler'))
    return row

def rebuilt(P,source):
    pool={}
    for r in source.values():add(pool,P.evaluate(r['model'],r['stops']))
    for seed in range(4):
        _,p=greedy_construct(P,seed,4);pool.update(p)
    return pool

def sensitivity():
    P=Physics();base=read(OUT/'solution.json');allpool=read_pool(OUT/'route_pool.jsonl');result=[]
    # Select type with greatest aircraft busy-time / (count * makespan).
    s=check(base)['summary'];loads={g:sum(r['route']['duration'] for r in base if r['route']['model']==g)/(P.data['M'][g]*s['Cmax']) for g in P.models}
    critical=max(loads,key=loads.get)
    dump(OUT/'resource_bottleneck.json',dict(aircraft_utilization=loads,selected_type=critical,criterion='largest aircraft workload / fleet capacity makespan'))
    for resource in ('M','K'):
        for delta in (-1,1):
            M=P.data['M'].copy();K=P.data['K'].copy();(M if resource=='M' else K)[critical]+=delta
            # Extra route generation uses changed resources, not only original inventory.
            Pc=Physics();Pc.data['M']=M;Pc.data['K']=K;pool=dict(allpool)
            for seed in range(6):
                _,extra=greedy_construct(Pc,seed,4);pool.update(extra)
            warm=base if delta>0 else None
            row,rows=run_case(f'sensitivity/{resource}_{critical}_{delta:+d}',Pc,pool,warm=warm,M=M,K=K,seconds=45)
            if delta>0 and (not rows or tuple(row[k] for k in ('D','Cmax','E','N'))>tuple(s[k] for k in ('D','Cmax','E','N'))):
                val=check(base,OUT/f'sensitivity/{resource}_{critical}_{delta:+d}/retained_incumbent',M=M,K=K)
                row.update(val['summary']);row['retained_base_incumbent']=True
            result.append(dict(resource=resource,model=critical,delta=delta,**row));table(OUT/'sensitivity_resources.csv',result)
    reserves=[]
    for rho in (.15,.2,.25,.3):
        if rho==.2:reserves.append(dict(rho=rho,**s));continue
        Pc=Physics(rho=rho);pool=rebuilt(Pc,allpool);warm=base if all(r['route']['id'] in pool for r in base) else None
        row,rows=run_case(f'sensitivity/reserve_{rho:.2f}',Pc,pool,warm=warm,seconds=45)
        if rho<.2 and (not rows or tuple(row[k] for k in ('D','Cmax','E','N'))>tuple(s[k] for k in ('D','Cmax','E','N'))):
            val=check(base,OUT/f'sensitivity/reserve_{rho:.2f}/retained_incumbent',rho=rho);row.update(val['summary']);row['retained_base_incumbent']=True
        reserves.append(dict(rho=rho,**row));table(OUT/'sensitivity_reserve.csv',reserves)

def stress(reoptimize=True):
    base=read(OUT/'solution.json');source=read_pool(OUT/'route_pool.jsonl');results=[]
    previous={r['scenario']:r for r in read(OUT/'stress_tests.json')} if not reoptimize else {}
    for name,kw in [('horizontal_plus5',dict(horizontal_scale=1.05)),('horizontal_plus10',dict(horizontal_scale=1.10)),('energy_plus5',dict(energy_scale=1.05)),('flight_plus5',dict(flight_scale=1.05)),('flight_plus10',dict(flight_scale=1.10))]:
        P=Physics(**kw);fixed=check(base,compare_reported=False,**kw);prop=copy.deepcopy(base);readyU={};readyB={};infeasible=[]
        # Fixed actual resource order; only start-time delays are propagated.
        for r in sorted(prop,key=lambda v:(v['start'],v['sortie'])):
            rr=P.evaluate(r['route']['model'],r['route']['stops'],screen=False)
            if rr is None:infeasible.append(r['sortie']);continue
            r['route']=rr;r['start']=max(r['start'],readyU.get(r['aircraft'],0),readyB.get(r['battery'],0));r['return']=r['start']+rr['duration'];r['battery_ready']=r['return']+rr['charge']
            readyU[r['aircraft']]=r['return'];readyB[r['battery']]=r['battery_ready']
        propagated=None if infeasible else check(prop,**kw)
        path=OUT/'stress'/name;dump(path/'fixed_replay.json',fixed)
        dump(path/'propagated_replay.json',dict(safe_to_execute=not infeasible,energy_infeasible_sorties=infeasible,result=propagated))
        if reoptimize:
            pool=rebuilt(P,source);warm=prop if not infeasible and propagated['summary']['valid'] else None
            row,rows=run_case(f'stress/{name}/reoptimized',P,pool,warm=warm,seconds=40)
        else:
            row=previous[name]['reoptimized'];rows=read(OUT/f'stress/{name}/reoptimized/solution.json');assert check(rows,**kw)['summary']['valid']
        results.append(dict(scenario=name,parameters=kw,fixed_summary=fixed['summary'],fixed_violation_types=dict(Counter(e['code'] for e in fixed['errors'])),propagated_summary=None if propagated is None else propagated['summary'],energy_infeasible_sorties=infeasible,reoptimized=row))
        dump(OUT/'stress_tests.json',results)

def tradeoffs():
    P=Physics();base=read(OUT/'solution.json');s=check(base)['summary'];pool=read_pool(OUT/'route_pool.jsonl');rows=[dict(extra_seconds=0,**s)]
    for extra in (60,180,300):
        alternatives=[base]
        for p in [OUT/'selected_final_grid/solution.json']+list((OUT/'controlled_seeds').glob('seed*/solution.json')):
            if p.exists():
                rr=read(p);ss=check(rr)['summary']
                if ss['valid'] and ss['D']<=s['D'] and ss['Cmax']<=s['Cmax']+extra:alternatives.append(rr)
        warm=min(alternatives,key=lambda rr:sum(r['route']['energy'] for r in rr))
        row,sol=run_case(f'tradeoffs/extra_{extra}',P,pool,warm=warm,seconds=40,fixed_D=s['D'],max_C=s['Cmax']+extra,objectives=('E','N'))
        rows.append(dict(extra_seconds=extra,**row));table(OUT/'tradeoffs.csv',rows)

def bounds():
    P=Physics();nodes=sorted(P.data['nodes']);idx={s:i for i,s in enumerate(nodes)};dist={}
    for g in P.models:
        a=np.zeros((16,16))
        for (typ,i,j),(t,d,h) in P.legs.items():
            if typ==g:a[idx[i],idx[j]]=t
        dist[g]=shortest_path(a,directed=True)
    lb=[]
    for b in P.boxes.values():
        vals=[]
        for g,m in P.models.items():
            if b['weight']<=m['Q'] and b['volume_L']<=m['volume_L']:
                vals.append(m['prep']+m['load']+dist[g][idx['O01'],idx[b['service']]]+m['handover']+m['handover_box']+dist[g][idx[b['service']],idx['O01']])
        lb.append(dict(box=b['id'],lower_bound=min(vals)))
    dump(OUT/'global_lower_bounds.json',dict(D=0,N=10,Cmax=max(x['lower_bound'] for x in lb),box_witness=max(lb,key=lambda x:x['lower_bound']),Cmax_derivation='max_b min_feasible_type [single-box prep + shortest directed flight out + one handover + shortest flight home]; ignores intermediate handovers, energy and finite resources; valid but weak',box_bounds=lb))

def comparisons():
    rows=[]
    for name in ('q1_fixed','single_stop','multi_greedy'):
        path=OUT/'baselines'/name/'validation.json'
        if path.exists():rows.append(dict(name=name,**read(path)['summary']))
        else:
            ev=read(OUT/'baselines'/name/'solver_evidence.json');rows.append(dict(name=name,valid=False,status=ev['evidence'][-1]['status']))
    rows.append(dict(name='expanded_joint',**read(OUT/'validation.json')['summary']));table(OUT/'baselines.csv',rows)

if __name__=='__main__':
    task=sys.argv[1] if len(sys.argv)>1 else 'q1'
    {'q1':q1_fixed,'greedy':greedy_baseline,'sensitivity':sensitivity,'stress':stress,'stress_replay':lambda:stress(False),'tradeoffs':tradeoffs,'bounds':bounds,'comparisons':comparisons}[task]()
