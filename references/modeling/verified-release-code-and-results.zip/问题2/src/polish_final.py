import env
from env import OUT,ROOT
import sys,json
sys.path.insert(0,str(ROOT))
from routes import Physics
from master import solve
from run_all import persist
from validate import check
from data_io import dump
P=Physics();base=json.loads((OUT/'solution.json').read_text(encoding='utf-8'))
res=solve(P,{v['route']['id']:v['route'] for v in base},seconds=30,q=.01,warm=base,objectives=('D','C','E','N','H'))
rows=persist(P,res,OUT/'final_slack_tie_break')
a=check(rows)['summary'];b=check(base)['summary']
if tuple(round(a[k],6) for k in ('D','Cmax','E','N'))<=tuple(round(b[k],6) for k in ('D','Cmax','E','N')):
    check(rows,OUT);summary=json.loads((OUT/'final_slack_tie_break/solution_summary.json').read_text(encoding='utf-8'));summary['optimality_scope']='D=0 global; other objectives restricted-pool heuristic. H=-minimum hard slack is an explicitly declared fifth tie-break, only after the four policy objectives.'
    summary['source']='final_slack_tie_break/solution.json';dump(OUT/'solution_summary.json',summary)
ass=json.loads((OUT/'assumptions.json').read_text(encoding='utf-8'));ass['final_schedule_tie_break']='For fixed selected routes, after D,Cmax,E,N, maximize min hard-deadline slack on0.01s grid; not a substitute for the four objectives.';dump(OUT/'assumptions.json',ass)
