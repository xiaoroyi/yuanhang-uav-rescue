import env
from env import OUT,PROJECT
from data_io import dump,sha
from routes import Physics,charge,add
from master import solve,decode,grid_route
from validate import check
from prepare import load
from ortools.sat.python import cp_model as cp
import itertools,json,copy,math

def run():
    P=Physics();tests=[]
    def record(name,condition,evidence=None):
        assert condition,(name,evidence)
        tests.append(dict(name=name,passed=True,evidence=evidence))
    for g,T in P.data['Tfull'].items():
        record('charge endpoints '+g,all(abs(charge(s,T)-want)<1e-8 for s,want in [(0,T),(.9,.35*T),(1,0)]))
        record('charge monotone '+g,all(charge(i/100,T)>=charge((i+1)/100,T)-1e-8 for i in range(100)))
    record('B SOC30% recharge1880',abs(charge(.3,2400)-1880)<1e-8)
    def mini(M,K):
        mod=cp.CpModel();s=[mod.new_int_var(0,100,'s'+str(i)) for i in range(2)];e=[mod.new_int_var(0,100,'e'+str(i)) for i in range(2)];b=[mod.new_int_var(0,100,'b'+str(i)) for i in range(2)]
        ui=[mod.new_interval_var(s[i],10,e[i],'u'+str(i)) for i in range(2)];bi=[mod.new_interval_var(s[i],30,b[i],'b'+str(i)) for i in range(2)]
        mod.add_cumulative(ui,[1,1],M);mod.add_cumulative(bi,[1,1],K);c=mod.new_int_var(0,100,'c');mod.add_max_equality(c,e);mod.minimize(c)
        sol=cp.CpSolver();status=sol.solve(mod);return status,sol.value(c),max(sol.value(v) for v in b)
    for M,K,want in [(1,2,20),(2,1,40),(1,1,40),(2,2,10)]:
        status,c,last=mini(M,K);record(f'dual resource {M}U {K}B',status==cp.OPTIMAL and c==want and last>c,dict(Cmax=c,last_charge=last))
    # Independent closed-form brute force for two jobs: all assignments and orderings.
    record('synthetic exhaustive result',mini(1,2)[1]==min(max(10,s+10) for s in range(101) if s>=10),20)
    for b,want in [('S001-MED-02',3600),('S012-MED-01',3600),('S014-MED-01',3600),('S001-WAT-02',None)]:record('deadline '+b,P.boxes[b]['hard_due']==want)
    manifest=json.loads((PROJECT/'问题1/results/run_manifest.json').read_text(encoding='utf-8'))
    record('Q1 code unchanged',all(sha(PROJECT/'问题1'/p)==h for p,h in manifest['code'].items()))
    for name,h in manifest['inputs'].items():record('input hash '+name.split('\\')[-1],sha(name)==h)
    # Q1 direct-trip equivalence for every published batch, independent model pathway.
    for b in json.loads((PROJECT/'问题1/results/batches.json').read_text(encoding='utf-8')):
        r=P.evaluate(b['model'],[(b['service'],b['boxes'])]);record('Q1 energy/time '+b['batch'],r is not None and abs(r['energy']-b['E'])<1e-10 and abs(r['duration']-b['T'])<1e-9)
    rows_path=OUT/'solution.json'
    if not rows_path.exists():rows_path=OUT/'initial_feasible/solution.json'
    rows=json.loads(rows_path.read_text(encoding='utf-8'));data=load()
    record('independent baseline replay',check(rows,data=data)['summary']['valid'])
    def fault(name,mutate,expected):
        altered=copy.deepcopy(rows);mutate(altered);result=check(altered,data=data);codes={e['code'] for e in result['errors']};record('fault '+name,expected in codes,sorted(codes))
    fault('duplicate sortie',lambda r:r.append(copy.deepcopy(r[0])),'coverage')
    fault('missing sortie',lambda r:r.pop(),'coverage')
    fault('wrong destination',lambda r:r[0]['route']['stops'][0].__setitem__(0,'S015' if r[0]['route']['stops'][0][0]!='S015' else 'S014'),'wrong_destination')
    medidx=next(i for i,r in enumerate(rows) if any(P.boxes[b]['category']=='MED' for b in r['route']['boxes']))
    fault('medical late',lambda r:r[medidx].__setitem__('start',20000),'hard_deadline')
    firstidx=next(i for i,r in enumerate(rows) if any(P.boxes[b]['first'] for b in r['route']['boxes']))
    fault('first late',lambda r:r[firstidx].__setitem__('start',20000),'hard_deadline')
    fault('cross type battery',lambda r:r[0].__setitem__('battery','Z-BAT-01'),'battery_type_or_id')
    fault('energy tampered',lambda r:r[0]['route'].__setitem__('energy',0),'energy_value')
    def overlap(rs,field):
        i,j=next((i,j) for i in range(len(rs)) for j in range(i+1,len(rs)) if rs[i]['route']['model']==rs[j]['route']['model'])
        rs[j][field]=rs[i][field];rs[j]['start']=rs[i]['start']
    fault('aircraft overlap',lambda r:overlap(r,'aircraft'),'aircraft_overlap')
    fault('battery overlap/unfilled',lambda r:overlap(r,'battery'),'battery_overlap')
    # Actual parameter injection independently exercises physical rather than cached coefficients.
    d=copy.deepcopy(data);d['models'][rows[0]['route']['model']]['Q']=1
    record('fault over mass',any(e['code']=='over_mass' for e in check(rows,data=d)['errors']))
    d=copy.deepcopy(data);d['models'][rows[0]['route']['model']]['volume_L']=1
    record('fault over volume',any(e['code']=='over_volume' for e in check(rows,data=d)['errors']))
    record('fault energy reserve',any(e['code']=='energy_reserve' for e in check(rows,data=data,energy_scale=3)['errors']))
    # Explicit witness that terrain flight cost cannot safely use Euclidean triangle pruning.
    record('nonmetric synthetic witness',1000>100+100,dict(direct_cost=1000,via_task_cost=200))
    dump(OUT/'tests.json',dict(passed=len(tests),failed=0,tests=tests))
    print('TESTS PASSED',len(tests),flush=True)

def small():
    P=Physics();ids=[b for s,n in [('S002',3),('S007',3),('S010',2)] for b in sorted(b for b in P.boxes if P.boxes[b]['service']==s)[:n]];assert len(ids)==8
    assert len({P.boxes[b]['service'] for b in ids})==3
    pool={};tested=0
    # Complete subsets and all service permutations, within one visit per service restriction.
    for mask in range(1,1<<len(ids)):
        bs=[b for i,b in enumerate(ids) if mask>>i&1];nodes=sorted(set(P.boxes[b]['service'] for b in bs))
        for order in itertools.permutations(nodes):
            stops=[(s,[b for b in bs if P.boxes[b]['service']==s]) for s in order]
            for typ in P.models:tested+=1;add(pool,P.evaluate(typ,stops))
    results=[]
    for explicit in (False,True):
        res=solve(P,pool,seconds=90,seed=42,q=1.,objectives=('D','C','E','N'),explicit=explicit,workers=1,box_ids=ids)
        rows=decode(P,res);val=check(rows,subset=ids);assert val['summary']['valid'],val
        dump(OUT/f'small_exact_{explicit}.json',dict(solver={k:v for k,v in res.items() if k!='selected'},validation=val,solution=rows))
        results.append(res)
    equal=results[0]['grid_objectives']==results[1]['grid_objectives']
    optimal=all(e['status']=='OPTIMAL' or e['stage']=='D' and e['objective']==0 for r in results for e in r['evidence'])
    dump(OUT/'small_exact_verification.json',dict(boxes=ids,services=sorted(set(P.boxes[b]['service'] for b in ids)),enumerated_raw=tested,feasible_candidates=len(pool),candidate_scope='all nonempty subsets, all permutations of distinct visited services, all3types; no repeated service visits in this small verification',same_objectives=equal,both_proved_optimal=optimal,objectives=[r['grid_objectives'] for r in results]))
    assert equal and optimal

if __name__=='__main__':
    import sys
    small() if '--small' in sys.argv else run()
