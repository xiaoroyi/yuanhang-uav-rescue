"""Workload-balanced route selections, only heuristic seeds for the real scheduler."""
import env
from env import OUT,ROOT
import sys
sys.path.insert(0,str(ROOT))
from run_all import persist
from routes import Physics,read_pool
from master import solve
from data_io import dump
from ortools.sat.python import cp_model as cp
import random,math

def run():
    P=Physics();pool=read_pool(OUT/'route_pool.jsonl');rs=list(pool.values())
    for seed in range(5):
        rng=random.Random(300+seed);mod=cp.CpModel();xs=[mod.new_bool_var(f'x{i}') for i in range(len(rs))];W=mod.new_int_var(0,100000,'workload')
        for b in P.boxes:mod.add(sum(x for r,x in zip(rs,xs) if b in r['boxes'])==1)
        for g in 'ABC':
            mod.add(sum(math.ceil(r['duration'])*x for r,x in zip(rs,xs) if r['model']==g)<=P.data['M'][g]*W)
            mod.add(sum(math.ceil(r['duration']+r['charge'])*x for r,x in zip(rs,xs) if r['model']==g)<=P.data['K'][g]*(W+math.ceil(max(r['charge'] for r in rs if r['model']==g))))
            for t in (1800,2400,3000,3600,4800,7200):
                for kind in ('M','K'):
                    mod.add(sum(math.floor(min(r['duration']+(r['charge'] if kind=='K' else 0),max(0,t-r['max_start'])))*x for r,x in zip(rs,xs) if r['model']==g and r['max_start'] is not None)<=P.data[kind][g]*t)
        mod.minimize(W*10000+sum(int(r['energy']*(100+200*rng.random()))*x for r,x in zip(rs,xs)))
        solver=cp.CpSolver();solver.parameters.max_time_in_seconds=18;solver.parameters.num_search_workers=2;solver.parameters.random_seed=seed
        status=solver.solve(mod);evidence=dict(status=solver.status_name(status),objective=solver.objective_value,bound=solver.best_objective_bound,wall_time=solver.wall_time)
        dump(OUT/f'workload_seeds/seed{seed}/workload_relaxation.json',evidence)
        if status not in (cp.OPTIMAL,cp.FEASIBLE):continue
        selected={r['id']:r for r,x in zip(rs,xs) if solver.value(x)}
        print('WORKLOAD',seed,'bound proxy',solver.value(W),'sorties',len(selected),flush=True)
        res=solve(P,selected,seconds=15,seed=seed,workers=2,objectives=('D','C','E','N'))
        persist(P,res,OUT/f'workload_seeds/seed{seed}')

if __name__=='__main__':run()
