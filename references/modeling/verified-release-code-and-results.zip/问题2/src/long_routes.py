"""Explicitly test relaxing the initial three-stop candidate-search limit."""
import env
from env import OUT,ROOT
import sys
sys.path.insert(0,str(ROOT))
from routes import Physics,read_pool,save_pool,add
from run_all import persist
from master import solve
from validate import check
from data_io import dump
import json,itertools

def run():
    P=Physics();best=json.loads((OUT/'solution.json').read_text(encoding='utf-8'));pool=read_pool(OUT/'route_pool.jsonl');probe={};attempts=0
    services=sorted({b['service'] for b in P.boxes.values()});smallest={s:min((b for b in P.boxes.values() if b['service']==s),key=lambda b:(b['weight'],b['volume_L'],b['id']))['id'] for s in services}
    for n in (4,5):
        for nodes in itertools.combinations(services,n):
            # Multiple deterministic nearest-neighbor and deadline orders; not full n! enumeration.
            order=[];rest=set(nodes);last='O01'
            while rest:
                nxt=min(rest,key=lambda s:(P.geo[last,s][0],s));order.append(nxt);rest.remove(nxt);last=nxt
            choices=[order,list(reversed(order)),sorted(nodes,key=lambda s:(P.boxes[smallest[s]]['hard_due'] or P.boxes[smallest[s]]['expected_s'],s))]
            for order in choices:
                for g in 'ABC':attempts+=1;add(probe,P.evaluate(g,[(s,[smallest[s]]) for s in order]))
    active={r['route']['id']:r['route'] for r in best}
    # Preserve normal alternatives so a longer route can replace selected boxes without leaving gaps.
    involved={b for r in probe.values() for b in r['boxes']}
    for r in pool.values():
        if len(r['boxes'])==1 or any(set(r['boxes'])<set(v['route']['boxes']) for v in best):add(active,r)
    for r in sorted(probe.values(),key=lambda r:r['duration']/len(r['boxes']))[:180]:add(active,r)
    pool.update(probe);save_pool(pool,OUT/'route_pool.jsonl');save_pool(active,OUT/'long_routes_pool.jsonl')
    result=solve(P,active,seconds=45,warm=best,objectives=('D','C','E','N'))
    rows=persist(P,result,OUT/'long_routes_check');s=check(best)['summary'];improved=False
    if rows:
        ss=check(rows)['summary']
        if tuple(ss[k] for k in ('D','Cmax','E','N'))<tuple(s[k] for k in ('D','Cmax','E','N')):
            best=rows;check(best,OUT);s=ss;improved=True
            dump(OUT/'solution_summary.json',dict(**s,solver_grid_objectives=result['grid_objectives'],continuous_replayed_objectives={k:s[k] for k in ('D','Cmax','E','N')},independent_validation=True,candidate_pool_complete=False,time_quantum=.1,energy_quantum_kwh=1e-6,optimality_scope='D=0 global lower bound; Cmax/E/N not globally proved',source='long_routes_check/solution.json'))
    dump(OUT/'long_routes_probe.json',dict(attempts=attempts,feasible_unique=len(probe),by_stops={n:sum(len(r['stops'])==n for r in probe.values()) for n in (4,5)},master_pool=len(active),improved=improved,complete=False,restriction='one smallest original box per visited service; three deterministic orderings per4/5-node subset; top180long candidates in master, others retained as search evidence'))

if __name__=='__main__':run()
