"""Targeted restricted-master neighborhoods, retaining all incumbent routes."""
import env
from env import OUT
import sys
sys.path.insert(0,str(env.ROOT))
from run_all import persist,warm_rows
from routes import Physics,read_pool,save_pool,add,expand
from master import solve
from validate import check
from data_io import dump
import json,random,itertools,time

def score(rows):
    s=check(rows)['summary'];return tuple(s[k] for k in ('D','Cmax','E','N'))

def run(rounds=10):
    P=Physics();best=json.loads((OUT/'solution.json').read_text(encoding='utf-8'));pool=read_pool(OUT/'route_pool.jsonl');rng=random.Random(2026);history=[]
    for step in range(rounds):
        ordered=sorted(best,key=lambda r:r['return'],reverse=True)
        # Alternate late-return, C workload and geographical neighborhoods.
        anchor=ordered[step%min(8,len(ordered))]
        if step%3==1:anchor=rng.choice([r for r in best if r['route']['model']=='C'])
        anchor_nodes=[s for s,_ in anchor['route']['stops']]
        near=sorted([r for r in best if r is not anchor],key=lambda r:min(0 if a==b else P.geo[a,b][0] for a in anchor_nodes for b,_ in r['route']['stops']))
        chosen=[anchor]+near[:3];ids=set(b for r in chosen for b in r['route']['boxes'])
        if len(ids)>18:chosen=chosen[:3];ids=set(b for r in chosen for b in r['route']['boxes'])
        # Complete existing candidates on local box set, with all other routes fixed by coverage.
        restricted={r['id']:r for r in pool.values() if set(r['boxes'])<=ids}
        for row in best:add(restricted,row['route'])
        nodes=sorted({P.boxes[b]['service'] for b in ids});listids=sorted(ids)
        masks=list(range(1,1<<len(ids))) if len(ids)<=9 else sorted({rng.randrange(1,1<<len(ids)) for _ in range(900)})
        for mask in masks:
            bs=[b for i,b in enumerate(listids) if mask>>i&1];vis=sorted({P.boxes[b]['service'] for b in bs})
            if len(vis)>5:continue
            orders=list(itertools.permutations(vis)) if len(vis)<=3 else [tuple(vis),tuple(reversed(vis))]
            for order in orders:
                st=[(s,[b for b in bs if P.boxes[b]['service']==s]) for s in order]
                for g in P.models:add(restricted,P.evaluate(g,st))
        expand(P,restricted,chosen,seed=step+700,limit=350)
        pool.update(restricted)
        print('LOCAL',step,'boxes',len(ids),'routes',len(restricted),flush=True)
        res=solve(P,restricted,seconds=50,seed=1000+step,warm=best,workers=4,objectives=('D','C','E','N'))
        candidate=persist(P,res,OUT/f'local/round{step}')
        if candidate and score(candidate)<score(best):best=candidate
        val=check(best,OUT);assert val['summary']['valid']
        dump(OUT/'solution_summary.json',dict(**val['summary'],solver_grid_objectives=res['grid_objectives'] if best is candidate else None,continuous_replayed_objectives={k:val['summary'][k] for k in ('D','Cmax','E','N')},candidate_pool_complete=False,time_quantum=.1,energy_quantum_kwh=1e-6,optimality_scope='Timeliness D=0 global; other objectives best feasible restricted candidate/neighbor search, no global optimality proof'))
        history.append(dict(round=step,local_boxes=len(ids),candidates=len(restricted),best=score(best),solver_seconds=res['seconds']));dump(OUT/'local_convergence.json',history);save_pool(pool,OUT/'route_pool.jsonl')
    # Fine-grid final chosen-route reoptimization; primary published plan chosen by exact replay.
    res=solve(P,{r['route']['id']:r['route'] for r in best},seconds=60,q=.01,warm=best,workers=4,objectives=('D','C','E','N'))
    rows=persist(P,res,OUT/'fine_grid_final')
    if rows and score(rows)<score(best):best=rows
    val=check(best,OUT)
    dump(OUT/'solution_summary.json',dict(**val['summary'],solver_grid_objectives=res['grid_objectives'] if best is rows else None,continuous_replayed_objectives={k:val['summary'][k] for k in ('D','Cmax','E','N')},candidate_pool_complete=False,time_quantum=.01 if best is rows else .1,energy_quantum_kwh=1e-6,optimality_scope='D=0 globally minimal; restricted candidate pool, fixed-resource continuous retiming; Cmax/E/N global optimality not proved'))

if __name__=='__main__':run(int(sys.argv[1]) if len(sys.argv)>1 else 10)
